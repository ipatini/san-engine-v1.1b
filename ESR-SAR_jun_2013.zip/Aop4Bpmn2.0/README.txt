WorkToken is an open source BPMN 2 engine written in Java.

WorkToken serves as a lightweight container for annotated POJOs that represent BPMN elements, such as user tasks or receive message events.

Project web site: www.worktoken.com