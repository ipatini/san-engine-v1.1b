
Place these file in the public directory of a web-server

Modify 'aop4bpmn2_async+action-pools.configuration.txt' file to reflect the correct URLs and paths.
