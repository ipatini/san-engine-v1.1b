/*
 * ++++++++++++++++++
 */

package example.advise;

import com.worktoken.model.Connector;
import com.worktoken.model.WorkToken;

import javax.swing.JOptionPane;
import javax.persistence.Entity;

@Entity 
public class AdviseBefore extends com.worktoken.model.UserTask {
    public void tokenIn(WorkToken token, Connector connector) {
		java.util.Date time = new java.util.Date();
		JOptionPane.showConfirmDialog(null, "ADVISE BEFORE:  Hurry up lad. The boss is angry!!!\n"+
											"Now is "+time+" and time is running out!!!");
		token.getData().put("advise.startTime", time);
        tokenOut(token);
    }
}
