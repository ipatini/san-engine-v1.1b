/*
 * ++++++++++++++++++
 */

package example.advise;

import com.worktoken.model.Connector;
import com.worktoken.model.WorkToken;

import javax.swing.JOptionPane;

public class AdviseAfter extends com.worktoken.model.UserTask {
    public void tokenIn(WorkToken token, Connector connector) {
		java.util.Date startTime = (java.util.Date) token.getData().get("advise.startTime");
		java.util.Date endTime = new java.util.Date();
		long diff = Math.abs(endTime.getTime()-startTime.getTime())/1000;
		token.getData().remove("advise.startTime");
		if (diff>10)
			JOptionPane.showConfirmDialog(null, "ADVISE AFTER:  You're late!!! AGAIN...  Boss is angry with you");
		else
			JOptionPane.showConfirmDialog(null, "ADVISE AFTER:  Well done lad. You made it in time :)");
        tokenOut(token);
    }
}
