/*
 * Copyright (c) 2011. Rush Project Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package example;

import com.worktoken.adapt.AdaptDialog;

import com.worktoken.annotation.FlowElement;
import com.worktoken.model.Connector;
import com.worktoken.model.UserTask;
import com.worktoken.model.WorkToken;

import javax.persistence.Entity;

import java.awt.event.*;
import javax.swing.JPanel;
import javax.swing.JOptionPane;

/**
 * @author Alex Pavlov (alex@rushproject.com)
 */
@FlowElement(nodeRef = "", processId = "")
@Entity
public class RunTest extends UserTask {
	protected String message;
	
    @Override
    public void tokenIn(WorkToken token, Connector connector) {
/*		System.out.println("User task \"" + getSubject() + "\" (" + getDefId()+"/"+getId() +
                           " @ " + getProcess().getDefId()+"/"+getProcess().getId() +
						   ") is ready. Description: " + getDocumentation());
		for (String s : token.getData().keySet()) {
			System.out.println("\t"+s+" = "+token.getData().get(s));
		}*/
		
		Thread runner = new Thread(new Runnable() {
			public void run() {
				String text = null;
				do {
					text = (String)JOptionPane.showInputDialog(new JPanel(),
						"User task: \"" + getMessage() + "\" (subject: "+getSubject()+")\n"+
						"Node:          "+ getDefId()+" (id: "+getId() +")\n"+
						"Process:    " + getProcess().getDefId()+" (id: "+getProcess().getId() +")\n\n",
						"Task: "+getDefId(),		// title
						JOptionPane.QUESTION_MESSAGE,
						new javax.swing.ImageIcon(getClass().getResource("/images/play.png")),
						null,
						getDocumentation()
					);
				} while (text==null || text.trim().equals(""));
				complete(text);
			}
		});
		runner.start();
    }

    public void complete(String notes) {
        System.out.println(message+" OK: "+notes);
        WorkToken token = new WorkToken();
        token.getData().put("notes", notes);
        tokenOut(token);
    }
	
	public String getMessage() {
		return message;
	}
}
