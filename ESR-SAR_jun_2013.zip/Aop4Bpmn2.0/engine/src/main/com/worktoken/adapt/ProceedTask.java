/*
 * ++++++
 */

package com.worktoken.adapt;

import com.worktoken.annotation.FlowElement;
import com.worktoken.model.Connector;
import com.worktoken.model.ScriptTask;
import com.worktoken.model.WorkToken;

import javax.persistence.Entity;

/**
 * @author ipatini
 */
@Entity
public class ProceedTask extends ScriptTask {
    @Override
    public void tokenIn(WorkToken token, Connector connector) {
		tokenOut(token);
    }
}
