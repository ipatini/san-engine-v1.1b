/*
 * ++++++++++++++
 */

package com.worktoken.adapt;				// XXX: AOP

import com.worktoken.engine.*;				// XXX: AOP
import com.worktoken.model.PathSocket;
import com.worktoken.model.*;
import org.omg.spec.bpmn._20100524.di.BPMNDiagram;
import org.omg.spec.bpmn._20100524.model.*;
import org.omg.spec.dd._20100524.dc.Bounds;
import org.omg.spec.dd._20100524.di.Diagram;
//import sun.plugin2.message.ShutdownJVMMessage;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import java.io.InputStream;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.*;
import java.util.concurrent.*;


/**
 * @author ipatini
 */

public class AdaptWorkSessionImpl implements AdaptWorkSession, Callable<String> {

    private String sessionId;
    private String engineId;	// XXX: AOP

    // persistence stuff
    private EntityManagerFactory emf;
    private ThreadLocal<EntityManager> em;
    private ThreadLocal<Integer> acquireCounter;

    // runner thread stuff
    private ExecutorService executor;
    private Future<String> future;
    private volatile boolean cancelled;
    private LinkedBlockingQueue<WorkItem> workItems;
    private static long TriggerPollCycle = 60000L;
    private long lastTriggerPollTime = 0L;

    // Concurrent tasks
    private Map<Long, Future<String>> activeTasks;

    // BPMN stuff
    private ThreadLocal<Boolean> tokenOut;
    private AdaptAnnotationDictionary dictionary;				// XXX: AOP
    private HashMap<String, TDefinitions> definitionsMap;
    private HashMap<String, ProcessDefinition> processDefinitions;
    private HashMap<String, MessageDefinition> messageDefinitions;
    private long threadId;
    private boolean shutdown;
	
	private Properties engineProperties;		// XXX: extension
	
// XXX: AOP - BEGIN
	// Adaptation vars
	protected boolean adaptationActive = true;
	protected AdaptControlServiceFactory acsFactory;
	
	// Workflow events vars
	protected boolean sendWorkflowEvents = true;
	
	// =========================================================================================== Adaptation methods
	public boolean isAdaptationActive() {
		return adaptationActive;
	}
	
	public void setAdaptationActive(boolean flag) {
        if (isRunning()) {
            throw new IllegalStateException("Call to setAdaptationActive() for an already running WorkSession");
        }
		adaptationActive = flag;
	}
	
	// =========================================================================================== Workflow Events methods
	public boolean isSendingWorkflowEvents() {
		return sendWorkflowEvents;
	}
	
	public void setSendingWorkflowEvents(boolean flag) {
        if (isRunning()) {
            throw new IllegalStateException("Call to setSendingWorkflowEvents() for an already running WorkSession");
        }
		sendWorkflowEvents = flag;
	}
	
	public String getEngineId() {
		return engineId;
	}
	
// XXX: AOP - END

    // =========================================================================================== AdaptWorkSessionImpl

    public AdaptWorkSessionImpl(/* XXX: extension */ Properties engineProperties, /* XXX: AOP */ String engineId, String id, EntityManagerFactory emf, /* XXX: AOP */ AdaptControlServiceFactory acsf, AdaptAnnotationDictionary dictionary, /* XXX: AOP */ Vector<String> aspectDefinitions) {
        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("Null or missing session id in AdaptWorkSessionImpl constructor");
        }
        if (AdaptSessionRegistry.getSession(id) != null) {
            throw new IllegalArgumentException("Duplicate session id in AdaptWorkSessionImpl constructor");
        }
        if (emf == null) {
            throw new IllegalArgumentException("Null EntityManagerFactory in AdaptWorkSessionImpl constructor");
        }
        this.emf = emf;
		this.engineId = engineId;	// XXX: AOP
        this.sessionId = id;
		this.acsFactory = acsf;		// XXX: AOP
        if (dictionary != null) {
            this.dictionary = dictionary;
        } else {
            dictionary = new AdaptAnnotationDictionary() {		// XXX: AOP
                @Override
                public void build() {
                }
            };
            dictionary.setScanned(true);
        }
        AdaptSessionRegistry.addSession(this);
        workItems = new LinkedBlockingQueue<WorkItem>();
        executor = Executors.newCachedThreadPool();
        em = new ThreadLocal<EntityManager>();
        acquireCounter = new ThreadLocal<Integer>();
        tokenOut = new ThreadLocal<Boolean>();
        activeTasks = new HashMap<Long, Future<String>>();
		
		// XXX: AOP
		AOP.processAspectDefinitions(this, aspectDefinitions);
		
		// XXX: extension  - node instantiation modes
		this.engineProperties = engineProperties;
		initInstantiationModes();
    }
	
// XXX: extension  - node instantiation modes
public String getEngineProperty(String key) {
	return engineProperties.getProperty(key);
}

   // =========================================================================================================== SessionListener methods
	
// XXX: extension: 2012-08-07:  Session listeners - BEGIN
protected Hashtable<SessionListener,Object> sessionListeners;

public void addSessionListener(SessionListener l) {
	if (sessionListeners==null) sessionListeners = new Hashtable<SessionListener,Object>();
	sessionListeners.put(l, l);
}

public void removeSessionListener(SessionListener l) {
	if (sessionListeners==null) return;
	sessionListeners.remove(l);
}

protected void fireSessionClosing() {
	if (sessionListeners==null) return;
	Hashtable<SessionListener,Object> tmp = null;
	synchronized (sessionListeners) {
		tmp = (Hashtable<SessionListener,Object>)sessionListeners.clone();
	}
	for (SessionListener l : tmp.keySet()) {
		l.sessionClosing();
	}
}

protected void fireSessionClosed() {
	if (sessionListeners==null) return;
	Hashtable<SessionListener,Object> tmp = null;
	synchronized (sessionListeners) {
		tmp = (Hashtable<SessionListener,Object>)sessionListeners.clone();
	}
	for (SessionListener l : tmp.keySet()) {
		l.sessionClosed();
	}
}

// XXX: extension: 2012-08-07:  Session listeners - END
	
   // =========================================================================================================== start

    @Override
    public void start() {
        if (isRunning()) {
            throw new IllegalStateException("Call to start() for already running WorkSession");
        }
        /*
        Recreate all incomplete service tasks
         */
        acquireEntityManager();
        List<ServiceTask> serviceTasks = em.get().createNamedQuery("ServiceTask.findAll").getResultList();
        for (ServiceTask node : serviceTasks) {
            if (node instanceof Callable) {
                if (activeTasks.containsKey(node.getId())) {
                    throw new IllegalStateException("Multiple tasks with id:" + node.getId());
                }
                activeTasks.put(node.getId(), executor.submit((Callable<String>)node));
            }
        }
        releaseEntityManager();
        /*
        Start runner thread
         */
        future = executor.submit(this);
    }
    // =========================================================================================================== getId

    @Override
    public String getId() {
        return sessionId;
    }

    // ============================================================================================================ call

    @Override
    public String call() {
        boolean interrupted = false;
        threadId = Thread.currentThread().getId();
        while (!cancelled) {
            WorkItem workItem = null;
            try {
                workItem = workItems.poll(500, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                cancelled = true;
                interrupted = true;
            }
            if (workItem != null) {
                acquireEntityManager();

                BusinessProcess process = em.get().find(BusinessProcess.class, workItem.getProcessInstanceId());
                if (process == null) {
                    releaseEntityManager();
                    throw new IllegalStateException("Process does not exist (id=" + workItem.getProcessInstanceId() + ")");
                }

                beginTransaction();

// XXX: AOP - BEGIN
boolean skipProcessing = false;
AOP aop = null;
if (adaptationActive && (AOP.getAdaptationMode()!=AOP.AdaptationMode.INACTIVE)) {
	String advise = null;
	try {
		// SOS: This updates current path/flow info and returns associated AOP instance
		aop = AOP.getInstance(this, process, workItem);
		// SOS: If no instance exists we create a new one
		if (aop==null) {
			aop = AOP.createInstance(acsFactory.getController(), this, process, workItem);
//System.out.println("---> NEW-AOP : ID="+aop.getId()+"    PATH: "+AOP.getCurrPath(this, workItem));
//System.out.println("---> PATHS : "+AOP.getAllPaths());
		}
		
		if (workItem instanceof TokenForNode) {
			assert(aop!=null);
			TokenForNode t4n = (TokenForNode) workItem;
			Node node = findOrCreateNode(t4n.getNodeDef(), process);
			
			AOP.State state = aop.getAdaptationState();
//System.out.println("---> AOP-ID : "+aop.getId()+"    PATH: "+AOP.getCurrPath(this, workItem));
//System.out.println("---> "+state+" NODE = "+process.getDefId()+"/"+process.getId()+"/"+node.getDefId()+"/"+node.getId() + "  CONNECTOR = "+t4n.getConnector().getId());

			// IF A NORMAL PROCESS
			if (aop.isNormalProcess(process)) {
				if ( state==AOP.State.INIT ) {
					// We are in normal process context, before task execution
					// Now it's time to check if adaptation is needed
					// This call will take work item out of flow and query Adaptation Controller
					// Upon A/C response AOP management will decide whether to put work item back
					// to flow or keep it off-line and start an adaptation process
					if (aop.queryPointcut(t4n, node, process)) {
						// Adaptation Controller has been queried
						// Skip the subsequent work item processing
						skipProcessing = true;
					}
					// else: current node is not a Task
				} else if ( state==AOP.State.EXECUTE ) {
					// No adaptation. Just reset state and execute task
					aop.resetAdaptationState();
registerExecutingTask(t4n, node, process);
				} else if ( state==AOP.State.PROCEED ) {
					// mark proceed task as being executed
					aop.proceeding(t4n, node, process);
				} else if ( state==AOP.State.PROCEEDING ) {
					// switch context to adaptation process, then execute task
					aop.switchToAdaptationProcess(t4n, node, process);
					skipProcessing = true;
				} else if ( state==AOP.State.ADAPT ) {
					// THIS STATE SHOULD NEVER OCCUR IN A NORMAL PROCESS
					throw new RuntimeException("AdaptWorkSessionImpl: call: AOP BUG!!! ENCOUNTERED 'ADAPT' STATE IN NORMAL PROCESS CONTEXT!!!");
				} else {
					throw new RuntimeException("AdaptWorkSessionImpl: call: Invalid Adaptation state for a normal process: "+state);
				}
			} else
			// IF AN ADAPTATION PROCESS
			if (aop.isAdaptationProcess(process)) {
				if ( state==AOP.State.INIT ) {
					// init adaptation state
					aop.initAdaptationState(t4n, node, process);
					skipProcessing = true;		// Forces an extra iteration in order to print state tracing info
				} else if ( state==AOP.State.ADAPT ) {
					// update adaptation state
					aop.updateState(t4n, node, process);
					aop.resetAdaptationState();
					
					// if proceed task, then mark this instance as PROCEED
					if (node instanceof ProceedTask) {
						aop.markProceed();
					}
				} else if ( state==AOP.State.PROCEED ) {
					// proceed task (in adaptation context) has been executed,
					// switch context back to normal process
					aop.switchToNormalProcess(t4n, node, process);
					skipProcessing = true;
				} else {
					throw new RuntimeException("AdaptWorkSessionImpl: call: Invalid Adaptation state for an adaptation process: "+state);
				}
			}
		}
	} catch (Exception e) {
		markRollbackTransaction();
		commitTransaction();
		releaseEntityManager();
		System.err.println("Failed to handle interaction with advise process '"+advise+"' on node. Reason: " + e);
		e.printStackTrace();
		throw new IllegalStateException("Failed to handle interaction with advise process '"+advise+"' on node. Reason: " + e);
	}
}
if (skipProcessing) {
	;
} else
// XXX: AOP - END
				if (workItem instanceof TokenForNode) {
                    TokenForNode t4n = (TokenForNode) workItem;
                    Node node = null;	// XXX: AOP - { = null }
                    try {
                        node = findOrCreateNode(t4n.getNodeDef(), process);
// XXX: AOP - Send ACTIVITY START event
if (sendWorkflowEvents) { AOP.getInstance(this, process).sendWorkflowEvent(AOP.WFE.ACTIVITY_START, node); }
                        node.tokenIn(t4n.getToken(), t4n.getConnector());
                        if (node instanceof Callable) {
                            if (activeTasks.containsKey(node.getId())) {
                                throw new IllegalStateException("Multiple tasks with id:" + node.getId());
                            }
                            activeTasks.put(node.getId(), executor.submit((Callable<String>)node));
                        }
                    } catch (Exception e) {
// XXX: AOP - Send ACTIVITY EXCEPTION event
if (sendWorkflowEvents) { AOP.getInstance(this, process).sendWorkflowEvent(AOP.WFE.ACTIVITY_EXCEPTION, node, e); }
                        markRollbackTransaction();
                        commitTransaction();
                        releaseEntityManager();
                        e.printStackTrace();
                        throw new IllegalStateException("Failed to process target node, " + e);
                    }
                    boolean endProcess = false;
                    if (isEndEvent(t4n.getNodeDef())) {
                        endProcess = processEndEvent(node, process);
                    }
                    if (endProcess) {
// XXX: AOP BEGIN
AOP.removePath(this, workItem);

if (adaptationActive && aop!=null) {
	if (aop.isAdaptationProcess(process)) {
		aop.endAdaptation();
	}
}
// XXX: AOP END
// XXX: AOP - Send PROCESS END event
if (sendWorkflowEvents) { AOP.getInstance(this, process).sendWorkflowEvent(AOP.WFE.PROCESS_END, process); }
                        em.get().remove(process);
                    }
                } else if (workItem instanceof TokenFromNode) {
                    try {
                        handleTokenFromNode((TokenFromNode) workItem);
                    } catch (Exception e) {
                        markRollbackTransaction();
                        commitTransaction();
                        releaseEntityManager();
                        e.printStackTrace();
                        throw new IllegalStateException("Failed to process outgoing token from node id=" + ((TokenFromNode) workItem).getNodeId() + ", " + e);
                    }
                } else if (workItem instanceof EventIn) {
                    try {
                        handleEventToken((EventIn) workItem);
                    } catch (Exception e) {
                        markRollbackTransaction();
                        commitTransaction();
                        releaseEntityManager();
                        e.printStackTrace();
                        throw new IllegalStateException("Failed to process event id=" + ((EventIn) workItem).getEventToken().getDefinitionId() + ", " + e);
                    }
                }
                commitTransaction();
                releaseEntityManager();
            } else if (shutdown) {   // exit loop if session is in shutdown mode and queue is empty
                break;
            }
            fireTimers();
        }
        if (interrupted) {
            Thread.currentThread().interrupt();
        }
// XXX: AOP - Clean AOP if needed (stop DSB endpoints)
AOP.cleanup();
        return null;
    }
	
	// XXX: AOP ============================================================================================== insertWorkItem
	
	public void insertWorkItem(WorkItem item) {
		workItems.add(item);
	}

	// XXX: AOP ============================================================================================== reg/unreg/interrupt executing tasks
	
protected String getNodeKey(Node node, BusinessProcess process) {
	return this.getId()+"-"+process.getDefId()+"-"+process.getId()+"-"+node.getDefId()+"-"+node.getId();
}

protected Hashtable<String,Object[]> runningTasks = new Hashtable<String,Object[]>();
protected Hashtable<String,Object> interruptedTasks = new Hashtable<String,Object>();

protected void registerExecutingTask(TokenForNode t4n, Node node, BusinessProcess process) {
	String key = getNodeKey(node, process);
	Object[] arr = new Object[3];
	arr[0] = t4n; arr[1] = node; arr[2] = process;
	runningTasks.put(key, arr);
}

protected boolean unregisterExecutingTask(WorkToken token, Node node, Connector connector) {
	String key = getNodeKey(node, node.getProcess());
	Object[] arr = runningTasks.remove(key);
	Object obj = interruptedTasks.remove(key);
	boolean rr = (obj!=null);
// 2013-02-08: extension for executing AFTER ADVISE right after task completion
	AOP aop = AOP.getInstance(this, node.getProcess(), node, connector, token);
	if (rr) aop.taskInterrupted(token, node, connector);
// 2013-02-08: extension for executing AFTER ADVISE right after task completion
	else return ! aop.executeAfterAdaptation(this, token, node, connector);
	return !rr;
}

public boolean interruptExecutingTask(String procDef, long procId, String nodeDef, long nodeId) {
	if (procDef==null || procDef.isEmpty() || procDef.equals("*") || procId<0 || 
	    nodeDef==null || nodeDef.isEmpty() || nodeDef.equals("*") || nodeId<0)
	{
		System.err.println("** Invalid task reference: Cannot interrupt task: "+procDef+":"+procId+" / "+nodeDef+":"+nodeId);
		return false;
	}
	if (runningTasks==null) {
		System.err.println("** No running tasks: Cannot interrupt task: "+procDef+":"+procId+" / "+nodeDef+":"+nodeId);
		return false;
	}
	
	String key = this.getId()+"-"+procDef+"-"+procId+"-"+nodeDef+"-"+nodeId;
	// remove task from running tasks list
	Object[] arr = runningTasks.remove(key);
	if (arr==null) {
		System.err.println("** Task is not running: Cannot interrupt task: "+procDef+":"+procId+" / "+nodeDef+":"+nodeId);
		return false;
	}
	TokenForNode t4n = (TokenForNode)arr[0];
	Node node = (Node)arr[1];
	BusinessProcess process = (BusinessProcess)arr[2];
	if (t4n==null || node==null || process==null) {
		throw new RuntimeException("BUG!!!  Running task info array contains nulls. Running task : "+procDef+":"+procId+" / "+nodeDef+":"+nodeId+
									".  Array: { t4n="+t4n+", node="+node+", process="+process+" }");
	}
	System.out.println("** Interrupting running task: "+procDef+":"+procId+" / "+nodeDef+":"+nodeId+" at session: "+getId());
	
	// If possible, interrupt running task (i.e. task implements Interruptible interface)
	if (node instanceof org.iccs.worktoken.model.Interruptible) {
		interruptedTasks.put(key, this);
		if (((org.iccs.worktoken.model.Interruptible)node).interrupt(null)) {
			System.out.println("** Task interrupted: "+procDef+":"+procId+" / "+nodeDef+":"+nodeId+" at session: "+getId());
			return true;
		} else {
			interruptedTasks.remove(key);
			System.out.println("** Failed to interrupt task: "+procDef+":"+procId+" / "+nodeDef+":"+nodeId+" at session: "+getId());
			return false;
		}
	} else {
//		System.err.println("** Task being interrupted is not interruptible. Trying to bypass it...");
		System.err.println("** Task cannot be interrupted : Task is not interruptible : \n" +
		                   "   i.e. does not implement 'org.iccs.worktoken.model.Interruptible' interface");
		return false;
	}
	
/*	// continue process execution from the next point if possible
	List<TFlowNode> next = BPMNUtils.findNext(node.getDefinition(), process.getDefinition());
	if (next.size()==0) {
		System.err.println("** No next node defined for task: Cannot interrupt task: "+procDef+":"+procId+" / "+nodeDef+":"+nodeId);
		return false;
	}
	if (next.size()>1) {
		System.err.println("** Many next nodes defined for task: Cannot interrupt task: "+procDef+":"+procId+" / "+nodeDef+":"+nodeId);
		return false;
	}
	TFlowNode nextNode = next.get(0);
	System.err.println("** Next task: "+nextNode.getId()+" : "+nextNode.getName());
	
	sendToken(t4n.getToken(), node, t4n.getConnector());
	// add task in interrupted tasks list
	interruptedTasks.put(key, this);
	return true;
*/
}

	// XXX: AOP ============================================================================================== GOTO tasks
	
public boolean gotoTask(TokenForNode old_t4n, Node old_node, BusinessProcess process, String gotoNode) {
	// Get the GOTO target node
	TFlowNode target;
	target = BPMNUtils.find(gotoNode, process.getDefinition(), TFlowNode.class);
	if (target==null) return false;
	
	// Get an incoming connector to the GOTO target node
	String linkId = null;
	List<QName> list = target.getIncoming();
	if (list==null || list.size()==0) return false;
	QName qn = list.get(0);
	linkId = qn.getLocalPart();
	
	// Get target and connector for GOTO target node
	TSequenceFlow link = BPMNUtils.find(linkId, process.getDefinition(), TSequenceFlow.class);
	if (link == null) {
		throw new IllegalStateException("Sequence flow with id:" + linkId + " not found");
	}
	Connector connector = new Connector(link);
	if (!(connector.getDefinition().getTargetRef() instanceof TFlowNode)) {
		throw new IllegalStateException("Target node " + connector.getDefinition().getTargetRef().toString() + " is not of TFlowNode type");
	}
	target = (TFlowNode) connector.getDefinition().getTargetRef();
	
	// Create new TokenForNode object
	TokenForNode t4n = new TokenForNode();
	t4n.setToken( old_t4n.getToken() );
	t4n.setNodeDef(target);
	t4n.setConnector(connector);
	acquireEntityManager();
	TFlowNode tSource = BPMNUtils.getFlowNode(old_node.getDefId(), getProcessDefinition(old_t4n.getProcessDefinitionId()));
//	BusinessProcess process = em.get().find(BusinessProcess.class, old_t4n.getProcessInstanceId());
	t4n.setProcessInstanceId(process.getId());
	t4n.setProcessDefinitionId(process.getDefId());
	/*
	Now we need to remove the token source node from database. We use findNode, which fetches persisted nodes only.
	Note that there is no need to delete non-persistent nodes, as all nodes are automatically deleted after
	calling tokenIn (see call() method)
	 */
	Node source = findNode(tSource, process);
	if (source instanceof Callable) {
		if (activeTasks.containsKey(source.getId())) {
	/*
	Removing associated future object. We do not care whether execution completed.
	 */
			activeTasks.remove(source.getId());
		}
	}
	if (source != null) {
		boolean nullProc = true;		// XXX: 2012-12-06:  bugfix for event-based gateways
		if (source instanceof CatchEventNode) {
			CatchEventNode eventNode = (CatchEventNode) source;
			if (eventNode.isStartEvent()) {
				cleanUpStartNodes(source.getProcess());
			} else if (eventNode.getOwnerId() != 0) {
				Node owner = getNode(eventNode.getOwnerId());
				if (owner != null) {
					if (owner instanceof EventBasedGateway) {
						handleGatewayEvent((EventBasedGateway) owner, eventNode);
					} else {
						// TODO: implement processing of boundary events
						throw new IllegalStateException("Not implemented yet");
					}
				} else {
					throw new IllegalStateException("Owner node for catch event " + eventNode.getDefId() + " does not exist");
				}
			}
		} else {
			if (!(source instanceof EventBasedGateway)) {	// XXX: 2012-12-06:  bugfix for event-based gateways
				em.get().remove(source);
			} else											// XXX: 2012-12-06:  bugfix for event-based gateways
				nullProc = false;							//
		}
		if (nullProc)						// XXX: 2012-12-06:  bugfix for event-based gateways
			source.setProcess(null);
	}
	workItems.add(t4n);
	releaseEntityManager();
	
	return true;
}

    // ======================================================================================================= isRunning

    @Override
    public boolean isRunning() {
        if (future != null) {
            return !future.isDone();
        }
        return false;
    }

    // ====================================================================================================== fireTimers

    private void fireTimers() {
        if (System.currentTimeMillis() - lastTriggerPollTime > TriggerPollCycle) {
            acquireEntityManager();
            beginTransaction();
            @SuppressWarnings("unchecked")
            List<TimerTrigger> triggers = em.get().createNamedQuery("TimerTrigger.findAlerts").setParameter("date", new Date()).getResultList();
            try {
                for (TimerTrigger trigger : triggers) {
                    /*
                   we do not care for repeat (cycle) events for now, each timer trigger fired once or never.
                   First thing we should do is to disarm trigger, to avoid false alarms
                    */
                    trigger.disarm();
                    EventIn eventIn = new EventIn();
                    BusinessProcess process = trigger.getEventNode().getProcess();
                    eventIn.setProcessInstanceId(process.getId());
                    eventIn.setProcessDefinitionId(process.getDefId());
                    EventToken token = new EventToken();
                    token.setTriggerInstanceId(trigger.getInstanceId());
                    eventIn.setEventToken(token);
                    workItems.add(eventIn);
                }
            } finally {
                commitTransaction();
                releaseEntityManager();
                lastTriggerPollTime = System.currentTimeMillis();
            }
        }
    }

    // ======================================================================================================== findNode

    protected Node findNode(TFlowNode nodeDef, BusinessProcess process) {
        acquireEntityManager();
        String query;
        if (nodeDef instanceof TUserTask) {
            query = "UserTask";
        } else if (nodeDef instanceof TSendTask) {
            query = "SendTask";
        } else if (nodeDef instanceof TCatchEvent) {
            query = "CatchEventNode";
        } else if (nodeDef instanceof TThrowEvent) {
            query = "ThrowEventNode";
        } else if (nodeDef instanceof TBusinessRuleTask) {
            query = "BusinessRuleTask";
        } else if (nodeDef instanceof TExclusiveGateway) {
            query = "ExclusiveGateway";
        } else if (nodeDef instanceof TEventBasedGateway) {
            query = "EventBasedGateway";
        } else if (nodeDef instanceof TScriptTask) {
            query = "ScriptTask";
        } else if (nodeDef instanceof TParallelGateway) {
            query = "ParallelGateway";
        } else if (nodeDef instanceof TServiceTask) {
            query = "ServiceTask";
        } else {
            throw new IllegalStateException("Unsupported node type: " + nodeDef.getClass().getName());
        }
        try {
            return (Node) em.get().createNamedQuery(
                    new StringBuilder(query).append(".findByDefIdAndProcess").toString()).setParameter("defId", nodeDef.getId()).setParameter("process", process).getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally {
            releaseEntityManager();
        }
    }

    // ================================================================================================ findOrCreateNode

    protected Node findOrCreateNode(TFlowNode nodeDef, BusinessProcess process) {
        Node node = findNode(nodeDef, process);
        if (node != null) {
            return node;
        }
        return createNode(nodeDef, process);
    }

    // ================================================================================================= processEndEvent

    private boolean processEndEvent(Node node, BusinessProcess process) {
        assert isRunner();
        if (isTerminateEvent(node)) {
            acquireEntityManager();
            for (long id : getNodeIds(process)) {
                Node n = getNode(id);
                if (activeTasks.containsKey(n.getId())) {
                    Future<String> future = activeTasks.get(n.getId());
                    future.cancel(true);
                    activeTasks.remove(n.getId());
                }
                if (em.get().contains(n)) {
                    em.get().remove(n);
                }
            }
            releaseEntityManager();
            return true;
        } else {
            cleanUpStartNodes(process);
        }
        Long count = (Long) em.get().createNamedQuery("Node.countByProcess").setParameter("process", process).getSingleResult();
        return count == 0;
    }

    // ================================================================================================ isTerminateEvent

    private boolean isTerminateEvent(Node node) {
        if (node instanceof ThrowEventNode) {
            for (TEventDefinition eventDefinition : ((ThrowEventNode) node).getEvents()) {
                if (eventDefinition instanceof TTerminateEventDefinition) {
                    return true;
                }
            }
        }
        return false;
    }

    // ====================================================================================================== isEndEvent

    private boolean isEndEvent(TFlowNode flowNode) {
        return flowNode.getOutgoing().isEmpty();
    }

    // ============================================================================================= handleTokenFromNode

    private void handleTokenFromNode(TokenFromNode tokenFromNode) {
        TFlowNode target;
        Connector connector = tokenFromNode.getConnector();
        if (!(connector.getDefinition().getTargetRef() instanceof TFlowNode)) {
            throw new IllegalStateException("Target node " + connector.getDefinition().getTargetRef().toString() + " is not of TFlowNode type");
        }
        target = (TFlowNode) connector.getDefinition().getTargetRef();
        TokenForNode t4n = new TokenForNode();
        t4n.setToken(tokenFromNode.getToken());
        t4n.setNodeDef(target);
        t4n.setConnector(connector);
        acquireEntityManager();
        TFlowNode tSource = BPMNUtils.getFlowNode(tokenFromNode.getNodeId(), getProcessDefinition(tokenFromNode.getProcessDefinitionId()));
        BusinessProcess process = em.get().find(BusinessProcess.class, tokenFromNode.getProcessInstanceId());
        t4n.setProcessInstanceId(process.getId());
        t4n.setProcessDefinitionId(process.getDefId());
        /*
        Now we need to remove the token source node from database. We use findNode, which fetches persisted nodes only.
        Note that there is no need to delete non-persistent nodes, as all nodes are automatically deleted after
        calling tokenIn (see call() method)
         */
        Node source = findNode(tSource, process);
        if (source instanceof Callable) {
            if (activeTasks.containsKey(source.getId())) {
        /*
        Removing associated future object. We do not care whether execution completed.
         */
                activeTasks.remove(source.getId());
            }
        }
        if (source != null) {
			boolean nullProc = true;		// XXX: 2012-12-06:  bugfix for event-based gateways
            if (source instanceof CatchEventNode) {
                CatchEventNode eventNode = (CatchEventNode) source;
                if (eventNode.isStartEvent()) {
                    cleanUpStartNodes(source.getProcess());
                } else if (eventNode.getOwnerId() != 0) {
                    Node owner = getNode(eventNode.getOwnerId());
                    if (owner != null) {
                        if (owner instanceof EventBasedGateway) {
                            handleGatewayEvent((EventBasedGateway) owner, eventNode);
                        } else {
                            // TODO: implement processing of boundary events
                            throw new IllegalStateException("Not implemented yet");
                        }
                    } else {
                        throw new IllegalStateException("Owner node for catch event " + eventNode.getDefId() + " does not exist");
                    }
                }
            } else {
				if (!(source instanceof EventBasedGateway)) {	// XXX: 2012-12-06:  bugfix for event-based gateways
					em.get().remove(source);
				} else											// XXX: 2012-12-06:  bugfix for event-based gateways
					nullProc = false;							//
            }
			if (nullProc)						// XXX: 2012-12-06:  bugfix for event-based gateways
				source.setProcess(null);
        }
        workItems.add(t4n);
        releaseEntityManager();
    }

    // ============================================================================================== handleGatewayEvent

    /**
     * Handles event caught by one of the target nodes of event based gateway
     *
     * @param gateway   - event based gateway entity
     * @param eventNode - target node entity (either catch event or receive task)
     */
    private void handleGatewayEvent(EventBasedGateway gateway, Node eventNode) {
        assert isRunner();
        // delete event node (token is already out)
        if (em.get().contains(eventNode)) {
            em.get().remove(eventNode);
        }
        TEventBasedGateway tGateway = BPMNUtils.find(gateway.getDefId(), getProcessDefinition(gateway.getProcess().getDefId()), TEventBasedGateway.class);
        if (tGateway.getEventGatewayType() == TEventBasedGatewayType.EXCLUSIVE) {
            /*
            if exclusive gateway, delete all other target nodes
             */
            for (CatchEventNode catchEventNode : (List<CatchEventNode>) em.get().createNamedQuery("CatchEventNode.findAttached").setParameter("nodeId", gateway.getId()).getResultList()) {
                em.get().remove(catchEventNode);
            }
            for (ReceiveTask receiveTask : (List<ReceiveTask>) em.get().createNamedQuery("ReceiveTask.findAttached").setParameter("nodeId", gateway.getId()).getResultList()) {
                em.get().remove(receiveTask);
            }
            /*
            finally, delete the gateway
             */
            if (em.get().contains(gateway)) {
                em.get().remove(gateway);
            }
        } else {
            /*
            if parallel gateway, delete it only if no targets remaining
             */
            Long targetCount = (Long) em.get().createNamedQuery("CatchEventNode.countAttached").setParameter("nodeId", gateway.getId()).getSingleResult();
            targetCount += (Long) em.get().createNamedQuery("ReceiveTask.countAttached").setParameter("nodeId", gateway.getId()).getSingleResult();
            if (targetCount == 0) {
                if (em.get().contains(gateway)) {
                    em.get().remove(gateway);
                }
            }
        }
    }

    // =========================================================================================================== close

    @Override
    public void close() {
		
// XXX: extension: 2012-08-07:  Session listeners
fireSessionClosing();

        /*
        Cancel all active tasks
         */
        Long[] keySet = activeTasks.keySet().toArray(new Long[0]);
        for (Long id : keySet) {
            activeTasks.get(id).cancel(true);
            activeTasks.remove(id);
        }
        /*
        Try to shutdown session thread by notifying it that it must exit if no incoming work items left in the queue
         */
        shutdown = true;
        try {
            future.get(60, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
            Thread.currentThread().interrupt();
        } catch (ExecutionException e) {
            e.printStackTrace();
            throw new IllegalStateException("Failed to close session, " + e);
        } catch (TimeoutException e) {
            /*
            Force cancellation if queue fails to clear
             */
            cancelled = true;
            try {
                future.get(5, TimeUnit.SECONDS);
            } catch (InterruptedException e1) {
                e.printStackTrace();
                Thread.currentThread().interrupt();
            } catch (ExecutionException e1) {
                e.printStackTrace();
                throw new IllegalStateException("Failed to close session, " + e);
            } catch (TimeoutException e1) {
                e.printStackTrace();
                throw new IllegalStateException("Failed to close session, " + e);
            }
        } finally {
            executor.shutdown();
            AdaptSessionRegistry.removeSession(getId());
        }
		
// XXX: extension: 2012-08-07:  Session listeners
fireSessionClosed();
		
    }

    // =============================================================================================== cleanUpStartNodes

    @SuppressWarnings("unchecked")
    private void cleanUpStartNodes(BusinessProcess process) {
        acquireEntityManager();
        List<CatchEventNode> nodes = em.get().createNamedQuery("CatchEventNode.findStartNodesByProcess").setParameter("process", process).getResultList();
        for (CatchEventNode node : nodes) {
            em.get().remove(node);
        }
        releaseEntityManager();
    }

    // ======================================================================================================== findNext

    private List<TFlowNode> findNext(final String nodeId, final String processId) {
        TProcess tProcess = getProcessDefinitions().get(processId).getProcessDefinition();
        TFlowNode fromNodeDef = BPMNUtils.find(nodeId, tProcess, TFlowNode.class);
        if (fromNodeDef == null) {
            throw new IllegalStateException("From node \"" + nodeId + "\" is not defined in process \"" + processId + "\"");
        }
        return BPMNUtils.findNext(fromNodeDef, tProcess);
    }

    // ====================================================================================================== sendTokens

    @Override
    public void sendTokens(Map<Connector, WorkToken> tokenMap, Node fromNode) {
// XXX: AOP - Send ACTIVITY END event
if (sendWorkflowEvents) { AOP.getInstance((AdaptWorkSession)fromNode.getSession(), fromNode.getProcess()).sendWorkflowEvent(AOP.WFE.ACTIVITY_END, fromNode); }
        tokenOut.set(true);
        if (!isRunner()) {
            fromNode = (Node) merge(fromNode);
        }
        for (Map.Entry<Connector, WorkToken> entry : tokenMap.entrySet()) {
// XXX: AOP - Unregister executing task (just completed). If interrupted then discard work token
if (unregisterExecutingTask(entry.getValue(), fromNode, entry.getKey())==false) continue;

            TokenFromNode tokenFromNode = new TokenFromNode();
            tokenFromNode.setToken(entry.getValue());
            BusinessProcess process = fromNode.getProcess();
            tokenFromNode.setProcessInstanceId(process.getId());
            tokenFromNode.setProcessDefinitionId(process.getDefId());
            tokenFromNode.setNodeId(fromNode.getDefId());
            tokenFromNode.setConnector(entry.getKey());
            workItems.add(tokenFromNode);
        }
    }

    // =========================================================================== sendToken(token, fromNode, connector)

    @Override
    public void sendToken(WorkToken token, Node fromNode, Connector connector) {
// XXX: AOP - Send ACTIVITY END event
if (sendWorkflowEvents) { AOP.getInstance((AdaptWorkSession)fromNode.getSession(), fromNode.getProcess()).sendWorkflowEvent(AOP.WFE.ACTIVITY_END, fromNode); }
        tokenOut.set(true);
        if (!isRunner()) {
            fromNode = (Node) merge(fromNode);
        }
// XXX: AOP - Unregister executing task (just completed). If interrupted then discard work token
if (unregisterExecutingTask(token, fromNode, connector)==false) return;
        TokenFromNode tokenFromNode = new TokenFromNode();
        tokenFromNode.setToken(token);
        BusinessProcess process = fromNode.getProcess();
        tokenFromNode.setProcessInstanceId(process.getId());
        tokenFromNode.setProcessDefinitionId(process.getDefId());
        tokenFromNode.setNodeId(fromNode.getDefId());
        tokenFromNode.setConnector(connector);
        workItems.add(tokenFromNode);
    }

    // ====================================================================================== sendToken(token, fromNode)

    @Override
    public void sendToken(WorkToken token, Node fromNode) {
// XXX: AOP - Send ACTIVITY END event
if (sendWorkflowEvents) { AOP.getInstance((AdaptWorkSession)fromNode.getSession(), fromNode.getProcess()).sendWorkflowEvent(AOP.WFE.ACTIVITY_END, fromNode); }
        tokenOut.set(true);
        if (!isRunner()) {
            fromNode = (Node) merge(fromNode);
        }
// XXX: AOP - Unregister executing task (just completed). If interrupted then discard work token
Connector conn = null;
{	//
	// find sequence flow element and create connector
	//
	TFlowNode tNode = BPMNUtils.getFlowNode(fromNode.getDefId(), fromNode.getProcess().getDefinition());
	if (tNode == null) {
		throw new IllegalStateException("Flow node with id:" + fromNode.getDefId() + " is not defined");
	}
	if (tNode.getOutgoing().size() != 1) {
		throw new IllegalStateException("Call to WorkSession.sendToken(token, fromNode) with fromNode having multiple or no outgoing connectors");
	}
	String linkId = tNode.getOutgoing().get(0).getLocalPart();
	TSequenceFlow link = BPMNUtils.find(linkId, fromNode.getProcess().getDefinition(), TSequenceFlow.class);
	if (link == null) {
		throw new IllegalStateException("Sequence flow with id:" + linkId + " not found");
	}
	conn = new Connector(link);
}
if (unregisterExecutingTask(token, fromNode, conn)==false) return;

        TokenFromNode tokenFromNode = new TokenFromNode();
        tokenFromNode.setToken(token);
        BusinessProcess process = fromNode.getProcess();
        tokenFromNode.setProcessInstanceId(process.getId());
        tokenFromNode.setProcessDefinitionId(process.getDefId());
        tokenFromNode.setNodeId(fromNode.getDefId());
        /*
        find sequence flow element and create connector
         */
        TFlowNode tNode = BPMNUtils.getFlowNode(fromNode.getDefId(), process.getDefinition());
        if (tNode == null) {
            throw new IllegalStateException("Flow node with id:" + fromNode.getDefId() + " is not defined");
        }
        if (tNode.getOutgoing().size() != 1) {
            throw new IllegalStateException("Call to WorkSession.sendToken(token, fromNode) with fromNode having multiple or no outgoing connectors");
        }
        String linkId = tNode.getOutgoing().get(0).getLocalPart();
        TSequenceFlow link = BPMNUtils.find(linkId, process.getDefinition(), TSequenceFlow.class);
        if (link == null) {
            throw new IllegalStateException("Sequence flow with id:" + linkId + " not found");
        }
        tokenFromNode.setConnector(new Connector(link));
        workItems.add(tokenFromNode);
    }

    // ================================================================================================ handleEventToken

    private void handleEventToken(EventIn eventIn) {
        assert isRunner();  // may not be called from application thread
        BusinessProcess process = em.get().find(BusinessProcess.class, eventIn.getProcessInstanceId());
        EventToken token = eventIn.getEventToken();
        /*
        We must find the trigger (it is a previously persisted entity). For timer triggers event token already keeps
        the entity id, because timer events are fired by polling the triggers. Message events are different,
        they provide definition id and we have to run query against the database.
         */
        EventTrigger trigger;
        if (token.getTriggerInstanceId() != 0) {
            trigger = em.get().find(EventTrigger.class, token.getTriggerInstanceId());
        } else {
            trigger = (EventTrigger) em.get().createNamedQuery("EventTrigger.findByDefIdAndProcess").setParameter("defId", eventIn.getEventToken().getDefinitionId()).setParameter("process", process).getSingleResult();
        }
        if (trigger != null) {
            /*
                We do not handle start event case (do not delete other start events) here, because catch event node
                is supposed to call tokenOut() immediately and tokenOut (through sendToken()) will take care of
                multiple start event nodes.
             */
            CatchEventNode node = trigger.getEventNode();
            node.eventIn(token);
            /*
            Catch event object may change after eventIn(), so we do merge. Since we may safely assume that we are in the
            engine thread, we use Entity Manager directly.
             */
            if (em.get().contains(node)) {
                trigger.setEventNode(em.get().merge(node));
            }
        }
    }

    // ================================================================================================== sendEventToken

    @Override
    public void sendEventToken(EventToken eventToken, long processId) {
        EventIn eventIn = new EventIn();
        eventIn.setProcessInstanceId(processId);
        eventIn.setEventToken(eventToken);
        workItems.add(eventIn);
    }

    // ================================================================================================= readDefinitions

    /**
     * Reads BPMN definitions from InputStream
     *
     * @param stream - BPMN definition input stream
     * @return initialized TDefinitions data structure
     */
// XXX: extension
@Override
public TDefinitions readDefinitions(InputStream stream) {
	return readDefinitions(stream, null);
}
	
    @Override
    public TDefinitions readDefinitions(InputStream stream, /* XXX: extension */ String overrideId) {
        String packageName1 = TDefinitions.class.getPackage().getName();
        String packageName2 = BPMNDiagram.class.getPackage().getName();
        String packageName3 = Bounds.class.getPackage().getName();
        String packageName4 = Diagram.class.getPackage().getName();
        TDefinitions tDefinitions;
        try {
            JAXBContext jc = null;
            jc = JAXBContext.newInstance(packageName1 + ":" + packageName2 + ":" + packageName3 + ":" + packageName4);
            Unmarshaller u = jc.createUnmarshaller();
            u.setEventHandler(new javax.xml.bind.helpers.DefaultValidationEventHandler());
            @SuppressWarnings("unchecked")
            JAXBElement<TDefinitions> doc = (JAXBElement<TDefinitions>) u.unmarshal(stream);
            tDefinitions = doc.getValue();
        } catch (JAXBException e) {
            e.printStackTrace();
            throw new IllegalStateException("Error parsing definitions, " + e);
        }
        String id = tDefinitions.getId();
// XXX: extension
if (overrideId!=null && !overrideId.trim().equals("")) {
	id = overrideId.trim();
}
        if (id == null || id.isEmpty()) {
            if (getDefinitionsMap().isEmpty()) {
                id = "com.worktoken.definitions.defaultId";
            } else {
                throw new IllegalArgumentException("Definitions set does not have ID");
            }
        }
        if (getDefinitionsMap().containsKey(id)) {
            throw new IllegalArgumentException("Duplicate ID (\"" + id + "\") for definitions");
        }
        getDefinitionsMap().put(id, tDefinitions);
        scanForProcesses(tDefinitions);
        scanForMessages(tDefinitions);
        return tDefinitions;
    }

    // ================================================================================================== getDefinitions

    @Override
    public TDefinitions getDefinitions(String id) {
        if (getDefinitionsMap().containsKey(id)) {
            return getDefinitionsMap().get(id);
        }
        return null;
    }

    // =============================================================================================== getDefinitionsIds

    @Override
    public Set<String> getDefinitionsIds() {
        return getDefinitionsMap().keySet();
    }

    // ================================================================================================= dropDefinitions

    @Override
    public void dropDefinitions(String id) {
        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("Null or empty definitions ID");
        }
        if (!getDefinitionsMap().containsKey(id)) {
            throw new IllegalArgumentException("No such definitions (ID=\"" + id + "\")");
        }
        // TODO: make sure no running processes from this definitions exist.
// XXX: extension
TDefinitions definitions = 
        getDefinitionsMap().remove(id);
		
// XXX: extension - BEGIN
// also drop related processes
forEachProcess(definitions, new EachProcessHandler() {
	public void process(TProcess tProcess) {
		String id = tProcess.getId();
		if (id == null || id.isEmpty()) {
			return;
		}
		if (!getProcessDefinitions().containsKey(id)) {
			return;
		}
		getProcessDefinitions().remove(id);
		System.out.println("\tProcess dropped: "+id);
	}
});
// also drop related messages
forEachMessage(definitions, new EachMessageHandler() {
	public void message(TMessage tMessage) {
		String id = tMessage.getId();
		if (id == null || id.isEmpty()) {
			return;
		}
		if (!getMessageDefinitions().containsKey(id)) {
			return;
		}
		getMessageDefinitions().remove(id);
		System.out.println("\tMessage dropped: "+id);
	}
});
// XXX: extension - END
    }

// XXX: extension - BEGIN
    // =============================================================================================== getProcessIds

    @Override
    public Set<String> getProcessIds() {
        return getProcessDefinitions().keySet();
    }

    // ================================================================================================= dropProcess
    
	@Override
    public void dropProcess(String id) {
        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("Null or empty Process ID");
        }
        if (!getProcessDefinitions().containsKey(id)) {
            throw new IllegalArgumentException("No such Process (ID=\"" + id + "\")");
        }
        // TODO: make sure no running processes from this definitions exist.
		getProcessDefinitions().remove(id);
		System.out.println("Process dropped: "+id);
    }
// XXX: extension - END

    // ======================================================================================================== isRunner

    private boolean isRunner() {
        return Thread.currentThread().getId() == threadId;
    }

    // =================================================================================================== createProcess

    @Override
    public long createProcess(String id) {
        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("Null or empty process id in call to createProcess");
        }
        if (!getProcessDefinitions().containsKey(id)) {
            throw new IllegalArgumentException("No process with id \"" + id + "\"");
        }
        TProcess tProcess = getProcessDefinitions().get(id).getProcessDefinition();
        BusinessProcess process;
        AnnotatedClass ac = dictionary.findProcess(id, tProcess.getName());
        if (ac == null) {
            process = new BusinessProcess();
        } else {
            Object entity;
            try {
                entity = Class.forName(ac.getClazz()).newInstance();
            } catch (Exception e) {
                throw new IllegalStateException("Failed to instantiate object of class " + ac.getClazz() + " due to " + e);
            }
            if (!(entity instanceof BusinessProcess)) {
                throw new IllegalStateException("Annotated business process class " + ac.getClazz() + " does not extend BusinessProcess class");
            }
            process = (BusinessProcess) entity;
        }
        acquireEntityManager();
        process.setDefId(id);
        process.setSessionId(getId());
        persist(process);
// XXX: AOP - Send PROCESS START event
if (sendWorkflowEvents) { AOP.getInstance(this, process).sendWorkflowEvent(AOP.WFE.PROCESS_START, process); }
        final List<TActivity> startActivities = new ArrayList<TActivity>();
        final List<TCatchEvent> noneStartEvents = new ArrayList<TCatchEvent>();
        final List<TCatchEvent> startEvents = new ArrayList<TCatchEvent>();
        forEachStartNode(tProcess,
                new EachNodeHandler() {
                    public boolean node(TFlowNode tNode) {
                        if (tNode instanceof TCatchEvent) {
                            if (((TCatchEvent) tNode).getEventDefinition().isEmpty()) {
                                noneStartEvents.add((TCatchEvent) tNode);
                            } else {
                                startEvents.add((TCatchEvent) tNode);
                            }
                        } else if (tNode instanceof TActivity) {
                            startActivities.add((TActivity) tNode);
                        }
                        return true;
                    }
                });
        /*
            All start activities (no incoming links) must be instantiated
         */
        for (TActivity activity : startActivities) {
            Node node = createNode(activity, process);
            tokenOut.set(false);
            node.tokenIn(new WorkToken(), null);
            if (!isRunner() && !tokenOut.get()) {
                merge(node);
            }
        }
        /*
            Only one start event will be triggered, if there is at least one None Start Event, it will be triggered,
            other start events will be ignored.
         */
        if (noneStartEvents.isEmpty()) {
            for (TCatchEvent start : startEvents) {
                CatchEventNode node = (CatchEventNode) createNode(start, process);
                node.setStartEvent(true);
                if (!isRunner()) {
                    merge(node);
                }
            }
        } else {
            CatchEventNode node = (CatchEventNode) createNode(noneStartEvents.get(0), process);
            tokenOut.set(false);
            node.eventIn(new EventToken());
            node.setStartEvent(true);
            if (!isRunner() && !tokenOut.get()) {
                merge(node);
            }
        }
        if (isRunner()) {
            em.get().flush();   // we need to flush here to ensure the process instance id is not empty
        }
        releaseEntityManager();
        return process.getId();
    }

    // ====================================================================================================== createNode

    private Node createNode(TFlowNode tNode, BusinessProcess process) {
        TLane lane = BPMNUtils.findLaneForNode(tNode, process.getDefinition());
        if (tNode instanceof TCatchEvent) {
            CatchEventNode node = createCatchEventNode((TCatchEvent) tNode, process, null);
            if (lane != null) {
                node.setLaneDefId(lane.getId());
            }
            node.setSession(this);
// Persistence becomes optional
//			persist(node);
try { persist(node); } catch (Exception e) { showPersistError(tNode, e); }
            return node;
        }
        if (tNode instanceof TUserTask) {
            UserTask node = instantiateNode(tNode, UserTask.class, process);
            if (lane != null) {
                node.setLaneDefId(lane.getId());
            }
            node.setSession(this);
// Persistence becomes optional
//			persist(node);
try { persist(node); } catch (Exception e) { showPersistError(tNode, e); }
            return node;
        }
        if (tNode instanceof TBusinessRuleTask) {
            BusinessRuleTask node = instantiateNode(tNode, BusinessRuleTask.class, process);
            if (lane != null) {
                node.setLaneDefId(lane.getId());
            }
            node.setSession(this);
// Persistence becomes optional
//			persist(node);
try { persist(node); } catch (Exception e) { showPersistError(tNode, e); }
            return node;
        }
        if (tNode instanceof TSendTask) {
            SendTask node = instantiateNode(tNode, SendTask.class, process);
            if (lane != null) {
                node.setLaneDefId(lane.getId());
            }
            node.setSession(this);
// Persistence becomes optional
//			persist(node);
try { persist(node); } catch (Exception e) { showPersistError(tNode, e); }
            return node;
        }
        if (tNode instanceof TScriptTask) {
// XXX: AOP - BEGIN
if (adaptationActive && (AOP.getAdaptationMode()!=AOP.AdaptationMode.INACTIVE)) {
	String format = ((TScriptTask)tNode).getScriptFormat();
	if (format!=null && format.equals("IMU_AOP4BPMN")) {
		List<Object> content = ((TScriptTask)tNode).getScript().getContent();
		String stmt = content.get(0).toString();
		if (stmt!=null && !stmt.trim().equals("")) {
			if ("PROCEED".equalsIgnoreCase(stmt)) {
				ProceedTask node = instantiateNode(tNode, ProceedTask.class, process);
				if (lane != null) {
					node.setLaneDefId(lane.getId());
				}
				node.setSession(this);
				// do not persist
				return node;
			}
		}
	}
}
// XXX: AOP - END

            ScriptTask node = instantiateNode(tNode, ScriptTask.class, process);
            if (lane != null) {
                node.setLaneDefId(lane.getId());
            }
            node.setSession(this);
            // do not persist
            return node;
        }
        if (tNode instanceof TServiceTask) {
            ServiceTask node = instantiateNode(tNode, ServiceTask.class, process);
            if (lane != null) {
                node.setLaneDefId(lane.getId());
            }
            node.setSession(this);
// Persistence becomes optional
//			persist(node);
try { persist(node); } catch (Exception e) { showPersistError(tNode, e); }
            return node;
        }
        if (tNode instanceof TEventBasedGateway) {
            EventBasedGateway node = createEventBasedGateway((TEventBasedGateway) tNode, process);
            if (lane != null) {
                node.setLaneDefId(lane.getId());
            }
            node.setSession(this);
// Persistence becomes optional
//			persist(node);
try { persist(node); } catch (Exception e) { showPersistError(tNode, e); }
            for (Node target : node.getTargets()) {
                if (target instanceof CatchEventNode) {
                    ((CatchEventNode) target).setOwnerId(node.getId());
                } else if (target instanceof ReceiveTask) {
                    ((ReceiveTask) target).setOwnerId(node.getId());
                }
// Persistence becomes optional
//                persist(target);
try { persist(target); } catch (Exception e) { showPersistError(target.getDefinition(), e); }
            }
            return node;
        }
        if (tNode instanceof TExclusiveGateway) {
            ExclusiveGateway node = instantiateNode(tNode, ExclusiveGateway.class, process);
            if (lane != null) {
                node.setLaneDefId(lane.getId());
            }
            node.setSession(this);
            // do not persist
            return node;
        }
        if (tNode instanceof TThrowEvent) {
            ThrowEventNode node = createThrowEventNode((TThrowEvent) tNode, process);
            if (lane != null) {
                node.setLaneDefId(lane.getId());
            }
            node.setSession(this);
            // do not persist
            return node;
        }
        if (tNode instanceof TParallelGateway) {
            ParallelGateway node = createParallelGateway((TParallelGateway) tNode, process);
            if (lane != null) {
                node.setLaneDefId(lane.getId());
            }
            node.setSession(this);
            for (QName qName : ((TParallelGateway) tNode).getIncoming()) {
                PathSocket socket = new PathSocket(qName.getLocalPart());
                socket.setNode(node);
                node.getSockets().add(socket);
//                persist(socket);
            }
// Persistence becomes optional
//			persist(node);
try { persist(node); } catch (Exception e) { showPersistError(tNode, e); }
            return node;
        }
        throw new IllegalArgumentException("Unknown or unsupported node type: process=\"" + process.getDefId() +
                "\", node(id=\"" + tNode.getId() + "\", name=\"" + tNode.getName() + "\")");
    }

// Print persistence error message if uncomment and compile
private void showPersistError(TFlowNode tNode, Exception e) {
	System.err.println("** Failed to persist Node: "+tNode.getId()+" / "+tNode.getName()+". Reason: "+e);
}

    // ================================================================================================= instantiateNode
/*
// XXX: extension:  replaced in order to introduce additional ways of node instantiation namely: through specifications
//                  in Node's BPMN extensionElements, looking in a set of search paths, as well as Annotations and default class
//                  (already used in the old (commented) instantiateNode

    private <T extends Node> T instantiateNode(TFlowNode tNode, Class<T> nClass, BusinessProcess process) {
        Node node;
        AnnotatedClass ac = dictionary.findNode(tNode.getId(), tNode.getName(), process.getDefId());
        if (ac == null) {
            try {
                node = nClass.newInstance();
            } catch (Exception e) {
                e.printStackTrace();
                throw new IllegalStateException("Failed to instantiate object of type  " + nClass.getName() + ", due to " + e);
            }
            node.setClassName(nClass.getName());
        } else {
            Object entity;
            try {
                entity = Class.forName(ac.getClazz()).newInstance();
            } catch (Exception e) {
                throw new IllegalStateException("Failed to instantiate object of class " + ac.getClazz() + " due to " + e);
            }
            if (!nClass.isInstance(entity)) {
                throw new IllegalStateException("Annotated class " + ac.getClazz() + " does not extend " + nClass.getName() + " class");
            }
            node = (Node) entity;
            node.setClassName(ac.getClazz());
        }
        node.setDefId(tNode.getId());
        node.setProcess(process);
        return (T) node;
    }
*/

// XXX: extension:  replaced in order to introduce additional ways of node instantiation namely: through specifications
//                  in Node's BPMN extensionsElement, looking in a set of packages, as well as dictionary Annotations and
//                  default class, already used in the old (commented) instantiateNode
// XXX: extension - BEGIN
private static enum NODE_INSTANTIATION_MODE { BPMN_EXT, ANNOTATION, PACKAGE_PATH, DEFAULT };

private NODE_INSTANTIATION_MODE[] instantiationModeOrder;

private String[] packageSearchArray;
private boolean nodeInstDebug = true;

private void initInstantiationModes() {
	// initialize node instantiation debug flag
	String str0 = engineProperties.getProperty("node-instantiation-debug");
	if (str0!=null && !str0.trim().equals("")) {
		str0 = str0.trim().toLowerCase();
		nodeInstDebug = !(str0.equals("false") || str0.equals("no") || str0.equals("off") || str0.equals("0") || str0.equals("-1"));
	}
	
	// initialize instantiation modes order
	String str = engineProperties.getProperty("node-instantiation-modes-order");
	Vector<NODE_INSTANTIATION_MODE> tmp = new Vector<NODE_INSTANTIATION_MODE>();
	if (str==null || str.trim().equals("")) {
		for (NODE_INSTANTIATION_MODE m : NODE_INSTANTIATION_MODE.values()) {
			tmp.add(m);
		}
	} else {
		String[] part = str.split("[ \t,;]");
		for (int i=0; i<part.length; i++) {
			part[i] = part[i].trim();
			if (part[i].equals("")) continue;
			NODE_INSTANTIATION_MODE v = null;
			try {
				v = NODE_INSTANTIATION_MODE.valueOf(part[i]);
			} catch (Exception e) {
				System.err.println("Invalid NODE_INSTANTIATION_MODE: "+part[i]);
				throw new RuntimeException(e);
			}
			tmp.add( v );
		}
	}
	if (tmp.size()==0) throw new IllegalArgumentException("No NODE_INSTANTIATION_MODE's specified");
	instantiationModeOrder = tmp.toArray(new NODE_INSTANTIATION_MODE[tmp.size()]);
	
	// print the NODE_INSTANTIATION_MODE's order setting
	System.out.print("Node instantiation mode order:");
	for (int i=0; i<instantiationModeOrder.length; i++) { System.out.print(" "); System.out.print(instantiationModeOrder[i]); }
	System.out.println();
	
	// initialize packages search path
	packageSearchArray = null;
	str = engineProperties.getProperty("node-instantiation-packages");
	if (str!=null && !str.trim().equals("")) {
		Vector<String> tmp2 = new Vector<String>();
		String[] part = str.split("[ \t,;]");
		for (int i=0; i<part.length; i++) {
			part[i] = part[i].trim();
			if (part[i].equals("")) continue;
			tmp2.add(part[i]);
		}
		if (tmp2.size()>0) {
			packageSearchArray = new String[tmp2.size()];
			packageSearchArray = tmp2.toArray(packageSearchArray);
		}
	}
	if (packageSearchArray==null) packageSearchArray = new String[0];
	
	// print the Package search path (for PACKAGE_PATH mode)
	System.out.print("Node instantiation Package path:");
	for (int i=0; i<packageSearchArray.length; i++) { System.out.print(" "); System.out.print(packageSearchArray[i]); }
	System.out.println();
}

private <T extends Node> T instantiateNode(TFlowNode tNode, Class<T> nClass, BusinessProcess process) {
	String nodeName = tNode.getName();
	String nodeClss = nClass.getName();
	nodeClss = nodeClss.substring(nodeClss.lastIndexOf('.')+1);
	if (nodeInstDebug) System.out.println("** Instatiating node '"+nodeName+"' ("+nodeClss+") at process: "+process.getDefId()+"/"+process.getId());
	
	T node = null;
	for (int i=0; i<instantiationModeOrder.length; i++) {
		if (instantiationModeOrder[i]==NODE_INSTANTIATION_MODE.BPMN_EXT) node = instantiateNodeFromBpmnExt(tNode, nClass, process);
		else if (instantiationModeOrder[i]==NODE_INSTANTIATION_MODE.ANNOTATION) node = instantiateNodeFromAnnotation(tNode, nClass, process);
		else if (instantiationModeOrder[i]==NODE_INSTANTIATION_MODE.PACKAGE_PATH) node = instantiateNodeFromPackagePath(tNode, nClass, process);
		else if (instantiationModeOrder[i]==NODE_INSTANTIATION_MODE.DEFAULT) node = instantiateNodeDefault(tNode, nClass, process);
		
		if (node!=null) {
			if (nodeInstDebug) System.out.println("** Node '"+nodeName+"' has been instantiated using "+instantiationModeOrder[i]+" mode");
			node.setClassName(node.getClass().getName());
			node.setDefId(tNode.getId());
			node.setProcess(process);
			break;
		}
	}
	if (node==null) System.err.println("** Failed to instantiate node "+nodeName+" ("+nodeClss+") at process "+process.getDefId()+"/"+process.getId());
	return node;
}

private <T extends Node> T instantiateNodeFromBpmnExt(TFlowNode tNode, Class<T> nClass, BusinessProcess process) {
	List<Object> any = null;
	if (tNode.getExtensionElements()==null) return null;
	if ((any=tNode.getExtensionElements().getAny())==null) return null;
	
	org.w3c.dom.Node implementationNode = null;
	String resource = null;
	String className = null;
	String instantiationMethod = null;
	Class[] instantiationParamTypes = null;
	Object[] instantiationParams = null;
	
	// Retrieve node implementation/instantiation information
	for (Object o : any) {
		if (o instanceof org.w3c.dom.Node) {
			// find 'implementation' node
			org.w3c.dom.Node n = (org.w3c.dom.Node) o;
			String name = n.getLocalName();
			if (!name.equals("implementation")) continue;
			implementationNode = n;
			
			// process 'implementation' node specifications for Node instantiation
			org.w3c.dom.Node nn = n.getFirstChild();
			while (nn!=null) {
				name = nn.getLocalName();
				if (name==null) { nn = nn.getNextSibling(); continue; }
				String value = nn.getTextContent();
				value = value!=null ? value.trim() : "";
				
				if (name.equals("codebase") && !value.equals("")) resource = value;
				if (name.equals("class") && !value.equals("")) className = value;
				if (name.equals("instantiation")) {
					try {
						Object[] results = prepareMethodCall(nn);
						if (results==null) {
							System.err.println("** BPMN_EXT: Node instantiation failed due to Node specification problem, at business process : "+process.getDefId()+"/"+process.getId()+". Reason: Instantiation constructor or method not found");
							return null;
						}
						instantiationMethod = (String)results[0];
						instantiationParamTypes = (Class[])results[1];
						instantiationParams = (Object[])results[2];
					} catch (Throwable e) {
						System.err.println("** BPMN_EXT: Node instantiation failed due to Node specification problem, at business process : "+process.getDefId()+"/"+process.getId()+". Reason: "+e);
						return null;
					}
				}
				
				nn = nn.getNextSibling();
			}
		}
	}
	if (className==null) return null;		// No implementation class specified
	
	// Load class
	Class clss = null;
	try {
		if (resource!=null) {
			if (nodeInstDebug) System.out.println("** BPMN_EXT: Loading class "+className+" definition from resource "+resource);
			URL[] urls = new java.net.URL[] { new URL(resource) };
			ClassLoader cl = new URLClassLoader(urls);
			clss = cl.loadClass(className);
		} else {
			if (nodeInstDebug) System.out.println("** BPMN_EXT: Loading class "+className+" definition from classpath");
			clss = Class.forName(className);
		}
		if ( ! Node.class.isAssignableFrom(clss)) {
			if (nodeInstDebug) System.out.println("** BPMN_EXT: Node implementation class "+className+" is NOT assignable to Node");
			clss = null;
		}
	} catch (Exception e) {
		System.err.println("** BPMN_EXT: Loading class "+className+" has failed at process : "+process.getDefId()+"/"+process.getId()+". Reason: "+e);
	}
	if (clss==null) return null;		// implementation class not loaded or not assignable to Node
	
	// Instantiate class
	Node node = null;
	try {
		// use instance factory (static) method to get a new instance. If none specified use a constructor
		if (instantiationMethod!=null && !instantiationMethod.equals("")) {
			if (nodeInstDebug) System.out.println("** BPMN_EXT: Instantiating class "+className+" using static method "+instantiationMethod);
			java.lang.reflect.Method method = clss.getDeclaredMethod(instantiationMethod, instantiationParamTypes);
			if (!java.lang.reflect.Modifier.isStatic(method.getModifiers())) 
					throw new IllegalArgumentException("Instantiation method is not static: "+instantiationMethod);
			Class rtClass = method.getReturnType();
			if (rtClass==null || !nClass.isAssignableFrom(rtClass))
					throw new IllegalArgumentException("Instantiation method does not return an instance of type Node or of a subclass of it: "+instantiationMethod);
			node = (Node) method.invoke(null, instantiationParams);
		} else {
			if (nodeInstDebug) System.out.println("** BPMN_EXT: Instantiating class "+className+" using constructor");
			if (instantiationParams==null || instantiationParams.length==0) {
				node = (Node) clss.newInstance();
			} else {
				node = (Node) clss.getDeclaredConstructor(instantiationParamTypes).newInstance(instantiationParams);
			}
		}
		
		node.setClassName(className);
		node.setDefId(tNode.getId());
		node.setProcess(process);
	} catch (Exception e) {
		System.err.println("** BPMN_EXT: Instantiating class "+className+" has failed at process : "+process.getDefId()+"/"+process.getId()+". Reason: "+e);
		node = null;
	}
	if (node==null) return null;		// node instantiation failed
		
	// process 'implementation' node specifications in order to call setup methods right after instantiation
	org.w3c.dom.Node nn = implementationNode.getFirstChild();
	while (nn!=null) {
		String name = nn.getLocalName();
		if (name==null) { nn = nn.getNextSibling(); continue; }
		String value = nn.getTextContent();
		value = value!=null ? value.trim() : "";
		
		// is it a setup method invocation??
		if (!name.equals("invoke-method")) { nn = nn.getNextSibling(); continue; }
		// yes, it is a setup method invocation
		
		String invokeMethod = null;
		Class[] invokeParamTypes = null;
		Object[] invokeParams = null;
		
		// retrieve and prepare setup method invocation information
		Object[] results = null;
		try {
			results = prepareMethodCall(nn);
			if (results==null) throw new RuntimeException("Setup method invocation specifications are missing or not valid");
			invokeMethod = (String)results[0];
			if (invokeMethod==null || invokeMethod.trim().equals("")) throw new RuntimeException("Setup method invocation specifications do not contain method name");
			invokeParamTypes = (Class[])results[1];
			invokeParams = (Object[])results[2];
		} catch (Throwable e) {
			System.err.println("** BPMN_EXT: Invocation preparation of '"+invokeMethod+"' setup method on "+className+" instance has failed due to Node specification problem, at process : "+process.getDefId()+"/"+process.getId()+". Reason: "+e);
			// failed to gather specifications of a setup method 
			return null;
		}
		
		// invoke setup method
		try {
			if (nodeInstDebug) System.out.println("** BPMN_EXT: Invoking setup method "+invokeMethod+" on "+className+" instance");
			java.lang.reflect.Method method = clss.getDeclaredMethod(invokeMethod, invokeParamTypes);
			Object ret = method.invoke(node, invokeParams);
			if (nodeInstDebug) System.out.println("** BPMN_EXT: Invocation result: "+ret);
			
			// store result in worktoken element (i.e. assignment target), if one is specified
			if (results[3]!=null) {
				Class rtClass = method.getReturnType();
				if (rtClass==Void.TYPE) throw new ClassCastException("Cannot store VOID to worktoken");
				// ++++++++++  XXX: TODO:  ??????  den kserw an pragmati xreiazetai  ????
			}
		} catch (Exception e) {
			System.err.println("** BPMN_EXT: Invocation of '"+invokeMethod+"' setup method on "+className+" instance has failed, at process : "+process.getDefId()+"/"+process.getId()+". Reason: "+e);
			// invocation of a setup method has failed
			return null;
		}
		
		nn = nn.getNextSibling();
	}
	
	// everything is alright!
	if (nodeInstDebug) System.out.println("** BPMN_EXT: Node implementation found in BPMN extensionElements : "+node.getClass().getName());
	return (T) node;
}

private <T extends Node> T instantiateNodeFromAnnotation(TFlowNode tNode, Class<T> nClass, BusinessProcess process) {
	Node node;
	AnnotatedClass ac = dictionary.findNode(tNode.getId(), tNode.getName(), process.getDefId());
	if (ac==null) return null;
	// an annotation found for this process def/node def pair
	
	Object entity;
	try {
		entity = Class.forName(ac.getClazz()).newInstance();
	} catch (Exception e) {
		System.err.println("** ANNOTATION: Failed to instantiate object of class " + ac.getClazz() + " due to " + e);
		throw new IllegalStateException("Failed to instantiate object of class " + ac.getClazz() + " due to " + e);
	}
	if (!nClass.isInstance(entity)) {
		System.err.println("** ANNOTATION: Annotated class " + ac.getClazz() + " does not extend " + nClass.getName() + " class");
		throw new IllegalStateException("Annotated class " + ac.getClazz() + " does not extend " + nClass.getName() + " class");
	}
	node = (Node) entity;
	node.setClassName(ac.getClazz());
	if (nodeInstDebug) System.out.println("** ANNOTATION: Node implementation found in annotations dictionary : "+ac.getClazz());
	
	return (T) node;
}

private <T extends Node> T instantiateNodeFromPackagePath(TFlowNode tNode, Class<T> nClass, BusinessProcess process) {
	// Checking if class exists in any packages in 'packageSearchArray'
	Node node = null;
	String clssName = nClass.getName().substring( nClass.getPackage().getName().length() );
	for (int i=0; i<packageSearchArray.length; i++) {
		String pkg = packageSearchArray[i];
		String clssPkgName = pkg+clssName;
		try {
			Class clss = Class.forName(clssPkgName);
			if (nClass.isAssignableFrom(clss)) {
				node = (Node)clss.newInstance();
				node.setClassName(clssPkgName);
				if (nodeInstDebug) System.out.println("** PACKAGE_PATH: Node implementation found in package/class : "+clssPkgName);
				break;
			} else {
				System.err.println("** PACKAGE_PATH: Node implementation "+clssPkgName+" is not assignable to "+nClass.getName());
			}
		} catch (Exception e) {	}
	}
	return (T) node;
}

private <T extends Node> T instantiateNodeDefault(TFlowNode tNode, Class<T> nClass, BusinessProcess process) {
	Node node = null;
	try {
		node = nClass.newInstance();
	} catch (Exception e) {
		e.printStackTrace();
		System.err.println("** DEFAULT: Failed to instantiate object of type " + nClass.getName() + ", due to " + e);
		return null;
	}
	if (nodeInstDebug) System.out.println("** DEFAULT: Using default node implementation : "+nClass.getName());
	node.setClassName(nClass.getName());
	return (T) node;
}

// Parses BPMN and gets method invocation information
// Returns an array where at [0]: method to call, [1]: parameter types array, [2]: parameter values array, [3]: assignment target
private Object[] prepareMethodCall(org.w3c.dom.Node nn) throws Throwable {
	Object[] results = new Object[4];
	try {
		String invocationMethod = null;
		Object[] invocationParams = null;
		Class[] invocationParamTypes = null;
		
		// get method name and optionally an assignment target for this call
		if (nn.getAttributes()!=null) {
			// get method name
			org.w3c.dom.Node at = nn.getAttributes().getNamedItem("method");
			if (at!=null) {
				invocationMethod = at.getTextContent();
				invocationMethod = invocationMethod!=null ? invocationMethod.trim() : null;
				results[0] = invocationMethod;
			}
			
			// get assignment target. The invocation result should be stored in the specified element of workitem
			at = nn.getAttributes().getNamedItem("assign-to");
			if (at!=null) {
				String target = at.getTextContent();
				target = target!=null ? target.trim() : null;
				results[3] = target;
			}
		}
		
		// get parameters for invocation
		Vector<Class> tmp1 = new Vector<Class>();
		Vector<Object> tmp2 = new Vector<Object>();
		org.w3c.dom.Node np = nn.getFirstChild();
		while (np!=null) {
			String pName = np.getLocalName();
			if (pName==null || !(pName=pName.trim()).equals("param")) { np = np.getNextSibling(); continue; }
			String pValue = np.getTextContent();
			//pValue = pValue!=null ? pValue.trim() : null;		// could be of 'char' type
			Object pObject = null;
			
			// if value is a reference/placeholder retrieve the associated value/object from workitem
/*							if (pValue!=null && pValue.length()>1 && pValue.charAt(0)=='$') {
				String ref = pValue.substring(1).trim();
				pValue = "++++ XXX: TODO: value retrieve from WORKITEM";
				pType = "java.lang.String";
			}*/
			
			// get parameter class from attribute 'type'
			String pType = null;
			Class pClass = null;
			if (np.getAttributes()!=null) {
				org.w3c.dom.Node ap = np.getAttributes().getNamedItem("type");
				if (ap!=null) {
					pType = ap.getTextContent();
				}
			}
			pType = pType!=null ? pType.trim() : null;
			pType = !pType.equals("") ? pType : null;
			if (pType==null) throw new IllegalArgumentException("Missing parameter type for parameter: "+pName);
			
			if (pType.equals("void")) throw new IllegalArgumentException("Parameter cannot be VOID: "+pName);
			else if (pType.equals("boolean")) { pClass = Boolean.TYPE; pObject = new Boolean( pValue.equalsIgnoreCase("true") || pValue.equalsIgnoreCase("yes") || pValue.equalsIgnoreCase("on") || pValue.equals("1") ); }
			else if (pType.equals("char")) { if (pValue.length()!=1) throw new IllegalArgumentException("Parameter of character type must provide a value specification of length 1: "+pName+",  value: '"+pValue+"'");  pClass = Character.TYPE; pObject = new Character(pValue.charAt(0)); }
			else if (pType.equals("byte")) { pClass = Byte.TYPE; pObject = new Byte(pValue); }
			else if (pType.equals("short")) { pClass = Short.TYPE; pObject = new Short(pValue); }
			else if (pType.equals("int") || pType.equals("integer")) { pClass = Integer.TYPE; pObject = new Integer(pValue); }
			else if (pType.equals("long")) { pClass = Long.TYPE; pObject = new Long(pValue); }
			else if (pType.equals("float")) { pClass = Float.TYPE; pObject = new Float(pValue); }
			else if (pType.equals("double")) { pClass = Double.TYPE; pObject = new Double(pValue); }
			else {
				pClass = Class.forName(pType);
				if (pClass.isPrimitive()) {
					if (pClass==Void.TYPE) throw new IllegalArgumentException("Parameter cannot be VOID: "+pName);
					else if (pClass==Boolean.TYPE) pObject = new Boolean( pValue.equalsIgnoreCase("true") || pValue.equalsIgnoreCase("yes") || pValue.equalsIgnoreCase("on") || pValue.equals("1") );
					else if (pClass==Character.TYPE) { if (pValue.length()!=1) throw new IllegalArgumentException("Parameter of character type must provide a value specification of length 1: "+pName+",  value: '"+pValue+"'");  pObject = new Character(pValue.charAt(0)); }
					else if (pClass==Byte.TYPE) pObject = new Byte(pValue);
					else if (pClass==Short.TYPE) pObject = new Short(pValue);
					else if (pClass==Integer.TYPE) pObject = new Integer(pValue);
					else if (pClass==Long.TYPE) pObject = new Long(pValue);
					else if (pClass==Float.TYPE) pObject = new Float(pValue);
					else if (pClass==Double.TYPE) pObject = new Double(pValue);
				} else {
					if (!pClass.equals("java.lang.String")) {
						java.lang.reflect.Constructor cons = pClass.getDeclaredConstructor(new Class[] { String.class });
						if (cons!=null) {
							pObject = cons.newInstance(new Object[] { pValue });
						} else {
							throw new IllegalArgumentException("Cannot instantiated parameter because there is no <init>(java.lang.String) constructor: "+pName);
						}
					} else {
						pObject = pValue;
					}
				}
			}
			tmp1.add( pClass );
			tmp2.add( pObject );
			
			np = np.getNextSibling();
		}
		
		invocationParamTypes = new Class[tmp1.size()];
		invocationParamTypes = (Class[])tmp1.toArray(invocationParamTypes);
		invocationParams = tmp2.toArray();
		
		results[1] = invocationParamTypes;
		results[2] = invocationParams;
		
	} catch (java.lang.reflect.InvocationTargetException e) {
		System.err.println("** Invocation failed: Reason: "+e.getCause());
		throw e.getCause();
	} catch (Exception e) {
		System.err.println("** Invocation specification is not valid: "+e);
		throw e;
	}
	
	return results;
}
// XXX: extension - END


    // ================================================================================================== EventValidator

    private interface EventValidator {
        public boolean validate(TEventDefinition tEventDefinition);
    }

    // ============================================================================================ createCatchEventNode

    /**
     * Creates an instance of Catch Event Node
     * <p/>
     * Instantiates annotated class. If no annotated class found, instantiates CatchEventNode object. Does not persist
     * the node.
     *
     * @param tNode
     * @param process
     * @param validator
     * @return CatchEventNode
     */
    private CatchEventNode createCatchEventNode(TCatchEvent tNode, BusinessProcess process, EventValidator validator) {
        CatchEventNode node = instantiateNode(tNode, CatchEventNode.class, process);
        /*
         * Setup triggers
         */
        for (JAXBElement<? extends TEventDefinition> element : tNode.getEventDefinition()) {
            TEventDefinition eventDefinition = element.getValue();
            if (validator != null && !validator.validate(eventDefinition)) {
                continue;
            }
            try {
                EventTrigger trigger = createEventTrigger(eventDefinition);
                node.getTriggers().add(trigger);
                trigger.setEventNode(node);
            } catch (Exception e) {
                throw new IllegalStateException("Failed to create event trigger for catch event node: id=\"" +
                        tNode.getId() + "\", name=\"" + tNode.getName() + "\", " + e, e);
            }
        }
        return node;
    }

    // =========================================================================================== createParallelGateway

    /**
     * Creates an instance of Parallel Gateway
     * <p/>
     * Instantiates annotated class. If no annotated class found, instantiates ParallelGateway object. Does not persist
     * the node.
     *
     * @param tNode
     * @param process
     * @return ParallelGateway
     */
    private ParallelGateway createParallelGateway(TParallelGateway tNode, BusinessProcess process) {
        /*
        Verify specification
         */
        switch (tNode.getGatewayDirection()) {
            case CONVERGING:
                if (tNode.getOutgoing().size() > 1) {
                    throw new IllegalStateException("Converging gateway may not have more than one outgoing sequence flow, gateway id:" + tNode.getId());
                }
                break;
            case DIVERGING:
                if (tNode.getIncoming().size() > 1) {
                    throw new IllegalStateException("Diverging gateway may not have more than one incoming sequence flow, gateway id:" + tNode.getId());
                }
                break;
        }
        ParallelGateway node = instantiateNode(tNode, ParallelGateway.class, process);
        return node;
    }

    // ========================================================================================= createEventBasedGateway

    /**
     * Creates an instance of Event Based Gateway
     * <p/>
     * Instantiates annotated class. If no annotated class found, instantiates EventBasedGateway object. Does not persist
     * the node.
     *
     * @param tNode
     * @param process
     * @return EventBasedGateway
     */
    private EventBasedGateway createEventBasedGateway(TEventBasedGateway tNode, BusinessProcess process) {
        EventBasedGateway node = instantiateNode(tNode, EventBasedGateway.class, process);
        /*
         * Setup targets
         */
        TProcess tProcess = getProcessDefinition(process.getDefId());
        final boolean[] hasMessageEvents = {false};
        boolean hasReceiveTasks = false;
        EventValidator validator = new EventValidator() {
            @Override
            public boolean validate(TEventDefinition e) {
                if (e instanceof TErrorEventDefinition ||
                        e instanceof TCancelEventDefinition ||
                        e instanceof TCompensateEventDefinition ||
                        e instanceof TLinkEventDefinition) {
                    throw new IllegalStateException("Event based gateway may not have target events of this type: " + e.getClass().getName());
                }
                if (e instanceof TMessageEventDefinition) {
                    hasMessageEvents[0] = true;
                }
                return true;
            }
        };
        for (TFlowNode tFlowNode : BPMNUtils.findNext(tNode, tProcess)) {
            if (tFlowNode instanceof TReceiveTask) {
                hasReceiveTasks = true;
                // TODO: create createReceiveTask()
            } else if (tFlowNode instanceof TIntermediateCatchEvent) {
                CatchEventNode catchEventNode = createCatchEventNode((TCatchEvent) tFlowNode, process, validator);
                node.getTargets().add(catchEventNode);
            }
        }
        if (hasMessageEvents[0] && hasReceiveTasks) {
            throw new IllegalStateException("Event based gateway may not have both Receive Tasks and Message Events target nodes, gateway id:" + tNode.getId());
        }
        return node;
    }

    // ============================================================================================ createThrowEventNode

    /**
     * Creates an instance of Throw Event Node
     * <p/>
     * Instantiates annotated class. If no annotated class found, instantiates ThrowEventNode object. Does not persist
     * the node.
     *
     * @param tNode
     * @param process
     * @return ThrowEventNode
     */
    private ThrowEventNode createThrowEventNode(TThrowEvent tNode, BusinessProcess process) {
        ThrowEventNode node = instantiateNode(tNode, ThrowEventNode.class, process);
        /*
         * Process event definitions
         */
        for (JAXBElement<? extends TEventDefinition> element : tNode.getEventDefinition()) {
            TEventDefinition eventDefinition = element.getValue();
            node.getEvents().add(eventDefinition);
        }
        return node;
    }
    // ============================================================================================== createEventTrigger

    private EventTrigger createEventTrigger(TEventDefinition eventDefinition) {
        if (eventDefinition instanceof TMessageEventDefinition) {
            return createMessageEventTrigger((TMessageEventDefinition) eventDefinition);
        } else if (eventDefinition instanceof TTimerEventDefinition) {
            TimerTrigger trigger = createTimerTrigger((TTimerEventDefinition) eventDefinition);
            trigger.arm();
            return trigger;
        } else {
            throw new IllegalStateException("Unknown event definition type " + eventDefinition.getClass().getName());
        }
    }

    // ============================================================================================== createTimerTrigger

    private TimerTrigger createTimerTrigger(TTimerEventDefinition eventDefinition) {
        TimerTrigger trigger = new TimerTrigger();
        trigger.setDefinitionId(eventDefinition.getId());
        TExpression timeExpression;
        if (eventDefinition.getTimeCycle() != null) {
            timeExpression = eventDefinition.getTimeCycle();
            trigger.setTriggerType(TimerTriggerType.Cycle);
        } else if (eventDefinition.getTimeDate() != null) {
            timeExpression = eventDefinition.getTimeDate();
            trigger.setTriggerType(TimerTriggerType.Date);
        } else if (eventDefinition.getTimeDuration() != null) {
            timeExpression = eventDefinition.getTimeDuration();
            trigger.setTriggerType(TimerTriggerType.Duration);
        } else {
            throw new IllegalStateException("Invalid timer event definition, " + eventDefinition.getId() + ", must have one of timeCycle, timeDate, timeDuration");
        }
        if (timeExpression == null || timeExpression.getContent().isEmpty()) {
            throw new IllegalStateException("Empty " + trigger.getTriggerType().toString() + "element in timer event definition " + eventDefinition.getId());
        }
        trigger.setExpression(timeExpression.getContent().get(0).toString());
        return trigger;
    }

    // ======================================================================================= createMessageEventTrigger

    private MessageTrigger createMessageEventTrigger(TMessageEventDefinition eventDefinition) {
        MessageTrigger trigger = new MessageTrigger();
        String messageId = eventDefinition.getMessageRef().getLocalPart();
        if (messageId == null || messageId.isEmpty()) {
            throw new IllegalStateException("Missing or empty message id in message event definition \"" + eventDefinition.getId() + "\"");
        }
        if (!getMessageDefinitions().containsKey(messageId)) {
            throw new IllegalStateException("Message is not defined, id=\"" + messageId + "\"");
        }
        MessageDefinition md = getMessageDefinitions().get(messageId);
        trigger.setDefinitionId(md.getId());
        trigger.setMessageName(md.getName());
        return trigger;
    }

    private Map<String, ProcessDefinition> getProcessDefinitions() {
        if (processDefinitions == null) {
            processDefinitions = new HashMap<String, ProcessDefinition>();
        }
        return processDefinitions;
    }

    public Map<String, MessageDefinition> getMessageDefinitions() {
        if (messageDefinitions == null) {
            messageDefinitions = new HashMap<String, MessageDefinition>();
        }
        return messageDefinitions;
    }

    // ================================================================================================= EachNodeHandler

    protected interface EachNodeHandler {
        public boolean node(TFlowNode tNode);
    }

    // ===================================================================================================== forEachNode

    protected static void forEachNode(TProcess process, EachNodeHandler handler) {
        for (JAXBElement<? extends TFlowElement> element : process.getFlowElement()) {
            if (element.getValue() instanceof TFlowNode) {
                if (!handler.node((TFlowNode) element.getValue())) {
                    break;
                }
            }
        }
    }

    // ================================================================================================ forEachStartNode

    public static void forEachStartNode(TProcess process, EachNodeHandler handler) {
        for (JAXBElement<? extends TFlowElement> element : process.getFlowElement()) {
            if (element.getValue() instanceof TFlowNode) {
                TFlowNode tFlowNode = (TFlowNode) element.getValue();
                if (tFlowNode.getIncoming().isEmpty() && !((tFlowNode instanceof TTask) && ((TTask) tFlowNode).isIsForCompensation())) {
                    if (tFlowNode instanceof TCatchEvent || tFlowNode instanceof TTask || tFlowNode instanceof TGateway) {
                        handler.node(tFlowNode);
                    }
                }
            }
        }
    }

    // ============================================================================================== EachProcessHandler

    protected interface EachProcessHandler {
        public void process(TProcess tProcess);
    }

    // ================================================================================================== forEachProcess

    protected static void forEachProcess(TDefinitions tDefinitions, EachProcessHandler handler) {
        for (JAXBElement<? extends TRootElement> element : tDefinitions.getRootElement()) {
            if (element.getValue() instanceof TProcess) {
                handler.process((TProcess) element.getValue());
            }
        }
    }

    // ============================================================================================== EachMessageHandler

    protected interface EachMessageHandler {
        public void message(TMessage tProcess);
    }

    // ================================================================================================== forEachMessage

    protected static void forEachMessage(TDefinitions tDefinitions, EachMessageHandler handler) {
        for (JAXBElement<? extends TRootElement> element : tDefinitions.getRootElement()) {
            if (element.getValue() instanceof TMessage) {
                handler.message((TMessage) element.getValue());
            }
        }
    }


    // ================================================================================================ scanForProcesses

    private void scanForProcesses(final TDefinitions definitions) {

        forEachProcess(definitions, new EachProcessHandler() {

            public void process(TProcess tProcess) {
                String id = tProcess.getId();
                if (id == null || id.isEmpty()) {
                    throw new IllegalArgumentException("Process with with no or empty name attribute");
                }
                if (getProcessDefinitions().containsKey(id)) {
                    throw new IllegalArgumentException("Duplicate process id: " + id);
                }
                ProcessDefinition processDefinition = new ProcessDefinition(tProcess);
                processDefinition.setDefinitionsId(definitions.getId());
                getProcessDefinitions().put(id, processDefinition);
            }
        });
    }

    // ================================================================================================= scanForMessages

    private void scanForMessages(final TDefinitions definitions) {

        forEachMessage(definitions, new EachMessageHandler() {

            public void message(TMessage tMessage) {
                String id = tMessage.getId();
                if (id == null || id.isEmpty()) {
                    throw new IllegalArgumentException("Message with with no or empty name attribute");
                }
                if (getMessageDefinitions().containsKey(id)) {
                    throw new IllegalArgumentException("Duplicate message id: " + id);
                }
                MessageDefinition messageDefinition = new MessageDefinition(tMessage);
                getMessageDefinitions().put(id, messageDefinition);
            }
        });
    }

    // =============================================================================================== getDefinitionsMap

    /* XXX: AOP   private */ public Map<String, TDefinitions> getDefinitionsMap() {
        if (definitionsMap == null) {
            definitionsMap = new HashMap<String, TDefinitions>();
        }
        return definitionsMap;
    }

//    protected List<Node> findNodes(BusinessProcess process) {
//        acquireEntityManager();
//        List<Node> nodes = em.get().createNamedQuery("Node.findByProcess").setParameter("process", process).getResultList();
//        releaseEntityManager();
//        return nodes;
//    }

    @Override
    public TProcess getProcessDefinition(String id) {
        if (getProcessDefinitions().containsKey(id)) {
            return getProcessDefinitions().get(id).getProcessDefinition();
        }
        return null;
    }

    public static long getTriggerPollCycle() {
        return TriggerPollCycle;
    }

    public static void setTriggerPollCycle(long triggerPollCycle) {
        TriggerPollCycle = triggerPollCycle;
    }

    /*
    ===================================== Persistence related methods ==================================================

    To avoid interference with application transactions, all persistence operations are executed outside of application
    Thread - either in queue runner or in a dedicated thread.

     */
    // ========================================================================================================= persist

    @Override
    public void persist(final Object o) {
        if (isRunner()) {
            em.get().persist(o);
        } else {
            final LinkedBlockingQueue<String> kicker = new LinkedBlockingQueue<String>();
            executor.execute(new Runnable() {
                @Override
                public void run() {
// XXX: BUG
try {
                    acquireEntityManager();
                    beginTransaction();
                    em.get().persist(o);
                    commitTransaction();
                    releaseEntityManager();
                    kicker.add("done");
// XXX: BUG - BEGIN
} catch (Exception e) {
	java.lang.annotation.Annotation[] an = o.getClass().getAnnotations();
	System.err.println("** AdaptWorkSessionImpl.persist(Object): EXCEPTION CAUGHT: "+e);
	e.printStackTrace();
	System.err.println("-----------------------");
	boolean found = false;
	for (int i=0; i<an.length; i++) {
		System.err.println("\t"+an[i]);
		if (an[i] instanceof javax.persistence.Entity) {
			found = true;
			javax.persistence.Entity ent = (javax.persistence.Entity)an[i];
			System.err.println("\tFOUND A PERSISTENT ENTITY:  name="+ent.name());
			break;
		}
	}
	System.err.println("-----------------------");
	if (!found) markRollbackTransaction();
	commitTransaction();
	releaseEntityManager();
	kicker.add("done");
	if (!found) {
		System.err.println("** AdaptWorkSessionImpl.persist(Object): object does not have a javax.persistence.Entity annotation: "+o);
		throw new RuntimeException(e);
	}
}
// XXX: BUG - END
                }
            });
            try {
                String result = null;
                int retries = 40;
                while (result == null && retries > 0) {
                    --retries;
                    result = kicker.poll(500, TimeUnit.MILLISECONDS);
                }
                /*
                TODO: and what now? no way to stop the Runnable. Rising exception here?
                 */
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    // =========================================================================================================== merge

    @Override
    public Object merge(final Object o) {
        if (isRunner()) {
            return em.get().merge(o);
        } else {
            final LinkedBlockingQueue<Object> kicker = new LinkedBlockingQueue<Object>();
            executor.execute(new Runnable() {
                @Override
                public void run() {
                    acquireEntityManager();
                    beginTransaction();
                    Object mergedEntity = em.get().merge(o);
                    commitTransaction();
                    releaseEntityManager();
                    kicker.add(mergedEntity);
                }
            });
            try {
                Object entity = null;
                int retries = 40;
                while (entity == null && retries > 0) {
                    --retries;
                    entity = kicker.poll(500, TimeUnit.MILLISECONDS);
                }
                /*
                TODO: and what now? no way to stop the Runnable. Rising exception here?
                 */
                return entity;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        return null;
    }

    // ==================================================================================================== getUserTasks

    private List<UserTask> getUserTasks(EntityManager em) {
        return em.createNamedQuery("UserTask.findAll").getResultList();
    }

    // ==================================================================================================== getUserTasks

    @Override
    public List<UserTask> getUserTasks() {
        if (isRunner()) {
            return getUserTasks(em.get());
        } else {
            final LinkedBlockingQueue<List<UserTask>> kicker = new LinkedBlockingQueue<List<UserTask>>();
            executor.execute(new Runnable() {
                @Override
                public void run() {
                    acquireEntityManager();
                    List<UserTask> tasks = getUserTasks(em.get());
                    releaseEntityManager();
                    kicker.add(tasks);
                }
            });
            try {
                List<UserTask> tasks = null;
                int retries = 40;
                while (tasks == null && retries > 0) {
                    --retries;
                    tasks = kicker.poll(500, TimeUnit.MILLISECONDS);
                }
                /*
                TODO: log error
                 */
                return tasks;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        return Collections.emptyList();
    }

    // ============================================================================================ acquireEntityManager

    protected EntityManager acquireEntityManager() {
        if (em.get() == null) {
            em.set(emf.createEntityManager());
            acquireCounter.set(1);
        } else {
            acquireCounter.set(acquireCounter.get() + 1);
        }
        return em.get();
    }

    // ============================================================================================ releaseEntityManager

    protected void releaseEntityManager() {
        if (acquireCounter.get() <= 0) {
            throw new IllegalStateException("Mismatched call to releaseEntityManager()");
        }
        acquireCounter.set(acquireCounter.get() - 1);
        if (acquireCounter.get() == 0) {
            em.remove();
        }
    }

    // ================================================================================================ beginTransaction

    protected void beginTransaction() {
        em.get().getTransaction().begin();
    }

    // =============================================================================================== commitTransaction

    protected void commitTransaction() {
        EntityTransaction transaction = em.get().getTransaction();
        if (transaction.getRollbackOnly()) {
            transaction.rollback();
        } else {
            transaction.commit();
        }
    }

    // ========================================================================================= markRollbackTransaction

    protected void markRollbackTransaction() {
        em.get().getTransaction().setRollbackOnly();
    }

    // ====================================================================================================== getNodeIds

    private List<Long> getNodeIds(BusinessProcess process) {
        return em.get().createNamedQuery("Node.listIdsByProcess").setParameter("process", process).getResultList();
    }
    // ========================================================================================================= getNode

    private Node getNode(long id) {
        String className = (String) em.get().createNamedQuery("Node.className").setParameter("id", id).getSingleResult();
        if (className != null && !className.isEmpty()) {
            try {
                Class clazz = Class.forName(className);
                @SuppressWarnings({"unchecked"})
                Object entity = em.get().find(clazz, id);
                if (entity == null) {
                    throw new IllegalStateException("Node id:" + id + " is not an instance of " + className);
                }
                if (entity instanceof Node) {
                    return (Node) entity;
                }
                throw new IllegalStateException("Object of class " + className + " with id:" + id + " is not a subclass of " + Node.class.getName());
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
                throw new IllegalStateException("Can't instantiate Class " + className);
            }
        } else {
            throw new IllegalStateException("No class name for node or node id:" + id + " not found");
        }
    }
}
