/*
 * +++++++
 */
package com.worktoken.adapt;

import com.worktoken.engine.*;
//import com.worktoken.model.*;
import org.omg.spec.bpmn._20100524.model.*;
import org.w3c.dom.*;

import org.apache.commons.jxpath.JXPathContext;

import java.util.HashSet;
import java.util.Map;
import java.util.Vector;

/**
 * @author ipatini
 */
public class FileAdaptControlService implements AdaptControlService {
	protected Document doc;
	protected Vector<Aspect> aspects;
	
	public FileAdaptControlService() {
//		this("/aop4bpmn.xml");
		
		aspects = new Vector<Aspect>();
		
		// Test aspect 1
		Aspect aspect = null;
		aspect = new Aspect();
		aspect.setName("Test Aspect 1");
		aspect.setDescription("Test Aspect 1 description");
		aspect.setStatus(true);
		aspect.addPointcut(new Pointcut("P/C 1", null, true, "/definitions/process/userTask"));
		aspect.addAdvise(new Advise("ADV 1", null, false, "advise2"));
		aspects.add(aspect);
		
		// Test aspect 2
		aspect = new Aspect();
		aspect.setName("Test Aspect 2");
		aspect.setDescription("Test Aspect 2 description");
		aspect.setStatus(true);
		aspect.addPointcut(new Pointcut("P/C 2", null, true, "/definitions/process/startEvent"));
		aspect.addAdvise(new Advise("ADV 2", null, true, "advise1"));
		aspects.add(aspect);
	}
	
	public FileAdaptControlService(String file) {
		try {
			// Load and parse AOP-XML file
			doc = XMLHelper.getDocument( getClass().getResourceAsStream(file) );
			
			aspects = new Vector<Aspect>();
			
			// Process document
			NodeList nodes = XMLHelper.getNodeListByXPath(doc, "/aspects");
			for (int i=0, n=nodes.getLength(); i<n; i++) {
				Node node = nodes.item(i);
				NodeList children = node.getChildNodes();
				Aspect aspect = Aspect.parseAspect(node);
				if (aspect.isReady()) {
					aspects.add(aspect);
				} else {
					System.err.println("** FileAdaptControlService: <init>: Aspect not ready. Ignored: "+aspect);
				}
			}
		} catch (Exception e) {
			e.printStackTrace(System.err);
			throw new RuntimeException(e);
		}
	}
	
	public void checkPointcut(AOP callback, Object...args) {
		HashSet results = new HashSet();
		for (Aspect aspect : aspects) {
			if (!aspect.getStatus()) continue;
			boolean match = false;
			for (Pointcut pcut : aspect.getPointcuts()) {
				if (!pcut.status) continue;
				String xpath = pcut.xpath;
				
				for (Object o : args) {
					if (o instanceof AdaptWorkSession) {
						Map<String, TDefinitions> dmap = ((AdaptWorkSession)o).getDefinitionsMap();
						for (String s : dmap.keySet()) {
							TDefinitions tdef = dmap.get(s);
							Object result = null; //JXPathContext.newContext(tdef).getValue(xpath);
System.err.println("FileAdaptControlService: checkPointcut:  XPATH search not implemented!!!");
							if (result!=null) {
								match = true;
								break;
							}
						}
						if (match) break;
					}
				}
				if (match) break;
			}
			if (!match) continue;
			for (Advise adv : aspect.getAdvises()) {
				if (!adv.status) continue;
				results.add(adv.processName);
			}
		}
		int nr = results.size();
		if (nr==0) {
			callback.queryPointcutReply(null);
		} else if (nr==1) {
			callback.queryPointcutReply( (String)results.iterator().next() );
		} else {
			throw new RuntimeException("FileAdaptControlService: checkPointcut: More than one advises match on Pointcut");
		}
	}
	
	protected static class Aspect {
		protected String name;
		protected String description;
		protected boolean status;
		protected Vector<Pointcut> pointcuts;
		protected Vector<Advise> advises;
		
		public Aspect() {
			status = true;
		}
		
		public static Aspect parseAspect(Node node) {
			NodeList children = node.getChildNodes();
			Aspect aspect = new Aspect();
System.err.println("** Parsing Aspect");
			for (int j=0, m=children.getLength(); j<m; j++) {
				Node child = children.item(j);
				String name = child.getNodeName();
				String value = child.getNodeValue();
System.err.println("** ----> "+name+"  "+value);
				if (name==null) continue;
				name = name.trim();
				if (name.equalsIgnoreCase("name")) {
					aspect.setName(value);
				} else
				if (name.equalsIgnoreCase("description")) {
					aspect.setDescription(value);
				} else
				if (name.equalsIgnoreCase("status")) {
					aspect.setStatus( XMLHelper.getBooleanValue(value, true) );
				} else
				if (name.equalsIgnoreCase("pointcuts")) {
					NodeList pcuts = node.getChildNodes();
					for (int k=0, l=pcuts.getLength(); k<l; k++) {
						Node pcut = pcuts.item(k);
						Pointcut p = Pointcut.parsePointcut(pcut);
						if (p!=null) aspect.addPointcut(p);
					}
				} else
				if (name.equalsIgnoreCase("advises")) {
					NodeList advs = node.getChildNodes();
					for (int k=0, l=advs.getLength(); k<l; k++) {
						Node adv = advs.item(k);
						Advise a = Advise.parseAdvise(adv);
						if (a!=null) aspect.addAdvise(a);
					}
				}
			}
			return aspect;
		}
		
		public String getName() { return name; }
		public String getDescription() { return description; }
		public boolean getStatus() { return status; }
		public Vector<Pointcut> getPointcuts() { return pointcuts; }
		public Vector<Advise> getAdvises() { return advises; }
		
		public void setName(String name) {
			if (name!=null && !name.trim().equals("")) {
				this.name = name.trim();
			}
		}
		
		public void setDescription(String descr) {
			if (descr!=null && !descr.trim().equals("")) {
				this.description = descr.trim();
			}
		}
		
		public void setStatus(boolean status) {
			this.status = status;
		}
		
		public void addPointcut(Pointcut p) {
			if (p==null) return;
			if (pointcuts==null) pointcuts = new Vector<Pointcut>();
			pointcuts.add(p);
		}
		
		public void addAdvise(Advise a) {
			if (a==null) return;
			if (advises==null) advises = new Vector<Advise>();
			advises.add(a);
		}
		
		public boolean isReady() {
			return (name!=null && status && pointcuts!=null && advises !=null);
		}
		
		public String toString() {
			String s = "ASPECT:\n\tname="+name+"\n\tstatus="+status+"\n\tdescription="+description+"\n\tPointcuts:";
			if (pointcuts!=null) {
				for (Pointcut p : pointcuts) {
					s += "\n\t\t"+p.toString();
				}
			}
			s += "\n\tAdvises:";
			if (advises!=null) {
				for (Advise a : advises) {
					s += "\n\t\t"+a.toString();
				}
			}
			s += "\n";
			return s;
		}
	}
	
	protected static class Pointcut {
		String name;
		String description;
		boolean status;
		String xpath;
		
		public Pointcut(String name, String descr, boolean status, String xpath) {
			this.name = name;
			this.description = descr;
			this.status = status;
			this.xpath = xpath;
		}
		
		public static Pointcut parsePointcut(Node node) {
System.err.println("** Parsing Pointcut");
			return null;
		}
		
		public String toString() {
			return "POINTCUT name="+name+", status="+status+", description="+description+", XPath="+xpath;
		}
	}
	
	protected static class Advise {
		String name;
		String description;
		boolean status;
		String processName;
		
		public Advise(String name, String descr, boolean status, String process) {
			this.name = name;
			this.description = descr;
			this.status = status;
			this.processName = process;
		}
		
		public static Advise parseAdvise(Node node) {
System.err.println("** Parsing Advise");
			return null;
		}
		
		public String toString() {
			return "ADVISE name="+name+", status="+status+", description="+description+", process="+processName;
		}
	}
}