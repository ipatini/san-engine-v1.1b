/*
 * +++++++++++++
 */

package com.worktoken.adapt;

import com.worktoken.engine.AnnotationDictionary;

/**
 * @author ipatini
 */
public abstract class AdaptAnnotationDictionary extends AnnotationDictionary {
    protected void setScanned(boolean scanned) {
        super.setScanned(scanned);
    }
}
