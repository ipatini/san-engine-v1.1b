/*
 * +++++++
 */
package com.worktoken.adapt;

/**
 * @author ipatini
 */
public class AdaptControlServiceFactory {
	public static AdaptControlService getController(Object...args) {
//		return new CLIAdaptControlService();
		return new GUIAdaptControlService();
//		return new FileAdaptControlService();
//		return new SANAdaptControlService();
	}
}