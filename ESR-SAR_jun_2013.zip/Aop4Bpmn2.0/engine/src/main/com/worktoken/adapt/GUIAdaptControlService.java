/*
 * +++++++
 */
package com.worktoken.adapt;

import com.worktoken.engine.*;
import com.worktoken.model.*;
import org.omg.spec.bpmn._20100524.model.*;

import javax.swing.JPanel;
import javax.swing.JOptionPane;

/**
 * @author ipatini
 */
public class GUIAdaptControlService implements AdaptControlService {
	public void checkPointcut(AOP callback, Object...args) {
		Thread runner = new Thread(new Worker(callback, args));
		runner.start();
	}
	
	protected class Worker implements Runnable {
		protected AOP callback;
		protected TokenForNode item;
		protected Node node;
		protected BusinessProcess process;
		
		public Worker(AOP callback, Object...args) {
			this.callback = callback;
			item = (TokenForNode)args[0];
			node = (Node)args[1];
			process = (BusinessProcess)args[2];
		}
		
		public void run() {
			askUser(item, node, process);
		}
		
		protected void askUser(TokenForNode t4n, Node node, BusinessProcess process) {
			// Ask user to indicate whether this node is a pointcut
			String advise = null;
			TFlowNode nodeDef = t4n.getNodeDef();
			int reply = JOptionPane.showConfirmDialog(new JPanel(), 
					"Is this node a PointCut?\n"+
					"Curr. Node: "+nodeDef.getId()+" (instance id: "+node.getId()+")\n"+
					"Process:    "+process.getDefId()+" (instance id: "+process.getId()+")", 
					"Is Pointcut?", 
					JOptionPane.YES_NO_OPTION, 
					JOptionPane.QUESTION_MESSAGE);
			// If node is a pointcut ask user the name of the BPMN process implementing the Advise
			advise = null;
			if (reply==JOptionPane.YES_OPTION) {
				advise = (String)JOptionPane.showInputDialog(new JPanel(),
						"BPMN process implementing pointCut Advise?",
						"Advise?", 
						JOptionPane.QUESTION_MESSAGE,
						null,
						null,
						"advise1");
				if (advise!=null) advise = advise.trim();
				if (advise!=null && advise.isEmpty()) advise = null;
			}
			
			// If user provided a BPMN process name we notify callback
			callback.queryPointcutReply(advise);
		}
	}
}