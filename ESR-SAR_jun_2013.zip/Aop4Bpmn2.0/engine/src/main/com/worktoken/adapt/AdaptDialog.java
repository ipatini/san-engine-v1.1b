/*
 * +++++++
 */
package com.worktoken.adapt;

import com.worktoken.engine.*;
import com.worktoken.model.*;
import org.omg.spec.bpmn._20100524.model.*;

import java.util.Hashtable;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.beans.*;

/**
 * @author ipatini
 */
public class AdaptDialog {
	protected ActionListener callback;
	protected boolean mandatory;
    protected JDialog optionPaneDialog;
	protected JOptionPane optPane;
	
	public AdaptDialog(boolean mandatory, String message, String title, Icon icon, 
					int messageType, int optionsType, Object[] options, Object initValue,
					ActionListener callback)
	{
		this.callback = callback;
		this.mandatory = mandatory;
		createOptionJDialog(message, title, icon, messageType, optionsType, options, initValue);
		
		//Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
				showOptionJDialog();
            }
        });
	}
	
	protected void createOptionJDialog(String message, String title, Icon icon, int messageType, int optionsType, Object[] options, Object initValue) {
        optionPaneDialog = new JDialog((JFrame)null, title);
		optionPaneDialog.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        
        //Note we are creating an instance of a JOptionPane
        //Normally it's just a call to a static method.
        optPane = new JOptionPane(message, messageType, optionsType, icon, options, initValue);
		if (options!=null || initValue!=null) {
			optPane.setWantsInput(true);
			optPane.setOptions(options);
			optPane.setInputValue(initValue);
			optPane.setInitialValue(initValue);
			optPane.setValue(initValue);
		}
        
        //Listen for the JOptionPane button click. It comes through as property change 
        //event with the propety called "value". 
        optPane.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent e) {
				if (e.getPropertyName().equals("value")) {
					boolean inputOk = false;
					int opt = (Integer)e.getNewValue();
					if (opt==JOptionPane.OK_OPTION || opt==JOptionPane.YES_OPTION) {
						inputOk = checkInput();
						if (inputOk) {
							ActionEvent ev = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, getInput());
							callback.actionPerformed(ev);
						}
					}
					if (optPane.getWantsInput()) {
						if (inputOk || !inputOk && !mandatory) optionPaneDialog.dispose();
					} else {
					}
				}
			}
		} );
        
		optionPaneDialog.addWindowListener(new WindowAdapter() {
			public void windowClose(WindowEvent evt) {
				if (!mandatory) {
					ActionEvent ev = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, getInput());
					callback.actionPerformed(ev);
					optionPaneDialog.dispose();
				}
			}
		});
		
		optionPaneDialog.setContentPane(optPane);
	}
	
    public void showOptionJDialog() {
        //Let the JDialog figure out how big it needs to be
        //based on the size of JOptionPane by calling the 
        //pack() method
        optionPaneDialog.pack();
        optionPaneDialog.setLocationRelativeTo(null);
        optionPaneDialog.setVisible(true);
    }
	
	protected boolean checkInput() {
		if (!optPane.getWantsInput()) return true;
		String v = (String)optPane.getInputValue();
		return (v!=null && !v.trim().equals(""));
	}
	
	protected String getInput() {
		if (!optPane.getWantsInput()) 
			return optPane.getValue().toString();
		return optPane.getInputValue().toString();
	}
}