/*
 * ++++++++++++++++++++++++++
 */

package com.worktoken.adapt;

import com.worktoken.engine.WorkSession;
import com.worktoken.engine.WorkItem;
import org.omg.spec.bpmn._20100524.model.TDefinitions;
import java.io.InputStream;
import java.util.Map;
import java.util.Set;


/**
 * @author ipatini
 */

public interface AdaptWorkSession extends WorkSession {
	public String getEngineId();
	public String getEngineProperty(String key);
	public void insertWorkItem(WorkItem item);
	public Map<String, TDefinitions> getDefinitionsMap();
    public TDefinitions readDefinitions(InputStream stream, String overrideId);
	public boolean interruptExecutingTask(String procDef, long procId, String nodeDef, long nodeId);
	
	public Set<String> getProcessIds();
	public void dropProcess(String id);
	
	public void addSessionListener(SessionListener l);
	public void removeSessionListener(SessionListener l);
}
