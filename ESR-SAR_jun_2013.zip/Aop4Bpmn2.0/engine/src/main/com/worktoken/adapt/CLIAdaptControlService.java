/*
 * +++++++
 */
package com.worktoken.adapt;

import com.worktoken.engine.*;
import com.worktoken.model.*;
import org.omg.spec.bpmn._20100524.model.*;

import java.util.Hashtable;
import javax.swing.JPanel;
import javax.swing.JOptionPane;

/**
 * @author ipatini
 */
public class CLIAdaptControlService implements AdaptControlService {
	protected enum RecType { POINTCUT, TASK }
	
	protected class Record {
		AOP callback;
		TokenForNode item;
		Node node;
		BusinessProcess process;
		RecType type;
	}
	
	protected Hashtable<Long,Record> records;
	protected long cnt;
	
	public CLIAdaptControlService() {
System.out.println("****                CLIAdaptControlService : add a PipedReader in constructor to read input from application CLI");
		records = new Hashtable<Long,Record>();
		cnt = 0;
	}
	
	public void checkPointcut(AOP callback, Object...args) {
		Record rec = new Record();
		rec.callback = callback;
		rec.item = (TokenForNode)args[0];
		rec.node = (Node)args[1];
		rec.process = (BusinessProcess)args[2];
		rec.type = RecType.POINTCUT;
		records.put(cnt, rec);
		System.out.println("CLI-AOP-CTRL> Node added");
	}
	
	public void listRecords() {
		for (Long n : records.keySet()) {
			Record r = records.get(n);
			BusinessProcess p = r.process;
			Node d = r.node;
			Connector c = r.item.getConnector();
			System.out.println(n+".\t"+r.type+"\t"+p.getDefId()+"/"+p.getId()+"\t"+d.getDefId()+"/"+d.getId()+"\t"+c.getId());
		}
	}
	
	public void replyToRecord(String reply) {
		// split reply string to ID and actual user input
		reply = reply.trim();
		int p = reply.indexOf(" ");
		long n = Long.parseLong(reply.substring(0,p));
		reply = reply.substring(p).trim();
		
		// get the relevant record
		Record rec = records.get(n);
		if (rec==null) {
			System.out.println("CLI-AOP-CTRL> Record "+n+" does not exists");
			return;
		}
		
		// process user input according to record type
		if (rec.type==RecType.POINTCUT) {
			String advise = (reply.equals("")) ? null : reply;
			rec.callback.queryPointcutReply(advise);
		} else
		if (rec.type==RecType.TASK) {
// XXX: TODO +++++++++++++++++++++
		}
	}
}