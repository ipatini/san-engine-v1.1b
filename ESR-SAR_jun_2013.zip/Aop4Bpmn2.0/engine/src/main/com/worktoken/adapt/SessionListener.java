/*
 * ++++++++++++++++++++++++++
 */

package com.worktoken.adapt;

/**
 * @author ipatini
 */

public interface SessionListener {
	public abstract void sessionClosing();
	public abstract void sessionClosed();
}
