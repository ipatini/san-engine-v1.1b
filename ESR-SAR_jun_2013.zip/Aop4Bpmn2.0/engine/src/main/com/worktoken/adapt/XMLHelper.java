package com.worktoken.adapt;

import java.io.*;
import java.io.IOException;
import java.util.*;
import org.w3c.dom.*;
import org.xml.sax.SAXException;
import javax.xml.parsers.*;
import javax.xml.xpath.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class XMLHelper 
{
	public static String getXPathValueSafe(String xml, String x_path) {
		try {
			return getXPathValue(xml, x_path);
		} catch (Exception ex) {
			return null;
		}
	}

	public static String[] getXPathListSafe(String xml, String xpath) {
		try {
			NodeList nodes = getNodeListByXPath(xml, xpath);
			if (nodes.getLength()==0) return null;

			String[] list = new String[ nodes.getLength() ];
			for (int i=0, n=nodes.getLength(); i<n; i++) {
				list[i] = nodes.item(i).getNodeValue();
			}
			return list;
		} catch (Exception ex) {
			return null;
		}
	}

	public static Document getDocument(String xml)
				throws ParserConfigurationException, SAXException, 
					IOException, UnsupportedEncodingException
	{
		InputStream is = new ByteArrayInputStream(xml.getBytes("UTF-8")); 

		return getDocument(is);
	}

	public static Document getDocument(InputStream is)
				throws ParserConfigurationException, SAXException, 
					IOException, UnsupportedEncodingException
	{
		DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
		domFactory.setNamespaceAware(false);
		DocumentBuilder builder = domFactory.newDocumentBuilder();

		return builder.parse(is);
	}

	protected static NodeList getNodeListByXPath(Document doc, String xpath)
				throws ParserConfigurationException, SAXException, 
					IOException, XPathExpressionException, UnsupportedEncodingException
	{
		XPathFactory factory = XPathFactory.newInstance();
		XPath x_path = factory.newXPath();
		XPathExpression expr = x_path.compile(xpath);

		Object result = expr.evaluate(doc, XPathConstants.NODESET);
		return (NodeList) result;
	}

	protected static NodeList getNodeListByXPath(String xml, String xpath)
				throws ParserConfigurationException, SAXException, 
					IOException, XPathExpressionException, UnsupportedEncodingException
	{
		Document doc = getDocument(xml);

		return getNodeListByXPath(doc, xpath);
	}

	public static String getXPathValue(String xml, String xpath)
				throws ParserConfigurationException, SAXException, 
					IOException, XPathExpressionException, UnsupportedEncodingException
	{
		NodeList nodes = getNodeListByXPath(xml, xpath);
		if (nodes.getLength()>0) {
			return nodes.item(0).getNodeValue();
		}

		return null;
	}

	protected static String getNodeXml(Node node)
			throws IOException, TransformerException
	{
		StringWriter sw = new StringWriter();

		Transformer t = TransformerFactory.newInstance().newTransformer();
		t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		t.transform(new DOMSource(node), new StreamResult(sw));

		return sw.toString();
	}

	public static String getNodeXml(String xml, String xpath)
			throws ParserConfigurationException, SAXException, 
				IOException, XPathExpressionException, UnsupportedEncodingException,
				TransformerException
	{
		NodeList nodes = getNodeListByXPath(xml, xpath);
		if (nodes.getLength()==0) return null;

		Node node = (Node)nodes.item(0);
		return getNodeXml(node);
	}

	protected static javax.xml.parsers.DocumentBuilder  docBld;

	public static synchronized Node createNode(String xmlFragment)
			throws ParserConfigurationException, SAXException, IOException
	{
		if (docBld==null) {
			docBld = DocumentBuilderFactory
				.newInstance() 
				.newDocumentBuilder();
		}

		Element node =  docBld
				.parse(new ByteArrayInputStream(xmlFragment.getBytes("UTF-8"))) 
				//.parse( new org.xml.sax.InputSource(new StringReader(xmlFragment)) )
				.getDocumentElement();

		return node;
	}

	public static String replaceNodeByXPath(String xml, String xpath, Vector rbNodes)
			throws ParserConfigurationException, SAXException,
				IOException, XPathExpressionException, TransformerException
	{
		Document doc = getDocument(xml);
		NodeList nodes = getNodeListByXPath(doc, xpath);
		if (nodes.getLength()>0) {
			Node refNode = nodes.item(0);
			Node parentNode = refNode.getParentNode();
			Node newNode = null;

			Enumeration en = rbNodes.elements();
			while (en.hasMoreElements()) {
				newNode = (Node)en.nextElement();
				newNode = doc.importNode(newNode, true);
				parentNode.insertBefore(newNode, refNode);
			}
			parentNode.removeChild(refNode);
		}
		return getNodeXml(doc);
	}
	
	public static boolean getBooleanValue(String value, boolean defValue) {
		if (value==null || value.trim().equals("")) return defValue;
		value = value.trim().toLowerCase();
		if (value.equals("yes") || value.equals("true") || value.equals("on") || value.equals("1") || value.startsWith("enable")) return true;
		if (value.equals("no") || value.equals("false") || value.equals("off") || value.equals("0") || value.startsWith("disable")) return false;
		return defValue;
	}
}
