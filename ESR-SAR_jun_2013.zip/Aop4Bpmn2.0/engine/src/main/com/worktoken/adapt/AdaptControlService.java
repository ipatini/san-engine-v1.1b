/*
 * +++++++
 */
package com.worktoken.adapt;

/**
 * @author ipatini
 */
public interface AdaptControlService {
	public void checkPointcut(AOP callback, Object...args);
}