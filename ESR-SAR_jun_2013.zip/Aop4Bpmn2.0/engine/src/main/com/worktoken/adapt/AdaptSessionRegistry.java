/*
 * ++++++
 */

package com.worktoken.adapt;

import com.worktoken.engine.SessionRegistry;
import java.util.HashMap;
import java.util.Map;

public class AdaptSessionRegistry {
    private static Map<String, AdaptWorkSession> sessions = new HashMap<String, AdaptWorkSession>();

    public static void addSession(AdaptWorkSession session) {
        sessions.put(session.getId(), session);
		SessionRegistry.addSession(session);
    }

    public static AdaptWorkSession getSession(String id) {
        return sessions.get(id);
    }

    public static void removeSession(String id) {
        if (sessions.containsKey(id)) {
            sessions.remove(id);
			SessionRegistry.removeSession(id);
        }
    }
	
	public static Map<String, AdaptWorkSession> getSessions() {
		return sessions;
	}
}
