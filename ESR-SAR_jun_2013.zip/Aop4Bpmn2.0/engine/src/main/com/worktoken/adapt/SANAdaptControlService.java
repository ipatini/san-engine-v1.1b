/*
 * +++++++
 */
package com.worktoken.adapt;

import com.worktoken.engine.*;
//import com.worktoken.model.*;
import org.omg.spec.bpmn._20100524.model.*;

import java.util.Properties;
import javax.xml.namespace.QName;
import org.iccs.dsb.DsbPubSubHelper;

/**
 * @author ipatini
 */
public class SANAdaptControlService implements AdaptControlService {
	public SANAdaptControlService() {
	}
	
	public void checkPointcut(AOP callback, Object...args) {
/*		String sid = null;	// session id
		String pdid = null;	// process definition id
		String ndid = null;	// node definition id
		String piid = null;	// process instance id
		String niid = null;	// node instance id
		
		for (int i=0, n=args.length; i<n; i++) {
			if (args[i] instanceof Node) {
				Node node = (Node)args[i];
				sid = node.getSession().getId();
				ndid = node.getDefId();
				nid = node.getId();
				pdid = node.getProcess().getDefId();
				piid = Long.toString(node.getProcess().getId());
			} else
			if (args[i] instanceof BusinessProcess) {
				BusinessProcess process = (BusinessProcess)args[i];
				pdid = process.getDefId();
				piid = Long.toString(process.getId());
			} else
			if (args[i] instanceof Session) {
				AdaptWorkSession session = (AdaptWorkSession)args[i];
				sid = session.getId();
			} else {
				System.out.println("SANAdaptControlService: checkPointcut: Argument #"+(i+2)+" type is not supported");
			}
		}
		StringBuffer sb = new StringBuffer();
		if (sid!=null)  { sb.append(" session_id="); sb.append(sid); }
		if (pdid!=null) { sb.append(" process_definition_id="); sb.append(pdid); }
		if (piid!=null) { sb.append(" process_instance_id="); sb.append(piid); }
		if (ndid!=null) { sb.append(" node_definition_id="); sb.append(ndid); }
		if (niid!=null) { sb.append(" node_instance_id="); sb.append(niid); }
		String query = sb.toString().trim();
		
		// Get query topic
		String topic = "";*/
		
		// Send a query event to SAN engine
		if (queryMode==null || queryMode.equals("")) _initDsbHelper();
		
		if (queryMode.equals("QUERY_SAN")) {
			dsbHelper.publishEvent(queryTopic, "<XXX>test_event</XXX>");
		}
		
		callback.queryPointcutReply(null);
	}
	
	protected String queryMode = "";
	protected QName queryTopic;
	protected DsbPubSubHelper dsbHelper;
	protected Properties dsbProperties;
	
	protected void _initDsbHelper() {
		if (dsbHelper!=null) return;
		
		String propFile = "/dsb.properties";
		try {
			dsbProperties = new Properties();
			dsbProperties.load( AOP.class.getResourceAsStream(propFile) );
			//dsbProperties.list(System.out);
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("SANAdaptControlService: _initDsbHelper: Failed to load DSB properties from '"+propFile+"'. Reason: ", ex);
		}
		
		// retrieve configuration settings
		String mode = dsbProperties.getProperty("query.mode");
		if (mode==null || !(mode=mode.trim().toUpperCase()).equals("QUERY_SAN") && !mode.equals("SAN_MONITORS")) {
			throw new IllegalArgumentException("SANAdaptControlService: _initDsbHelper: Invalid SAN query mode: "+mode);
		}
		queryMode = mode;
		
		if (mode.equals("QUERY_SAN")) {
			String topic = dsbProperties.getProperty("query.topic");
			if (topic==null || topic.trim().equals("")) {
				throw new IllegalArgumentException("SANAdaptControlService: _initDsbHelper: Missing 'Query Topic' needed in "+mode+" mode");
			}
			String[] part = topic.split("[ \t]");
			if (part.length!=3) {
				throw new IllegalArgumentException("SANAdaptControlService: _initDsbHelper: Invalid 'Query Topic' specification: "+topic);
			}
			queryTopic = new QName(part[0], part[1], part[2]);
			
			try {
				dsbHelper = DsbPubSubHelper.getInstance(null, dsbProperties);
				dsbHelper.startEndpointWS();
			} catch (Exception ex) {
				ex.printStackTrace();
				throw new RuntimeException("SANAdaptControlService: _initDsbHelper: Failed to start DSB notification consumer WS. Reason: ", ex);
			}
		}
			
	}
	
	protected void _disposeDsbHelper() {
		if (dsbHelper==null) return;
		dsbHelper.stopEndpointWS();
		dsbHelper = null;
		queryMode = "";
		queryTopic = null;
	}
}