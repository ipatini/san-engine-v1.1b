/*
 * +++++++
 */
package com.worktoken.adapt;

import com.worktoken.engine.*;
import com.worktoken.model.*;
import org.omg.spec.bpmn._20100524.model.*;

import java.util.Hashtable;
import javax.swing.*;
import java.awt.event.*;

import org.iccs.dsb.DsbPubSubHelper;
import org.iccs.dsb.EventReceiver;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import javax.xml.namespace.QName;
import java.util.concurrent.ConcurrentLinkedQueue;

import java.util.List;
import javax.xml.XMLConstants;
import javax.xml.transform.TransformerException;
import com.ebmwebsourcing.easycommons.xml.XMLHelper;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.NotificationMessageHolderType;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.NotificationMessageHolderType.Message;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.Notify;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.TopicExpressionType;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.utils.WsnbException;
import com.ebmwebsourcing.wsstar.wsnb.services.impl.util.Wsnb4ServUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import org.iccs.san.util.HtmlEntities;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Vector;


/**
 * @author ipatini
 */

public class AOP {
	/*
	 *  Path/Flow management methods
	 */
	protected static Hashtable<String,Hashtable<String,String>> processPaths;
	protected static long pathCnt = 0;
	protected static boolean debugOn = false;
	
	static {
		processPaths = new Hashtable<String,Hashtable<String,String>>();
	}
	
	public static void updatePath(AdaptWorkSession session, WorkItem item) {
		updatePath(session, item, true);
	}
	
	protected static void updatePath(AdaptWorkSession session, WorkItem item, boolean firstLevel) {
		debug("\n@@ updatePath: PID="+getPID(session, item));
		debug("\n@@ updatePath: "+item);
		String nodeId = getNodeId(item);
		Connector conn = getConnector(item);
		debug("@@ updatePath: node '"+nodeId+"' via "+conn);
		
		if (conn==null) return;		// assume it is an EventIn work item
		if (!(item instanceof TokenFromNode)) return;
		
		String srcId = ((TBaseElement)conn.getDefinition().getSourceRef()).getId();
		String trgId = ((TBaseElement)conn.getDefinition().getTargetRef()).getId();
		debug("@@ updatePath: conn: "+srcId+" -> "+trgId);
		
		Hashtable<String,String> pathConns = getPathConns(session, item);
		
		debug("@@ updatePath: pathConns=", pathConns);
		String path = null;
		if (item instanceof TokenForNode) {
			debug("@@ updatePath: Search using t4n: "+trgId);
			path = pathConns.get(trgId);
		} else if (item instanceof TokenFromNode) {
			debug("@@ updatePath: Search using tfn: "+srcId);
			path = pathConns.get(srcId);
		} else {
			debug("@@ updatePath: No Search");
			path = null;
		}
		debug("@@ updatePath: path="+path);
		if (path==null) {
			newPath(session, item);
			debug("@@ updatePath: calling updatePath again: "+item);
			if (firstLevel) updatePath(session, item, false);
		} else {
			if (item instanceof TokenForNode) {
				debug("@@ updatePath: updating path '"+path+"' to '"+trgId+"'");
				pathConns.remove(trgId);
				pathConns.put(trgId, path);
			} else if (item instanceof TokenFromNode) {
				debug("@@ updatePath: updating path '"+path+"' to '"+trgId+"'");
				pathConns.remove(srcId);
				pathConns.put(trgId, path);
			}
		}
	}
	
	public static void newPath(AdaptWorkSession session, WorkItem item) {
		debug("\n@@ newPath: PID="+getPID(session, item));
		debug("\n@@ newPath: "+item);
		String nodeId = getNodeId(item);
		Connector conn = getConnector(item);
		debug("@@ newPath: node '"+nodeId+"' via "+conn);
		
		if (conn==null) return;		// assume it is an EventIn work item
		
		String srcId = ((TBaseElement)conn.getDefinition().getSourceRef()).getId();
		String trgId = ((TBaseElement)conn.getDefinition().getTargetRef()).getId();
		debug("@@ newPath: conn: "+srcId+" -> "+trgId);
		
		Hashtable<String,String> pathConns = getPathConns(session, item);
		
		String path = ""+(pathCnt++);
		if (item instanceof TokenForNode) {
			pathConns.put(trgId, path);
			debug("@@ newPath: adding new path: "+path+" set to t4n: "+trgId);
		} else if (item instanceof TokenFromNode) {
			pathConns.put(srcId, path);
			debug("@@ newPath: adding new path: "+path+" set to tfn: "+srcId);
		} else {
			debug("@@ newPath: No path added");
		}
	}
	
	public static void removePath(AdaptWorkSession session, WorkItem item) {
		debug("\n@@ removePath: PID="+getPID(session, item));
		debug("\n@@ removePath: "+item);
		String nodeId = getNodeId(item);
		Connector conn = getConnector(item);
		debug("@@ removePath: node '"+nodeId+"' via "+conn);
		
		if (conn==null) return;		// assume it is an EventIn work item
		
		Hashtable<String,String> pathConns = getPathConns(session, item);
		
		debug("@@ removePath: BEFORE pathConns=", pathConns);
		debug("@@ removePath: Remove using t4n: "+nodeId);
		pathConns.remove(nodeId);
		if (pathConns.isEmpty()) {
			String pid = getPID(session, item);
			processPaths.remove(pid);
		}
		debug("@@ removePath: AFTER pathConns=", pathConns);
	}
	
	protected static String getNodeId(WorkItem item) {
		if (item instanceof TokenForNode) {
			TokenForNode t4n = (TokenForNode)item;
			return t4n.getNodeDef().getId();
		} else if (item instanceof TokenFromNode) {
			TokenFromNode tfn = (TokenFromNode)item;
			return tfn.getNodeId();
		} else {
			EventIn ei = (EventIn)item;
			return ei.getEventToken().getDefinitionId();
		}
	}
	
	protected static Connector getConnector(WorkItem item) {
		if (item instanceof TokenForNode) {
			TokenForNode t4n = (TokenForNode)item;
			return t4n.getConnector();
		} else if (item instanceof TokenFromNode) {
			TokenFromNode tfn = (TokenFromNode)item;
			return tfn.getConnector();
		} else {
			EventIn ei = (EventIn)item;
			return null;
		}
	}
	
	protected static String getPID(AdaptWorkSession session, WorkItem item) {
		return session.getId()+"-"+session.hashCode()+"-"+item.getProcessDefinitionId()+"-"+item.getProcessInstanceId();
	}
	
	protected static Hashtable<String,String> getPathConns(AdaptWorkSession session, WorkItem item) {
		String pid = getPID(session, item);
		Hashtable<String,String> pathConns = processPaths.get(pid);
		if (pathConns==null) {
			pathConns = new Hashtable<String,String>();
			processPaths.put(pid, pathConns);
		}
		return pathConns;
	}
	
	public static String getCurrPath(AdaptWorkSession session, WorkItem item) {
		debug("\n@@ getCurrPath: PID="+getPID(session, item));
		debug("\n@@ getCurrPath: "+item);
		String nodeId = getNodeId(item);
		Connector conn = getConnector(item);
		debug("@@ getCurrPath: node '"+nodeId+"' via "+conn);
		
		if (conn==null) return null;		// assume it is an EventIn work item
		if (!(item instanceof TokenForNode)) return null;
		
		String srcId = ((TBaseElement)conn.getDefinition().getSourceRef()).getId();
		String trgId = ((TBaseElement)conn.getDefinition().getTargetRef()).getId();
		debug("@@ getCurrPath: conn: "+srcId+" -> "+trgId);
		
		Hashtable<String,String> pathConns = getPathConns(session, item);
		
		debug("@@ getCurrPath: pathConns=", pathConns);
		String path = null;
		if (item instanceof TokenForNode) {
			debug("@@ getCurrPath: Search using tfn: "+trgId);
			path = pathConns.get(trgId);
		}
		debug("@@ getCurrPath: FOUND= "+path);
		return path;
	}
	
	public static String getAllPaths(AdaptWorkSession session, WorkItem item) {
		String pid = getPID(session, item);
		debug("\n@@ getAllPaths: PID="+pid);
		Hashtable<String,String> pathConns = getPathConns(session, item);
		return getAllPaths(pathConns);
	}
	
	protected static String getAllPaths(Hashtable<String,String> pathConns) {
		String s = "";
		String comma = "";
		for (String n : pathConns.keySet()) {
			s += comma+n+":"+pathConns.get(n);
			comma = ", ";
		}
		return s;
	}
	
	public static String getAllPaths() {
		debug("\n@@ getAllPaths: ALL PROCESSES");
		String s = "";
		for (String pid : processPaths.keySet()) {
			Hashtable<String,String> pathConns = processPaths.get(pid);
			s += pid+" : { "+getAllPaths(pathConns)+" }\n";
		}
		return s;
	}
	
	public static void debug(String mesg) {
		if (!debugOn) return;
		System.err.println(mesg);
	}
	
	public static void debug(String mesg, Hashtable<String,?> ht) {
		StringBuffer sb = new StringBuffer(mesg);
		String comma = null;
		for (String k : ht.keySet()) {
			if (comma==null) comma = ", ";
			sb.append(comma);
			sb.append(k);
			sb.append(":");
			sb.append(ht.get(k));
		}
		debug(sb.toString());
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////////
	
	/*
	 *  Static variables and initialization for Adaptation management
	 */
	protected static Hashtable<String,AOP> instances;
	protected static Hashtable<String,AOP> adaptationProcesses;
	protected static Hashtable<String,AOP> normalToAdaptProcMap;
	
	static {
		instances = new Hashtable<String,AOP>();
		adaptationProcesses = new Hashtable<String,AOP>();
		normalToAdaptProcMap = new Hashtable<String,AOP>();
	}
	
	/*
	 *  Adaptation Life-Cicle management methods
	 */
	protected static String getInstanceId(AdaptWorkSession session, BusinessProcess process, String path) {
		return session.getId()+"-"+session.hashCode()+"-"+process.getDefId()+"-"+process.getId()+"-"+path;
	}
	
	public static AOP getInstance(AdaptWorkSession session, BusinessProcess process, WorkItem item) {
		AOP.updatePath(session, item);
		String path = getCurrPath(session, item);
		return getInstance(session, process, path);
	}
	
	public static AOP getInstance(AdaptWorkSession session, BusinessProcess process, Node node, Connector connector, WorkToken token) {
		String srcId = ((TBaseElement)connector.getDefinition().getSourceRef()).getId();
		String trgId = ((TBaseElement)connector.getDefinition().getTargetRef()).getId();
		String pid = session.getId()+"-"+session.hashCode()+"-"+process.getDefId()+"-"+process.getId();
		Hashtable<String,String> pathConns = processPaths.get(pid);
		if (pathConns==null) {
			pathConns = new Hashtable<String,String>();
			processPaths.put(pid, pathConns);
		}
		String path = pathConns.get(srcId);

		if (path==null) {
			path = ""+(pathCnt++);
			pathConns.put(srcId, path);
		}

		AOP aop = getInstance(session, process, path);
		if (aop==null) aop = AOP.createInstance(null, (AdaptWorkSession)session, process, path);
		return aop;
	}
	
	public static AOP getInstance(AdaptWorkSession session, BusinessProcess process, String path) {
		String iid = getInstanceId(session, process, path);
		AOP aop = instances.get(iid);
		return aop;
	}
	
	public static AOP getInstance(AdaptWorkSession session, BusinessProcess process) {
		String dummyPath = "NO-PATH-SEND-EVENT";
		String iid = getInstanceId((AdaptWorkSession)session, process, dummyPath);
		AOP aop = instances.get(iid);
		if (aop==null) aop = AOP.createInstance(null, (AdaptWorkSession)session, process, dummyPath);
		return aop;
	}
	
	public static AOP createInstance(AdaptControlService controller, AdaptWorkSession session, BusinessProcess process, WorkItem item) {
		String path = getCurrPath(session, item);
		return AOP.createInstance(controller, session, process, path);
	}
	
	public static AOP createInstance(AdaptControlService controller, AdaptWorkSession session, BusinessProcess process, String path) {
		AOP aop = new AOP(controller, session, process, path);
		instances.put(aop.getId(), aop);
		return aop;
	}
	
	public static AOP removeInstance(String id) {
		return instances.remove(id);
	}
	
	/*
	 *  Adaptation state management methods
	 */
	public static enum State { INIT, QUERY, EXECUTE, ADAPT, PROCEED, PROCEEDING };
	
	protected String uniqueId;
	protected AdaptWorkSession session;
	protected BusinessProcess process;
	protected AdaptControlService controller;
	
	protected String path;
	protected State adaptState;
	protected String advise;
	protected boolean proceedCalled;
	
	protected TokenForNode workItem_1;		// also try WorkItem ????
	protected Node workNode_1;
	protected BusinessProcess workProcess_1;
	
	protected AOP(AdaptControlService controller, AdaptWorkSession session, BusinessProcess process, String path) {
		this.uniqueId = getInstanceId(session, process, path);
		this.session = session;
		this.process = process;
		this.path = path;
		this.controller = controller;
		
		resetAdaptationState();
	}
	
	// Used in constructor, in normal process EXECUTE state, and in adaptation process ADAPT state
	public void resetAdaptationState() {
		adaptState = State.INIT;
		advise = null;
		proceedCalled = false;
		
		workItem_1 = null;
		workNode_1 = null;
		workProcess_1 = null;
	}
	
	public String getId() {
		return uniqueId;
	}
	
	public State getAdaptationState() {
		return adaptState;
	}
	
	public String getAdvise() {
		return advise;
	}
	
	public boolean isAdaptationProcess(BusinessProcess process) {
		String key = getProcessKey(process.getId());
		return normalToAdaptProcMap.containsKey(key);
	}
	
	public boolean isNormalProcess(BusinessProcess process) {
		return !isAdaptationProcess(process);
	}

	// Generates a unique process key (a combination of session id and process id)
	protected String getProcessKey(Node node) {
		return session.hashCode()+"-"+node.getProcess().getId();
	}
	
	// Generates a unique process key (a combination of session id and process id)
	protected String getProcessKey(long pid) {
		return session.hashCode()+"-"+pid;
	}
	
	// Used in normal process INIT state
	public boolean queryPointcut(TokenForNode t4n, Node node, BusinessProcess process) {
		// If not in INIT state we are in the middle of an adaptation,
		// so it's not a new pointcut
		if (adaptState!=State.INIT) return false;
		
		// Exclude adaptation processes
		String key = getProcessKey(node);
		if (normalToAdaptProcMap.containsKey(key)) {
			// We are in adaptation process context
			// Update adaptation process state
			adaptState = State.ADAPT;
			initAdaptationState(t4n, node, process);
			return false;
		}
		
		// Exclude non-task nodes
		Class clss = node.getClass();
		while (!clss.getName().endsWith("Task")) {
			clss = clss.getSuperclass();
			if (clss==null) return false;
		}
		
		// Take work token off the flow
		workItem_1 = t4n;
		workNode_1 = node;
		workProcess_1 = process;
		
		// Update state
		adaptState = State.QUERY;
		
		// Notify decision-making service to indicate whether this is a pointcut.
		// Till then work token is kept offline.
		if (adaptationMode==AdaptationMode.INACTIVE) {
			// nothing to do, just move on
			queryPointcutReply(null);
		} else
		if (adaptationMode==AdaptationMode.INTERNAL_ADAPTATION ||
			adaptationMode==AdaptationMode.ASYNCHRONOUS_ADAPTATION)
		{
			// In case of ASYNCHRONOUS adaptation, SAN Engine will asynchronously
			// send Adaptation Recommendation events when appropriate
			
			//controller.checkPointcut(this, t4n, node, process, session);
			Advise advise = getMatchingAdvise(session, process, node, null);
			// check if aspect has been weaved
			if (advise!=null) {
				Aspect aspect = advise.getAspect();
			}
			
			// check if advise process has been loaded
			if (advise!=null) {
				String advUri = advise.getProcessURI();
				if (advUri!=null && !advUri.trim().equals("")) {
					advUri = advUri.trim();
					if (session.getDefinitions(advUri)==null) {
						try {
							// Upon advise instruction...
							// Loads BPMN process definition file...
							// If not already loaded. URI/URL becomes the Definitions Id,
							// which overrides the one in Definitions file.
							InputStream is = org.iccs.san.util.SANHelper.getResourceAsStream(advUri);
							if (is!=null) {
								session.readDefinitions(is, advUri);
							} else {
								System.out.println("Could not open stream to Definitions at : "+advUri);
							}
						} catch (Exception ex) {
							System.out.println("Could not read Definitions from : "+advUri);
							ex.printStackTrace();
						}
					}
				}
			}
			String advProcess = (advise==null) ? null : advise.getProcessId();
			if (advise!=null && advise.getAspect().isOnceOff()) {
				// remove once-off aspect
				Aspect aspect = advise.getAspect();
				System.out.println("** Removing once-off aspect: "+aspect.getName());
				removeAspect(session, aspect);
			}
			
// 2013-02-08: extension to support GOTO command
// check if it is a command
if (advProcess!=null && advProcess.toUpperCase().startsWith(".GOTO-NODE")) {
	String nodeId = advProcess.substring(10).trim();
	((AdaptWorkSessionImpl)session).gotoTask(workItem_1, workNode_1, workProcess_1, nodeId);
}
else
			queryPointcutReply(advProcess);
		} else
		if (adaptationMode==AdaptationMode.SYNCHRONOUS_ADAPTATION) {
			sendAdaptationQueryEvent(node);
		}
		
		return true;
	}
	
	// Called by Adaptation Controller after a call to 'queryPointcut'
	public void queryPointcutReply(String advise) {
		if (advise==null || advise.trim().equals("")) {
			// No adaptation is needed.
			// Update status and put work token back to flow
			adaptState = State.EXECUTE;
			session.insertWorkItem(workItem_1);
		} else {
			// Adaptation is needed.
			// Begin adaptation process
			this.advise = advise;
			beginAdaptation(workItem_1, workNode_1, workProcess_1);
		}
	}
	
	// Called by 'queryPointcutReply' to start an adaptation process
	// It is called in normal process context
	protected void beginAdaptation(TokenForNode t4n, Node node, BusinessProcess process) {
		// Store normal process data in cache
		this.workItem_1 = t4n;
		this.workNode_1 = node;
		this.workProcess_1 = process;
		
		// Start adaptation process
		synchronized (normalToAdaptProcMap) {
			adaptState = State.ADAPT;					// Indicate that normal process is being adapted
			long pid = session.createProcess(advise);	// Create and Start adaptation process
			String key = getProcessKey(pid);			// Generate adaptation process key
			normalToAdaptProcMap.put(key, this);		// Map normal process to the adaptation process key
			System.out.println("** Advise process started: "+advise+", with id: "+pid);
		}
	}
	
	// Used in adaptation process INIT state
	public void initAdaptationState(TokenForNode t4n, Node node, BusinessProcess process) {
		// We are in adaptation process
		adaptState = State.ADAPT;						// Change state to ADAPT
		String key = getProcessKey(process.getId());	// Get the process key
		adaptationProcesses.put(key, this);				// Register adaptation process
		
		// update adaptation process state
		updateState(t4n, node, process);
		
		// Re-insert work item back to flow
		session.insertWorkItem( workItem_1 );
	}
	
	// Used in adaptation process ADAPT state and is also called by 
	// 'initAdaptationState', 'switchToNormalProcess' and 'switchToAdaptationProcess'
	public void updateState(TokenForNode t4n, Node node, BusinessProcess process) {
		// Store adaptation process state
		workItem_1 = t4n;
		workNode_1 = node;
		workProcess_1 = process;
	}
	
	// Used in adaptation process ADAPT state, WHEN current node is a Proceed Task
	public void markProceed() {
		// Change adaptation process state to PROCEED
		adaptState = State.PROCEED;
	}
	
	// Used in adaptation process PROCEED state (just after ProceedTask node execution but BEFORE
	// the actual normal process PROCEED task execution).
	public void switchToNormalProcess(TokenForNode t4n, Node node, BusinessProcess process) {
		// Store current adaptation process state
		updateState(t4n, node, process);
		
		// Signal normal process to proceed
		normalToAdaptProcMap.get( getProcessKey(process.getId()) ).proceed();
	}
	
	// Called from adaptation process context on a normal process instance
	protected void proceed() {
		// Update normal process state to PROCEED
		adaptState = State.PROCEED;
		// and put work item into flow
		session.insertWorkItem( workItem_1 );
	}
	
	// Used in normal process PROCEED state
	public void proceeding(TokenForNode t4n, Node node, BusinessProcess process) {
		// Store current normal process state
		updateState(t4n, node, process);
		
		// Change state to PROCEEDING
		adaptState = State.PROCEEDING;
		proceedCalled = true;
	}
	
	// Used in normal process PROCEEDING state
	public void switchToAdaptationProcess(TokenForNode t4n, Node node, BusinessProcess process) {
		// Store current normal process state
		updateState(t4n, node, process);
		
		// Change state back to ADAPT
		adaptState = State.ADAPT;
		
		// 'normalToAdaptProcMap' maps adaptation process keys onto the corresponding
		// normal process AOP instances
		String key = null;
		AOP aop = null;
		for (String k : normalToAdaptProcMap.keySet()) {
			AOP a = normalToAdaptProcMap.get(k);
			if (a==this) {
				key = k;		// adaptation process key
				aop = a;		// normal process AOP instance
				break;
			}
		}
		
		// Signal adaptation process to continue adaptation
		adaptationProcesses.get(key).continueAdaptation();
	}
	
	// Called from normal process context on an adaptation process instance
	protected void continueAdaptation() {
		// Update adaptation process state to ADAPT
		adaptState = State.ADAPT;
		// and put work item into flow
		session.insertWorkItem( workItem_1 );
	}
	
	// Used in adaptation process WHEN node is an END EVENT
	public void endAdaptation() {
		// Remove this instance from internal structures
		String key = getProcessKey(process.getId());
		AOP aop = normalToAdaptProcMap.remove(key);
		adaptationProcesses.remove(key);
		
		// Signal normal process to continue (AFTER TASK)
		aop.continueExecution();
		
		// Reset adaptation process state
		resetAdaptationState();
	}
	
	// Called from adaptation process context on a normal process instance
	protected void continueExecution() {
		if (proceedCalled) {
			// Put work item into flow
			session.insertWorkItem( workItem_1 );
		} else {
			// we must bypass normal process task since adaptation process ended without a PROCEED task
			session.sendToken( workItem_1.getToken(), workNode_1 );
		}
		
		// Reset normal process state
		resetAdaptationState();
	}
	
// Called from an external source on a normal process instance
public void taskInterrupted(WorkToken token, Node node, Connector connector) {
	// An AFTER advise was found and an adaptation circle will begin
	TFlowNode target;
	if (!(connector.getDefinition().getTargetRef() instanceof TFlowNode)) {
		throw new IllegalStateException("Target node " + connector.getDefinition().getTargetRef().toString() + " is not of TFlowNode type");
	}
	target = (TFlowNode) connector.getDefinition().getTargetRef();
	
	TokenForNode t4n = new TokenForNode();
	t4n.setToken(token);
	t4n.setNodeDef(target);
	t4n.setConnector(connector);
//	TFlowNode tSource = BPMNUtils.getFlowNode(tokenFromNode.getNodeId(), getProcessDefinition(tokenFromNode.getProcessDefinitionId()));
	BusinessProcess process = node.getProcess();
	t4n.setProcessInstanceId(process.getId());
	t4n.setProcessDefinitionId(process.getDefId());
	

	// Check if there is an (AFTER) advise that probably interrupts this task
	queryPointcut(t4n, node, process);
}

// 2013-02-08:  extension for executing AFTER ADVISE right after task completion
// Execute AFTER ADVISE right after task completion
public boolean executeAfterAdaptation(AdaptWorkSession session, WorkToken token, Node node, Connector connector) {
	if (session==null || node==null || node.getProcess()==null) return false;
	BusinessProcess proc = node.getProcess();
	Advise afterAdvise = getMatchingAdvise(session, process, node, ADAPTATION_TYPE.AFTER_ADAPTATION);
	if (afterAdvise!=null) {
		taskInterrupted(token, node, connector);
		return true;
	}
	return false;
}
	
	// ===================================================================================================
	
	/*
	 *  DSB init/dispose methods
	 */
	
	protected static DsbPubSubHelper dsbHelper;
	protected static Properties dsbProperties;
	protected static ConcurrentLinkedQueue<QueuedEvent> queue;
	protected static Thread runner;
	protected static boolean keepRunning;
	protected static EventDispatcher dispatcher;
	
	protected static class QueuedEvent {
		QName topic;
		String content;
		
		public QueuedEvent(QName topic, String content) {
			this.topic = topic;
			this.content = content;
		}
	}
	
	public static void init() {
		_initDsbConfiguration();
	}
	
	public static void cleanup() {
		_disposeDsbHelper();
	}
	
	protected static void _initDsbConfiguration() {
		if (dsbHelper!=null) return;
		try {
			queue = new ConcurrentLinkedQueue<QueuedEvent>();
			runner = new Thread() {
				public void run() {
					keepRunning = true;
					while (keepRunning) {
						try {
							QueuedEvent qe = queue.poll();
							if (qe!=null) dsbHelper.publishEvent(qe.topic, qe.content);
							try { runner.sleep(500); } catch (Exception ex) {}
						} catch (Exception e) {}
					}
				}
			};
			runner.setDaemon(true);
			runner.start();
			
			String propFile = "/AOP.properties";
			dsbProperties = new Properties();
			//dsbProperties.load( AOP.class.getResourceAsStream(propFile) );
			dsbProperties.load( org.iccs.san.util.SANHelper.getResourceAsStream(propFile) );
			
			// set debug flag
			String df = dsbProperties.getProperty("DEBUG_EVENTS");
			df = df!=null ? df.trim().toLowerCase() : "";
			debugOn = df.equals("yes") || df.equals("on") || df.equals("true") || df.equals("1");
			
			// parse and initialize adaptation mode
			String tmp = dsbProperties.getProperty("adaptation.mode");
			tmp = tmp!=null ? tmp.trim().toUpperCase() : "";
			try {
				setAdaptationMode( AdaptationMode.valueOf(tmp) );
				System.out.println("Adaptation Mode: "+getAdaptationMode());
			} catch (IllegalArgumentException ex) {
				throw new IllegalArgumentException("AOP: _initDsbConfiguration: Invalid or missing 'adaptation.mode' value in configuration: "+dsbProperties.getProperty("adaptation.mode"));
			}
			
			// parse and initialize default recommendation weaving mode
			tmp = dsbProperties.getProperty("common.recom.weaving");
			tmp = tmp!=null ? tmp.trim().toUpperCase() : "";
			try {
				System.out.println("Def. Weaving Mode: "+WEAVING_MODE.valueOf(tmp));
			} catch (IllegalArgumentException ex) {
				throw new IllegalArgumentException("AOP: _initDsbConfiguration: Invalid or missing 'common.recom.weaving' value in configuration: "+dsbProperties.getProperty("common.recom.weaving"));
			}
			
			// parse and set send workflow events (WFE) flag
			tmp = dsbProperties.getProperty("wfe.send.workflow.events");
			tmp = tmp!=null ? tmp.trim().toLowerCase() : "";
			setSendWFEvents( tmp.equals("yes") || tmp.equals("on") || tmp.equals("true") || tmp.equals("1") );
			
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("AOP: _initDsbConfiguration: Failed to start DSB notification consumer WS. Reason: ", ex);
		}
	}
	
	protected static void _initDsbHelper() throws java.io.IOException {
		if (dsbHelper!=null) return;
		
		//dsbProperties.list(System.out);
		dispatcher = new EventDispatcher();
		dsbHelper = DsbPubSubHelper.getInstance(dispatcher, dsbProperties);
		dsbHelper.startEndpointWS();
		System.out.println("DSB endpoint started");
	}
	
	protected static void _disposeDsbHelper() {
		if (dsbHelper==null) return;
		unsubsubscribeFromAdaptationEvents();
		
		keepRunning = false;
		try { runner.interrupt(); } catch (Exception ex) {}
		dsbHelper.stopEndpointWS();
		dsbHelper = null;
		dispatcher = null;
		
		System.out.println("DSB endpoint stopped");
	}
	
	public static int getQueuedEventsCount() {
		return queue!=null ? queue.size() : -1;
	}
	
	// ===================================================================================================
	
	/*
	 *  Workflow events (WFE) methods
	 */
	
	public static enum WFE {
		ACTIVITY_START, ACTIVITY_END, ACTIVITY_EXCEPTION, PROCESS_START, PROCESS_END
	};
	
	protected static boolean sendWFEvents;
	
	public static boolean isSendWFEvents() {
		return sendWFEvents;
	}
	
	public static void setSendWFEvents(boolean newValue) {
		if (sendWFEvents==newValue) return;
		sendWFEvents = newValue;
		_setAdaptationMode(adaptationMode);
	}
	
	public void sendWorkflowEvent(WFE eventType, BusinessProcess process) {
		if (adaptationMode==AdaptationMode.INACTIVE) return;
		if (!sendWFEvents) return;
		if (eventType!=WFE.PROCESS_START && eventType!=WFE.PROCESS_END) {
			throw new IllegalArgumentException("sendWorkflowEvent(WFE,BusinessProcess) : Illegal event type "+eventType+". Only PROCESS START/END types are allowed");
		}
		String mesg = eventType+": "+process.getSessionId()+":"+process.getDefId()+"/"+process.getId();
		debug(mesg);
		debug("  -->  WF event publish: "+_sendWorkflowEvent(eventType, process, null, ""));
	}
	
	public void sendWorkflowEvent(WFE eventType, Node node) {
		if (adaptationMode==AdaptationMode.INACTIVE) return;
		if (!sendWFEvents) return;
		if (eventType==WFE.PROCESS_START || eventType==WFE.PROCESS_END) {
			throw new IllegalArgumentException("sendWorkflowEvent(WFE,TokenForNode) : Illegal event type "+eventType+". Only ACTIVITY START/END/EXCEPTION types are allowed");
		}
		String mesg = eventType+": "+node.getSession().getId()+":"+node.getProcess().getDefId()+"/"+node.getProcess().getId()+":"+node.getDefId()+"/"+node.getId();
		debug(mesg);
		debug("  -->  WF event publish: "+_sendWorkflowEvent(eventType, null, node, ""));
	}
	
	public void sendWorkflowEvent(WFE eventType, Node node, Exception e) {
		if (adaptationMode==AdaptationMode.INACTIVE) return;
		if (!sendWFEvents) return;
		if (eventType==WFE.PROCESS_START || eventType==WFE.PROCESS_END) {
			throw new IllegalArgumentException("sendWorkflowEvent(WFE,TokenForNode) : Illegal event type "+eventType+". Only ACTIVITY START/END/EXCEPTION types are allowed");
		}
		String mesg = null;
		if (node!=null)
			mesg = eventType+": "+node.getSession().getId()+":"+node.getProcess().getDefId()+"/"+node.getProcess().getId()+":"+node.getDefId()+"/"+node.getId()+"\n\tEXCEPTION: "+e;
		else
			mesg = eventType+": <unknown>"+"\n\tEXCEPTION: "+e;
		debug(mesg);
		debug("  -->  WF event publish: "+_sendWorkflowEvent(eventType, null, node, "EXCEPTION: "+e));
	}
	
	protected boolean _sendWorkflowEvent(WFE wfEventType, BusinessProcess process, Node node, String mesg) {
		if (adaptationMode==AdaptationMode.INACTIVE) return false;
		if (!sendWFEvents) return false;
		if (dsbHelper==null) return false;
		
		String engineId = getEngineId();
		String sessionId = process!=null ? process.getSessionId() : node!=null ? node.getSession().getId() : "";
		String processDefId = process!=null ? process.getDefId() : node!=null ? node.getProcess().getDefId() : "";
		String processId = process!=null ? ""+process.getId() : node!=null ? ""+node.getProcess().getId() : "";
		String nodeDefId = node!=null ? node.getDefId() : "";
		String nodeType = node!=null ? (node.getDefinition()!=null ? node.getDefinition().getClass().getName() : "") : "";
		String nodeClass = node!=null ? ((node.getClassName()!=null && !node.getClassName().trim().equals("")) ? node.getClassName().trim() : node.getClass().getName()) : "";
		String nodeId = node!=null ? ""+node.getId() : "";
		
		String ns = dsbProperties.getProperty("wfe.topic.namespace");
		String lp = dsbProperties.getProperty("wfe.topic.local-part");
		String pf = dsbProperties.getProperty("wfe.topic.prefix");
		QName topic = new QName(ns, lp, pf);
		
		String eventId = java.util.UUID.randomUUID().toString().replace("-", "_");
		String tm = org.iccs.san.util.DateParser.formatW3CDateTime(new java.util.Date());
		
		String url = dsbProperties.getProperty("wfe.event.url");
		String eventType = dsbProperties.getProperty("wfe.event.type");
		String content = dsbProperties.getProperty("wfe.event.template");
		
		content = content.replace("%NL%", "\n");
		content = content.replace("%MESSAGE%", mesg);
		content = content.replace("%URL%", url);
		
		content = content.replace("%TOPIC_NAMESPACE%", ns);
		content = content.replace("%TOPIC_LOCALPART%", lp);
		content = content.replace("%TOPIC_PREFIX%", pf);
		content = content.replace("%TIMESTAMP%", tm);
		content = content.replace("%EVENT_ID%", eventId);
		content = content.replace("%EVENT_TYPE%", eventType);
		
		content = content.replace("%WF_EVENT_TYPE%", wfEventType.toString());
		content = content.replace("%ENGINE_ID%", engineId);
		content = content.replace("%SESSION_ID%", sessionId);
		content = content.replace("%PROCESS_DEF_ID%", processDefId);
		content = content.replace("%PROCESS_INST_ID%", processId);
		content = content.replace("%NODE_DEF_ID%", nodeDefId);
		content = content.replace("%NODE_TYPE%", nodeType);
		content = content.replace("%NODE_CLASS%", nodeClass);
		content = content.replace("%NODE_INST_ID%", nodeId);
		
		//System.out.println("PUBLISHING TO : "+topic+"\n"+content);
		
		// Queue event for asynchronous publishing
		queue.add( new QueuedEvent(topic, content) );
		return true;
		
		// Event publishing (synchronous)
		//return dsbHelper.publishEvent(topic, content);
	}
	
	// ===================================================================================================
	
	/*
	 *  SYNCHRONOUS and ASYNCHRONOUS Adaptation Mode methods
	 */
	
	public static enum AdaptationMode {
		INACTIVE, INTERNAL_ADAPTATION, ASYNCHRONOUS_ADAPTATION, SYNCHRONOUS_ADAPTATION
	};
	
	public static enum WEAVING_MODE {
		DEFAULT, ACCEPT, REJECT, ASK_USER, RECOM_SUGGESTION
	}
	
	protected static AdaptationMode adaptationMode;
	protected static String subscriptionUUID;
	protected static QName subscriptionTopic;
	protected static Hashtable<String,AOP> pendingQueryEvents;
	protected static Hashtable<String,String> processedReplyEvents;
	
	public static AdaptationMode getAdaptationMode() {
		return adaptationMode;
	}
	
	public static void setAdaptationMode(AdaptationMode newMode) {
		if (adaptationMode==newMode) return;
		_setAdaptationMode(newMode);
	}
	
	protected static void _setAdaptationMode(AdaptationMode newMode) {
		try {
			if (adaptationMode==null) adaptationMode = AdaptationMode.INACTIVE;
			AdaptationMode oldMode = adaptationMode;
			
			// unsubscribe from any active streams
			if (adaptationMode!=newMode) {
				if (adaptationMode==AdaptationMode.SYNCHRONOUS_ADAPTATION || 
					adaptationMode==AdaptationMode.ASYNCHRONOUS_ADAPTATION)
				{
					if (dsbHelper!=null) {
						unsubsubscribeFromAdaptationEvents();
					}
				}
			}
			
			// stop DSB endpoint if not needed
			if (!sendWFEvents && newMode==AdaptationMode.INTERNAL_ADAPTATION ||
			    newMode==AdaptationMode.INACTIVE) 
			{
				if (dsbHelper!=null) {
					_disposeDsbHelper();
				}
			}
			
			// set 'adaptationMode'
			adaptationMode = newMode;
			
			// init local DSB endpoint, if needed
			if (sendWFEvents && adaptationMode!=AdaptationMode.INACTIVE || 
				adaptationMode==AdaptationMode.SYNCHRONOUS_ADAPTATION || 
				adaptationMode==AdaptationMode.ASYNCHRONOUS_ADAPTATION) 
			{
				if (dsbHelper==null) {
					_initDsbHelper();
				}
			}
			
			// subscribe for Adaptation events if configured
			if (adaptationMode!=oldMode) {
				if (adaptationMode==AdaptationMode.ASYNCHRONOUS_ADAPTATION) {
					subscribeForAsynchronousAdaptationEvents();
				} else
				if (adaptationMode==AdaptationMode.SYNCHRONOUS_ADAPTATION) {
					subscribeForSynchronousAdaptationEvents();
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException("AOP: setAdaptationMode: Failed to change Adaptation Mode. Reason: ", ex);
		}
	}
	
	public void sendAdaptationQueryEvent(Node node) {
		String mesg = "ADAPTATION_QUERY_EVENT: "+node.getSession().getId()+":"+node.getProcess().getDefId()+"/"+node.getProcess().getId()+":"+node.getDefId()+"/"+node.getId();
		System.out.println(mesg);
		System.out.println("  -->  SYNCRONOUS_ADAPTATION: SAN query event publish: "+_sendAdaptationQueryEvent(null, node, ""));
	}
	
	protected boolean _sendAdaptationQueryEvent(BusinessProcess process, Node node, String mesg) {
		String engineId = "";
		String sessionId = process!=null ? process.getSessionId() : node!=null ? node.getSession().getId() : "";
		String processDefId = process!=null ? process.getDefId() : node!=null ? node.getProcess().getDefId() : "";
		String processId = process!=null ? ""+process.getId() : node!=null ? ""+node.getProcess().getId() : "";
		String nodeDefId = node!=null ? node.getDefId() : "";
		String nodeType = node!=null ? (node.getDefinition()!=null ? node.getDefinition().getClass().getName() : "") : "";
		String nodeClass = node!=null ? ((node.getClassName()!=null && !node.getClassName().trim().equals("")) ? node.getClassName().trim() : "") : node.getClass().getName();
		String nodeId = node!=null ? ""+node.getId() : "";
		
		if (dsbHelper==null) _initDsbConfiguration();
		
		String ns = dsbProperties.getProperty("sync.query.topic.namespace");
		String lp = dsbProperties.getProperty("sync.query.topic.local-part");
		String pf = dsbProperties.getProperty("sync.query.topic.prefix");
		QName topic = new QName(ns, lp, pf);
		
		String eventId = java.util.UUID.randomUUID().toString().replace("-", "_");
		String tm = org.iccs.san.util.DateParser.formatW3CDateTime(new java.util.Date());
		
		String url = dsbProperties.getProperty("sync.query.event.url");
		String eventType = dsbProperties.getProperty("sync.query.event.type");
		String eventSubtype = dsbProperties.getProperty("sync.query.event.subtype");
		String content = dsbProperties.getProperty("sync.query.event.template");
		
		content = content.replace("%NL%", "\n");
		content = content.replace("%MESSAGE%", mesg);
		content = content.replace("%URL%", url);
		
		content = content.replace("%TOPIC_NAMESPACE%", ns);
		content = content.replace("%TOPIC_LOCALPART%", lp);
		content = content.replace("%TOPIC_PREFIX%", pf);
		content = content.replace("%TIMESTAMP%", tm);
		content = content.replace("%EVENT_ID%", eventId);
		content = content.replace("%EVENT_TYPE%", eventType);
		
		content = content.replace("%ADQ_EVENT_TYPE%", eventSubtype);
		content = content.replace("%ENGINE_ID%", engineId);
		content = content.replace("%SESSION_ID%", sessionId);
		content = content.replace("%PROCESS_DEF_ID%", processDefId);
		content = content.replace("%PROCESS_INST_ID%", processId);
		content = content.replace("%NODE_DEF_ID%", nodeDefId);
		content = content.replace("%NODE_TYPE%", nodeType);
		content = content.replace("%NODE_CLASS%", nodeClass);
		content = content.replace("%NODE_INST_ID%", nodeId);
		
		//System.out.println("PUBLISHING TO : "+topic+"\n"+content);
		
		// Registering query event with current AOP instance
		// for later back-referencing
		if (pendingQueryEvents==null) pendingQueryEvents = new Hashtable<String,AOP>();
		pendingQueryEvents.put(eventId, this);
		
		// Queue event for asynchronous publishing
		System.out.println("  -->  SYNCRONOUS_ADAPTATION: Event Id: "+eventId);
		queue.add( new QueuedEvent(topic, content) );
		return true;
		
		// Event publishing (synchronous)
		//return dsbHelper.publishEvent(topic, content);
	}
	
	protected static void subscribeForAsynchronousAdaptationEvents() {
		String ns = dsbProperties.getProperty("async.recom.topic.namespace");
		String lp = dsbProperties.getProperty("async.recom.topic.local-part");
		String pf = dsbProperties.getProperty("async.recom.topic.prefix");
		QName topic = new QName(ns, lp, pf);
		
		System.out.println("ASYNCRONOUS_ADAPTATION: Subscribing for Adaptation events : "+topic+"...");
		String UUID = dsbHelper.subscribeFor(topic);
		subscriptionUUID = UUID!=null ? UUID : "";
		subscriptionTopic = topic;
		System.out.println("ASYNCRONOUS_ADAPTATION: Subscription SUCCESSFULL.  UUID="+subscriptionUUID);
	}
	
	protected static void subscribeForSynchronousAdaptationEvents() {
		String ns = dsbProperties.getProperty("sync.reply.topic.namespace");
		String lp = dsbProperties.getProperty("sync.reply.topic.local-part");
		String pf = dsbProperties.getProperty("sync.reply.topic.prefix");
		QName topic = new QName(ns, lp, pf);
		
		System.out.println("SYNCRONOUS_ADAPTATION: Subscribing for Adaptation events : "+topic+"...");
		String UUID = dsbHelper.subscribeFor(topic);
		subscriptionUUID = UUID!=null ? UUID : "";
		subscriptionTopic = topic;
		System.out.println("SYNCRONOUS_ADAPTATION: Subscription SUCCESSFULL.  UUID="+subscriptionUUID);
	}
	
	protected static void unsubsubscribeFromAdaptationEvents() {
		if (subscriptionTopic!=null) {
			System.out.println("A/SYNCRONOUS_ADAPTATION: Unsubscribing from Adaptation events : "+subscriptionTopic+"...");
			if (dsbHelper.unsubscribeFrom(subscriptionTopic, subscriptionUUID)) {
				System.out.println("A/SYNCRONOUS_ADAPTATION: Unsubscription SUCCESSFULL");
			} else {
				System.out.println("A/SYNCRONOUS_ADAPTATION: Unsubscription FAILED");
			}
		}
		subscriptionTopic = null;
		subscriptionUUID = null;
	}
	
	public String getEngineId() {
		return session.getEngineId();
	}
	
	public static String notify2string(Notify notify) {
		try {
			if (debugOn) {
				// get the DOM from the bean
				Document dom = Wsnb4ServUtils.getWsnbWriter().writeNotifyAsDOM(notify);
				String notifyXml = null;
				try {
					notifyXml = XMLHelper.createStringFromDOMDocument(dom);
					
					System.out.println("------------------------------------------------------------------------------");
					System.out.println(notifyXml);
					System.out.println("------------------------------------------------------------------------------");
				} catch (TransformerException e) {
					e.printStackTrace();
				}
			}
			
			// get the topic
			List<NotificationMessageHolderType> messages = notify.getNotificationMessage();
			for (NotificationMessageHolderType notificationMessageHolderType : messages) {
				TopicExpressionType targetTopic = notificationMessageHolderType.getTopic();
				//logInfo("Target topic : " + targetTopic.getContent());
				
				// extract topic indices
				String namespaceURI = XMLConstants.NULL_NS_URI;
				String localPart = null;
				String prefix = XMLConstants.DEFAULT_NS_PREFIX;
				
				// get topic prefix and local part
				String content = targetTopic.getContent();
				int p = content.indexOf(":");
				if (p>0) {
					localPart = content.substring(p+1);
					prefix = content.substring(0, p);
				} else {
					localPart = content;
					prefix = "";
				}
				
				// get topic namespace. If many namespaces exist then we choose the one 
				// with a prefix matching the local part's prefix. If no such namespace
				// exists then when leave NULL_NS_URI
				for (QName ns : targetTopic.getTopicNamespaces()) {
					String nsPrefix = ns.getLocalPart();
					if (nsPrefix.equals(prefix)) {
						namespaceURI = ns.getNamespaceURI();
						break;
					}
				}
				
				QName topic = new QName(namespaceURI, localPart, prefix);
				debug("EVENT TOPIC : " + topic);
				
				// Process the business message
				Message message = notificationMessageHolderType.getMessage();
				Element businessMessage = message.getAny();
				if (businessMessage!=null) {
					try {
						org.w3c.dom.Node node = businessMessage.getFirstChild();
						String nodeXml = XMLHelper.createStringFromDOMNode(node);
						
						return nodeXml;
						
					} catch (TransformerException te) {
						te.printStackTrace();
					}
				} else {
					debug("EVENT CONTENT PROBLEM : No Business Message");
				}
			}
		} catch (Exception ex) {
			System.err.println("notify2string: Failed to convert Notify to String due to exception: "+ex);
			throw new RuntimeException(ex);
		}
		
		return null;
	}
	
	protected static class EventDispatcher implements EventReceiver {
		public void eventReceived(Notify notify) throws WsnbException {
			try {
				String nodeXml = notify2string(notify);
				if (nodeXml!=null) {
					_processEvent(nodeXml);
				} else {
					System.err.println("EventDispatcher: eventReceived(Notify): Notify to String returned NULL");
				}
			} catch (Exception e) {
				System.err.println("EventDispatcher: eventReceived(Notify): Failed to convert Notify to String: "+e);
				e.printStackTrace(System.err);
			}
		}
		
		public void eventReceived(String notify) {
			if (debugOn) {
				// get the DOM from the bean
				System.out.println("------------------------------------------------------------------------------");
				System.out.println(notify);
				System.out.println("------------------------------------------------------------------------------");
			}
			
			// get topic and message from notify
			String topicStr = null;
			String mesg = null;
			
			int p = notify.indexOf("}\n");
			if (p>-1) {
				topicStr = notify.substring(1, p);
				mesg = notify.substring(p+2);
			} else {
				System.err.println("    EVENT-DISPATCHER: eventReceived(String):  EVENT IS REJECTED: MISSING EVENT HEADER: \n"+notify);
				return;
			}
			String[] part = topicStr.split("[ \t]+");
			if (part.length<3) {
				System.err.println("    EVENT-DISPATCHER: eventReceived(String):  EVENT IS REJECTED: INVALID TOPIC SPECIFICATION: "+topicStr);
				return;
			}
			QName topic = new QName(part[0].trim(), part[1].trim(), part[2].trim());
			debug("EVENT TOPIC : " + topic);
			
			// process message
			_processEvent(mesg);
		}
		
		protected boolean _processEvent(String nodeXml) {
			nodeXml = HtmlEntities.decode( nodeXml );
			
			// extract needed information (query event id, advise process etc)
			String type = getTypeValue(nodeXml, dsbProperties.getProperty("common.event.type.attrib"));
			String subtype = getValue(nodeXml, dsbProperties.getProperty("common.event.subtype.attrib"));
			String eid = getValue(nodeXml, dsbProperties.getProperty("common.event.id.attrib"));
			String ask = getValue(nodeXml, dsbProperties.getProperty("common.event.ask-user.attrib"));
			boolean askUser = (ask.equals("yes") || ask.equals("on") || ask.equals("true") || ask.equals("1"));
			
			if (debugOn) {
				System.out.println("************   Event RDF/Trig payload");
				System.out.println(nodeXml);
				System.out.println("************   EXTRACTED INFO\n");
				System.out.println("    Event type:     "+type);
				System.out.println("    Event subtype:  "+subtype);
				System.out.println("    Event Id:       "+eid);
				System.out.println("    Ask User:       "+ask);
				System.out.println();
			}
			
			// filter out duplicate events
			if (processedReplyEvents==null) processedReplyEvents = new Hashtable<String,String>();
			if (processedReplyEvents.containsKey(eid)) {
				debug("    EVENT-DISPATCHER:  Duplicate reply event, with Id: "+eid);
				return false;
			}
			processedReplyEvents.put(eid, eid);
			
			// process SYNCHRONOUS adaptation reply event
			if (type.trim().equals( dsbProperties.getProperty("sync.reply.event.type") )) {
				
				// event filtering based on event subtype
				if (!subtype.trim().equals( dsbProperties.getProperty("sync.reply.event.subtype") )) {
					debug("    EVENT-DISPATCHER: SYNC:  Wrong event subtype: "+subtype);
					return false;
				}
				
				// collect info specific to synchronous mode
				String qeId = getValue(nodeXml, dsbProperties.getProperty("sync.reply.event.query-event-id.attrib"));
				String advise = getValue(nodeXml, dsbProperties.getProperty("sync.reply.event.advise-process.attrib"));
				debug("    Query-Event-Id: "+qeId);
				debug("    Advise Process: "+advise);
				debug("");
				
				// notify appropriate AOP instance to continue
				if (pendingQueryEvents!=null && pendingQueryEvents.size()>0) {
					AOP aop = pendingQueryEvents.remove(qeId);	// get and remove
					if (aop!=null) {
						if (advise!=null) {
							advise.trim();
							if (advise.equals("")) advise = null;
						}
						if (advise!=null) {
							// check recommendation (reply) weaving mode
							String weaveStr = dsbProperties.getProperty("common.recom.weaving");
							WEAVING_MODE weaveMode = WEAVING_MODE.ACCEPT;
							if (weaveStr!=null && !weaveStr.trim().equals("")) {
								try { weaveMode = WEAVING_MODE.valueOf(weaveStr); } catch (Exception e) {}
								if (weaveMode==WEAVING_MODE.ACCEPT) ;
								else if (weaveMode==WEAVING_MODE.REJECT) advise = null;
								else if (weaveMode==WEAVING_MODE.ASK_USER ||
										 weaveMode==WEAVING_MODE.RECOM_SUGGESTION && askUser)
								{
									String cMesg = "SYNC: Advise "+advise+" is recommended!!\n\n XXX: TODO: Improve message!!!";
									int rr = javax.swing.JOptionPane.showConfirmDialog(null, cMesg, 
												"Confirmation - EVENT-DISPATCHER", javax.swing.JOptionPane.YES_NO_OPTION);
									if (rr!=javax.swing.JOptionPane.YES_OPTION) {
										// if user answers 'No' then we should set 'advise' to 'null'
										advise = null;
									} 
								}
							}
						}
// XXX: TODO
//  Advise should be a process URI.
//  WT engine must check if it has already loaded it
//  if not it MUST !!!
//  Then process is executed
						aop.queryPointcutReply(advise);
					} else {
						debug("    EVENT-DISPATCHER: SYNC:  No pending query event with Id="+qeId);
					}
				} else {
					debug("    EVENT-DISPATCHER: SYNC:  Pending query events queue is empty");
				}
			} else
			
			// process ASYNCHRONOUS adaptation reply event
			if (type.trim().equals( dsbProperties.getProperty("async.recom.event.type") )) {
				
				// event filtering based on event subtype
				if (!subtype.trim().equals( dsbProperties.getProperty("async.recom.event.subtype") )) {
					debug("    EVENT-DISPATCHER: ASYNC:  Wrong event subtype: "+subtype);
					return false;
				}
				
				// collect info specific to asynchronous mode
				String engineId = getValue(nodeXml, dsbProperties.getProperty("async.recom.event.engine.attrib"));
				String sessionId = getValue(nodeXml, dsbProperties.getProperty("async.recom.event.session.attrib"));
				String mesg = getValue(nodeXml, dsbProperties.getProperty("async.recom.event.message.attrib"));
				String aspects = getValue(nodeXml, dsbProperties.getProperty("async.recom.event.aspects.attrib"));
				String action = getValue(nodeXml, dsbProperties.getProperty("async.recom.event.action.attrib"));
				String processes = getValue(nodeXml, dsbProperties.getProperty("async.recom.event.processes.attrib"));
				
				engineId = (engineId==null) ? "" : engineId.trim();
				sessionId = (sessionId==null) ? "" : sessionId.trim();
				mesg = (mesg==null) ? "" : mesg.trim();
				aspects = (aspects==null) ? "" : aspects.trim();
				action = (action==null) ? "" : action.trim();
				processes = (processes==null) ? "" : processes.trim();
				
				debug("    Engine Id:      "+engineId);
				debug("    Session Id:     "+sessionId);
				debug("    Message:        "+mesg);
				debug("    Aspect URIs:    "+aspects);
				debug("    Process URIs:   "+processes);
				debug("    Action:         "+action);
				debug("");
				
				// Get aspects array
				String[] aspect = aspects.split("[ \t]");
				for (int i=0; i<aspect.length; i++) aspect[i] = aspect[i].trim();
				
				// Get processes array
				String[] process = processes.split("[ \t]");
				for (int i=0; i<process.length; i++) process[i] = process[i].trim();
				
				// check recommendation (aspect or process) weaving mode
				String weaveStr = dsbProperties.getProperty("common.recom.weaving");
				WEAVING_MODE weaveMode = WEAVING_MODE.ACCEPT;
				if (weaveStr!=null && !weaveStr.trim().equals("")) {
					try { weaveMode = WEAVING_MODE.valueOf(weaveStr); } catch (Exception e) {}
					if (weaveMode==WEAVING_MODE.ACCEPT) ;
					else if (weaveMode==WEAVING_MODE.REJECT) aspect = null;
					else if (weaveMode==WEAVING_MODE.ASK_USER ||
							 weaveMode==WEAVING_MODE.RECOM_SUGGESTION && askUser)
					{
						int notNull = 0;
						for (int i=0; i<aspect.length; i++) {
							String cMesg = "ASYNC: Aspect "+aspect[i]+" is recommended!!\n\n XXX: TODO: Improve message!!!";
							int rr = javax.swing.JOptionPane.showConfirmDialog(null, cMesg, 
										"Confirmation - EVENT-DISPATCHER", javax.swing.JOptionPane.YES_NO_OPTION);
							if (rr!=javax.swing.JOptionPane.YES_OPTION) {
								// aspect weaving rejected by user
								aspect[i] = null;
							} 
							else notNull++;
						}
						String[] tmp = aspect;
						aspect = null;
						if (notNull>0) {
							aspect = new String[notNull];
							for (int i=0, j=0; i<tmp.length; i++) {
								if (tmp[i]!=null) aspect[j++] = tmp[i];
							}
						}
					}
				}
				
// ++++++++++++++++++++++++++++++++++++++++
// XXX: TODO :  find target engine/session and deploy adaptation
// check if adaptation recommendation is for this engine - (*) means all engines

				// Find target session. (*) means all active sessions
				if (aspect!=null) {
					for (AdaptWorkSession s : AdaptSessionRegistry.getSessions().values()) {
						if (sessionId.equals("*") || sessionId.equals(s.getId())) {
							if (action.equalsIgnoreCase("activate-aspect")) {
								for (int i=0; i<aspect.length; i++) {
									activateAspect(s, aspect[i], true);
								}
							} else
							if (action.equalsIgnoreCase("deactivate-aspect")) {
								for (int i=0; i<aspect.length; i++) {
									deactivateAspect(s, aspect[i]);
								}
							} else
							if (action.equalsIgnoreCase("add-aspect")) {
								for (int i=0; i<aspect.length; i++) {
									loadAndAddAspects(s, aspect[i]);
								}
							} else
							if (action.equalsIgnoreCase("remove-aspect")) {
								for (int i=0; i<aspect.length; i++) {
									removeAspect(s, aspect[i]);
								}
							} else
							if (action.equalsIgnoreCase("start-process")) {
								for (int i=0; i<process.length; i++) {
									startProcess(s, process[i]);
								}
							} else
							if (!action.equals("")) {
								System.out.println("    EVENT-DISPATCHER: ASYNC:  Unknown action in adaptation recommendation: "+action);
							}
						}
					}
				}
			} else {
				System.out.println("    EVENT-DISPATCHER:  Wrong event type: "+type);
			}
			
			return true;
		}
		
		protected String getTypeValue(String xml, String attrib) {
			int p1 = xml.indexOf(attrib);
			p1 = xml.indexOf(":", p1 + attrib.length());
			int p2 = xml.indexOf(";", p1+1);
			int p2b = xml.indexOf(".", p1+1);
			if (p2>-1 && p2b>-1) p2 = (p2>p2b ? p2b : p2);
			else if (p2b>-1) p2 = p2b;
			if (p2>p1+1) {
				return xml.substring(p1+1, p2);
			}
			return "";
		}
		
		protected String getValue(String xml, String attrib) {
			int p1 = xml.indexOf(attrib);
			p1 = xml.indexOf("\"", p1 + attrib.length());
			int p2 = xml.indexOf("\"", p1+1);
			if (p2>p1+1) {
				return xml.substring(p1+1, p2);
			}
			return "";
		}
	}
	
	// ===================================================================================================
	
	/*
	 *  INTERNAL Adaptation Mode methods
	 */
	
	protected static Hashtable<AdaptWorkSession,Hashtable<String,Aspect>> aspectsPerSession;
	
	public static void processAspectDefinitions(AdaptWorkSession session, Vector<String> aspectURI) {
		if (aspectURI==null) return ;
		for (int i=0, n=aspectURI.size(); i<n; i++) {
			String uri = aspectURI.elementAt(i);
			loadAndAddAspects(session, uri);
		}
	}
	
	public static Aspect[] loadAspects(String url) {
		// URL may have the form <Resource-URL> # <Aspect-Id>
		String tmp = url;
		int p = tmp.lastIndexOf("#");
		url = (p==-1) ? tmp : tmp.substring(0,p).trim();
		String id = (p>-1 && p+1<tmp.length()) ? tmp.substring(p+1).trim() : null;
		
		String xml = org.iccs.san.util.SANHelper.getResourceContent(url);
		if (xml==null) return null;
		
		com.worktoken.adapt.XMLHelper xmlHelper = new com.worktoken.adapt.XMLHelper();
		
		try {
			org.w3c.dom.NodeList nodes = xmlHelper.getNodeListByXPath(xml, "/aspects/aspect");
			if (nodes==null || nodes.getLength()==0) return null;
			
			Vector<Aspect> aspects = new Vector<Aspect>();
			for (int i=0, n=nodes.getLength(); i<n; i++) {
				org.w3c.dom.Node node = nodes.item(i);
				String nodeXml = xmlHelper.getNodeXml(node);
				Aspect aspect = Aspect.parse(url, nodeXml);
				if (aspect!=null) {
					// If no aspect Id is specified or Id equals to aspect's id then add aspect...
					if (id==null || id.equals("") || id.equals(aspect.getId())) {
						aspects.add(aspect);
					}
				}
			}
			
			return aspects.toArray(new Aspect[0]);
		} catch (Exception ex) {
			return null;
		}
	}
	
	public static Aspect[] loadAndAddAspects(AdaptWorkSession session, String aspectUri) {
		System.out.print("Loading aspects from "+aspectUri+"...");
		System.out.flush();
		Aspect[] aspects = loadAspects(aspectUri);
		boolean succ = false;
		boolean fail = false;
		if (aspects!=null) {
			for (int i=0; i<aspects.length; i++) {
				if (aspects[i]!=null) {
					succ = true;
				} else {
					fail = true;
				}
			}
		} else {
			fail = true;
		}
		System.out.println( succ && fail ? "partially ok" : (succ ? "ok" : (fail ? "fail" : "nothing to do")) );
		
		if (aspects!=null) {
			for (int i=0; i<aspects.length; i++) {
				if (aspects[i]!=null) {
					addAspect(session, aspects[i]);
				}
			}
		}
		return aspects;
	}
	
	public static Aspect addAspect(AdaptWorkSession session, Aspect aspect) {
		if (aspectsPerSession==null) aspectsPerSession = new Hashtable<AdaptWorkSession,Hashtable<String,Aspect>>();
		Hashtable<String,Aspect> sessionAspects = aspectsPerSession.get(session);
		if (sessionAspects==null) {
			sessionAspects = new Hashtable<String,Aspect>();
			aspectsPerSession.put(session, sessionAspects);
		}
		String uri = aspect.getURI();
		Aspect oldAspect = aspect;
		if (!sessionAspects.containsKey(uri)) {
			oldAspect = sessionAspects.get(uri);
		}
		sessionAspects.put(uri, aspect);
		return oldAspect;
	}
	
	public static Aspect removeAspect(AdaptWorkSession session, Aspect aspect) {
		String uri = aspect.getURI();
		return removeAspect(session, uri);
	}
	
	public static Aspect removeAspect(AdaptWorkSession session, String aspectUri) {
		if (aspectsPerSession==null) return null;
		Hashtable<String,Aspect> sessionAspects = aspectsPerSession.get(session);
		if (sessionAspects==null) return null;
		Aspect tmp = sessionAspects.remove(aspectUri);
		if (tmp!=null) System.out.println("** Aspect removed: "+aspectUri+" from session: "+session.getId());
		return tmp;
	}
	
	public static void activateAspect(AdaptWorkSession session, String aspectUri) {
		setAspectActivationState(session, aspectUri, true, false);
	}
	
	public static void activateAspect(AdaptWorkSession session, String aspectUri, boolean create) {
		setAspectActivationState(session, aspectUri, true, create);
	}
	
	public static void deactivateAspect(AdaptWorkSession session, String aspectUri) {
		setAspectActivationState(session, aspectUri, false, false);
	}
	
	protected static void setAspectActivationState(AdaptWorkSession session, String aspectUri, boolean newState, boolean create) {
		if (!create) {
			if (aspectsPerSession==null) return;
			Hashtable<String,Aspect> sessionAspects = aspectsPerSession.get(session);
			if (sessionAspects==null) return;
			Aspect aspect = sessionAspects.get(aspectUri);
			if (aspect==null) return;
			aspect.setActive(newState);
			logStatusChange(session, aspectUri, newState, false);
		} else {
			boolean addAspect = false;
			if (aspectsPerSession==null) addAspect = true;
			else if (aspectsPerSession.get(session)==null) addAspect = true;
			else if (aspectsPerSession.get(session).get(aspectUri)==null) addAspect = true;
			if (addAspect) {
				Aspect[] aspect = loadAndAddAspects(session, aspectUri);
				if (aspect!=null) {
					for (int i=0; i<aspect.length; i++) {
						aspect[i].setActive(newState);
						logStatusChange(session, aspect[i].getURI(), newState, true);
						aspect[i].execInterruptTaskDirectives(session);
					}
				}
			} else {
				aspectsPerSession.get(session).get(aspectUri).setActive(newState);
				logStatusChange(session, aspectUri, newState, false);
			}
		}
	}
	
	protected static void logStatusChange(AdaptWorkSession session, String aspectUri, boolean newState, boolean created) {
		String action = (created) ? ( newState ? "added and activated" : "added and deactivated" ) : ( newState ? "activated" : "deactivated" );
		System.out.printf("** Aspect %s: %s on session %s\n", action, aspectUri, session.getId());
	}
	
	public Aspect[] getSessionAspects() {
		return getSessionAspects(session);
	}
	
	public static Aspect[] getSessionAspects(AdaptWorkSession session) {
		if (aspectsPerSession==null) return null;
		Aspect[] tmp = new Aspect[ aspectsPerSession.get(session).size() ];
		int i=0;
		for (Aspect a : aspectsPerSession.get(session).values()) {
			tmp[i++] = a;
		}
		return tmp;
	}
	
	public static Aspect getSessionAspectById(AdaptWorkSession session, String aid) {
		if (aspectsPerSession==null) return null;
		if (aid==null || aid.trim().equals("")) return null;
		aid = aid.trim();
		for (Aspect a : aspectsPerSession.get(session).values()) {
			if (a.getId().equals(aid)) return a;
		}
		return null;
	}
	
	public static Aspect getSessionAspectByURI(AdaptWorkSession session, String uri) {
		if (aspectsPerSession==null) return null;
		if (uri==null || uri.trim().equals("")) return null;
		uri = uri.trim();
		for (Aspect a : aspectsPerSession.get(session).values()) {
			if (a.getURI().equals(uri)) return a;
		}
		return null;
	}
	
	public static Aspect[] getAllAspects() {
		if (aspectsPerSession==null) return null;
		Vector<Aspect> tmp = new Vector<Aspect>();
		for (AdaptWorkSession s : aspectsPerSession.keySet()) {
			Hashtable<String,Aspect> ht = aspectsPerSession.get(s);
			for (Aspect a : ht.values()) {
				tmp.add(a);
			}
		}
		return tmp.toArray(new Aspect[0]);
	}
	
	/*
	 *  Return the first matching Aspect/Advise
	 */
	public static Advise getMatchingAdvise(AdaptWorkSession session, BusinessProcess process, Node node, ADAPTATION_TYPE filterByType) {
		if (aspectsPerSession==null) return null;
		if (aspectsPerSession.get(session)==null) return null;
		
		for (Aspect aspect : aspectsPerSession.get(session).values()) {
			if (!aspect.isActive()) continue;
			
			Pointcut matchedPcut = null;
			for (Pointcut pcut : aspect.pointcuts()) {
				if (!pcut.isActive()) continue;
				if (!pcut.checkJoinPoint(process, node)) continue;
				if (!pcut.checkCondition()) continue;
				matchedPcut = pcut;
				break;
			}
			if (matchedPcut==null) continue;
			
			for (Advise adv : aspect.advises()) {
				if (!adv.isActive()) continue;
				if (!adv.checkPointcut(matchedPcut)) continue;
				if (filterByType!=null && filterByType!=adv.getAdaptationType()) continue;
				return adv;
			}
		}
		return null;
	}
	
	public static void startProcess(AdaptWorkSession session, String processId) {
		System.out.print("Starting process "+processId+" in session "+session.getId());
		try {
			session.createProcess(processId);
		} catch (Throwable t) {
			System.err.println("Process '"+processId+"' failed to start in session "+session.getId()+". Reason: "+t.getMessage());
			t.printStackTrace(System.err);
		}
	}
	
	/*
	 *  Return a vector of all matching Aspects/Advises
	 */
	public static Vector<Advise> checkAspects(AdaptWorkSession session, BusinessProcess process, Node node) {
		Vector<Pointcut> matchedPcuts = new Vector<Pointcut>();
		Vector<Advise> matchedAdvises = new Vector<Advise>();
		for (Aspect aspect : aspectsPerSession.get(session).values()) {
			if (!aspect.isActive()) continue;
			
			matchedPcuts.clear();
			for (Pointcut pcut : aspect.pointcuts()) {
				if (!pcut.isActive()) continue;
				if (!pcut.checkJoinPoint(process, node)) continue;
				if (!pcut.checkCondition()) continue;
				matchedPcuts.add(pcut);
			}
			if (matchedPcuts.size()==0) continue;
			
			for (Advise adv : aspect.advises()) {
				if (!adv.isActive()) continue;
				if (!adv.checkPointcuts(matchedPcuts)) continue;
				matchedAdvises.add(adv);
			}
		}
		return matchedAdvises;
	}
	
	public static class Aspect {
		protected static com.worktoken.adapt.XMLHelper xmlHelper = new com.worktoken.adapt.XMLHelper();
		
		public static Aspect parse(String aspectUri, String nodeXml) {
			try {
				String id   = xmlHelper.getXPathValue(nodeXml, "/aspect/id/text()");
				String name = xmlHelper.getXPathValue(nodeXml, "/aspect/name/text()");
				String dscr = xmlHelper.getXPathValue(nodeXml, "/aspect/description/text()");
				String flag = xmlHelper.getXPathValue(nodeXml, "/aspect/active/text()");
				String once = xmlHelper.getXPathValue(nodeXml, "/aspect/once-off/text()");
				id = (id==null) ? "" : id.trim();
				name = (name==null) ? "" : name.trim();
				dscr = (dscr==null) ? "" : dscr.trim();
				flag = (flag==null) ? "" : flag.trim().toLowerCase();
				once = (once==null) ? "" : once.trim().toLowerCase();
				
				String uri = aspectUri+"#"+id;
				boolean active = flag.equals("yes") || flag.equals("on") || flag.equals("true") || flag.equals("1");
				boolean onceOff = once.equals("yes") || once.equals("on") || once.equals("true") || once.equals("1");
				
				// set aspect's metadata
				Aspect aspect = new Aspect();
				aspect.setId(id);
				aspect.setURI(uri);
				aspect.setName(name);
				aspect.setDescription(dscr);
				aspect.setActive(active);
				aspect.setOnceOff(onceOff);
				
				// parse aspect's pointcuts
				org.w3c.dom.NodeList pcuts = xmlHelper.getNodeListByXPath(nodeXml, "/aspect/pointcuts/pointcut");
				if (pcuts!=null && pcuts.getLength()>0) {
					for (int i=0, n=pcuts.getLength(); i<n; i++) {
						org.w3c.dom.Node nodePcuts = pcuts.item(i);
						String pcutXml = xmlHelper.getNodeXml(nodePcuts);
						Pointcut pcut = Pointcut.parse(aspect, pcutXml);
						if (pcut!=null) aspect.addPointcut(pcut);
					}
				}
				
				// parse aspect's advises
				org.w3c.dom.NodeList advs = xmlHelper.getNodeListByXPath(nodeXml, "/aspect/advises/advise");
				if (advs!=null && advs.getLength()>0) {
					for (int i=0, n=advs.getLength(); i<n; i++) {
						org.w3c.dom.Node nodeAdvs = advs.item(i);
						String advXml = xmlHelper.getNodeXml(nodeAdvs);
						Advise adv = Advise.parse(aspect, advXml);
						if (adv!=null) aspect.addAdvise(adv);
					}
				}
				
				return aspect;
				
			} catch (Exception ex) {
				return null;
			}
		}
		
		protected String id;
		protected String uri;
		protected String name;
		protected String description;
		protected boolean active;
		protected boolean onceOff;
		protected Hashtable<String,Pointcut> pointcuts;
		protected Hashtable<String,Advise> advises;
		
		public Aspect() {
			pointcuts = new Hashtable<String,Pointcut>();
			advises = new Hashtable<String,Advise>();
		}
		
		public String toString() {
			return toString("");
		}
		
		public String toString(String ident) {
			String str = ident+"ASPECT: \n"+
						ident+"{\n"+
						ident+"    id="+id+"\n"+
						ident+"    uri="+uri+"\n"+
						ident+"    name="+name+"\n"+
						ident+"    active="+active+"\n"+
						ident+"    once-off="+onceOff+"\n"+
						ident+"    description="+description+"\n";
			String ident1 = ident+"    ";
			for (Pointcut p : pointcuts.values()) {
				str += p.toString(ident1);
			}
			for (Advise a : advises.values()) {
				str += a.toString(ident1);
			}
			str += ident+"}\n";
			return str;
		}
		
		public String getId() { return id; }
		public void setId(String id) { this.id = id; }
		public String getURI() { return uri; }
		public void setURI(String uri) { this.uri = uri; }
		public String getName() { return name; }
		public void setName(String name) { this.name = name; }
		public String getDescription() { return description; }
		public void setDescription(String description) { this.description = description; }
		public boolean isActive() { return active; }
		public void setActive(boolean active) { this.active = active; }
		public boolean isOnceOff() { return onceOff; }
		public void setOnceOff(boolean onceOff) { this.onceOff = onceOff; }
		
		public void addPointcut(Pointcut pc) { pointcuts.put(pc.getURI(), pc); }
		public void removePointcut(Pointcut pc) { pointcuts.remove(pc.getURI()); }
		public void removePointcut(String uri) { pointcuts.remove(uri); }
		public Pointcut getPointcut(String uri) { return pointcuts.get(uri); }
		public Collection<Pointcut> pointcuts() { return pointcuts.values(); }
		
		public void addAdvise(Advise advise) { advises.put(advise.getURI(), advise); }
		public void removeAdvise(Advise advise) { advises.remove(advise.getURI()); }
		public void removeAdvise(String uri) { advises.remove(uri); }
		public Advise getAdvise(String uri) { return advises.get(uri); }
		public Collection<Advise> advises() { return advises.values(); }
		
		public void execInterruptTaskDirectives(AdaptWorkSession session) {
			if (!isActive()) return;
			
			// Apply immediately any interrupt-task directives
			for (Pointcut pcut : pointcuts()) {
				if (pcut.getInterruptTask()==false) continue;
				String pdef = pcut.getJoinPointProcess();
				long pid = pcut.getJoinPointProcessId();
				String ndef = pcut.getJoinPointNode();
				long nid = pcut.getJoinPointNodeId();
				session.interruptExecutingTask(pdef, pid, ndef, nid);
			}
		}
	}
	
	public static class Pointcut {
		protected static com.worktoken.adapt.XMLHelper xmlHelper = new com.worktoken.adapt.XMLHelper();
		
		public static Pointcut parse(Aspect aspect, String nodeXml) {
			try {
				String id = xmlHelper.getXPathValue(nodeXml, "/pointcut/id/text()");
				String name = xmlHelper.getXPathValue(nodeXml, "/pointcut/name/text()");
				String dscr = xmlHelper.getXPathValue(nodeXml, "/pointcut/description/text()");
				String flag = xmlHelper.getXPathValue(nodeXml, "/pointcut/active/text()");
				String jpnt = xmlHelper.getXPathValue(nodeXml, "/pointcut/join-point/text()");
				String cond = xmlHelper.getXPathValue(nodeXml, "/pointcut/condition/text()");
				String intr = xmlHelper.getXPathValue(nodeXml, "/pointcut/interrupt-task/text()");
				
				id = (id==null) ? "" : id.trim();
				name = (name==null) ? "" : name.trim();
				dscr = (dscr==null) ? "" : dscr.trim();
				flag = (flag==null) ? "" : flag.trim().toLowerCase();
				jpnt = (jpnt==null) ? "" : jpnt.trim();
				cond = (cond==null) ? "" : cond.trim();
				intr = (intr==null) ? "" : intr.trim();
				
				String uri = aspect.getURI()+"#"+id;
				boolean active = flag.equals("yes") || flag.equals("on") || flag.equals("true") || flag.equals("1");
				boolean interrupt = org.iccs.san.util.Configurator.checkBoolean(intr, false);
				
				// set pointcut's metadata
				Pointcut pointcut = new Pointcut(aspect);
				pointcut.setId(id);
				pointcut.setURI(uri);
				pointcut.setName(name);
				pointcut.setDescription(dscr);
				pointcut.setActive(active);
				pointcut.setJoinPoint(jpnt);
				pointcut.setCondition(cond);
				pointcut.setInterruptTask(interrupt);
				
				return pointcut;
				
			} catch (Exception e) {
				return null;
			}
		}
		
		protected Aspect aspect;
		protected String id;
		protected String uri;
		protected String name;
		protected String description;
		protected boolean active;
		protected String joinPoint;
		protected String joinPointProcess, joinPointNode;
		protected long joinPointProcessId, joinPointNodeId;
		protected String condition;
		protected boolean interruptTask;
		
		public Pointcut(Aspect aspect) {
			this.aspect = aspect;
		}
		
		public Aspect getAspect() { return aspect; }
		
		public String toString() {
			return toString("");
		}
		
		public String toString(String ident) {
			return ident+"POINTCUT: \n"+
					ident+"{\n"+
					ident+"    id="+id+"\n"+
					ident+"    uri="+uri+"\n"+
					ident+"    name="+name+"\n"+
					ident+"    active="+active+"\n"+
					ident+"    join-point="+joinPoint+"   ["+joinPointProcess+"="+(joinPointProcessId==-1?"*":joinPointProcessId)+" : "+joinPointNode+"="+(joinPointNodeId==-1?"*":joinPointNodeId)+"]\n"+
					ident+"    condition="+condition+"\n"+
					ident+"    interrupt-task="+interruptTask+"\n"+
					ident+"    description="+description+"\n"+
					ident+"}\n";
		}
		
		public String getId() { return id; }
		public void setId(String id) { this.id = id; }
		public String getURI() { return uri; }
		public void setURI(String uri) { this.uri = uri; }
		public String getName() { return name; }
		public void setName(String name) { this.name = name; }
		public String getDescription() { return description; }
		public void setDescription(String description) { this.description = description; }
		public boolean isActive() { return active; }
		public void setActive(boolean active) { this.active = active; }
		public String getJoinPoint() { return joinPoint; }
		public void setJoinPoint(String joinPoint) {
			this.joinPoint = joinPoint;
			String[] part = joinPoint.split(":");
			this.joinPointProcess = part[0].trim();
			this.joinPointNode = (part.length>1) ? part[1].trim() : "*";
			
			part = joinPointProcess.split("=");
			this.joinPointProcess = part[0].trim();
			try { this.joinPointProcessId = (part.length>1) ? Long.parseLong(part[1].trim()) : -1; } 
			catch (Exception ex) { System.err.println("AOP:Pointcut:setJoinPoint: Error while parsing Process Id: "+ex); this.joinPointProcessId = -1; }
			
			part = joinPointNode.split("=");
			this.joinPointNode = part[0].trim();
			try { this.joinPointNodeId = (part.length>1) ? Long.parseLong(part[1].trim()) : -1; } 
			catch (Exception ex) { System.err.println("AOP:Pointcut:setJoinPoint: Error while parsing Node Id: "+ex); this.joinPointNodeId = -1; }
		}
		public String getJoinPointProcess() { return joinPointProcess; }
		public long getJoinPointProcessId() { return joinPointProcessId; }
		public String getJoinPointNode() { return joinPointNode; }
		public long getJoinPointNodeId() { return joinPointNodeId; }
		//
		public String getCondition() { return condition; }
		public void setCondition(String condition) { this.condition = condition; }
		public boolean getInterruptTask() { return interruptTask; }
		public void setInterruptTask(boolean intr) { this.interruptTask = intr; }
		
		public boolean checkJoinPoint(BusinessProcess process, Node node) {
			long pid = process.getId();
			long nid = node.getId();
			boolean rr = ((process.getDefId().equals(joinPointProcess) || joinPointProcess.equals("*")) &&
					(node.getDefId().equals(joinPointNode) || joinPointNode.equals("*")) &&
					(joinPointProcessId==pid || joinPointProcessId==-1) &&
					(joinPointNodeId==nid || joinPointNodeId==-1) );
/*System.out.println("checkJoinpoint\n"+
	"\nProcess: "+process.getDefId()+":"+pid+"  --> "+joinPointProcess+":"+joinPointProcessId+
	"\nNode:    "+node.getDefId()+":"+nid+"  --> "+joinPointNode+":"+joinPointNodeId+
	"\n\nRESULT = "+rr);
org.iccs.worktoken.model.JavascriptHelper.alert("CHECK OUTPUT");*/
			return rr;
		}
		
		public boolean checkCondition() {
			return true;
		}
	}
	
	public static enum ADAPTATION_TYPE {
		BEFORE_ADAPTATION, AFTER_ADAPTATION, AROUND_ADAPTATION, REPLACE_ADAPTATION, SKIP_ADAPTATION, COMPOSITE_ADAPTATION, UNKNOWN_ADAPTATION
	};
	
	public static class Advise {
		protected static com.worktoken.adapt.XMLHelper xmlHelper = new com.worktoken.adapt.XMLHelper();
		
		public static Advise parse(Aspect aspect, String nodeXml) {
			try {
				String id = xmlHelper.getXPathValue(nodeXml, "/advise/id/text()");
				String name = xmlHelper.getXPathValue(nodeXml, "/advise/name/text()");
				String dscr = xmlHelper.getXPathValue(nodeXml, "/advise/description/text()");
				String flag = xmlHelper.getXPathValue(nodeXml, "/advise/active/text()");
				String pcuts= xmlHelper.getXPathValue(nodeXml, "/advise/pointcuts/text()");
				String proc = xmlHelper.getXPathValue(nodeXml, "/advise/process/text()");
				String type = xmlHelper.getXPathValue(nodeXml, "/advise/adaptation-type/text()");
				
				id = (id==null) ? "" : id.trim();
				name = (name==null) ? "" : name.trim();
				dscr = (dscr==null) ? "" : dscr.trim();
				flag = (flag==null) ? "" : flag.trim().toLowerCase();
				pcuts= (pcuts==null) ? "" : pcuts.trim();
				proc = (proc==null) ? "" : proc.trim();
				type = (type==null) ? null : type.trim().toUpperCase();
				
				String uri = aspect.getURI()+"#"+id;
				boolean active = flag.equals("yes") || flag.equals("on") || flag.equals("true") || flag.equals("1");
				int p = proc.lastIndexOf("#");
				String procId  = (p>-1) ? ((p+1<proc.length()) ? proc.substring(p+1).trim() : null) : proc;
				String procUri = (p>-1) ? proc.substring(0, p).trim() : null;
				
				// set advise's metadata
				Advise advise = new Advise(aspect);
				advise.setId(id);
				advise.setURI(uri);
				advise.setName(name);
				advise.setDescription(dscr);
				advise.setActive(active);
				advise.setRelatedPointcuts(pcuts.split(":"));
				advise.setProcessId(procId);
				advise.setProcessURI(procUri);
				if (type!=null && !type.equals("")) advise.setAdaptationType( ADAPTATION_TYPE.valueOf(type) );
				
				return advise;
				
			} catch (Exception e) {
				return null;
			}
		}
		
		protected Aspect aspect;
		protected String id;
		protected String uri;
		protected String name;
		protected String description;
		protected boolean active;
		protected String[] relatedPointcuts;
		protected String processId;
		protected String processURI;
		protected ADAPTATION_TYPE adaptationType = ADAPTATION_TYPE.UNKNOWN_ADAPTATION;
		
		public Advise(Aspect aspect) {
			this.aspect = aspect;
		}
		
		public Aspect getAspect() { return aspect; }
		
		public String toString() {
			return toString("");
		}
		
		public String toString(String ident) {
			StringBuilder pcuts = new StringBuilder();
			String comma = "";
			for (int i=0; i<relatedPointcuts.length; i++) {
				pcuts.append(comma);
				pcuts.append(relatedPointcuts[i]);
				comma = ", ";
			}
			return ident+"ADVISE: \n"+
					ident+"{\n"+
					ident+"    id="+id+"\n"+
					ident+"    uri="+uri+"\n"+
					ident+"    name="+name+"\n"+
					ident+"    active="+active+"\n"+
					ident+"    pointcuts="+pcuts.toString()+"\n"+
					ident+"    process-id="+processId+"\n"+
					ident+"    process-uri="+processURI+"\n"+
					ident+"    description="+description+"\n"+
					ident+"    adaptation-type="+adaptationType+"\n"+
					ident+"}\n";
		}
		
		public String getId() { return id; }
		public void setId(String id) { this.id = id; }
		public String getURI() { return uri; }
		public void setURI(String uri) { this.uri = uri; }
		public String getName() { return name; }
		public void setName(String name) { this.name = name; }
		public String getDescription() { return description; }
		public void setDescription(String description) { this.description = description; }
		public boolean isActive() { return active; }
		public void setActive(boolean active) { this.active = active; }
		public ADAPTATION_TYPE getAdaptationType() { return this.adaptationType; }
		public void setAdaptationType(ADAPTATION_TYPE atype) { this.adaptationType = atype; }
		
		public String[] getRelatedPointcuts() { return relatedPointcuts; }
		public void setRelatedPointcuts(String[] relPcuts) {
			this.relatedPointcuts = relPcuts; 
			for (int i=0; i<relPcuts.length; i++) {
				relPcuts[i] = relPcuts[i].trim();
			}
		}
		public String getProcessId() { return processId; }
		public void setProcessId(String processId) { this.processId = processId; }
		public String getProcessURI() { return processURI; }
		public void setProcessURI(String processURI) { this.processURI = processURI; }
		
		public boolean checkPointcut(Pointcut pointcut) {
			if (relatedPointcuts==null) return true;
			if (pointcut.getAspect()!=getAspect()) return false;
			String pcId = pointcut.getId();
			for (int i=0; i<relatedPointcuts.length; i++) {
				if (relatedPointcuts[i].equals(pcId)) return true;
				if (relatedPointcuts[i].equals("*")) return true;
			}
			return false;
		}
		
		public boolean checkPointcuts(Vector<Pointcut> pointcuts) {
			Enumeration<Pointcut> en = pointcuts.elements();
			while (en.hasMoreElements()) {
				if (checkPointcut( en.nextElement() )) return true;
			}
			return false;
		}
	}
}
