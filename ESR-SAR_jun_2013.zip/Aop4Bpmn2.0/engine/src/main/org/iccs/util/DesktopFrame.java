/*
 *  ++++++++++++++++++++++++++++++++++++
 */

package org.iccs.util;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JDesktopPane;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.Box;
import javax.swing.*;

public class DesktopFrame extends JFrame 
{
	// test method
	public static void main(String[] args) {
		DesktopFrame.Handler fh;
		
		fh = DesktopFrame.getInstance().openMessage("title A", "message A", Boolean.parseBoolean(args[0]));
		fh.waitForUserAction();
		System.out.println("Action="+fh.getAction()+", Value="+fh.getInput()+"\n\n");
		
		fh = DesktopFrame.getInstance().openInput("title B", "message B", "coco", Boolean.parseBoolean(args[0]));
		fh.waitForUserAction();
		System.out.println("Action="+fh.getAction()+", Value="+fh.getInput()+"\n\n");
		
		String[] options = { "Alpha", "Beta", "Gamma", "Delta" };
		final DesktopFrame.Handler fh2 = DesktopFrame.getInstance().openChoice("title A", "message A", options, 2, Boolean.parseBoolean(args[0]));
/*		new Thread(new Runnable() {
			public void run() {
				try { Thread.currentThread().sleep(5000); } catch (Exception e) {}
				System.out.println("Trying to close dialog...");
				fh2.close();
			}
		}).start();*/
		fh2.waitForUserAction();
		System.out.println("Action="+fh2.getAction()+", Value="+fh2.getInput());
		
		DesktopFrame.getInstance().alert("AAAAAAAAAAAAA");
		
		System.out.println( DesktopFrame.getInstance().confirm("OOOOOOOOOO") );
		
		System.out.println( DesktopFrame.getInstance().prompt("XXXXXXXXXXXXXX", "rrrrrrrrr") );
		
		System.out.println( DesktopFrame.getInstance().choice("OOOOOOOOOO", "a=Alpha;b=Beta;c=Gamma") );
		
		Handler[] fhs = new Handler[10];
		for (int i=0; i<10; i++)
			fhs[i] = getInstance().openInput("Input-"+i, "Message-"+i, ""+i, false);
		for (int i=0; i<10; i++)
			System.out.println(fhs[i].getInput());
		
		DesktopFrame.getInstance().clearInstance();
	}
	
	//
	//  Static, singleton methods and fields
	//
	protected static DesktopFrame instance;
	
	public static DesktopFrame initInstance() {
		return initInstance("");
	}
	
	public static DesktopFrame initInstance(String title) {
		if (instance==null) {
			DesktopFrame desktopFrame = new DesktopFrame(false, title);
			instance = desktopFrame;
		}
		return instance;
	}
	
	public static DesktopFrame getInstance() {
		return getInstance(true);
	}
	
	public static DesktopFrame getInstance(boolean show) {
		if (instance==null) {
			DesktopFrame desktopFrame = new DesktopFrame(true, "");
			instance = desktopFrame;
		} else
		if (!instance.isVisible()) instance.setVisible(show);
		return instance;
	}
	
	public static void clearInstance() {
		if (instance!=null) {
			instance.closeDesktopFrame();
		}
		instance = null;
	}
	
	
	//
	//  The desktop frame
	//
	private JDesktopPane theDesktop;

	// constructor. Create the desktop frame
	protected DesktopFrame(boolean show, String title)
	{
		super( title );
		
		// setup menus
		JMenuBar bar = new JMenuBar(); // create menu bar
		JMenu engineMenu = new JMenu( "Engine" ); // create Add menu
		JMenuItem exitFrame = new JMenuItem( "Exit" );

		engineMenu.add( exitFrame ); // add new frame item to Add menu
		bar.add( engineMenu ); // add Add menu to menu bar
		setJMenuBar( bar ); // set menu bar for this application
		
		exitFrame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearInstance();
			}
		});
		
		// set window listener
		addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				clearInstance();
			}
		});
		
		// setup desktop pane
		theDesktop = new JDesktopPane(); // create desktop pane
		add( theDesktop ); // add desktop pane to frame
		
		setTitle(title);
		setDefaultCloseOperation( JFrame.DO_NOTHING_ON_CLOSE );
		setSize( 600, 480 ); // set frame size
		setVisible( show ); // display frame
		
	} // end constructor DesktopFrame
	
	public void closeDesktopFrame() {
		JInternalFrame[] frame = theDesktop.getAllFrames();
		for (int i=0; i<frame.length; i++) {
			frame[i].dispose();
		}
		dispose();
	}
	
	
	//
	//  Popup methods
	//
	protected static enum PopupType { MESSAGE_POPUP, CHOICE_POPUP, INPUT_POPUP };
	
	public Handler openMessage(String title, String message, boolean mandatory) {
		return createPopup(PopupType.MESSAGE_POPUP, title, message, null, -1, null, mandatory);
	}
	
	public Handler openInput(String title, String message, String initValue, boolean mandatory) {
		return createPopup(PopupType.INPUT_POPUP, title, message, null, -1, initValue, mandatory);
	}
	
	public Handler openChoice(String title, String message, String[] options, int initSelection, boolean mandatory) {
		return createPopup(PopupType.CHOICE_POPUP, title, message, options, initSelection, null, mandatory);
	}
	
	protected Handler createPopup(PopupType popupType, String title, String message, String[] options, int initSelection, String initValue, boolean mandatory) {
		Object __message;
		if (message==null) __message = "";
		else if (message.indexOf("\n")==-1) __message = message;
		else __message = message.split("[\n]");

		int optionType = mandatory ? JOptionPane.DEFAULT_OPTION : JOptionPane.OK_CANCEL_OPTION;
		JOptionPane pane = new JOptionPane(__message, JOptionPane.PLAIN_MESSAGE, optionType, null);
		
		if (popupType==PopupType.MESSAGE_POPUP) {
			// nothing to set
		} else
		if (popupType==PopupType.INPUT_POPUP) {
			pane.setWantsInput(true);
			String[] init = { initValue };
			pane.setInitialSelectionValue(init[0]);
		} else
		if (popupType==PopupType.CHOICE_POPUP) {
			pane.setSelectionValues(options);
			if (initSelection>=0 && initSelection<options.length) {
				pane.setInitialSelectionValue(options[initSelection]);
			}
		}
		
		JInternalFrame frame = pane.createInternalFrame(theDesktop, title);
		if (mandatory) {
			frame.setDefaultCloseOperation( JInternalFrame.DO_NOTHING_ON_CLOSE );
			frame.setClosable(false);
		}
		frame.setLocation(newX, newY);
		updateNewLocation(frame.getSize());
		frame.setVisible(true);
		
		return new Handler(frame, pane);
	}
	
	protected int newX, newY, incX, incY;
	
	protected void updateNewLocation(java.awt.Dimension size) {
		java.awt.Dimension d = theDesktop.getSize();
		incX = 30;
		incY = (int)(incX * d.height / d.width);
		newX += incX;
		newY += incY;
		if (newX+size.width>d.width) newX = newX+size.width-d.width;
		if (newY+size.height>d.height) newY = newY+size.height-d.height;
	}
	
	//
	//  Helper class used to control internal frames
	//
	public static class Handler {
		protected JInternalFrame frame;
		protected JOptionPane pane;
		protected String action;
		protected String input;
		protected boolean isOpen;
		
		protected Handler(JInternalFrame frame, JOptionPane pane) {
			this.frame = frame;
			this.pane = pane;
			isOpen = true;
		}
		
		public String getAction() {
			waitForUserAction();
			return action;
		}
		
		public String getInput() {
			waitForUserAction();
			return input;
		}
		
		public void waitForUserAction() {
			if (!isOpen) return;
			
			// wait until popup is closed
			while (frame.isVisible() && !frame.isClosed()) try { Thread.currentThread().sleep(500); } catch (InterruptedException e) {}
			
			// get values
			Object act = pane.getValue();
			Object inp = pane.getInputValue();
			
			// set action
			if (act instanceof Integer) {
				int opt = ((Integer)act).intValue();
				if (opt==pane.OK_OPTION) action = "OK";
				else if (opt==pane.CANCEL_OPTION) action = "CANCEL";
				else if (opt==pane.CLOSED_OPTION) action = "CANCEL";
				else action = "CANCEL";
			} else 
			if (act==JOptionPane.UNINITIALIZED_VALUE) {
				action = "CANCEL";
			} else {
				action = act.toString().toUpperCase();
			}
			
			// set input
			if (inp!=null && inp!=pane.UNINITIALIZED_VALUE ) {
				input = inp.toString();
			} else {
				input = null;
			}
			
			isOpen = false;
		}
		
		public void close() {
			frame.dispose();
		}
	}
	
	
	//
	//  JavaScript-like popup dialogs in Desktop frame
	//
	public void alert(String message) {
		alert("Alert", message);
	}
	
	public void alert(String title, String message) {
		//JOptionPane.showInternalMessageDialog(theDesktop, _prepMesg(mesg), title, JOptionPane.INFORMATION_MESSAGE);
		DesktopFrame.Handler fh = getInstance().openMessage(title, message, true);
		fh.waitForUserAction();
	}
	
	public boolean confirm(String message) {
		return confirm("Confirm", message);
	}
	
	public boolean confirm(String title, String message) {
		DesktopFrame.Handler fh = getInstance().openMessage(title, message, false);
		if (fh.getAction().equals("OK")) return true;
		else return false;
	}
	
	public String prompt(String message) {
		return prompt("Prompt", message, "");
	}
	
	public String prompt(String title, String message) {
		return prompt(title, message, "");
	}
	
	public String prompt(String title, String message, String initValue) {
		DesktopFrame.Handler fh = getInstance().openInput(title, message, initValue, false);
		return fh.getInput();
	}
	
	public String choice(String message, String options) {
		return choice("Choice", message, options, -1);
	}
	
	public String choice(String title, String message, String options, int defaultOption) {
		// process options, i.e. split to value-label pairs
		String[] pair = options.split("[;]");
		String[] dscr = new String[pair.length];
		String[] val = new String[pair.length];
		for (int i=0; i<pair.length; i++) {
			String tmp[] = pair[i].split("[:=]", 2);
			val[i] = tmp[0].trim();
			if (tmp.length>1) dscr[i] = tmp[1].trim();
			else dscr[i] = val[i];
		}
		
		// display choice dialog
		DesktopFrame.Handler fh = getInstance().openChoice(title, message, dscr, defaultOption, false);
		String sel = fh.getInput();
		
		// get value for selected label
		if (sel==null) return null;
		for (int i=0; i<dscr.length; i++) {
			if (dscr[i].equals(sel)) return val[i];
		}
		return null;
	}
	
} // end class DesktopFrame
