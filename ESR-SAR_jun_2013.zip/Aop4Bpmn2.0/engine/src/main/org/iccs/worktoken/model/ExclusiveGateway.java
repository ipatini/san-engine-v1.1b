/*
 * ++++++++++++++++++
 */

package org.iccs.worktoken.model;

import com.worktoken.model.Connector;
import com.worktoken.model.WorkToken;
import com.worktoken.engine.BPMNUtils;
import org.iccs.util.DesktopFrame;
import javax.xml.namespace.QName;
import org.omg.spec.bpmn._20100524.model.TExclusiveGateway;
import org.omg.spec.bpmn._20100524.model.TFlowElement;
import org.omg.spec.bpmn._20100524.model.TProcess;
import org.omg.spec.bpmn._20100524.model.TSequenceFlow;

import javax.persistence.Entity;

@Entity(name="IccsExclusiveGateway")
public class ExclusiveGateway extends com.worktoken.model.ExclusiveGateway {
	protected transient WorkToken token;
	protected transient Connector connector;
	
    /**
     * <p>Routes incoming token to the outgoing connector indicated by user. Pops up a dialog with the available routes</p>
     *
     * <p>If overridden in subclass, does not need to call parent method.</p>
     *
     * @param token incoming token
     * @param connectorIn incoming connector the token arrived through
     */
	@Override
	public void tokenIn(WorkToken token, Connector connectorIn) {
		TProcess tProcess = getProcess().getDefinition();
		TExclusiveGateway gateway = (TExclusiveGateway) BPMNUtils.getFlowNode(getDefId(), tProcess);
		String myname = gateway.getName()+" ("+getDefId()+":"+getId()+")".trim();
		
		// if the outgoing route is defined in token data then use it
		if (token!=null && token.getData()!=null && token.getData().containsKey(getDefinition().getName())) {
			Object route = token.getData().get(getDefinition().getName());
			if (route!=null && !route.toString().trim().equals("")) {
				TSequenceFlow link = BPMNUtils.find(route.toString().trim(), tProcess, TSequenceFlow.class);
				if (link!=null) {
					tokenOut(token, new Connector(link));
					return;
				}
			}
		}
		
		// get default route if any
		TSequenceFlow defaultRoute = BPMNUtils.findDefaultOutgoing(gateway, tProcess);
		String defaultRouteId = (defaultRoute!=null) ? defaultRoute.getId() : null;
		
		// get outgoing routes and build options for GUI
		StringBuffer sb = new StringBuffer();
		int cnt = 0;
		int defOption = -1;
		for (QName qName :  gateway.getOutgoing()) {
			TSequenceFlow link = BPMNUtils.find(qName.getLocalPart(), tProcess, TSequenceFlow.class);
			String linkName = link.getName();
			if (linkName==null) {
				// find target node's name
				Object target = link.getTargetRef();
				if (target!=null && target instanceof TFlowElement) {
					linkName = ((TFlowElement)target).getName();
				} else {
					// use 
					linkName = qName.getLocalPart();
				}
			}
			
			// add options
			String id = qName.getLocalPart();
			sb.append(id);
			sb.append(":");
			sb.append(linkName + (id.equals(defaultRouteId) ? " <default>" : ""));
			sb.append(";");
			if (id.equals(defaultRouteId)) defOption = cnt;
			cnt++;
		}
		
		// query user for route if more than 1 routes are available
		String input = null;
			if (cnt>1) {
			String title = "Exclusive Gateway: "+getDefinition().getName();
			String mesg = "Exclusive Gateway: ("+getDefId()+":"+getId()+") "+getDefinition().getName()+
							"\nProcess Id: "+getProcess().getId()+"\nRoutes:";
			
			String options = sb.toString();
			options = options.substring(0, sb.length()-1);
			input = DesktopFrame.getInstance().choice(title, mesg, options, defOption);
			System.out.println("** "+myname+": User selected route: "+input);
		} else
		if (cnt==1) {
			input = defaultRouteId;
		} else {
			System.err.println("**  "+myname+": No outgoing routes defined.  Invalid BPMN specification");
			throw new RuntimeException("No outgoing routes defined for exclusive gateway \"" + gateway.getId() + "\".  Invalid BPMN specification.");
		}
		
		// route token to the selected destination
		TSequenceFlow tSequenceFlow = null;
		if (input!=null) {
			tSequenceFlow = BPMNUtils.find(input, tProcess, TSequenceFlow.class);
			if (tSequenceFlow==null) System.err.println("**  "+myname+": Route not found: "+input);
		} else {
			System.out.println("");
			tSequenceFlow = defaultRoute;
			if (tSequenceFlow!=null) System.err.println("**  "+myname+": Using default route: "+tSequenceFlow.getId());
			else System.err.println("**  "+myname+": No default route");
		}
		if (tSequenceFlow != null) {
			tokenOut(token, new Connector(tSequenceFlow));
		} else {
			// TODO: add a link to error description
			throw new IllegalStateException("Can't route token out of exclusive gateway \"" + gateway.getId() + "\"");
		}
    }
}
