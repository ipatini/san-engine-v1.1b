/*
 *  +++++++++++++++
 */

package org.iccs.worktoken;

import com.worktoken.adapt.AdaptClassListAnnotationDictionary;
import com.worktoken.adapt.AdaptControlServiceFactory;
import com.worktoken.adapt.AdaptWorkSessionImpl;
import com.worktoken.adapt.AOP;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.io.IOException;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import java.util.logging.LogManager;
import java.util.Vector;

/**
 * @author ipatini
 */
public class CLI {

    private static Scanner scanner;
	
    public static void main(String[] args) throws SQLException, InterruptedException, IOException, ClassNotFoundException {
		System.out.println("WorkToken BPMN 2.0 engine with IMU AOP4BPMN support");
		System.out.println("Copyright (C) 2012.  Licensed under the Apache License, Version 2.0");
		System.out.println("For more info see README.TXT and http://www.apache.org/licenses/LICENSE-2.0\n");
		//System.out.println("  WorkToken:    by Rush Project Inc, (C) 2011, http://www.worktoken.com");
		//System.out.println("  IMU AOP4BPMN: by Information Management Unit, (C) 2012, http://imu.ntua.gr\n");
		
		String configFile = "/aop4bpmn2.properties";
		
		boolean hasInput = false;
		boolean aopOff = false;
		long exitDelay = 0;
		String exitDelayOpt = "-exit-delay:";
		for (int i=0; i<args.length; i++) {
			// check if at least one input (BPMN) file has been specified
			if (!args[i].startsWith("-")) {
				hasInput = true;
			}
			// set adaptation to off if specified
			if (args[i].equalsIgnoreCase("-aop:off")) {
				aopOff = true;
			}
			// set exit delay if specified
			if (args[i].toLowerCase().startsWith(exitDelayOpt)) {
				if (args[i].length()>exitDelayOpt.length()) {
					try {
						long lng1 = Long.parseLong( args[i].substring(exitDelayOpt.length()) );
						if (lng1>0) exitDelay = lng1;
					} catch (Exception e) {}
				}
			}
			// set master config file if set
			String cfgOpt = "-config:";
			if (args[i].toLowerCase().startsWith(cfgOpt)) {
				if (cfgOpt.length()+1<args[i].length()) {
					String tmp = args[i].substring( cfgOpt.length()+1 ).trim();
					if (!tmp.isEmpty()) configFile = tmp;
				}
			}
		}
		if (!hasInput) {
			System.out.println("No BPMN file specified");
			//return;
		}
		
		// Read application settings
		System.out.println("Configuration file: "+configFile);
		Properties prop = new Properties();
		//prop.load( CLI.class.getResourceAsStream("/aop4bpmn2.properties") );
		prop.load( org.iccs.san.util.SANHelper.getResourceAsStream(configFile) );
        String propLogging = prop.getProperty("logging-properties");
		String dbConnStr = prop.getProperty("persistent-store-connection-string");
		String dbUser = prop.getProperty("persistent-store-usename");
		String dbPwd = prop.getProperty("persistent-store-password");
		String dbPU = prop.getProperty("persistent-store-PU");
		
		// Create logger, persistent store connection and factories
		LogManager.getLogManager().readConfiguration(LogManager.class.getResourceAsStream(propLogging));
        Connection connection = DriverManager.getConnection(dbConnStr, dbUser, dbPwd);
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(dbPU);
		AdaptControlServiceFactory acsf = new AdaptControlServiceFactory();		// XXX: AOP

        // Prepare and verify annotation library
        List<Class> annotatedClasses = new ArrayList<Class>();
		for (int i=0; i<args.length; i++) {
			if (args[i].startsWith("-") && args[i].toLowerCase().startsWith("-annotation:")) {
				String[] clss = args[i].substring(12).split("[,:; ]");
				for (int j=0; j<clss.length; j++) {
					clss[j] = clss[j].trim();
					System.out.println("Adding annotated class "+clss[j]+"...");
					annotatedClasses.add( Class.forName(clss[j]) );
				}
			}
		}
        AdaptClassListAnnotationDictionary dictionary = new AdaptClassListAnnotationDictionary(annotatedClasses);
        dictionary.build();
		
        // Prepare aspect definitions
		Vector<String> aspectDefURIs = new Vector<String>();
		for (int i=0; i<args.length; i++) {
			if (args[i].startsWith("-") && args[i].toLowerCase().startsWith("-aspect:")) {
				String[] uri = args[i].substring(8).split("[,; ]");
				for (int j=0; j<uri.length; j++) {
					uri[j] = uri[j].trim();
					System.out.println("Adding aspect definition "+uri[j]+"...");
					aspectDefURIs.add( uri[j] );
				}
			}
		}
		
		// initialize AOP (connect to DSB)
		AOP.init();
		org.iccs.util.DesktopFrame.initInstance("AOP4BPMN2 workflow engine");
		
        // Create work session and load process definitions
		String engineId = "aop4bpmn2-engine-"+System.currentTimeMillis();
		String sessionId = "aop4bpmn2-session-"+java.util.UUID.randomUUID().toString().replace("-", "_");
        AdaptWorkSessionImpl session = new AdaptWorkSessionImpl(prop, engineId, sessionId, emf, acsf, dictionary, aspectDefURIs);
        for (int i=0; i<args.length; i++) {
			if (!args[i].startsWith("-")) {
				System.out.println("Reading file "+args[i]+"...");
				session.readDefinitions(CLI.class.getResourceAsStream(args[i]));
			}
		}
		if (aopOff) session.setAdaptationActive(false);
        session.start();
		
		// Enter CLI...
		scanner = new Scanner(System.in);
		String menu = "\n"+
					"Main Menu\n"+
					"=========\n"+
					"n  - New Process\n"+
					"x  - Exit\n"+
					"X  - Forced Exit\n"+
					"q  - Number of queued events\n"+
					"a  - add aspect\n"+
					"ad - Delete aspect\n"+
					"al - list deployed aspects\n"+
					"p  - Load process definitions\n"+
					"pd - Drop process definition\n"+
					"pl - List process definitions\n"+
					"dd - Drop definitions (process and messages)\n"+
					"dl - List definitions (process and messages)\n"+
					"m  - Display and Set current adaptation mode\n"+
					"ml - List valid adaptation modes\n"+
					"w  - Display and Set send WF events flag\n"+
					"db - Enter database CLI mode\n"+
					"i  - Interrupt task\n"+
					"?  - Main Menu\n";
		String promptMesg = menu;
		do {
            String choice = getResponse(promptMesg, "> ").trim();
			promptMesg = "";
            if ("n".equalsIgnoreCase(choice)) {
				String procName = getResponse("", "Process to start? ");
				try {
					session.createProcess(procName);
				} catch (Throwable t) {
					System.out.println(t.getMessage());
				}
            } else if ("x".equals(choice)) {
				if (session.getUserTasks().size()>0) {
					System.out.println("There are unfinished processes");
				} else if (AOP.getQueuedEventsCount()>0) {
					System.out.println("There are unpublished events in the queue");
				} else {
					break;
				}
            } else if ("X".equals(choice)) {
				break;
            } else if ("?".equalsIgnoreCase(choice)) {
				promptMesg = menu;  // print again main menu
			} else if ("q".equalsIgnoreCase(choice)) {
				System.out.println("\nQueued events: "+AOP.getQueuedEventsCount());
			} else if ("a".equalsIgnoreCase(choice)) {
				String aspectUri = getResponse("", "Aspect to add? ");
				AOP.loadAndAddAspects(session, aspectUri);
			} else if ("ad".equalsIgnoreCase(choice)) {
				String aspectId = getResponse("", "Aspect to delete? ").trim();
				if (!aspectId.equals("")) {
					AOP.Aspect aspect = AOP.getSessionAspectById(session, aspectId);
					if (aspect!=null) {
						AOP.removeAspect(session, aspect.getURI());
					} else {
						System.out.println("Aspect not found: "+aspectId);
					}
				}
			} else if ("al".equalsIgnoreCase(choice)) {
				AOP.Aspect[] aspects = AOP.getAllAspects();
				if (aspects!=null && aspects.length>0) {
					System.out.println("** Deployed aspects:");
					for (int i=0, n=aspects.length; i<n; i++) {
						System.out.printf("%2d. %s\n", i+1, aspects[i].toString("    ").trim());
					}
				} else {
					System.out.println("** No deployed aspects");
				}
				System.out.println();
			} else if ("p".equalsIgnoreCase(choice)) {
				String processUri = getResponse("", "Process file to load? ");
				try {
					java.io.InputStream is = org.iccs.san.util.SANHelper.getResourceAsStream(processUri);
					if (is!=null) {
						String id = session.readDefinitions( is ).getId();
						System.out.println("Process file loaded with id: "+id);
					} else {
						System.out.println("Process file FAILED to load: "+processUri);
						System.out.println("Reason: Could not open an input stream to resource");
					}
				} catch (Exception ex) {
					System.out.println("Process file FAILED to load: "+processUri);
					ex.printStackTrace();
				}
			} else if ("pd".equalsIgnoreCase(choice)) {
				System.out.println("Please note that running instances of the process might exist");
				String procId = getResponse("", "Process to delete? ").trim();
				if (!procId.equals("")) {
					try {
						session.dropProcess(procId);
					} catch (Exception ex) {
						System.out.println("Could not delete process definition: "+ex);
					}
				}
			} else if ("pl".equalsIgnoreCase(choice)) {
				int i=0;
				for (String id : session.getProcessIds()) {
					System.out.printf("%2d.  %s\n", ++i, id);
				}
				if (i==0) System.out.println("** No process definition");
			} else if ("dd".equalsIgnoreCase(choice)) {
				System.out.println("Please note that running instances of the process might exists");
				String procId = getResponse("", "Definitions to delete? ").trim();
				if (!procId.equals("")) {
					try {
						session.dropDefinitions(procId);
					} catch (Exception ex) {
						System.out.println("Could not delete definitions: "+ex);
					}
				}
			} else if ("dl".equalsIgnoreCase(choice)) {
				int i=0;
				for (String id : session.getDefinitionsIds()) {
					System.out.printf("%2d.  %s\n", ++i, id);
				}
				if (i==0) System.out.println("** No definitions loaded");
			} else if ("m".equalsIgnoreCase(choice)) {
				AOP.AdaptationMode currMode = AOP.getAdaptationMode();
				System.out.println("Current Adaptation Mode: "+currMode);
				String mode = getResponse("", "New adaptation mode? [<dot> to leave mode intact] ").trim();
				if (!mode.equals("") && !mode.equals(".")) {
					try {
						AOP.AdaptationMode newMode = AOP.AdaptationMode.valueOf(mode);
						if (currMode!=newMode) {
							AOP.setAdaptationMode(newMode);
							System.out.println("Adaptation Mode changed to "+newMode);
						}
					} catch (IllegalArgumentException ex) {
						System.out.println("Invalid Adaptation Mode: "+mode);
					}
				}
			} else if ("ml".equalsIgnoreCase(choice)) {
				System.out.println("Valid Adaptation Modes:");
				int i = 0;
				for (AOP.AdaptationMode mode : AOP.AdaptationMode.values()) {
					System.out.printf("%2d.  %s\n", ++i, mode);
				}
			} else if ("w".equalsIgnoreCase(choice)) {
				boolean currFlag = AOP.isSendWFEvents();
				System.out.println("Current Send WF events flag: "+currFlag);
				String flag = getResponse("", "New WF events flag? [<dot> to leave mode intact] ").trim();
				if (flag.equals("") || flag.equals(".")) {
					;
				} else
				if (flag.equalsIgnoreCase("yes") || flag.equalsIgnoreCase("on") || flag.equalsIgnoreCase("true") || flag.equalsIgnoreCase("1")) {
					AOP.setSendWFEvents(true);
					System.out.println("Send WF events flag set to "+true);
				} else
				if (flag.equalsIgnoreCase("no") || flag.equalsIgnoreCase("off") || flag.equalsIgnoreCase("false") || flag.equalsIgnoreCase("0")) {
					AOP.setSendWFEvents(false);
					System.out.println("Send WF events flag set to "+false);
				} else {
					System.out.println("Invalid value for Send WF events flag : "+flag);
				}
			} else if ("db".equalsIgnoreCase(choice)) {
				databaseCLIMode(connection);
			} else if ("i".equalsIgnoreCase(choice)) {
				String taskRef = getResponse("", "Task to interrupt? ").trim();
				if (!taskRef.equals("")) {
					String[] part = taskRef.split("[ \t:]");
					if (part.length==4) {
						try {
							String procDef = part[0].trim();
							long   procId  = Long.parseLong(part[1].trim());
							String nodeDef = part[2].trim();
							long   nodeId  = Long.parseLong(part[3].trim());
							
							boolean rr = session.interruptExecutingTask(procDef, procId, nodeDef, nodeId);
							if (rr) System.out.println("Task interrupted");
							else System.err.println("Task not interrupted");
						} catch (NumberFormatException e) {
							System.err.println("Invalid task reference. Invalid process or node Id. Exception: "+e);
						}
					} else {
						System.err.println("Invalid task reference. Valid refs are of the form 'Proc-Def : Proc-Id : Node-Def : Node-Id'");
					}
				}
            } else {
                System.out.println("\nUnknown command: " + choice);
            }
		} while (true);
		// Exit CLI
		
        // Clean up: close session, entity manager factory and shutdown database
        session.close();
        if (emf != null) {
            emf.close();
        }
        connection.createStatement().execute("SHUTDOWN");
		
		// Wait for 2 seconds to allow DSB shutdown endpoints and then force exit
		AOP.cleanup();
		if (exitDelay>0) {
			System.out.println("Waiting for about "+Math.round(exitDelay/1000)+" seconds to allow cleanup operations complete");
			try { Thread.sleep(exitDelay); } catch (Exception ex) {}
		}
		
		// Close GUI
		org.iccs.util.DesktopFrame.clearInstance();
		System.exit(0);
    }
	
	private static void databaseCLIMode(Connection connection) {
		// Enter CLI...
		System.out.println("Entering Database CLI mode");
		scanner = new Scanner(System.in);
		String menu = "\n"+
					"Main Menu\n"+
					"=========\n"+
					"l <table>          - List table cotents\n"+
					"lt <table filter>  - List schema tables\n"+
					"x                  - Exit database CLI mode\n"+
					"?                  - This menu\n";
		String promptMesg = menu;
		Statement statement = null;
		do {
            String choice = getResponse(promptMesg, "DATABASE> ").trim();
			promptMesg = "";
            if ("x".equals(choice)) {
				break;
            } else
			if ("?".equalsIgnoreCase(choice)) {
				promptMesg = menu;  // print again main menu
            } else {
				if (choice.startsWith("lt ") || choice.startsWith("lt\t") || choice.equals("lt")) {
					if (choice.length()>2 && !choice.substring(2).trim().equals("")) {
						choice = "WHERE table_name LIKE '"+choice.substring(2).trim().toUpperCase()+"' ";
					} else {
						choice = "";
					}
					choice = "SELECT table_name FROM information_schema.tables "+choice+"ORDER BY table_name";
				} else
				if (choice.startsWith("l ") || choice.startsWith("l\t") || choice.equals("l")) {
					if (choice.length()>1 && !choice.substring(1).trim().equals("")) {
						choice = "SELECT * FROM "+choice.substring(1).trim();
					} else {
						System.err.println("Please specify a valid table");
						continue;
					}
				}
				
                System.out.println("Executing database query: " + choice);
				try {
					if (statement==null) statement = connection.createStatement();
					
					boolean rsType = statement.execute(choice);
					do {
						if (rsType) {
							// the result of the SQL statement is a ResultSet
							ResultSet rs = statement.getResultSet();
							ResultSetMetaData meta = rs.getMetaData();
							// print result set name
							System.out.println("Result-Set: "+rs.getCursorName());
							// print result set labels
							int[] width = new int[meta.getColumnCount()];
							String sep = "";
							for (int i=0; i<width.length; i++) {
								width[i] = meta.getColumnDisplaySize(i+1);
								if (meta.getColumnLabel(i+1).length()>width[i]) width[i] = meta.getColumnLabel(i+1).length();
								System.out.print(sep);
								sep = ", ";
								//System.out.print( String.format("%"+width[i]+"s", meta.getColumnLabel(i+1)) );
								System.out.print( String.format("%s", meta.getColumnLabel(i+1)) );
							}
							System.out.println();
							System.out.println("----------------------------------------------------------------------------");
							// print rows
							while (rs.next()) {
								sep = "";
								for (int i=0; i<width.length; i++) {
									Object v = rs.getObject(i+1);
									System.out.print(sep);
									sep = ", ";
									v = v!=null ? v.toString() : "null";
									//System.out.print( String.format("%"+width[i]+"s", v) );
									System.out.print( String.format("%s", v) );
								}
								System.out.println();
							}
						} else {
							// the result of the SQL statement is an update count, or no results returned
							int rc = statement.getUpdateCount();
							if (rc>=0) {
								System.out.println("Rows updated: "+rc);
							} else {
								System.out.println("No results returned");
								break;
							}
						}
						System.out.println();
						
						// move to the next result (if any)
						rsType = statement.getMoreResults();
					} while ((statement.getResultSet() != null) || (statement.getUpdateCount() != -1));
					
				} catch (SQLException e) {
					System.err.println(e);
				}
            }
		} while (true);
		System.out.println("Returning to BPMN CLI mode");
		// Exit CLI
	}
    
	private static String getResponse(String message, String prompt) {
        System.out.print(message);
        String line;
		do { System.out.print(prompt); System.out.flush(); }
		while ((line=scanner.nextLine())==null || line.trim().equals(""));
		return line;
    }

    private static int getIntResponse(String prompt) {
        System.out.print(prompt);
        int n = scanner.nextInt();
        scanner.nextLine();
        return n;
    }
}
