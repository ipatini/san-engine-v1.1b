/*
 * ++++++++++++++++++
 */

package org.iccs.worktoken.model;

import javax.swing.JOptionPane;

import com.worktoken.adapt.AdaptWorkSession;
import com.worktoken.model.BusinessProcess;
import com.worktoken.model.Node;
import com.worktoken.model.WorkToken;
import org.mozilla.javascript.*;
import java.io.PrintStream;
import java.util.List;

public class JavascriptHelper {
	public static void alert(String mesg) {
		JOptionPane.showMessageDialog(null, mesg, "Alert", JOptionPane.INFORMATION_MESSAGE);
	}
	
	public static boolean confirm(String mesg) {
		int rr = JOptionPane.showConfirmDialog(null, mesg, "Confirm", JOptionPane.YES_NO_OPTION);
		return (rr==JOptionPane.YES_OPTION);
	}
	
	public static String prompt(String mesg, String defValue) {
		return javax.swing.JOptionPane.showInputDialog(null, mesg, defValue);
	}
	
	public static Object evaluateJavascript(Node node, WorkToken token, List<Object> content, AdaptWorkSession session, BusinessProcess process, String uid) {
		return evaluateJS(node, token, content, session, process, uid);
	}
	
	public static Object evaluateJavaScript(Node node, WorkToken token, List<Object> content, AdaptWorkSession session, BusinessProcess process, String uid) {
		return evaluateJS(node, token, content, session, process, uid);
	}
	
	public static Object evaluateJS(Node node, WorkToken token, List<Object> content, AdaptWorkSession session, BusinessProcess process, String uid) {
		org.mozilla.javascript.Context cx = org.mozilla.javascript.Context.enter();
		try {
			// Initialize the standard objects (Object, Function, etc.)
			// This must be done before scripts can be executed. Returns
			// a scope object that we use in later calls.
			Scriptable scope = cx.initStandardObjects();
			
			PrintStream out = System.out;
			Object wrappedOut = org.mozilla.javascript.Context.javaToJS(out, scope);
			Object wrappedUtil = org.mozilla.javascript.Context.javaToJS(new JavascriptHelper(), scope);
			Object wrappedToken = org.mozilla.javascript.Context.javaToJS(token, scope);
			Object wrappedSession = org.mozilla.javascript.Context.javaToJS(session, scope);
			Object wrappedProcess = org.mozilla.javascript.Context.javaToJS(process, scope);
			Object wrappedNode = org.mozilla.javascript.Context.javaToJS(node, scope);
			
			ScriptableObject.putProperty(scope, "out", wrappedOut);
			ScriptableObject.putProperty(scope, "util", wrappedUtil);
			ScriptableObject.putProperty(scope, "token", wrappedToken);
			ScriptableObject.putProperty(scope, "session", wrappedSession);
			ScriptableObject.putProperty(scope, "process", wrappedProcess);
			ScriptableObject.putProperty(scope, "node", wrappedNode);
			ScriptableObject.putProperty(scope, "gui", org.iccs.util.DesktopFrame.getInstance(false));
			
			// get javascript definition
			StringBuilder sb = new StringBuilder();
			for (Object o : content) {
				if (o instanceof String) sb.append((String)o);
			}
			String definition = sb.toString();
			
			// Now evaluate the string we've collected.
			Object result = cx.evaluateString(scope, definition, "<JS: "+uid+">", 1, null);
			
			return result;
		
		} catch (Exception e) {
			System.err.println("JavascriptHelper: evaluateJC: Exception caught: "+e);
			e.printStackTrace();
			return null;
		} finally {
			org.mozilla.javascript.Context.exit();
		}
	}
}
