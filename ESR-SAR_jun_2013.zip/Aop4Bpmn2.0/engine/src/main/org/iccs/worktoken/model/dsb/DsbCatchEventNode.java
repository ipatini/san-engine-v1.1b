/*
 * ++++++++++++++++++
 */

package org.iccs.worktoken.model.dsb;

import com.worktoken.model.Connector;
import com.worktoken.model.WorkToken;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import com.worktoken.model.*;
import org.iccs.worktoken.model.Interruptible;
import javax.xml.namespace.QName;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Stack;

import com.worktoken.adapt.AOP;

@Entity (name="DsbCatchEvent")
public class DsbCatchEventNode extends com.worktoken.model.CatchEventNode implements DsbHelper.EventReceiver, Interruptible {
	private QName topic;
	private String topicStr;			// Used to store the Topic string representation in the persistent storage
	private boolean allowOverride;
	protected String messageFilter;
	protected String ebgKey;			// Used to identify the source event-based gateway (if any) as well as any sibling catch event nodes
	protected transient WorkToken token;
	protected transient boolean initStarted;
	protected transient boolean subscribed;
	protected transient boolean interrupted;
	
	public DsbCatchEventNode() {
		allowOverride = true;
		initStarted = false;
	}
	
	// topic get/set methods
	public QName getTopic() { return topic; }
	
	public void setTopic(QName t) {
		if (t!=null) topic = t; else throw new IllegalArgumentException("Argument of setTopic cannot be null");
		if (isStartEvent()) {
			_init();
		}
		if (topic!=null) topicStr = topic.toString();
	}
	public void setTopic(String t) {
		if (t==null) throw new IllegalArgumentException("Argument of setTopic cannot be null");
		setTopic( _parseTopic(t) );
		if (topic==null) throw new IllegalArgumentException("Invalid Topic specification: "+t);
	}
	
	protected QName _parseTopic(String t) {
		String[] part = t.split("[ \t]+");
		if (part.length==3) {
			String ns = part[0].trim();
			String lp = part[1].trim();
			String pf = part[2].trim();
			if (!ns.isEmpty() && !lp.isEmpty()) {
				return new QName(ns, lp, pf);
			}
		}
		return null;
	}
	
	// allow override get/set methods
	public boolean isAllowOverride() { return allowOverride; }
	public void setAllowOverride(boolean ao) { allowOverride = ao; }
	
	// start event setter method (override parent's methods)
	public void setStartEvent(boolean s) {
		super.setStartEvent(s);
		if (s && topic!=null) {
			_init();
		}
	}
	
	protected void _init() {
		if (initStarted) return;
		initStarted = true;
		AOP.debug("** "+getClass().getName()+": _init: Waiting for event from DSB: topic="+topic);
		tokenIn(null, null);
	}
	
	// topic get/set methods
	public String getMessageFilter() { return messageFilter; }
	
	public void setMessageFilter(String filter) { messageFilter = filter; }
	
    public void tokenIn(WorkToken token, Connector connector) {
		if (interrupted) return;
		
		if (token!=null) this.token = token;
		
		if (token!=null) {
			Stack<String> stack = (Stack<String>)token.getData().get("IccsEventBasedGateway");
			if (stack!=null) {
				this.ebgKey = stack.peek();
			}
			if (this.ebgKey!=null) {
				// store this event-based gateway in key's group
				org.iccs.worktoken.model.EventBasedGateway.addSiblingCatchEventNode(this.ebgKey, this);
			}
		}
		
		boolean ok = false;
		if (topic!=null) {
			if ( DsbHelper.getConnection(this).subscribe(topic, this) ) {
				this.token = token;
				this.subscribed = true;
				ok = true;
				AOP.debug("** "+getClass().getName()+": tokenIn: Subscribed to topic : "+topic);
				AOP.debug("** "+getClass().getName()+": tokenIn: Waiting for message from topic : "+topic);
			} else {
				System.err.println("** "+getClass().getName()+": tokenIn: Could not subscribe to topic : "+topic);
			}
		} else {
			System.err.println("** "+getClass().getName()+": tokenIn: No topic has been specified");
		}
		
		if (!ok) {
			tokenOut(token);
		}
	}
	
	public synchronized void eventReceived(QName _topic, String message) {
		if (interrupted) return;
		
		AOP.debug("** "+getClass().getName()+": eventReceived: Message received from topic : "+topic);
		
		if (messageFilter!=null && message.indexOf(messageFilter)<0) {
			// message does not match message filter
			AOP.debug("** "+getClass().getName()+": eventReceived: Event message does not match filter.  Topic : "+topic);
			return;
		}
		
		if ( DsbHelper.getConnection(this).unsubscribe(topic, this) ) {
			AOP.debug("** "+getClass().getName()+": eventReceived: Unsubscribe from topic : "+topic);
			this.subscribed = false;
		} else {
			System.err.println("** "+getClass().getName()+": eventReceived: Could not unsubscribe from topic : "+topic+".  Abandoning subscription");
		}
		
		EventToken evtToken = new EventToken();
		evtToken.getData().put("message", message);
		eventIn(evtToken);
	}
	
	public void eventIn(EventToken event) {
		if (interrupted) return;
		
		String mesg = (String)event.getData().get("message");
		AOP.debug("** "+getClass().getName()+": Event received from DSB: Event message: "+mesg);
		if (token==null) {
			token = new WorkToken();
		}
		String pName = getDefId() + "-" + getId() + "-received-message";
		token.getData().put(pName, mesg);
		String myname = getDefinition().getName();
		if (myname!=null && !(myname=myname.trim()).isEmpty()) {
			pName = myname + "-" + getId() + "-received-message";
			token.getData().put(pName, mesg);
		}
		
		// interrupt any siblings
		if (this.ebgKey!=null) {
			Interruptible[] sibling = org.iccs.worktoken.model.EventBasedGateway.removeSiblingCatchEventNodes(this.ebgKey);
			if (sibling!=null) {
				for (int i=0; i<sibling.length; i++) {
					if (sibling[i]!=this) {
						sibling[i].interrupt(this);
					}
				}
			}
		}
		
		tokenOut(token);
	}
	
	public boolean interrupt(Object param) {
		if (interrupted) return false;
		interrupted = true;
		if (subscribed) {
			if ( DsbHelper.getConnection(this).unsubscribe(topic, this) ) {
				AOP.debug("** "+getClass().getName()+": interrupt: Unsubscribe from topic : "+topic);
				this.subscribed = false;
			} else {
				System.err.println("** "+getClass().getName()+": interrupt: Could not unsubscribe from topic : "+topic+".  Abandoning subscription");
			}
		}
		return true;
	}
}
