/*
 * ++++++++++++++++++
 */

package org.iccs.worktoken.model;

public interface Interruptible {
	public boolean interrupt(Object param);
}
