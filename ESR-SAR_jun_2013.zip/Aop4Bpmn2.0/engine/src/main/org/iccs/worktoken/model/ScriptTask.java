/*
 * ++++++++++++++++++
 */

package org.iccs.worktoken.model;

import com.worktoken.adapt.AdaptWorkSession;
import com.worktoken.model.BusinessProcess;
import com.worktoken.model.Connector;
import com.worktoken.model.Node;
import com.worktoken.model.WorkToken;
import org.omg.spec.bpmn._20100524.model.TScript;
import org.omg.spec.bpmn._20100524.model.TScriptTask;
import org.mozilla.javascript.*;
import java.io.PrintStream;
import java.util.List;

import javax.swing.JOptionPane;

import javax.persistence.Entity;

@Entity(name="IccsScriptTask")
public class ScriptTask extends com.worktoken.model.ScriptTask {
    public void tokenIn(WorkToken token, Connector connector) {
		AdaptWorkSession session = (AdaptWorkSession)getSession();
		BusinessProcess process = getProcess();
		String sesId = session.getId();
		String procDef = process.getDefId();
		long procId = process.getId();
		String nodeDef = getDefId();
		long nodeId = getId();
		String uid = sesId+"/"+procDef+":"+procId+"/"+nodeDef+":"+nodeId;
		
		TScriptTask tScriptTask = (TScriptTask) getDefinition();
		String format = tScriptTask.getScriptFormat();
		format = format!=null ? format.trim() : "";
		
		if (format.equalsIgnoreCase("JS") || format.equalsIgnoreCase("JavaScript") || format.equalsIgnoreCase("text/javascript")) {
			// execute JavaScript task
			System.out.println("** "+getClass().getName()+": Task "+uid+": Format is 'javascript'");
			doJSTask(token, tScriptTask.getScript().getContent(), session, process, uid);
		} else
		if (format.equalsIgnoreCase("java")) {
			System.out.println("** "+getClass().getName()+": Task "+uid+": Format is 'JAVA'");
			doJavaTask(token, tScriptTask.getScript().getContent(), session, process, uid);
		} else {
			// unknown script format
			System.err.println("** "+getClass().getName()+": Task "+uid+": Unknown Script Format '"+format);
		}
		
        tokenOut(token);
    }
	
	protected void doJSTask(WorkToken token, List<Object> content, AdaptWorkSession session, BusinessProcess process, String uid) {
		System.out.println("** "+getClass().getName()+": Task "+uid+": executing javascript...");
		Object result = JavascriptHelper.evaluateJS(this, token, content, session, process, uid);
		System.out.println("** "+getClass().getName()+": Task "+uid+": execution outcome: "+result);
	}
	
	protected void doJavaTask(WorkToken token, List<Object> content, AdaptWorkSession session, BusinessProcess process, String uid) {
JOptionPane.showConfirmDialog(null, getClass().getName()+": JAVA format is NOT IMPLEMENTED");
		throw new RuntimeException(getClass().getName()+": Task "+uid+": doJavaTask: NOT YET IMPLEMENTED     uid="+uid);
	}
}
