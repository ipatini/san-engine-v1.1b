/*
 * ++++++++++++++++++
 */

package org.iccs.worktoken.model;

import com.worktoken.model.Connector;
import com.worktoken.model.WorkToken;
import com.worktoken.engine.BPMNUtils;
import org.iccs.util.DesktopFrame;
import org.iccs.worktoken.model.Interruptible;
import javax.xml.namespace.QName;
import java.util.HashMap;
import java.util.Map;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Stack;
import org.omg.spec.bpmn._20100524.model.TEventBasedGateway;
import org.omg.spec.bpmn._20100524.model.TFlowElement;
import org.omg.spec.bpmn._20100524.model.TProcess;
import org.omg.spec.bpmn._20100524.model.TSequenceFlow;

import javax.persistence.Entity;

@Entity(name="IccsEventBasedGateway")
public class EventBasedGateway extends com.worktoken.model.EventBasedGateway {
	protected transient WorkToken token;
	protected transient Connector connector;
	
    /**
     * <p>Routes incoming token to all outgoing connectors tergeting event-based gateways</p>
     *
     * <p>If overridden in subclass, does not need to call parent method.</p>
     *
     * @param token incoming token
     * @param connectorIn incoming connector the token arrived through
     */
	@Override
	public void tokenIn(WorkToken token, Connector connectorIn) {
		TProcess tProcess = getProcess().getDefinition();
		TEventBasedGateway gateway = (TEventBasedGateway) BPMNUtils.getFlowNode(getDefId(), tProcess);
		
		// generate a unique key, store it in the token
		String key = getSession().getId()+"/"+getProcess().getDefId()+":"+getProcess().getId()+"/"+getDefId()+":"+getId()+"/"+(cnt++);
		Stack<String> stack = (Stack<String>)token.getData().get("IccsEventBasedGateway");
		if (stack==null) {
			token.getData().put("IccsEventBasedGateway", stack = new Stack<String>());
		}
		stack.push(key);
		
		// get outgoing routes and start CatchEventNodes
		Map<Connector,WorkToken> map = new HashMap<Connector,WorkToken>();
		for (QName qName :  gateway.getOutgoing()) {
			TSequenceFlow link = BPMNUtils.find(qName.getLocalPart(), tProcess, TSequenceFlow.class);
			// find target node
			Object target = link.getTargetRef();
			if (target==null) {
				throw new RuntimeException("Event-based gateway: "+gateway.getId()+" : Target ref at Link \""+link.getId()+"\" points to a non-existing node.  Invalid BPMN specification.");
			}
			
			// add token to event node
			map.put(new Connector(link), token);
		}
		
		tokensOut(map);
    }
	
	protected static Hashtable<String,Vector<Interruptible>>  ebgEvents = new Hashtable<String,Vector<Interruptible>>();
	protected static int cnt = 0;
	
	public static void addSiblingCatchEventNode(String key, Interruptible node) {
		Vector<Interruptible> v = ebgEvents.get(key);
		if (v==null) {
			ebgEvents.put(key, v = new Vector<Interruptible>());
		}
		v.add(node);
	}
	
	public static Interruptible[] removeSiblingCatchEventNodes(String key) {
		Vector<Interruptible> v = ebgEvents.remove(key);
		if (v==null) return null;
		return v.toArray( new Interruptible[0] );
	}
}
