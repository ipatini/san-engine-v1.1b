/*
 * ++++++++++++++++++
 */

package org.iccs.worktoken.model;

import com.worktoken.model.Connector;
import com.worktoken.model.WorkToken;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.swing.JOptionPane;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.persistence.Entity;

@Entity(name="IccsWebServiceTask")
public class WebServiceTask extends com.worktoken.model.ServiceTask {
	protected URL address;
	protected String target;
	
    public void tokenIn(WorkToken token, Connector connector) {
		JOptionPane.showConfirmDialog(null, "THIS IS MY WEB-SERVICE TASK");
		
		callWebService(token);
		tokenOut(token);
	}
	
	public URL getAddress() { return address; }
	
	public void setAddress(URL addr) { address = addr; }
	
	public void setAddress(String addr) throws MalformedURLException {
		address = new URL(addr);
	}
	
	public String getTarget() { return target; }
	
	public void setTarget(String trg) { trg = (trg!=null) ? trg.trim() : null; trg = (!trg.trim().equals("")) ? trg : null; target = trg; }
	
	protected void callWebService(WorkToken token) {
		try {
			System.out.println("** "+this.getClass().getName()+": Connecting to "+address+"...");
			URL url = address;
			StringBuffer cn = new StringBuffer();
			BufferedReader in = new BufferedReader( new InputStreamReader( url.openStream() ) );
			String inputLine;
			System.out.println("** "+this.getClass().getName()+": Retrieving content");
			while ((inputLine = in.readLine()) != null) {
				cn.append(inputLine);
			}
			in.close();
			String response = cn.toString();
			System.out.println("** "+this.getClass().getName()+": Connection closed");
			
			// Store response in WorkToken if a target element has been specified
			if (target!=null && !target.trim().equals("")) {
				token.getData().put(target, response);
				System.out.println("** "+this.getClass().getName()+": Response stored in '"+target+"'");
			}
			
		} catch (Exception ex) {
			System.err.println("** "+this.getClass().getName()+": Failed to connect or retrieve content from "+address);
			ex.printStackTrace( System.err );
		}
	}
}
