/*
 * ++++++++++++++++++
 */

package org.iccs.worktoken.model.dsb;

import com.worktoken.adapt.AdaptWorkSession;
import com.worktoken.adapt.SessionListener;
import com.worktoken.model.Node;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Properties;
import javax.xml.namespace.QName;

import com.worktoken.adapt.AOP;
import org.iccs.dsb.*;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.Notify;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.utils.WsnbException;
import java.util.List;
import javax.xml.XMLConstants;
import com.ebmwebsourcing.easycommons.xml.XMLHelper;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.NotificationMessageHolderType;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.NotificationMessageHolderType.Message;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.TopicExpressionType;
import org.w3c.dom.Element;
import javax.xml.transform.TransformerException;

class DsbHelper implements EventReceiver, SessionListener/*, Runnable*/ {
	protected static DsbHelper connection;
	
	public static DsbHelper getConnection(Node node) {
		if (connection==null) {
			AdaptWorkSession session = (AdaptWorkSession)node.getSession();
			String url = session.getEngineProperty("dsb-properties-url");
			if (url==null || (url=url.trim()).isEmpty()) throw new RuntimeException("DsbHelper: getConnection: Missing 'dsb-properties-url' parameter in engine configuration");
			Properties prop = new Properties();
			System.out.println("** DsbHelper: getConnection:  retrieving DSB configuration from url: "+url);
			java.io.InputStream is = org.iccs.san.util.SANHelper.getResourceAsStream(url);
			if (is==null) throw new RuntimeException("DsbHelper: getConnection: Invalid, non-existing or inaccessible resource at url: "+url);
			try { prop.load( is ); }
			catch (IOException e) {
				System.err.println("** DsbHelper: getConnection:  Exception while reading DSB properties from url: "+url);
				return null;
			}
			connection = new DsbHelper(prop);
			System.out.println("** DsbHelper: getConnection:  Connecting to DSB...");
			if ( connection.connect() ) System.out.println("** DsbHelper: getConnection:  Connected to DSB");
			else { connection = null; System.err.println("** DsbHelper: getConnection:  failed to connect to DSB"); }
			
			// add a session listener to clean up connection and active subscriptions on session close
			if (connection!=null) session.addSessionListener(connection);
		}
		return connection;
	}
	
	public static boolean closeConnection() {
		if (connection!=null) {
			System.out.println("** DsbHelper: closeConnection:  Disconnecting from DSB");
			if (connection.disconnect()) {
				System.out.println("** DsbHelper: closeConnection:  Disconnected from DSB");
				return true;
			}
		}
		
		return false;
	}
	
	// ============================================================================================
	
	protected Properties connProperties;
	protected boolean connected;
	protected DsbPubSubHelper dsbHelper;
	protected Hashtable<QName,Hashtable<DsbHelper.EventReceiver,Object>> subscriptions;
	
	protected DsbHelper(Properties prop) {
		connected = false;
		if (prop==null || prop.size()==0) throw new IllegalArgumentException("DsbHelper: <init>: Invalid connection properties argument");
		connProperties = prop;
	}
	
	// DSB connection methods
	
	protected boolean connect() {
		if (connected) return true;
		try {
			dsbHelper = DsbPubSubHelper.getInstance(this, connProperties);
			dsbHelper.startEndpointWS();
			connected = true;
		} catch (Exception e) {
			System.err.println("DsbHelper: connect: Could not establish connection to DSB or start local notification service");
			return false;
		}
		
		return true;
	}
	
	protected boolean disconnect() {
		if (!connected) return false;
		connected = false;
		unsubscribeAll();
		try {
			dsbHelper.stopEndpointWS();
		} catch (Exception e) {
			System.err.println("DsbHelper: disconnect: Could not close connection. Connection abandoned");
		}
		dsbHelper = null;
		return true;
	}
	
	public boolean isConnected() {
		return connected;
	}
	
	// DSB publish and subscribe methods
	
	public boolean publish(QName topic, String message) {
		if (topic==null || message==null || message.trim().isEmpty()) return false;
		
		try {
			String tmp = message.trim();
			return dsbHelper.publishEvent(topic, message);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public synchronized boolean subscribe(QName topic, DsbHelper.EventReceiver callback) {
		if (!isConnected()) return false;
		if (topic==null || callback==null) return false;
		
		// check if already subscribed to this topic
		if (subscriptions==null) subscriptions = new Hashtable<QName,Hashtable<DsbHelper.EventReceiver,Object>>();
		Hashtable<DsbHelper.EventReceiver,Object> topicSubscribers = subscriptions.get(topic);
		
		// subscribe to DSB topic (only the first time)
		String sid = null;
		if (topicSubscribers==null || topicSubscribers.isEmpty()) {
			try {
				sid = dsbHelper.subscribeFor(topic);
				if (sid==null || sid.trim().equals("")) {
					System.err.println("DsbHelper: subscribe: Could not subscribe to topic : "+topic);
					return false;
				}
			} catch (Exception e) {
				System.err.println("DsbHelper: subscribe: Exception caught: "+e);
				e.printStackTrace();
				return false;
			}
			
			// register subscription data
			topicSubscribers = new Hashtable<DsbHelper.EventReceiver,Object>();
			subscriptions.put(topic, topicSubscribers);
		} else {
			for (DsbHelper.EventReceiver aCallback : topicSubscribers.keySet()) {
				sid = (String) topicSubscribers.get(aCallback);
				break;
			}
		}
		
		// register subscription data
		topicSubscribers.put(callback, sid);
		
		return true;
	}
	
	public synchronized boolean unsubscribe(QName topic, DsbHelper.EventReceiver callback) {
		if (!isConnected()) return false;
		if (topic==null || callback==null) return false;
		
		// retrieve and remove subscription data
		if (subscriptions==null) return true;
		Hashtable<DsbHelper.EventReceiver,Object> topicSubscribers = subscriptions.get(topic);
		if (topicSubscribers==null) return true;
		String sid = (String)topicSubscribers.get(callback);
		if (sid==null) return true;
		topicSubscribers.remove(callback);
		
		if (topicSubscribers.isEmpty()) {
			subscriptions.remove(topic);
			
			// unsubscribe from DSB topic (only if no subscribers exist for this topic)
			try {
				return dsbHelper.unsubscribeFrom(topic, sid);
			} catch (Exception e) {
				System.err.println("DsbHelper: unsubscribe: Exception caught while unsubscribing from topic : "+topic+". Exception: "+e);
				e.printStackTrace();
				return false;
			}
		}
		
		return true;
	}
	
	public synchronized void unsubscribeAll() {
		AOP.debug("DsbHelper: unsubscribeAll: Unsubscribe from all topics...");
		if (subscriptions==null) return;
		for (QName topic : subscriptions.keySet()) {
			Hashtable<DsbHelper.EventReceiver,Object> topicSubscribers = subscriptions.get(topic);
			for (DsbHelper.EventReceiver callback : topicSubscribers.keySet()) {
				String sid = (String) topicSubscribers.get(callback);
				
				try {
					if ( !dsbHelper.unsubscribeFrom(topic, sid) ) {
						System.err.println("DsbHelper: unsubscribeAll: Failed to unsubscribe from topic : "+topic);
					}
				} catch (Exception e) {
					System.err.println("DsbHelper: unsubscribeAll: Exception caught while unsubscribing from topic : "+topic+". Exception: "+e);
				}
				
				break;
			}
		}
		subscriptions = null;
	}
	
	public static interface EventReceiver {
		public abstract void eventReceived(QName topic, String event);
	}
	
	// EventReceiver interface methods
	
	public void eventReceived(String notify) {
		AOP.debug("DsbHelper: eventReceived(String)");
		
		String topicStr = null;
		String mesg = null;
		int p = notify.indexOf("}\n");
		if (p>-1) {
			topicStr = notify.substring(1, p);
			mesg = notify.substring(p+1).trim();
		} else {
			topicStr = notify;
			mesg = "";
		}
		String[] part = topicStr.split("[ \t]+");
		if (part.length!=3) {
			System.err.println("DsbHelper: eventReceived(String): Invalid message topic : "+(topicStr.length()>30 ? topicStr.substring(30)+"..." : topicStr));
			return;
		}
		QName topic = new QName(part[0], part[1], part[2]);
		
		dispatchMessage(topic, mesg);
	}
	
	public void eventReceived(Notify notify) throws WsnbException {
		AOP.debug("DsbHelper: eventReceived(Notify)");
		_eventReceived(notify);
	}
	
	protected void _eventReceived(Notify notify) throws WsnbException {
		// get the topic
		List<NotificationMessageHolderType> messages = notify.getNotificationMessage();
		for (NotificationMessageHolderType notificationMessageHolderType : messages) {
			TopicExpressionType targetTopic = notificationMessageHolderType.getTopic();
			
			// extract topic indices
			String namespaceURI = XMLConstants.NULL_NS_URI;
			String localPart = null;
			String prefix = XMLConstants.DEFAULT_NS_PREFIX;
			
			// get topic prefix and local part
			// targetTopic content is something like 'prefix:Name'
			String content = targetTopic.getContent();
			int p = content.indexOf(":");
			if (p>0) {
				localPart = content.substring(p+1);
				prefix = content.substring(0, p);
			} else {
				localPart = content;
				prefix = "";
			}
			
			// get topic namespace. If many namespaces exist then we choose the one 
			// with a prefix matching the local part's prefix. If no such namespace
			// exists then when leave NULL_NS_URI
			for (QName ns : targetTopic.getTopicNamespaces()) {
				String nsPrefix = ns.getLocalPart();
				if (nsPrefix.equals(prefix)) {
					namespaceURI = ns.getNamespaceURI();
					break;
				}
			}
			
			QName topic = new QName(namespaceURI, localPart, prefix);
			
			// Process the business message
			Message message = notificationMessageHolderType.getMessage();
			Element businessMessage = message.getAny();
			
			// dispatch message content to subscribers
			try {
				String xml = XMLHelper.createStringFromDOMNode(businessMessage);
				dispatchMessage(topic, xml);
			} catch (TransformerException e) {
				System.err.println(e);
			}
		}
	}
	
	protected void dispatchMessage(QName topic, String message) {
		//if (!isConnected()) return;
		if (topic==null) return;
		
		// retrieve subscription data
		if (subscriptions==null) return;
		Hashtable<DsbHelper.EventReceiver,Object> topicSubscribers = subscriptions.get(topic);
		if (topicSubscribers==null) return;
		
		// iterate through subscribers
		Object[] tmp = topicSubscribers.keySet().toArray();
		for (int i=0, n=tmp.length; i<n; i++) {
			DsbHelper.EventReceiver callback = (DsbHelper.EventReceiver)tmp[i];
			callback.eventReceived(topic, message);
		}
		/*for (DsbHelper.EventReceiver callback : topicSubscribers.keySet()) {
			callback.eventReceived(topic, message);
		}*/
	}
	
	// SessionListener interface methods
	
	public void sessionClosing() { 
		DsbHelper.closeConnection();
	}
	
	public void sessionClosed() {
	}
}