/*
 * ++++++++++++++++++
 */

package org.iccs.worktoken.model;

import com.worktoken.model.Connector;
import com.worktoken.model.WorkToken;
import org.iccs.util.DesktopFrame;

import javax.persistence.Entity;

@Entity(name="IccsUserTask")
public class UserTask extends com.worktoken.model.UserTask implements Interruptible {
	private transient WorkToken token;
	private transient Connector connector;
	private transient DesktopFrame.Handler handler;
	
	public void tokenIn(WorkToken token, Connector connector) {
		this.token = token;
		this.connector = connector;
		
		String title = "User Task: "+getDefinition().getName();
		String mesg = "User Task: ("+getDefId()+":"+getId()+") "+getDefinition().getName()+
						"\nProcess Id: "+getProcess().getId()+"\nToken data:";
		//String input = DesktopFrame.getInstance().prompt(title, mesg);
		handler = DesktopFrame.getInstance().openInput(title, mesg, null, true);
		String input = handler.getInput();
		handler = null;
		
		processInputAndContinue(input);
	}
	
	public boolean interrupt(Object param) {
        if (handler==null) return false;
		handler.close();
		return true;
	}
	
	protected void processInputAndContinue(String dataStr) {
		if (dataStr!=null && !(dataStr=dataStr.trim()).equals("")) {
			java.util.Map data = token.getData();
			String[] pair = dataStr.split("[;,]");
			for (int i=0; i<pair.length; i++) {
				int p = pair[i].indexOf('=');
				if (p==-1) {	// remove
					String name = pair[i].trim();
					if (!name.equals("")) {
						data.remove(name);
						System.out.println("** Token Item '"+name+"' has been removed");
					}
				} else {	// add or update
					String name = pair[i].substring(0,p).trim();
					String value = (p+1<pair[i].length()) ? pair[i].substring(p+1).trim() : "";
					if (!name.equals("")) {
						data.put(name, value);
						System.out.println("** Token Item '"+name+"' has been added/updated to value: '"+value+"'");
					}
				}
			}
		}
		
        tokenOut(token);
	}
}
