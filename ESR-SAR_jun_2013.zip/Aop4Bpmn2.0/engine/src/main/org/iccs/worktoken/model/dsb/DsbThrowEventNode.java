/*
 * ++++++++++++++++++
 */

package org.iccs.worktoken.model.dsb;

import com.worktoken.model.Connector;
import com.worktoken.model.WorkToken;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import com.worktoken.model.*;
import java.util.Hashtable;
import javax.xml.namespace.QName;

import com.worktoken.adapt.AOP;

@Entity (name="DsbThrowEvent")
public class DsbThrowEventNode extends com.worktoken.model.ThrowEventNode {
	private QName topic;
	private String topicStr;			// Used to store the Topic string representation in the persistent storage
	private String messageTemplateUrl;
	private transient String messageTemplate;
	private boolean allowOverride;
	
	public DsbThrowEventNode() {
		allowOverride = true;
	}
	
	// topic get/set methods
	public QName getTopic() { return topic; }
	
	public void setTopic(QName t) {
		if (t!=null) topic = t; else throw new IllegalArgumentException("Argument of setTopic cannot be null");
		if (topic!=null) topicStr = topic.toString();
	}
	public void setTopic(String t) {
		if (t==null) throw new IllegalArgumentException("Argument of setTopic cannot be null");
		setTopic( _parseTopic(t) );
		if (topic==null) throw new IllegalArgumentException("Invalid Topic specification: "+t);
	}
	
	protected QName _parseTopic(String t) {
		String[] part = t.split("[ \t]+");
		if (part.length==3) {
			String ns = part[0].trim();
			String lp = part[1].trim();
			String pf = part[2].trim();
			if (!ns.isEmpty() && !lp.isEmpty()) {
				return new QName(ns, lp, pf);
			}
		}
		return null;
	}
	
	// allow override get/set methods
	public boolean isAllowOverride() { return allowOverride; }
	public void setAllowOverride(boolean ao) { allowOverride = ao; }
	
	// message template url get/set methods
	public String getMessageTemplateURL() { return messageTemplateUrl; }
	public void setMessageTemplateURL(String url) { messageTemplateUrl = url; }
	
	protected String prepareMessage(java.util.Map data) {
		String template = null;
		
		// get message template from token data
		String myname = getDefinition().getName();
		String myid = getDefId();
		if (myname!=null && !(myname=myname.trim()).isEmpty()) {
			Object o;
			if ((o=data.get(myname+"-message"))!=null) {
				template = o.toString();
			}
		} else {
			Object o;
			if ((o=data.get(myid+"-message"))!=null) {
				template = o.toString();
			}
		}
		
		// get message template from Node definition
		if (template==null) {
			if (messageTemplate==null && messageTemplateUrl!=null && !(messageTemplateUrl=messageTemplateUrl.trim()).isEmpty()) {
				messageTemplate = org.iccs.san.util.SANHelper.getResourceContent( messageTemplateUrl );
			}
			template = messageTemplate;
		}
		
		// no template found
		if (template==null) return null;
		
		// replace placeholders with values from token data
		if (data==null) data = new Hashtable();
		data.put("EVENT_ID", org.iccs.san.util.ActionHelper.getGUID());
		data.put("TIMESTAMP", org.iccs.san.util.ActionHelper.formatW3CDateTime(new java.util.Date()));
		data.put("TASK", "("+myid+")"+(myname!=null ? " "+myname : ""));
		return org.iccs.san.util.ActionHelper.prepareText(template, data, true);
	}
	
    public void tokenIn(WorkToken token, Connector connector) {
		String myname = getDefinition().getName();
		java.util.Map data = token.getData();
		QName _topic = topic;
		// override instance configuration using token data
		if (allowOverride && myname!=null && !(myname=myname.trim()).isEmpty()) {
			Object o;
			// check for topic override
			if ((o=data.get(myname+"-topic"))!=null && (o instanceof String  ||  o instanceof QName)) {
				if (o instanceof QName) _topic = (QName)o;
				else _topic = _parseTopic((String)o);
				if (_topic==null) _topic = topic;
			}
		}
		// get message content
		String mesg = prepareMessage(data);
		
		if (mesg!=null) {
			AOP.debug("** "+getClass().getName()+": tokenIn: Publishing an event to DSB : topic="+_topic);
			boolean r = DsbHelper.getConnection(this).publish(_topic, mesg);
			if (r) AOP.debug("** "+getClass().getName()+": tokenIn: Event published to DSB : topic="+topic);
			else System.err.println("** "+getClass().getName()+": tokenIn: Failed to publish event to DSB : topic="+topic);
		} else {
			System.err.println("** "+getClass().getName()+": tokenIn: No message found");
		}
		
		tokenOut(token);
	}
}
