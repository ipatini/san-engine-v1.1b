
				***  ESR :  FRANCE-TELECOM use case  ***

CONTENTS
========
ft-1.configuration.txt		Use case configuration file
ft-1.dsb.properties		Use case secondary (dsb intf. specific) configuration file
ft-1.n3				The file N3 SAN definition exported from SAN editor and manually modified
ft-1_RECOM-1.txt		Recommendation event template (suggest subscription to geolocation stream)
ft-1_RECOM-2.txt		Recommendation event template (suggest unsubscription from geolocation stream)
ft-1_RECOM-3.txt		Recommendation event template (location update)
README.txt			This file
run.bat				Double click it to start the use case

test-events			Directory containing test events (see Test section below)


================================   EXECUTION   ====================================

REQUIREMENTS
============

SIAFU simulator or Clic2Call service of Orange (they must be configured to publish events to DSB)


RUN
===

Double click on 'run.bat' in '<SAN_HOME>\apps\france-telecom\'


================================   TEST   ====================================

SETUP
=====

Set 'use-loopback-helper' setting to 'yes'  in file 'ft-1.dsb.properties'

Set 'use-loopback-helper' setting to 'yes'  in file 'dsb.properties' (in global configuration dir)


RUN
===

Double click on 'run.bat' in '<SAN_HOME>\apps\france-telecom\'

Double click on 'run.bat' in '<SAN_HOME>\bin\'

Publish test events using the second 'run.bat'
See below the commands for publishing test events


Test Events
===========

- Missed Call Event
event guid FT http://streams.event-processing.org/ids/ TaxiUCClic2Call @ apps/france-telecom/test-events/ft-1__event1.txt

- GeoLoc event (friend is in vicinity)
event guid FT http://streams.event-processing.org/ids/ TaxiUCGeoLocation @ apps/france-telecom/test-events/ft-1__event2.txt

- GeoLoc event (caller moved away)
event guid FT http://streams.event-processing.org/ids/ TaxiUCGeoLocation @ apps/france-telecom/test-events/ft-1__event2_b.txt

- GeoLoc event (caller moved closer)
event guid FT http://streams.event-processing.org/ids/ TaxiUCGeoLocation @ apps/france-telecom/test-events/ft-1__event2_c.txt

- GeoLoc event (friend has been reached)
event guid FT http://streams.event-processing.org/ids/ TaxiUCGeoLocation @ apps/france-telecom/test-events/ft-1__event3.txt

