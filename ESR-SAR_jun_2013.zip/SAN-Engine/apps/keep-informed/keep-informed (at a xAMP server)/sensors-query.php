<?php
###################################
# !!!   SET these variables   !!! #
###################################
$db_host = 'localhost';
$db_user = 'root';
$db_pwd = '<you password>';
$database = 'sensors_db';


	function calc_dist($lat1, $lon1, $lat2, $lon2) {
		$r = 6371; // km
		$dLat = ($lat2-$lat1) * pi() / 180;
		$dLon = ($lon2-$lon1) * pi() / 180;
		$lat1 = $lat1 * pi() / 180;
		$lat2 = $lat2 * pi() / 180;

		$a = sin($dLat/2) * sin($dLat/2) +
				sin($dLon/2) * sin($dLon/2) * cos($lat1) * cos($lat2); 
		$c = 2 * atan2(sqrt($a), sqrt(1-$a)); 
		$d = $r * $c;
		return round($d*1000);
	}


// Get query parameters from query string
$lat = $_GET['lat'];
$lon = $_GET['lon'];
$rng = $_GET['range'];
$base = $_GET['base'];

if (!$rng || trim($rng)=='') $rng = 10 * 1000;	// 10Km

// Load and prepare templates
$output = file_get_contents('templ-action-pool-header.txt');
$sensor = file_get_contents('templ-action-pool-sensor.txt');

$output = str_replace('%BASE%', $base, $output);
$sensor = str_replace('%BASE%', $base, $sensor);

date_default_timezone_set('UTC');
$output = str_replace('%TIMESTAMP%', date(DATE_ATOM), $output);

// Connect to database and query
$table = 'sensors';

if (!mysql_connect($db_host, $db_user, $db_pwd))
    die("Can't connect to database");

if (!mysql_select_db($database))
    die("Can't select database");

// sending query
//$qry = "SELECT *, sqrt((lat-$lat)*(lat-$lat)+(lon-$lon)*(lon-$lon)) dist FROM {$table} WHERE (lat-$lat)*(lat-$lat)+(lon-$lon)*(lon-$lon) < $rng";
$qry = "SELECT * FROM {$table} ";
$result = mysql_query($qry);
if (!$result) {
    die("Query to show fields from table failed");
}


// 
$list1 = '';
$list2 = '';
while($row = mysql_fetch_assoc($result))
{
    // Retrieve sensor data
	$sid = $row['sid'];
	$name = $row['name'];
	$s_lat = $row['lat'];
	$s_lon = $row['lon'];
	$manufacturer = $row['manufacturer'];
	$owner = $row['owner'];
	$throughput = $row['throughput'];
	$age = $row['age'];
	$accuracy = $row['accuracy'];
//	$dist = $row['dist'];

    // Check if sensor is in range
	$dist = calc_dist($lat, $lon, $s_lat, $s_lon);
	if ($dist > $rng) continue;

    // Prepare sensor sections
	$tmp = ''.$sensor;
	$tmp = str_replace( '%SID%', $sid, $tmp );
	$tmp = str_replace( '%NAME%', $name, $tmp );
	$tmp = str_replace( '%MFC%', $manufacturer, $tmp );
	$tmp = str_replace( '%OWN%', $owner, $tmp );
	$tmp = str_replace( '%THR%', $throughput, $tmp );
	$tmp = str_replace( '%AGE%', $age, $tmp );
	$tmp = str_replace( '%ACC%', $accuracy, $tmp );
	$tmp = str_replace( '%DIST%', $dist, $tmp );
	
    // Append prepared sections to the appropriate lists
	$list1 .= '	san:hasAction	:'.$base.'__SENSOR_'.$sid." ;\n";
	$list2 .= $tmp;
}

// Free resources
mysql_free_result($result);


// Prepare output and send it back to user agent
$output = str_replace( '%SENSOR_URI_LIST%', $list1, $output );
$output = str_replace( '%SENSOR_URI_DETAILS%', $list2, $output );

header('Content-type: text/plain');
echo $output;


?>