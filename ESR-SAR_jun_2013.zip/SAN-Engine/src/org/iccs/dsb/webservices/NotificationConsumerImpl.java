package org.iccs.dsb.webservices;

import java.util.List;

import javax.xml.transform.TransformerException;

import org.iccs.dsb.DsbPubSubHelper;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.ebmwebsourcing.easycommons.xml.XMLHelper;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.NotificationMessageHolderType;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.NotificationMessageHolderType.Message;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.Notify;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.TopicExpressionType;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.utils.WsnbException;
import com.ebmwebsourcing.wsstar.wsnb.services.INotificationConsumer;
import com.ebmwebsourcing.wsstar.wsnb.services.impl.util.Wsnb4ServUtils;

/**
 * @author chamerling
 * 
 */
public class NotificationConsumerImpl implements INotificationConsumer {

    private static INotificationConsumer INSTANCE;

    public static final synchronized INotificationConsumer getInstance(DsbPubSubHelper caller) {
        if (INSTANCE == null) {
            INSTANCE = new NotificationConsumerImpl(caller);
        }
        return INSTANCE;
    }

	protected DsbPubSubHelper caller;
	
    private NotificationConsumerImpl(DsbPubSubHelper caller) {
		this.caller = caller;
    }

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ebmwebsourcing.wsstar.wsnb.services.INotificationConsumer#notify(
	 * com.ebmwebsourcing
	 * .wsstar.basenotification.datatypes.api.abstraction.Notify)
	 */
    public void notify(Notify notify) throws WsnbException {
		this.caller.eventReceived(notify);
    }

}
