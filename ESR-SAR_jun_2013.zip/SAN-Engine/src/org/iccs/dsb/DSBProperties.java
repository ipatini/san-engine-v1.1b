package org.iccs.dsb;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Properties;

public class DSBProperties {
	protected Properties properties;
	
	public DSBProperties() throws IOException {
		properties = new Properties();
		properties.load(this.getClass().getClassLoader().getResourceAsStream("dsb.properties"));
	}
	
	public DSBProperties(String string) throws IOException {
		properties = new Properties();
		BufferedInputStream stream = new BufferedInputStream(new FileInputStream(string));
		properties.load(stream);
		stream.close();
	}
	
	public DSBProperties(Properties prop) throws IOException {
		properties = new Properties();
		properties = (Properties)prop.clone();	// Shallow copy of hashtable. Keys and values are not cloned.
	}
	
	public void printProperties(PrintStream out) {
		Properties p = properties;
		Enumeration keys = p.keys();		
		while (keys.hasMoreElements()) {
			String key = (String)keys.nextElement();
			String value = (String)p.get(key);
			out.println(key + ": " + value);
		}
	}

	// Get Properties
	public String getPublishEndpoint() {
		return properties.getProperty("PUBLISH_ENDPOINT");
	}
	
	public String getSubscribeEndpoint() {
		return properties.getProperty("SUBSCRIBE_ENDPOINT");
	}
	
	public String getTopicsEndpoint() {
		return properties.getProperty("TOPICS_ENDPOINT");
	}

	public String getNotifyEndpoint() {
		return properties.getProperty("NOTIFY_ENDPOINT");
	}
		
	public String getNotificationProducerEndpoint() {
		return properties.getProperty("NOTIFICATION_PRODUCER_ENDPOINT");
	}
	
	public String getProperty(String prop_name) {
		return properties.getProperty(prop_name);
	}
	
	public Object setProperty(String prop_name, String prop_value) {
		return properties.setProperty(prop_name, prop_value);
	}
}
