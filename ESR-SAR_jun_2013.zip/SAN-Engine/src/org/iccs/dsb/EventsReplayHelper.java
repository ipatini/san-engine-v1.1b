/**
 *	Event Replay helper for DSB Pub/Sub helper
 */
package org.iccs.dsb;

import org.iccs.san.cep.ReplayCapable;
import org.iccs.san.util.Configurator;
import org.iccs.san.util.SANThread;

import org.iccs.dsb.DSBProperties;

import java.io.IOException;
import java.io.File;
import java.io.FilenameFilter;
import java.io.FileInputStream;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.Hashtable;
import java.util.Vector;

import javax.xml.namespace.QName;
import org.w3c.dom.Document;

import com.ebmwebsourcing.easycommons.xml.XMLHelper;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.Notify;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.refinedabstraction.RefinedWsnbFactory;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.utils.WsnbException;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EventsReplayHelper implements ReplayCapable {
//	protected static EventsReplayHelper instance = null;
	
	protected EventReceiver dsbHelper;
	protected DSBProperties dsbProperties;
	
	protected boolean replayOn;
	protected String replayFile;
	protected boolean batchReplay;
	protected boolean exitAfterReplay;
	protected int replayDelay;
	protected int replayStartDelay;
	protected int replayEndDelay;
	protected boolean replayNextFlag;
	protected boolean retry;
	protected boolean moreEventsExists;
	protected boolean replayCompleted;
	protected int replayPrintPeriod;
	protected int replayMod;
	protected boolean replayAutoStart;
	protected Thread runner;
	
//	public static EventsReplayHelper getInstance() {
//		return instance;
//	}
	
	public EventsReplayHelper(EventReceiver dsbHelper, DSBProperties dsbProperties) {
//		if (instance!=null) throw new RuntimeException("EventsReplayHelper: <init>: ONLY ONE INSTANCE OF EventsReplayHelper IS ALLOWED!!");
		
		this.dsbHelper = dsbHelper;
		this.dsbProperties = dsbProperties;
		
		activeTopics = new Vector<QName>();
		activeTopicExtras = new Vector<String[]>();
		activeSubscriptions = new Vector<Integer>();
		patterns = new Vector<Pattern>();
		
		configReplay();
//		instance = this;
	}
	
	protected boolean configReplay() {
		// Event replay (if configured)
		try {
			// get replay dir/file name
			String rp = dsbProperties.getProperty("replay-file");
			if (rp!=null && !rp.trim().equals("")) {
				
				// get replay event delay
				String dl = dsbProperties.getProperty("replay-delay");
				int delay = -1;
				if (dl!=null && !dl.trim().equals("")) {
					try { delay = Integer.parseInt(dl); }
					catch (NumberFormatException ex) {
						err().println("EventsReplayHelper: configReplay: ** Invalid Replay delay: "+dl);
						return true;
					}
				}
				if (delay<0) {
					err().println("EventsReplayHelper: configReplay: ** Negative Replay delay: "+dl);
					return true;
				}
				
				// get replay start delay
				String sdl = dsbProperties.getProperty("replay-start-delay");
				int startDelay = -1;
				if (sdl!=null && !sdl.trim().equals("")) {
					try { startDelay = Integer.parseInt(sdl); }
					catch (NumberFormatException ex) {
						err().println("EventsReplayHelper: configReplay: ** Invalid Replay start delay: "+sdl);
						return true;
					}
				}
				if (startDelay<=0) {
					err().println("EventsReplayHelper: configReplay: ** Zero or Negative Replay start delay: "+sdl);
					return true;
				}
				
				// get replay end delay
				String edl = dsbProperties.getProperty("replay-end-delay");
				int endDelay = -1;
				if (edl!=null && !edl.trim().equals("")) {
					try { endDelay = Integer.parseInt(edl); }
					catch (NumberFormatException ex) {
						err().println("EventsReplayHelper: configReplay: ** Invalid Replay end delay: "+edl);
						return true;
					}
				}
				if (endDelay<=0) {
					err().println("EventsReplayHelper: configReplay: ** Zero or Negative Replay end delay: "+edl);
					return true;
				}
				
				// get replay mode
				String mode = dsbProperties.getProperty("replay-mode");
				this.batchReplay = true;
				if (mode!=null && !mode.trim().equals("")) {
					mode = mode.trim().toUpperCase();
					if (mode.startsWith("STEP") || mode.startsWith("MANUAL")) {
						this.batchReplay = false;
						out().println("EventsReplayHelper: configReplay: EVENT REPLAY IN MANUAL MODE");
					} else {
						out().println("EventsReplayHelper: configReplay: EVENT REPLAY IN BATCH MODE");
					}
				}
				
				// get replay print period
				String per = dsbProperties.getProperty("replay-print-period");
				this.replayPrintPeriod = 1000;
				if (per!=null && !per.trim().equals("")) {
					try {
						this.replayPrintPeriod = Integer.parseInt(per);
					} catch (Exception ex) {}
				}
				this.replayPrintPeriod = (this.replayPrintPeriod>0) ? this.replayPrintPeriod : 1000;
				
				// get 'exit after replay' flag
				this.exitAfterReplay = Configurator.checkBoolean(dsbProperties.getProperty("replay-exit-after"), false);
				
				// get 'mod' parameter. I.e. keep the 1st out of 'mod' events, ignore the rest
				String mod = dsbProperties.getProperty("replay-mod");
				this.replayMod = 1;
				if (mod!=null && !mod.trim().equals("")) {
					try {
						this.replayMod = Integer.parseInt(mod);
					} catch (Exception ex) {}
				}
				this.replayMod = (this.replayMod>0) ? this.replayMod : 1;
				
				// get 'auto-start replay' flag
				this.replayAutoStart = Configurator.checkBoolean(dsbProperties.getProperty("replay-auto-start"), true);
				
				// Set variables
				this.replayOn = true;
				this.replayFile = rp;
				this.replayDelay = delay;
				this.replayStartDelay = startDelay;
				this.replayEndDelay = endDelay;
				this.replayNextFlag = true;
				this.moreEventsExists = false;
				this.replayCompleted = false;
				this.retry = false;
				
				if (replayAutoStart) _startReplay();		// see next method
				return true;
			}
			return false;
    	} catch (Exception e) {
    		err().println("EventsReplayHelper: configReplay: ** Cannot start event replay");
			throw new RuntimeException(e);
    	}
	}
	
	protected void _startReplay() {
		runner = new Thread(new Runnable() {
			public void run() {
				try {
					// Start delay
					if (batchReplay) {
						Thread.currentThread().sleep(replayStartDelay);
					}
					// Replay events
					replayEvents(replayFile, replayDelay);
					// End delay
					if (batchReplay) {
						Thread.currentThread().sleep(replayEndDelay);
					}
				} catch (InterruptedException ex) { 
					err().println("EventsReplayHelper: EVENT REPLAY THREAD INTERRUPTED");
				}
				replayCompleted = true;
			}
		}, "EventsReplayHelper: EVENT BATCH REPLAY THREAD");
		runner.setDaemon(true);
		runner.start();
	}
	
	protected void replayEvents(String replayFile, int delay) {
		File f = new File(replayFile);
		if (f.isDirectory()) {
			// Get xml files in directory
			FilenameFilter filter = new FilenameFilter() {
				public boolean accept(File dir, String name) {
					File f = new File(dir, name);
					return name.toUpperCase().endsWith(".XML") && f.isFile();
				}
			};
			File[] xmlFile = f.listFiles(filter);
			
			// Sort xml files by name
			Arrays.sort(xmlFile,
				new Comparator<File>(){
					public int compare(File f1, File f2) {
						return f1.getName().compareTo(f2.getName());
					}
				}
			);
			
			// Replay events from xml file
			out().println("EventsReplayHelper: replayEvents: ** REPLAYING EVENTS from files in directory: "+replayFile);
			String dir = replayFile+File.separator;
			for (int i=0, n=xmlFile.length; i<n; i++) {
				//if (!xmlFile[i].isFile()) continue;
				_replayEvents(dir+xmlFile[i].getName(), delay);
			}
			out().println("EventsReplayHelper: replayEvents: ** REPLAYING EVENTS from files in directory: COMPLETED");
		} else {
			// Replay events from file
			_replayEvents(replayFile, delay);
		}
	}
	
	protected void _replayEvents(String replayFile, int delay) {
		String extra;
		if (batchReplay) extra = "  with replay delay: "+delay; else extra = "";
		out().println("EventsReplayHelper: _replayEvents: ** REPLAYING EVENTS from file: "+replayFile+extra);
		
		moreEventsExists = true;
		try {
		    Pattern pattern = Pattern.compile("<mt:nativeMessage (.*?)</mt:nativeMessage>", Pattern.DOTALL);
		    Matcher matcher = pattern.matcher(fromFile(replayFile));
			int i = 0;
			while (matcher.find()) {
				if (!replayOn) {
					err().println("EventsReplayHelper: _replayEvents: Stopped");
					break;
				}
				if (batchReplay) {
					if (i>0 && !retry) {
						// wait for a while before sending another event
						try { Thread.sleep(delay); }
						catch (InterruptedException ex2) {
							err().println("EventsReplayHelper: _replayEvents: Interrupted: "+ex2);
							break;
						}
					}
				} else {
					boolean stop = false;
					replayNextFlag = false;
					if (retry) { replayNextFlag = true; retry = false; }
					while (!replayNextFlag) {
						try { Thread.currentThread().sleep(100); }
						catch (InterruptedException ex2) {
							err().println("EventsReplayHelper: _replayEvents: Interrupted (2): "+ex2);
							stop = true;
							break;
						}
					}
					if (stop) break;
				}
				i++;
				String nodeXml = matcher.group();
				
				// Search through topic filters to find any matching topics
				synchronized (patterns) {
					synchronized (activeTopics) {
						for (int k=0, n=patterns.size(); k<n; k++) {
							Pattern pat = patterns.elementAt(k);
							Matcher mat = pat.matcher(nodeXml);
							if (mat.find()) {
								QName tp = activeTopics.elementAt(k);
								String descr = activeTopicExtras.elementAt(k)[1];
								// Send event
								if (activeSubscriptions.elementAt(k)>0) {
									try {
										// Send event to DSB engine
										sendEvent(tp, descr, nodeXml);
									} catch (Exception ex) {
										err().println("EventsReplayHelper: _replayEvents: Exception while sending event: "+ex);
										ex.printStackTrace(err());
									}
								}
							}
						}
					}
				}
				
				retry = false;
			}
		} catch (Exception ex) {
			err().println("EventsReplayHelper: _replayEvents: Exception while creating event: "+ex);
			ex.printStackTrace(err());
		}
		moreEventsExists = false;
		
		out().println("EventsReplayHelper: _replayEvents: ** REPLAYING EVENTS from file: "+replayFile+"  DONE");
	}
	
	protected boolean sendEvent(QName replayTopic, String descr, String nodeXml) {
		String topicNS = replayTopic.getNamespaceURI();
		String topicPrefix = replayTopic.getPrefix();
		String topicLocalPart = replayTopic.getLocalPart();
		String topicPrefixAndLocalPart = (topicPrefix.equals("") ? "" : topicPrefix+":")+topicLocalPart;
		try {
			out().println("EventsReplayHelper: sendEvent: Sending notification...");
			String notify = "{"+topicNS+" "+topicLocalPart+" "+topicPrefix+"}\n"+nodeXml;
			dsbHelper.eventReceived(notify);
			out().println("EventsReplayHelper: sendEvent: Sending notification... Done");
			return true;
		} catch (Exception e) {
			err().println("EventsReplayHelper: sendEvent: Exception while creating WSN notification DOM Document: "+e);
			err().println("WSN message (stack trace follows) :\n"+nodeXml);
			err().println("Stack trace:");
			e.printStackTrace(err());
			return false;
		}
	}
	
	protected CharSequence fromFile(String filename) throws IOException {
	    FileInputStream fis = new FileInputStream(filename);
	    FileChannel fc = fis.getChannel();

	    // Create a read-only CharBuffer on the file
	    ByteBuffer bbuf = fc.map(FileChannel.MapMode.READ_ONLY, 0, (int)fc.size());
	    CharBuffer cbuf = Charset.forName("UTF-8").newDecoder().decode(bbuf);
	    return cbuf;
	}
	
	// ReplayCapable methods
	public boolean isReplaying() { return replayOn; }
	public boolean isBatchReplay() { return batchReplay; }
	public boolean exitAfterReplay() { return exitAfterReplay; }
	public boolean hasNextEvent() { return !hasCompleted(); /*return moreEventsExists;*/ }
	public boolean hasCompleted() { return replayCompleted; }
	public boolean replayNextEvent() { replayNextFlag = true; return hasNextEvent(); }
	public boolean replayNextEvents(int num) {
		for (int i=0; i<num; i++) {
			if (!replayNextEvent()) break;
		}
		return hasNextEvent();
	}
	public void startReplay() { if (runner==null) _startReplay(); }
	public void stopReplay() { if (runner!=null) { replayOn = false; try { runner.interrupt(); } catch (Exception ex) {} runner = null; } }
	
	/*
	 *  Topic creation/disposal methods
	 */
	protected static int topicCounter = 0;
	protected Vector<QName> activeTopics;
	protected Vector<String[]> activeTopicExtras;
	protected Vector<Integer> activeSubscriptions;
	protected Vector<Pattern> patterns;
	
	public synchronized QName createTopic(String spec) {
		String[] part = spec.split("[ \t,]", 5);
		if (part.length<4) throw new RuntimeException("EventsReplayHelper: createTopic: Invalid topic specification (1): "+spec);
		String ns = part[0].trim();
		String lp = part[1].trim();
		String pf = part[2].trim();
		String descr = part[3].trim();
		String filter = (part.length>4) ? part[4].trim() : ".";
		if (ns.equals("") || lp.equals("") || pf.equals("")) throw new RuntimeException("EventsReplayHelper: createTopic: Invalid topic specification (2): "+spec);
		
		lp = lp+"-"+(topicCounter++)+"-"+descr;
		QName topic = new QName(ns, lp, pf);
		String[] extra = new String[2];
		extra[0] = pf;
		extra[1] = descr;
		Pattern pattern = Pattern.compile(filter, Pattern.DOTALL);
		
		activeTopics.add(topic);
		activeTopicExtras.add(extra);
		activeSubscriptions.add(new Integer(0));
		patterns.add(pattern);
		return topic;
	}
	
	public synchronized boolean destroyTopic(QName topic) {
		int pos = activeTopics.indexOf(topic);
		if (pos<0) return false;
		activeTopics.removeElementAt(pos);
		activeTopicExtras.removeElementAt(pos);
		activeSubscriptions.removeElementAt(pos);
		patterns.removeElementAt(pos);
		return true;
	}
	
	/*
	 *  Pub/Sub and Publish methods
	 */
	public synchronized String subscribe(QName topic) {
		int pos = activeTopics.indexOf(topic);
		if (pos<0) return null;
		
		int cnt = activeSubscriptions.elementAt(pos);
		cnt++;
		activeSubscriptions.setElementAt(new Integer(cnt), pos);
		
		String UUID = (new Date()).toString();
		out().println("EventsReplayHelper: subscribe: Subscribe to topic: "+topic+". UUID="+UUID);
		return UUID;
	}
	
	public synchronized boolean unsubscribe(QName topic, String UUID) {
		int pos = activeTopics.indexOf(topic);
		if (pos<0) return false;
		
		int cnt = activeSubscriptions.elementAt(pos);
		if (cnt==0) throw new RuntimeException("EventsReplayHelper: unsubscribe: SUBSCRIPTIONS COUNTER=0 for Topic="+topic+", UUID="+UUID);
		cnt--;
		activeSubscriptions.setElementAt(new Integer(cnt), pos);
		
		out().println("EventsReplayHelper: unsubscribe: Unsubscribe from topic: "+topic+". UUID="+UUID);
		return true;
	}
	
	public synchronized boolean publishEvent(QName topic, String content) {
		err().println("EventsReplayHelper: publishEvent: Event publishing is not allowed during event replay");
		err().println("EventsReplayHelper: publishEvent: Topic:  "+topic+", Event Contents:\n"+content);
		return true;
	}
	
	/*
	 *  Other methods
	 */
	protected static PrintStream out() {
		return SANThread.getOut();
	}
	
	protected static PrintStream err() {
		return SANThread.getErr();
	}
}
