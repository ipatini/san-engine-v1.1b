package org.iccs.san.api;


public interface NotDecorator extends Decorator {
}
