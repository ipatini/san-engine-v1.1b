package org.iccs.san.api;

import java.util.Iterator;

public interface Expression extends SANObject {
	public abstract String getDialect();
	public abstract String getDefinition();
	public abstract Iterator<Parameter> getParameters();
	public abstract Object getValue();

	public abstract void setDialect(String dialect);
	public abstract void setDefinition(String expr);
	public abstract void addParameter(Parameter param);
	public abstract void deleteParameter(Parameter param);
	public abstract void setValue(Object value);
}
