package org.iccs.san.api;


public interface ParallelTimeoutAction extends CompositeAction {
	public abstract long getTimeout();
	public abstract void setTimeout(long timeout);
}
