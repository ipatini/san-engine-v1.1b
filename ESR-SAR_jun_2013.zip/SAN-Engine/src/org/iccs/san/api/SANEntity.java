package org.iccs.san.api;

public interface SANEntity extends SANObject {
	public abstract RootGoal[] getRootGoals();
	public abstract boolean isAutoStart();
	
/*	public abstract void createEntity(String url);
	public abstract void destroyEntity();
	public abstract void startEntity();
	public abstract void stopEntity();
	
	public abstract void startRootGoal(RootGoal root);
	public abstract void startRootGoal(RootGoal root, int mode);
	public abstract void stopRootGoal(RootGoal root);
	public abstract Iterator<RootGoal> getRootGoals();*/
}
