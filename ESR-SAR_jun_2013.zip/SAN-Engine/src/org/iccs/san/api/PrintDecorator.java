package org.iccs.san.api;


public interface PrintDecorator extends Decorator {
	public abstract String getMessage();
	public abstract void setMessage(String message);
}
