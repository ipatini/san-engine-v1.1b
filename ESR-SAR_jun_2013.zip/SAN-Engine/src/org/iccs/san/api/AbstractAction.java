package org.iccs.san.api;


public interface AbstractAction extends Action {
	public abstract ActionPool getActionPool();
	public abstract ActionPool getActionPool(String uri);
	public abstract String getSearchMethod();
	public abstract String getExecutionPolicy();
	
	public abstract void setActionPool(ActionPool pool);
	public abstract void setSearchMethod(String searchMethod);
	public abstract void setExecutionPolicy(String execPolicy);
}
