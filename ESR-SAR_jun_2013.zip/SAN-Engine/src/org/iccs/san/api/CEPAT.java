package org.iccs.san.api;


public interface CEPAT extends SANObject {
	public abstract Expression getDefinition();
	public abstract String[] getInputEventTypes();		// ??? Mipws na valw EventType anti gia String
	public abstract String[] getOutputEventTypes();

	public abstract void setDefinition(Expression definition);
	public abstract void setInputEventTypes(String[] types);
	public abstract void setOutputEventTypes(String[] types);
}
