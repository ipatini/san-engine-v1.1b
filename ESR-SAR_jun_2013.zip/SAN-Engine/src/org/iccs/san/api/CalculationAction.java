package org.iccs.san.api;


public interface CalculationAction extends Action {
	public abstract Expression getExpression();
	public abstract void setExpression(Expression expr);
}
