package org.iccs.san.api;


public interface Decorator extends SANNode {
	public abstract SANNode getJob();		// The job following this decorator
	public abstract String getDecoratorType();	// Isws na min xreiazetai

	public abstract void setDecoratorType(String t);
	public abstract void setJob(SANNode job);
}
