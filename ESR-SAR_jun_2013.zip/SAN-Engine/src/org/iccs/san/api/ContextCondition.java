package org.iccs.san.api;


public interface ContextCondition extends SANNode {
	public abstract Expression getExpression();
	public abstract void setExpression(Expression e);
}
