package org.iccs.san.api;

import java.util.Comparator;


public interface SANNode extends SANObject {
	public static final int UNSPECIFIED = 0;
	public static final int SUCCESS = 1;
	public static final int FAILURE = 2;
	public static final int ERROR = 3;
	public static final int EXCEPTION = 4;
	
	public abstract int getOrder();		// H seira tou node se sxesh me ta simblings tou
	public abstract void setOrder(int ord);
	
// Gia sequence / selector / parallel actions 
	public abstract SANNode getNextJob();
	public abstract void setNextJob(SANNode nextJob);
	
	/*
	 *   SAN node comparison staff
	 */
	public static final Comparator<SANNode> Comparator = new SANNodeComparator();
	
	static class SANNodeComparator implements Comparator<SANNode> {
		public int compare(SANNode o1, SANNode o2) {
			int n1 = o1.getOrder();
			int n2 = o2.getOrder();
			if (n1<n2) return -1;
			else if (n1>n2) return +1;
			else return 0;
		}
		
		public boolean equals(SANNode o) {
			return false;
		}
	}
}
