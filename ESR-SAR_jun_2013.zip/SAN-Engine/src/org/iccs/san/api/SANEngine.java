package org.iccs.san.api;

import org.iccs.san.context.Context;
import org.iccs.san.util.Configurator;
import java.util.Enumeration;

/**
 *	The SAN Execution Engine Factory
 */
public interface SANEngine {
	public abstract void startExecution();
	public abstract void stopExecution();
	public abstract void suspend();
	public abstract void resume();
	
	public abstract Configurator getConfigurator();
	public abstract void setConfigurator(Configurator configurator);
	
	// Entity methods
	public abstract SANEntity createEntity(String entityURI);
	public abstract SANEntity createEntity(String entityURI, boolean autoStartRootGoals);
	public abstract SANEntity destroyEntity(String entityURI);
	public abstract Enumeration<SANEntity> getEntities();
	
	// Root Goal methods
	public abstract void startRootGoal(String rootURI, String entityURI);
	public abstract void stopRootGoal(String rootURI);
	
	// Helper methods
	public abstract Context getGlobalContext();
	public abstract Object evaluateExpression(Expression expr);
	public abstract Object evaluateExpression(Expression expr, Context localContext);
}
