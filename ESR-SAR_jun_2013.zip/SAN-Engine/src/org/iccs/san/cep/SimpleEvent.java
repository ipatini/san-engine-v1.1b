package org.iccs.san.cep;

import org.iccs.san.api.CEPAT;
import org.iccs.san.util.SANHelper;
import org.iccs.san.util.SANThread;
import java.util.Date;
import java.util.Properties;
import javax.xml.namespace.QName;

/**
 *	A simple implementation of Event interface
 */
public class SimpleEvent implements Event {
	protected String eventId;
	protected String eventSource;
	protected Date sendDate;
	protected Date receivedDate;
	protected boolean complex;
	protected CEPAT  cepat;
	protected Properties properties;
	protected String content;
	protected QName topic;
	protected Object payload;
	protected String payloadType;
	
	protected SimpleEvent() {
		complex = false;
		cepat = null;
		properties = new Properties();
		setSendTimestamp(new Date());
	}
	
	public SimpleEvent(String id, String source) {
		this();
		setEventId(id);
		setSource(source);
	}
	
	public SimpleEvent(String id, String source, QName topic) {
		this();
		setEventId(id);
		setSource(source);
		setTopic(topic);
	}
	
	public SimpleEvent(String id, String source, QName topic, String content) {
		this();
		setEventId(id);
		setSource(source);
		setTopic(topic);
		setContent(content);
	}
	
	public SimpleEvent(String id, String source, QName topic, String content, Date sendDate) {
		this();
		setEventId(id);
		setSource(source);
		setTopic(topic);
		setContent(content);
		setSendTimestamp(sendDate);
	}
	
	public String getEventId() { return eventId; }
	public String getSource() { return eventSource; }
	public Date getSendTimestamp() { return sendDate; }
	public Date getReceiveTimestamp() { return receivedDate; }
	public CEPAT getCEPAT() { return cepat; }
	public boolean isComplex() { return complex; }
	public Properties getSemantics() { return properties; }
	public String getContent() { return content; }
	public QName getTopic() { return topic; }
	public Object getPayload() { return payload; }
	public String getPayloadType() { return payloadType; }
	
	public void setEventId(String id) { eventId = id; }
	public void setSource(String source) { eventSource = source; }
	public void setSendTimestamp(Date sendDate) { this.sendDate = sendDate; }
	public void setReceiveTimestamp(Date receivedDate) { this.receivedDate = receivedDate; }
	public void setCEPAT(CEPAT cepat) { this.cepat = cepat; }
	public void setComplex(boolean complex) { this.complex = complex; }
	public void setSemantics(Properties semantics) { properties = semantics; }
	public void setContent(String content) { this.content = content; }
	public void setTopic(QName topic) { this.topic = topic; }
	public void setPayload(Object payload) { this.payload = payload; }
	public void setPayloadType(String payloadType) { this.payloadType = payloadType; }
}
