package org.iccs.san.cep;

import org.iccs.san.api.CEPAT;
import org.iccs.san.api.SANObject;
import org.iccs.san.util.Configurator;
import java.util.Hashtable;
import java.util.concurrent.LinkedBlockingQueue;

/**
 *	An event manager to notify waiting threads per CEPAT
 */
public class EventManager {
	protected Hashtable<String,Object> listeners;
	protected Hashtable<String,LinkedBlockingQueue<Event>> queues;
	
	public EventManager() {
		listeners = new Hashtable<String,Object>();
		queues = new Hashtable<String,LinkedBlockingQueue<Event>>();
	}
	
	protected String getHashCode(Object obj) {
		return Long.toString( obj.hashCode() );
	}
	
	public synchronized void addEventListener(Object obj) {
		String uri;
		//if (obj==null || (uri=obj.getObjectURI())==null || !uri.trim().equals("")) return;
		//uri = obj.getObjectURI();
		uri = getHashCode(obj);
		
		if (listeners.containsKey(uri)) return;
		listeners.put(uri, obj);
		queues.put(uri, new LinkedBlockingQueue<Event>());
	}
	
	public synchronized void removeEventListener(Object obj) {
		String uri;
		//if (obj==null || (uri=obj.getObjectURI())==null || !uri.trim().equals("")) return;
		//uri = obj.getObjectURI();
		uri = getHashCode(obj);
		
		listeners.remove(uri);
		LinkedBlockingQueue<Event> q = queues.remove(uri);
		q.clear();
	}
	
	/**
	 * This is a blocking operation
	 */
	public Event nextEvent(Object obj) throws InterruptedException {
		String uri;
		//if (obj==null || (uri=obj.getObjectURI())==null || !uri.trim().equals("")) return;
		//uri = obj.getObjectURI();
		uri = getHashCode(obj);
		
		LinkedBlockingQueue<Event> q = queues.get(uri);
		return q.take();
	}
	
	public synchronized void dispatchEvent(Event event) {
		//if (event==null) return;
		
		for (LinkedBlockingQueue<Event> q : queues.values()) {
			try { q.put(event); }
			catch (InterruptedException ex) { throw new RuntimeException("EventManager: dispatchEvent: INTERNAL ERROR: PUT operation interrupted", ex); }
		}
	}
}
