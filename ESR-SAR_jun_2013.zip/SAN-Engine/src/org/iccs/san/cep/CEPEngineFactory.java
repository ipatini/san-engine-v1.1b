package org.iccs.san.cep;

import org.iccs.san.util.Configurator;
import java.util.Hashtable;

/**
 *	The CEP Engine Factory
 */
public class CEPEngineFactory {
	protected static Hashtable<String,CEPEngine> enginePool;
	protected Configurator configurator;
	
	public static CEPEngineFactory getCEPEngineFactory(Configurator configurator) {
		return new CEPEngineFactory(configurator);
	}
	
	protected CEPEngineFactory(Configurator configurator) {
		setConfigurator(configurator);
	}
	
	public CEPEngine getCEPEngine() throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		String className = configurator.configuration.getProperty("cep-engine.class");
		if (className==null || className.trim().equals("")) throw new RuntimeException("CEPEngineFactory: getCEPEngine: Missing 'cep-engine.class' specification in configuration");
		return getCEPEngine( className );
	}
	
	public CEPEngine getCEPEngine(String className) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		if (enginePool==null) {
			enginePool = new Hashtable<String,CEPEngine>();
		}
		
		if (enginePool.containsKey(className)) {
			return enginePool.get(className);
		}
		
		CEPEngine engine = (CEPEngine)Class.forName(className).newInstance();
		enginePool.put( className, engine );
		return engine;
	}
	
	public Configurator getConfigurator() { return this.configurator; }
	public void setConfigurator(Configurator configurator) { this.configurator = configurator; }
}
