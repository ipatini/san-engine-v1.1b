package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import org.iccs.san.context.Context;
import org.iccs.san.repository.basic.BasicParallelAnyAction;
import org.iccs.san.repository.basic.BasicParallelAllAction;
import org.iccs.san.repository.basic.BasicParallelTimeoutAction;
import org.iccs.san.util.Metadata;
import org.iccs.san.util.SANThread;
import java.util.*;

public class NaiveEngineAbstractAction extends NaiveEngineAction {
	public NaiveEngineAbstractAction(Action action, NaiveEngineSANObject parent) {
		super(action, parent);
	}
	
	public int execute() throws InterruptedException {
		// Get action pool uri, search method and exec. policy from metadata (if they exists)
		Metadata metaActionPoolUri = action.getMetadata("action-pool");
		Metadata metaSearchMethod = action.getMetadata("search-method");
		Metadata metaExecPolicy = action.getMetadata("execution-policy");
		
		// Initialize abstract action parameters from metadata values
		ActionPool actionPool = null;
		String searchMethod = null;
		String execPolicy = null;
		
		Context ctx = SANThread.current().context;
		
		if (metaActionPoolUri!=null) {
			String uri = (String)metaActionPoolUri.getValue(ctx);
			if (uri!=null && !uri.trim().equals("")) {
				actionPool = ((AbstractAction)action).getActionPool(uri);
			}
		}
		if (metaSearchMethod!=null) {
			String v = (String)metaSearchMethod.getValue(ctx);
			if (v!=null && !v.trim().equals("")) {
				searchMethod = v;
			}
		}
		if (metaExecPolicy!=null) {
			String v = (String)metaExecPolicy.getValue(ctx);
			if (v!=null && !v.trim().equals("")) {
				execPolicy = v;
			}
		}
		
		// Initialize abstract action parameters from node settings if not already initialized
		actionPool = (actionPool!=null) ? actionPool : ((AbstractAction)action).getActionPool();
		searchMethod = (searchMethod!=null) ? searchMethod : ((AbstractAction)action).getSearchMethod();
		execPolicy = (execPolicy!=null) ? execPolicy : ((AbstractAction)action).getExecutionPolicy();
		
		// Check for missing parameters
		String errors = "";
		if (actionPool==null) {
			errors += "NaiveEngineAbstractAction: execute: No Action Pool was specified or Action Pool does not exist\n";
		}
		if (searchMethod==null || searchMethod.trim().equals("")) {
			errors += "NaiveEngineAbstractAction: execute: No Action Pool Search Method was specified\n";
		}
		if (execPolicy==null || execPolicy.trim().equals("")) {
			errors += "NaiveEngineAbstractAction: execute: No Action Pool Execution Policy was specified\n";
		}
		if (!errors.equals("")) {
			logError(errors);
			return FAILURE;
		}
		
		// Prepare needed parameters
		searchMethod = searchMethod.trim();
		execPolicy = execPolicy.trim().toUpperCase();
		String apName = actionPool.getName();
		
		// DEBUG MESSAGES
// XXX
/*		SANNode[] jobs = actionPool.getPoolJobs();
		logInfo("================================================================");
		logInfo("EXECUTING ABSTRACT ACTION :");
		logInfo("\tAction Pool      : "+apName);
		logInfo("\tSearch Method    : "+searchMethod);
		logInfo("\tExecution Policy : "+execPolicy);
		logInfo("\tNum of Actions   : "+((jobs==null) ? "NULL" : jobs.length));
		if (jobs!=null) {
			logInfo("\tPool Actions     : ");
			for (int i=0; i<jobs.length; i++) {
				logInfo("\t  "+(i+1)+".\tAction '"+jobs[i].getName()+"' : "+jobs[i].getClass().getName());
			}
		}*/
		
		// Select a job from Action Pool
		Iterator<ActionPoolSearchMethod.Result> results = null;
		boolean sm_initialized = false;
		try {
			ActionPoolSearchMethod sm = (ActionPoolSearchMethod)Class.forName(searchMethod).newInstance();
			sm_initialized = true;
//			Context ctx = SANThread.current().context;
			results = sm.searchAndOrderJobs(actionPool, ctx, action);
		} catch (Exception ex) {
			if (!sm_initialized) {
				logError("NaiveEngineAbstractAction: execute: Failed to initialize Action Pool Search Method: "+ex);
			} else {
				logError("NaiveEngineAbstractAction: execute: Exception while searching in Action Pool: "+ex);
			}
			throw new RuntimeException(ex);
		}
		
		// Execute selected job(s)
		if (results==null || !results.hasNext()) {
			logInfo("NaiveEngineAbstractAction: execute: No jobs were matched in Action Pool '"+apName+"' using Search Method: "+searchMethod);
			return FAILURE;
		}
		
		ActionPoolSearchMethod.Result rs = results.next();
		SANNode job = rs.getJob();
		job.attachObject("action-pool-item-rank", rs.getRank());
		job.attachObject("action-pool-item-relevance", rs.getRelevance());
		job.attachObject("action-pool-item-description", rs.getDescription());
		int rc;
		if (!results.hasNext()) {
			logInfo("NaiveEngineAbstractAction: execute: ONE job matched in Action Pool '"+apName+"' using Search Method: "+searchMethod);
			logInfo("NaiveEngineAbstractAction: execute: Executing Job '"+job.getName()+"'");
			rc = NaiveEngineSANNode.getInstance( job, this ).execute();
			logInfo("NaiveEngineAbstractAction: execute: Matched Job ended with : "+getReturnCodeString(rc));
			return rc;
		} else {
			logInfo("NaiveEngineAbstractAction: execute: MORE than one jobs matched in Action Pool '"+apName+"' using Search Method: "+searchMethod);
			logInfo("NaiveEngineAbstractAction: execute: Execution Policy '"+execPolicy+"' will be used.");
			
			if (execPolicy.equals("ONE_FIRST")) {
				logInfo("NaiveEngineAbstractAction: execute: Executing ONE FIRST policy with Job '"+job.getName()+"'");
				rc = NaiveEngineSANNode.getInstance( job, this ).execute();
				logInfo("NaiveEngineAbstractAction: execute: ONE FIRST policy ended with: "+getReturnCodeString(rc));
				return rc;
			} else
			if (execPolicy.equals("ONE_RANDOM")) {
				job = getRandomJob(job, results);
				logInfo("NaiveEngineAbstractAction: execute: Executing ONE RANDOM policy with Job '"+job.getName()+"'");
				rc = NaiveEngineSANNode.getInstance( job, this ).execute();
				logInfo("NaiveEngineAbstractAction: execute: ONE RANDOM policy ended with: "+getReturnCodeString(rc));
				return rc;
			} else
			if (execPolicy.equals("PARALLEL_ANY")) {
				CompositeAction ca = createParallelAction(new BasicParallelAnyAction(), job, results);
				logInfo("NaiveEngineAbstractAction: execute: Executing PARALLEL ANY policy");
				rc = NaiveEngineSANNode.getInstance( ca, this ).execute();
				logInfo("NaiveEngineAbstractAction: execute: PARALLEL ANY policy ended with: "+getReturnCodeString(rc));
				return rc;
			} else
			if (execPolicy.equals("PARALLEL_ALL")) {
				CompositeAction ca = createParallelAction(new BasicParallelAllAction(), job, results);
				logInfo("NaiveEngineAbstractAction: execute: Executing PARALLEL ALL policy");
				rc = NaiveEngineSANNode.getInstance( ca, this ).execute();
				logInfo("NaiveEngineAbstractAction: execute: PARALLEL ALL policy ended with: "+getReturnCodeString(rc));
				return rc;
			} else
			if (execPolicy.equals("PARALLEL_TIMEOUT")) {
				// Get timeout parameter
				String tmStr = ((AbstractAction)action).getProperty("timeout");
				if (tmStr==null || tmStr.trim().equals("")) {
					throw new RuntimeException("NaiveEngineAbstractAction: execute: No Timeout was specified for PARALLEL TIMEOUT Execution Policy");
				}
				long timeout = Long.parseLong(tmStr.trim());
				
				// Execute
				ParallelTimeoutAction pta;
				CompositeAction ca = createParallelAction(pta = new BasicParallelTimeoutAction(), job, results);
				pta.setTimeout(timeout);
				logInfo("NaiveEngineAbstractAction: execute: Executing PARALLEL TIMEOUT policy with timeout: "+((double)timeout/1000d)+" secs");
				rc = NaiveEngineSANNode.getInstance( ca, this ).execute();
				logInfo("NaiveEngineAbstractAction: execute: PARALLEL TIMEOUT policy ended with: "+getReturnCodeString(rc));
				return rc;
			} else
			if (execPolicy.equals("CLONE_SAN")) {
// XXX
throw new RuntimeException("NaiveEngineAbstractAction: execute: NOT YET IMPLEMENTED:  'CLONE_SAN' Execution Policy");
			} else {
				logError("NaiveEngineAbstractAction: execute: Invalid Abstract Action Execution Policy: "+execPolicy);
				throw new RuntimeException("NaiveEngineAbstractAction: execute: Invalid Abstract Action Execution Policy: "+execPolicy);
			}
		}
	}
	
	protected CompositeAction createParallelAction(CompositeAction action, SANNode job, Iterator<ActionPoolSearchMethod.Result> results) {
		action.addJob(job);
		while (results.hasNext()) {
			ActionPoolSearchMethod.Result rs = results.next();
			job = rs.getJob();
			job.attachObject("action-pool-item-rank", rs.getRank());
			job.attachObject("action-pool-item-relevance", rs.getRelevance());
			job.attachObject("action-pool-item-description", rs.getDescription());
			action.addJob(job);
		}
		return action;
/* 
// ENALLAKTIKO API
		action.setFirstJob(job);
		SANNode prev = job;
		while (results.hasNext()) {
			job = results.next().getJob();
			prev.setNextJob(job);
			prev = job;
		}
		return action;
*/
	}
	
	protected SANNode getRandomJob(SANNode job, Iterator<ActionPoolSearchMethod.Result> results) {
		Vector<SANNode> tmp = new Vector<SANNode>();
		tmp.add(job);
		while (results.hasNext()) {
			ActionPoolSearchMethod.Result rs = results.next();
			job = rs.getJob();
			job.attachObject("action-pool-item-rank", rs.getRank());
			job.attachObject("action-pool-item-relevance", rs.getRelevance());
			job.attachObject("action-pool-item-description", rs.getDescription());
			tmp.add(job);
		}
		int rr = (int)(tmp.size() * Math.random());
		return tmp.get(rr);
	}
}
