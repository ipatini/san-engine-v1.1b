package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import org.iccs.san.util.SANThread;

public class NaiveEngineMountAction extends NaiveEngineAction {
	public NaiveEngineMountAction(Action action, NaiveEngineSANObject parent) {
		super(action, parent);
	}
	
	public int execute() throws InterruptedException {
		String referredSAN = ((MountAction)action).getReferencedSAN();
		logInfo("Executing MOUNT ACTION : Mounting '"+referredSAN+"' SAN");
		Goal tmpGoal = ((ExecutionContext)SANThread.current().data).repository.getSAN(referredSAN);
		if (tmpGoal==null) {
			logError("SAN '"+referredSAN+"' was NOT FOUND in repository");
			return ERROR;
		} else {
			NaiveEngineGoal goal = new NaiveEngineGoal( tmpGoal, this );
			logError("SAN '"+tmpGoal.getName()+"' was FOUND in repository and was mounted");
			return goal.execute();
		}
	}
}
