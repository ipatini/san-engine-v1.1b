package org.iccs.san.engine.naive;

import org.iccs.san.api.*;


public class NaiveEngineExceptionHandlerDecorator extends NaiveEngineDecorator {
	protected ExceptionHandlerDecorator decorator;
	
	public NaiveEngineExceptionHandlerDecorator(Decorator decorator, NaiveEngineSANObject parent) {
		super(decorator, parent);
		this.decorator = (ExceptionHandlerDecorator)decorator;
	}
	
	public int execute() throws InterruptedException {
		try {
			logInfo("Executing EXCEPTION HANDLER DECORATOR Job '"+getJob().getName()+"'");
			int rc = super.execute();
			logInfo("EXCEPTION HANDLER DECORATOR Job ended with : "+getReturnCodeString(rc));
			return rc;
		} catch (Exception ex) {
			logInfo("EXCEPTION HANDLER DECORATOR Job raised an exception : "+ex);
			String exceptionType = this.decorator.getExceptionType();
			try {
				if (Class.forName( exceptionType ).isInstance( ex )) {
					SANNode job = decorator.getFailoverJob();
					if (job!=null) {
						logInfo("Exception '"+exceptionType+"' was caught and failover job '"+job.getName()+"' will be executed");
						int rc = NaiveEngineSANNode.getInstance( job, this ).execute();
						logInfo("Failover job '"+job.getName()+"' ended with : "+getReturnCodeString(rc));
						return rc;
					} else {
						logInfo("Exception '"+exceptionType+"' was caught but no failover job is specified. Decorator returns SUCCESS");
						return SUCCESS;
					}
				} else {
					logInfo("Exception was NOT caught so EXCEPTION HANDLER DECORATOR returns : EXCEPTION");
					return EXCEPTION;
				}
			} catch (ClassNotFoundException ex2) {
				logError("NaiveEngineExceptionHandlerDecorator: execute: Exception class '"+exceptionType+"' not found");
				return EXCEPTION;
			} catch (Exception ex2) {
				logError("NaiveEngineExceptionHandlerDecorator: execute: Exception raised during failover job execution");
				logError(ex2);
				return EXCEPTION;
			}
		}
	}
}
