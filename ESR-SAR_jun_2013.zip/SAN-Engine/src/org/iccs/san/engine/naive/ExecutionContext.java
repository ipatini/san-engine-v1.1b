package org.iccs.san.engine.naive;

import org.iccs.san.api.SANEngine;
import org.iccs.san.api.SANRepository;
import org.iccs.san.api.SANNode;
import org.iccs.san.context.Context;
import org.iccs.san.util.SANThread;
import java.util.logging.Logger;

class ExecutionContext {
	public SANRepository repository;
//	public Context context;
	public SANNode root;
	public SANEngine engine;
	
	public ExecutionContext() {
	}
	
	public ExecutionContext(boolean cloneCurrent) {
		if (cloneCurrent) {
			Thread thread = Thread.currentThread();
			if (thread instanceof SANThread) {
				SANThread thread1 = (SANThread)thread;
				if (thread1.data!=null && thread1.data instanceof ExecutionContext) {
					ExecutionContext data1 = (ExecutionContext)thread1.data;
					this.repository = data1.repository;
//					this.context = data1.context;
					this.root = data1.root;
					this.engine = data1.engine;
				}
			}
		}
	}
	
	public static ExecutionContext copyCurrent() {
		return new ExecutionContext(true);
	}
}
