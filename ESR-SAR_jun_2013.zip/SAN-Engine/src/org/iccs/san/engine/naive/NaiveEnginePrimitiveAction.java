package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import org.iccs.san.util.ActionHelper;
import javax.xml.namespace.QName;


public class NaiveEnginePrimitiveAction extends NaiveEngineAction {
	protected String command;
	protected NaiveEngineExpression expression;
	
	public NaiveEnginePrimitiveAction(Action action, NaiveEngineSANObject parent) {
		super(action, parent);
	}
	
	protected NaiveEngineExpression getExpression() { return this.expression; }
	protected void setExpression(Expression expression) { this.expression = new NaiveEngineExpression( this, expression ); }
	
	public int execute() throws InterruptedException {
		String actionName = ((Action)action).getName();
		String cmd = ((PrimitiveAction)action).getCommand();
		if (cmd!=null && !cmd.trim().equals("")) {
			logInfo("Executing PRIMITIVE ACTION with Command : "+cmd);
			cmd = cmd.trim().toUpperCase();
			if (cmd.startsWith("DELAY ")) {
				String[] args = cmd.substring(6).split("[ ]+");
				int delay = Integer.parseInt(args[0]);
				logInfo("Action '"+((Action)action).getName()+"' is delaying for "+delay+" seconds...");
				Thread.currentThread().sleep(delay*1000);
				if (args.length>1) {
					args[1] = args[1].toUpperCase();
					if (args[1].equals("SUCCESS")) return SUCCESS;
					else if (args[1].equals("FAILURE")) return FAILURE;
					else if (args[1].equals("ERROR")) return ERROR;
					else if (args[1].equals("EXCEPTION")) return EXCEPTION;
				}
			} else
			if (cmd.startsWith("THROW ")) {
				String[] args = cmd.substring(6).split("[ ]+", 2);
				String exception = args[0];
				String mesg;
				if (args.length>1) {
					mesg = args[1];
				} else {
					mesg = "Action '"+((Action)action).getName()+"' : executing THROW command";
				}
				logInfo("Action '"+((Action)action).getName()+"' throws exception '"+exception+"' with message '"+mesg+"'");
				if (exception.equals("RUNTIME")) {
					throw new RuntimeException(mesg);
				} else
				if (exception.equals("INTERRUPTED")) {
					throw new InterruptedException(mesg);
				}
			} else
			if (cmd.startsWith("EXPRESSION")) {
				setExpression( ((PrimitiveAction)action).getExpression() );
				Object result = this.expression.evaluate();
				logInfo("Primitive Action expression evaluated to: "+result);
			} else
			if (cmd.startsWith("SEND EVENT")) {
				// Check command
				String[] part = ((PrimitiveAction)action).getCommand().substring("SEND EVENT".length()).split("[ \t]");
				boolean missingArgs = false;
				int partCnt = 0;
				if (part.length<3) {
					missingArgs = true;
				}
				for (int i=0; i<part.length; i++) {
					part[i] = part[i].trim();
					if (!part[i].equals("")) partCnt++;
				}
				if (missingArgs || partCnt<3) {
					String mesg = "Action '"+actionName+"' : too few arguments in SEND EVENT command: "+cmd+"\n"+
							"Usage: SEND EVENT <namespace-uri> <topic-local-part> <prefix> <xml-payload>";
					logError(mesg);
					throw new RuntimeException(mesg);
				}
				
				// Build topic
				int a=-1, b=-1, c=-1, d=-1;
				for (int i=0; i<part.length; i++) {
					if (part[i].equals("")) continue;
					if (a==-1) a=i;
					else if (b==-1) b=i;
					else if (c==-1) c=i;
					else if (d==-1) d=i;
				}
				QName topic = new QName(part[a], part[b], part[c]);
				
				// Get event payload
				String payload = null;
				setExpression( ((PrimitiveAction)action).getExpression() );
				if (this.expression!=null) {
					// If an expression is specified, use it to get recommendation
					Object result = this.expression.evaluate();
					if (result!=null) payload = result.toString();
				}
				if (payload==null || payload.trim().equals("")) {
					// If no expression is specified or returned null, consider the remaining command arguments as recommendation
					payload = "";
					if (d>0) {
						for (int i=d; i<part.length; i++) {
							payload+=part[i];
							payload+=" ";
						}
					}
					payload = payload.trim();
				}
				if (payload==null || payload.trim().equals("")) {
					// No payload. Don't send event and FAIL action
					logInfo("Event send: No event payload specified");
					logInfo("Event send: FAILED");
					return FAILURE;
				}
				
				// Send event
				String eid = ActionHelper.getUniqueEventId();
				logInfo("Action '"+actionName+"' is sending event: ID="+eid+", TOPIC="+topic+", PAYLOAD="+payload);
				boolean r = ActionHelper.getInstance().sendEvent(eid, actionName, topic, payload);
				if (r) logInfo("Event send: OK");
				else { logInfo("Event send: FAILED"); return FAILURE; }
			}
// TODO: relay to Task/Action Execution Component
			return SUCCESS;
		} else {
			logError("Executing PRIMITIVE ACTION : ERROR : No command was specified");
			return FAILURE;
		}
	}
}
