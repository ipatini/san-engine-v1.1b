package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import java.util.Arrays;


public class NaiveEngineSelectorAction extends NaiveEngineCompositeAction {
	public NaiveEngineSelectorAction(Action action, NaiveEngineSANObject parent) {
		super(action, parent);
	}
	
	public int execute() throws InterruptedException {
		int selMeth = ((SelectorAction)action).getSelectionMethod();
		String selMethStr;
		if (selMeth==SelectorAction.ORDER_UNSPECIFIED) { selMethStr = "UNSPECIFIED"; selMeth = -1; }
		else if (selMeth==SelectorAction.ORDER_SEQUENTIAL) selMethStr = "SEQUENTIAL";
		else if (selMeth==SelectorAction.ORDER_RANDOM) selMethStr = "RANDOM";
		else if (selMeth==SelectorAction.ORDER_PROBABLISTIC) selMethStr = "PROBABLISTIC";
		else { selMethStr = "Invalid Selection Method specification : "; selMeth = -1; }
		if (selMeth<0) throw new RuntimeException("NaiveEngineSelectorAction: execute: Unspecified or Invalid selection method: "+selMeth);
		
		logInfo("Executing SELECTOR ACTION with selection method '"+selMethStr+"' ...");
		SANNode job = ((CompositeAction)action).getFirstJob();
		int rc = FAILURE;
		if (job==null) {
			logError("No jobs were found");
			return rc;
		}
		
		int i=0;
		while (job!=null) {
			logInfo("....Starting child action #"+(i+1)+" :");
			NaiveEngineSANNode node = NaiveEngineSANNode.getInstance((SANNode)job, this);
			rc = node.execute();
			logInfo("....Child action #"+(i+1)+" ended with return code : "+getReturnCodeString(rc));
			if (rc==SUCCESS) break;
			job = job.getNextJob();
			i++;
		}
		return rc;
	}
}
