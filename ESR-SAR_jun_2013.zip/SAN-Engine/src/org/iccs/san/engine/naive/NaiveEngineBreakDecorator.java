package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import org.iccs.san.util.SANThread;

public class NaiveEngineBreakDecorator extends NaiveEngineDecorator {
	protected BreakDecorator decorator;
	
	public NaiveEngineBreakDecorator(Decorator decorator, NaiveEngineSANObject parent) {
		super(decorator, parent);
		this.decorator = (BreakDecorator)decorator;
	}
	
	public int execute() throws InterruptedException {
		String mesg = decorator.getMessage();
		logInfo("*******************************************************");
		logInfo("DEBUG BREAK DECORATOR :   "+mesg);
		logInfo("*******************************************************");
		logInfo("");
		logInfo("TYPE 'continue' IN CLI PROMPT TO CONTINUE");
		logInfo("");
		
		((NaiveSANEngine)((ExecutionContext)SANThread.current().data).engine).suspend();
		
		logInfo("Executing DEBUG BREAK DECORATOR Job '"+getJob().getName()+"'");
		int rc = super.execute();
		logInfo("DEBUG BREAK DECORATOR Job ended with : "+getReturnCodeString(rc));
		
		return rc;
	}
}
