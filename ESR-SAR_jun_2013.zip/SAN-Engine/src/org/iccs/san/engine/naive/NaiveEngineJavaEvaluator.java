package org.iccs.san.engine.naive;

import org.iccs.san.context.Context;
import java.lang.reflect.*;

class NaiveEngineJavaEvaluator extends NaiveEngineEvaluator {
	public boolean isBoolean(NaiveEngineSANObject owner, String definition, Context context) {
		Class rtype = getMethod(definition).getReturnType();
		return rtype.equals(Boolean.class) || rtype.equals(boolean.class);
	}
	
	public Object evaluate(NaiveEngineSANObject owner, String definition, Context context) {
		try {
			Method meth = getMethod(definition);
			Class  clss = meth.getDeclaringClass();
			Object obj = clss.newInstance();
			return meth.invoke(obj);
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}
	
	@SuppressWarnings("unchecked")
	protected Method getMethod(String definition) {
		definition = definition.replaceAll("[\\s]", "");
		int p = definition.lastIndexOf(".");
		if (p<1) {
			throw new RuntimeException("NaiveEngineJavaEvaluator: evaluate: Invalid Java Expression: Use fully qualified method names (i.e. include package and class name): "+definition);
		}
		String clss = definition.substring(0, p);
		String meth = definition.substring(p+1);
		if (clss.equals("") || meth.equals("")) {
			throw new RuntimeException("NaiveEngineJavaEvaluator: evaluate: Invalid Java Expression: Missing class or method: "+definition);
		}
		
		try {
			Class cls = Class.forName(clss);
			return cls.getMethod(meth);
		} catch (Exception ex) {
			throw new RuntimeException("NaiveEngineJavaEvaluator: evaluate: Java Expression evaluation failed: "+ex+". Java Expression: "+definition);
		}
	}
}
