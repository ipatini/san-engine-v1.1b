package org.iccs.san.engine.naive;

import org.iccs.san.api.*;

public class NaiveEngineNotDecorator extends NaiveEngineDecorator {
	public NaiveEngineNotDecorator(Decorator decorator, NaiveEngineSANObject parent) {
		super(decorator, parent);
	}
	
	public int execute() throws InterruptedException {
		logInfo("Executing NOT DECORATOR Job '"+getJob().getName()+"'");
		int rc = super.execute();
		int new_rc = (rc!=SUCCESS) ? SUCCESS : FAILURE;
		logInfo("NOT DECORATOR Job ended with : "+getReturnCodeString(new_rc));
		return new_rc;
	}
}
