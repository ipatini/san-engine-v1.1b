package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import org.iccs.san.context.*;
import org.iccs.san.engine.*;
import org.iccs.san.repository.RepositoryFactory;
import org.iccs.san.util.*;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.concurrent.locks.LockSupport;
import java.util.concurrent.LinkedBlockingDeque;

/**
 *	The SAN execution engine - Naive implementation
 */
public class NaiveSANEngine implements SANEngine {
	public static final String ENGINE_VERSION = "Naive SAN Engine, Version 2.0, Dec 2011";
	
	protected Configurator configurator;
	protected Context globalContext;
	protected SANRepository repository;
	protected SANThreadPool<ExecutionContext> threadPool;
	protected boolean running;
	protected LinkedBlockingDeque<Thread> breakQueue;
	protected Hashtable<String,SANEntity> entities;
	protected Hashtable<String,NaiveEngineRootGoal> activeRootGoals;
	
	public NaiveSANEngine() throws java.io.IOException {
		running = false;
		breakQueue = new LinkedBlockingDeque<Thread>(1);
	}
	
	public Configurator getConfigurator() {
		return configurator;
	}
	
	public void setConfigurator(Configurator configurator) {
		this.configurator = configurator;
	}
	
	public void startExecution() {
		startExecutionNamespace("");
	}
	
	protected void startExecutionNamespace(String namespace) {
		if (running) throw new RuntimeException("NaiveSANEngine: SAN engine is already RUNNING");
		
		// Get SAN repository
		repository = configurator.repository;
		
		// Prepare global context
		globalContext = configurator.globalContext;
		globalContext.setItem("Engine", ENGINE_VERSION);
		globalContext.setItem("Start-Timestamp", new java.util.Date());
		
		// Initialize engine structures
		activeRootGoals = new Hashtable<String,NaiveEngineRootGoal>();
		
		// Retrieve auto-start entities
		SANEntity[] autoStartEntities = repository.getAutoStartEntities();	// Add namespace param!!!
		
		logInfo("");
		if (autoStartEntities==null || autoStartEntities.length==0) {
			logError("No auto-start entities in repository: "+namespace+": "+this.getClass().getName());
			return ;
		} else {
			logInfo("Auto-start Entities found in repository : "+autoStartEntities.length+" auto-start entities");
			logInfo();
		}
		
		// Initialize goal execution structures
		threadPool = new SANThreadPool<ExecutionContext>();
		entities = new Hashtable<String,SANEntity>();
		running = true;
		
		// Create and start Auto-start entities
		for (int i=0; i<autoStartEntities.length; i++) {
			createEntity( autoStartEntities[i].getObjectURI() );
		}
	}
	
	public SANEntity createEntity(String entityURI) {
		boolean autoStartRootGoals = configurator.getBoolean("engine.auto-start-root-goals", true);
		return createEntity(entityURI, autoStartRootGoals);
	}
	
	public SANEntity createEntity(String entityURI, boolean autoStartRootGoals) {
		SANEntity entity = repository.getEntity(entityURI);
		if (entity==null) return null;
		entities.put( entityURI, entity );
		String name = entity.getName();
		logInfo("Entity created: "+name);
		
		// Execute entity's auto-starting root goals
		RootGoal[] roots = entity.getRootGoals();
		logInfo("");
		if (!autoStartRootGoals) {
			logInfo("Auto-start Root Goals are not started, for entity: "+name);
		} else if (roots==null || roots.length==0) {
			// No autostart root goals found
			logError("No Root Goals found, for entity: "+name);
		} else {
			logInfo("Entity has Root Goals. Entity: "+name);
			logInfo("-------------------------------------------------------------\n");
			
			// Create an Entity context (2nd level context)
			Context ctx = globalContext.createEntityContext(entity.getObjectURI());
			ctx.setItem("Entity", entity.getObjectURI());
			ctx.setItem("Start-Timestamp", new java.util.Date());
			
			// List autostart root goals
			logInfo("* * *   LISTING AUTO-START ROOT GOALS   * * *\n");
			int cnt = 0;
			for (int i=0; i<roots.length; i++) {
				if (roots[i].isAutoStart()) {
					logInfo( String.format("%3d. '%s'", i+1, roots[i].getName()) );
					cnt++;
				}
			}
			if (cnt>0) {
				// Launch autostart root goals
				logInfo("\n* * *   LAUNCHING AUTO-START ROOT GOALS   * * *\n");
				for (int i=0; i<roots.length; i++) {
					if (roots[i].isAutoStart()) {
						doRoot( roots[i], ctx );
					}
				}
				logInfo("* * *   AUTO-START ROOT GOALS WERE LAUNCHED   * * *\n");
			} else {
				logInfo("No auto-start Root Goal found for entity: "+name+"\n");
			}
		}
		
		return entity;
	}
	
	public SANEntity destroyEntity(String entityURI) {
		SANEntity entity = entities.get(entityURI);
		if (entity==null) return null;
		
		/*RootGoal[] root = entity.getActiveRootGoals();
		for (int i=0; i<root.length; i++) {
			stopRoot(root[i]);
		}
		killEntityThreads(entity);
		
		// Update entity context (2nd level context)
		Context ctx = entity.getContext();
		ctx.setItem("End-Timestamp", new java.util.Date());
		*/
		entities.remove(entityURI);

// XXX: TODO: UNTESTED - dispose entity context if configured
		if (configurator.getBoolean("context.dispose-contexts", false)) {
			globalContext.removeEntityContext(entityURI);
			try { logInfo("Entity context of Entity'"+entity.getName()+"' (uri:"+entityURI+") has been disposed"); }
			catch (Exception ex) { }
		}
		
		return entity;
	}
	
	public Enumeration<SANEntity> getEntities() {
		return entities.elements();
	}
	
	public void startRootGoal(String rootURI, String entityURI) {
		SANEntity entity = entities.get(entityURI);
		Context entCtx = globalContext.getEntityContext(entityURI);
		RootGoal[] root = entity.getRootGoals();
		for (int i=0, n=root.length; i<n; i++) {
			if (root[i].getObjectURI().equals(rootURI)) {
				doRoot(root[i], entCtx);
			}
		}
	}
	
	public void stopRootGoal(String rootURI) {
		NaiveEngineRootGoal root = activeRootGoals.get(rootURI);
		if (root!=null) {
			root.stopGoal();
		} else {
			logError("NaiveSANEngine: stopRootGoal: Root Goal NOT FOUND: "+rootURI);
		}
	}
	
	protected void doRoot(RootGoal root, Context entityContext) {
		NaiveEngineRootGoal er = new NaiveEngineRootGoal( root );
		SANThread<ExecutionContext> thread = threadPool.create(er);
		
		// Add thread-local data
		thread.configurator = this.configurator;
		thread.context = entityContext.createLocalContext(null);
		thread.data = new ExecutionContext(true);
		thread.data.repository = repository;
// TODO		thread.data.root = er;
		thread.data.engine = this;
		
		activeRootGoals.put(root.getObjectURI(), er);
		
		thread.start();
	}
	
	public void stopExecution() {
		if (threadPool==null) return;
		
		logInfo("* * *   STOPPING ENTITIES   * * *\n");
		Enumeration<String> en = entities.keys();
		while (en.hasMoreElements()) {
			String entityURI = en.nextElement();
			destroyEntity(entityURI);
		}
		
		logInfo("* * *   STOPPING REMAINING ROOTS   * * *\n");
		
		logInfo("Sending interruption signal to all threads...");
		threadPool.stopAll();
		int delay = Integer.parseInt(configurator.configuration.getProperty("engine.naive.exit-delay", "5000"));
		logInfo("Waiting for "+((int)(delay/1000))+" seconds to allow threads terminate decently");
		threadPool.waitFor(delay);
		logInfo("Killing remaining threads...");
		threadPool.killAll();
		logInfo("Done\n");
		
		running = false;
		threadPool = null;
		activeRootGoals = null;
		globalContext.setItem("End-Timestamp", new java.util.Date());
		
		logInfo("* * *   EXECUTION TERMINATED   * * *\n");
	}
	
	public void suspend() {
		logInfo("NaiveSANEngine: suspend: thread execution suspended");
		Thread th = Thread.currentThread();
		synchronized (breakQueue) {
			try {
				breakQueue.put(th);
				LockSupport.park();
			} catch (InterruptedException ex) {
				logInfo("NaiveSANEngine: suspend: thread suspension interrupted");
			}
		}
	}
	
	public void resume() {
		if (breakQueue.size()==0) {
			logInfo("NaiveSANEngine: suspend: no suspended threads");
			return;
		}
		Thread th = breakQueue.remove();
		LockSupport.unpark(th);
	}
	
	public Context getGlobalContext() {
		return this.globalContext;
	}
	
	public Object evaluateExpression(org.iccs.san.api.Expression expr) {
		return (new NaiveEngineExpression(null, expr)).evaluate();
	}
	
	public Object evaluateExpression(org.iccs.san.api.Expression expr, Context localContext) {
		return (new NaiveEngineExpression(null, expr, localContext)).evaluate();
	}
	
	protected void logInfo() { SANThread.getOut().println(); }
	protected void logInfo(String mesg) { SANThread.getOut().println(mesg); }
	protected void logInfo(Exception ex) { SANThread.getOut().println(ex); }
	protected void logError() { SANThread.getErr().println(""); }
	protected void logError(String mesg) { SANThread.getErr().println(mesg); }
	protected void logError(Exception ex) { ex.printStackTrace(SANThread.getErr()); }
}
