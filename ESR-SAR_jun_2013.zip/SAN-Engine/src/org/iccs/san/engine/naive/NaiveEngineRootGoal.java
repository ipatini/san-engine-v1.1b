package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import org.iccs.san.cep.Event;
import org.iccs.san.context.Context;
import org.iccs.san.util.Metadata;
import org.iccs.san.util.SANThread;
import org.iccs.san.util.SANThreadPool;


public class NaiveEngineRootGoal extends NaiveEngineGoal implements Runnable {
	protected RootGoal root;
	protected NaiveEngineRootSituation situation;
	protected boolean keepRunning;
	protected SANThreadPool<ExecutionContext> clonesPool;
	
	public NaiveEngineRootGoal(RootGoal root) {
		super(root, null);
		this.root = root;
		this.clonesPool = new SANThreadPool<ExecutionContext>();
	}
	
	public synchronized void run() {
		try {
			goalThread = SANThread.current();
			logInfo("Root Goal '"+root.getName()+"' starts...");
			
			// deploy Situation
			this.situation = new NaiveEngineRootSituation( root.getSituation(), this );
			this.situation.deployCEPAT();
			keepRunning = true;
			int iter = 1;
			while (keepRunning) {
				if (stopFlag) {
					keepRunning = false;
					logError("Root Goal '"+root.getName()+"' was stopped");
					break;
				}
				
				logInfo("Root Goal '"+root.getName()+"' starts iteration #"+iter++);
				// wait for situation event
				Event evt = this.situation.waitForSituation();
				// ... then create a clone and let it continue
				spawnClone(evt);
				
				// if NULL situation do not iterate again
				if (evt==null || evt.getEventId()==null || evt.getCEPAT()==null) {
					keepRunning = false;
				}
				
				// Check if it is an ONCE-OFF Root Goal
				if (iter==2) {
					Metadata md = root.getMetadata("goal-type");
					if (md!=null) {
						Object value = md.getValue();
						if (value!=null && value instanceof String) {
							String goalType = (String)value;
							if ((goalType=goalType.trim()).equalsIgnoreCase("ONCE-OFF")) {
								keepRunning = false;
							}
						}
					}
				}
			}
		} catch (InterruptedException ex) {
			logInfo("Root Goal '"+root.getName()+"' was interrupted");
		} finally {
			// clean-up
			clonesPool.stopAll();
			this.situation.undeployCEPAT();
			SANThread.current().context.setItem("End-Timestamp", new java.util.Date());
			logInfo("Root Goal '"+root.getName()+"' ended");
		}
	}
	
	protected SANThread<ExecutionContext> spawnClone(Event evt) {
		logInfo("Spawning new thread for '"+this.root.getName()+"'");
		// create new thread and copy its execution context
		NaiveEngineGoal goal = new NaiveEngineGoal( this.root, getParent(), true );
		SANThread<ExecutionContext> thread = clonesPool.create(goal);
		thread.data = new ExecutionContext(true);
		// create new local context
		Context ctx = SANThread.current().context.getParentContext().createLocalContext(null);
		ctx.setItem("Start-Timestamp", new java.util.Date());
		// swap contexts between threads
		thread.context = SANThread.current().context;
		SANThread.current().context = ctx;
		// start new thread
		thread.start();
		return thread;
	}
}
