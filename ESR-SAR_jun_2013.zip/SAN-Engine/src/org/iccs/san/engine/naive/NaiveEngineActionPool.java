package org.iccs.san.engine.naive;

import org.iccs.san.api.*;


public class NaiveEngineActionPool extends NaiveEngineSANObject {
	public NaiveEngineActionPool(ActionPool pool, NaiveEngineSANObject parent) {
		super(pool, parent);
	}
}
