package org.iccs.san.context.contextualizer;

import org.iccs.san.cep.Event;
import org.iccs.san.context.Context;
import org.iccs.san.util.SANThread;
import java.util.Enumeration;
import java.util.Properties;

public class NVPContextualizer extends AbstractContextualizer {
	public NVPContextualizer() {
		setType("NVP");
	}
	
	public boolean contextualize(Event event, Context context) {
		checkType(event);
		NVPContextualizer.Descriptor descr = (NVPContextualizer.Descriptor)getDescriptor();
		if (descr==null) {
			SANThread.getErr().println("NVPContextualizer: contextualize: No Contextualizer Descriptor returned from SAN repository");
			return false;
		}
		String[] name = descr.getPairNames();
		if (name==null) {
			SANThread.getErr().println("NVPContextualizer: contextualize: No pair names in NVP Contextualizer Descriptor returned from SAN repository");
			return false;
		}
		
		Properties prop = (Properties)event.getPayload();
		boolean rr = false;
		if (name.length==1 && name[0]!=null && name[0].equals("*")) {
			for (Enumeration en = prop.propertyNames(); en.hasMoreElements();) {
				String n = (String)en.nextElement();
				addToContext(context, n, prop.getProperty(n), event, null);
				rr = true;
			}
		} else {
			for (int i=0; i<name.length; i++) {
				addToContext(context, name[i], prop.getProperty(name[i]), event, null);
				rr = true;
			}
		}
		return rr;
	}
	
	public static interface Descriptor extends Contextualizer.Descriptor {
		public abstract String[] getPairNames();
	}
}
