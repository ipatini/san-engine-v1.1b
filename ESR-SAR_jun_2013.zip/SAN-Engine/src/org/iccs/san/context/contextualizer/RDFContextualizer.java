package org.iccs.san.context.contextualizer;

import org.iccs.san.api.Expression;
import org.iccs.san.cep.Event;
import org.iccs.san.context.Context;
import org.iccs.san.util.HtmlEntities;
import org.iccs.san.util.SANThread;
import org.iccs.san.util.sesame.SesameRDFRepository;
import org.iccs.san.util.sesame.SesameGraph;

import java.util.Iterator;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;
import java.io.StringReader;
import com.ebmwebsourcing.easycommons.xml.XMLHelper;
import javax.xml.transform.TransformerException;
import org.w3c.dom.Element;
import org.openrdf.repository.RepositoryConnection;
import org.openrdf.rio.RDFFormat;
import org.openrdf.model.Namespace;
import org.openrdf.repository.RepositoryResult;

public class RDFContextualizer extends AbstractContextualizer {
	protected boolean printPayload;
	
	public RDFContextualizer() {
		setType("RDF");
		setDebugOn( SANThread.current().configurator.getBoolean("ctxlzr.rdf.DEBUG", false) );
		printPayload = SANThread.current().configurator.getBoolean("ctxlzr.rdf.PRINT_PAYLOAD", false);
	}
	
	@SuppressWarnings("unchecked")
	public boolean contextualize(Event event, Context context) {
		boolean rr = __contextualize(event, context);
		SANThread.getErr().println("RDFContextualizer: contextualize: RESULT = "+rr);
		return rr;
	}
	
	protected boolean __contextualize(Event event, Context context) {
		checkType(event);
		
		// Get RDF queries used for contextualization
		RDFContextualizer.Descriptor descriptor = (RDFContextualizer.Descriptor)getDescriptor();
		if (descriptor==null) {
			SANThread.getErr().println("RDFContextualizer: contextualize: No RDF Contextualizer Descriptor returned from SAN repository");
			return false;
		}
		Query[] queries = descriptor.getQueries();
		if (queries==null || queries.length==0) {
			SANThread.getErr().println("RDFContextualizer: contextualize: No queries found in RDF Contextualizer Descriptor returned from SAN repository");
			return false;
		}
		
		// Get event payload and detect RDF format
		Object payload = event.getPayload();
		String payloadText = null;
		String rdfText = null;
		if (payload==null) {
			SANThread.getErr().println("RDFContextualizer: contextualize: Event payload is NULL");
			return false;
		}
		if (payload instanceof Element) {
			Element businessMessage = (Element)payload;
			try {
				payloadText = XMLHelper.createStringFromDOMNode(businessMessage);
			} catch (TransformerException ex) {
				SANThread.getErr().println("RDFContextualizer: contextualize: Failed to convert Event RDF payload from DOM/RDFXML into plain XML text. Reason: "+ex);
				ex.printStackTrace(SANThread.getErr());
				SANThread.getErr().println("Event Payload: "+businessMessage);
				return false;
			} catch (Exception ex) {
				SANThread.getErr().println("RDFContextualizer: contextualize: Failed to convert Event RDF payload from DOM/RDFXML into plain XML text. Reason: "+ex);
				ex.printStackTrace(SANThread.getErr());
				SANThread.getErr().println("Event Payload: "+businessMessage);
				return false;
			}
		} else
		if (payload instanceof String) {
			payloadText = (String)payload;
		} else {
			SANThread.getErr().println("RDFContextualizer: contextualize: Cannot handle event payload of type: "+payload.getClass().getName());
			return false;
		}
		
		// Event payload RDF format
		RDFFormat rdfFormat = null;
		if (payloadText.trim().substring(0,20).toLowerCase().startsWith("<rdf")) {
			// RDF/XML format detected
			// XXX: OBSOLETE (does not consider an <mt:nativeMessage> XML wrapper)
			if (isDebugOn()) SANThread.getOut().println("RDFContextualizer: contextualize: Event Payload Format: RDF/XML");
			rdfFormat = RDFFormat.RDFXML;
			rdfText = payloadText;
		} else
		if (payloadText.trim().toLowerCase().indexOf("application/x-trig")>0) {
			// RDF/TRIG format detected
			rdfFormat = RDFFormat.TRIG;
			if (isDebugOn()) SANThread.getOut().println("RDFContextualizer: contextualize: Event Payload Format: RDF/TRIG");
			int p1 = payloadText.indexOf('>');
			int p2 = payloadText.lastIndexOf("</");
			if (p1<0 || p2<0) {
				throw new RuntimeException("RDFContextualizer: contextualize: Missing XML wrapper in RDF/TRIG format event payload (quoting start: '"+payloadText.trim().substring(0,20)+"') in RDF Contextualizer Description: '"+descriptor.getURI()+"'");
			}
			rdfText = payloadText.substring(p1+1, p2);
			rdfText = HtmlEntities.decode(rdfText);
		} else {
			throw new RuntimeException("RDFContextualizer: contextualize: Unknown RDF format in event payload (quoting start: '"+payloadText.trim().substring(0,20)+"') in RDF Contextualizer Description: '"+descriptor.getURI()+"'");
		}
		
		// Create a temporary RDF repository, using Sesame
		SesameRDFRepository rep = new SesameRDFRepository(false);
		SesameGraph sg = new SesameGraph(rep.getRepository());
		RepositoryConnection con = null;
		try {
			con = rep.getRepository().getConnection();
		} catch (Exception ex) {
			SANThread.getErr().println("RDFContextualizer: contextualize: Failed to create a temporary RDF repository. Reason: "+ex);
			ex.printStackTrace(SANThread.getErr());
			return false;
		}
		
		// Load event RDF payload into temporary RDF repository
		try {
			StringReader sr = new StringReader(rdfText);
			con.add(sr, "", rdfFormat);
			
			if (isDebugOn() && printPayload) {
				SANThread.getOut().println("RDFContextualizer: contextualize: Event "+rdfFormat.getName()+" payload:");
				SANThread.getOut().println("--------------------------------------------------------");
				sg.dumpRDF(SANThread.getOut(), sg.N3);
				SANThread.getOut().println("--------------------------------------------------------");
			}
		} catch (Exception ex) {
			SANThread.getErr().println("RDFContextualizer: contextualize: Failed to load Event RDF payload to a temporary RDF repository. Reason: "+ex);
			ex.printStackTrace(SANThread.getErr());
			try {
				con.close();
			} catch (Exception e) {
				SANThread.getErr().println("RDFContextualizer: contextualize: Failed to dispose temporary RDF repository decently (P1). Reason: "+e);
				e.printStackTrace(SANThread.getErr());
			}
			return false;
		}
		
		// Retrieve repository namespaces and prefixes
		String namespaces = "";
		try {
			RepositoryResult<Namespace> rr = con.getNamespaces();
			while (rr.hasNext()) {
				Namespace ns = rr.next();
				String name = ns.getName();
				String prefix = ns.getPrefix();
				namespaces += "prefix "+prefix+": <"+name+"> ";
			}
			rr.close();
			if (isDebugOn()) SANThread.getOut().println("Using namespaces: "+namespaces);
		} catch (Exception ex) {
			SANThread.getErr().println("RDFContextualizer: contextualize: Failed to retrieve namespaces from temporary RDF repository. Reason: "+ex);
			ex.printStackTrace(SANThread.getErr());
			try {
				con.close();
			} catch (Exception e) {
				SANThread.getErr().println("RDFContextualizer: contextualize: Failed to dispose temporary RDF repository decently (P2). Reason: "+e);
				e.printStackTrace(SANThread.getErr());
			}
			return false;
		}
		
		// Check uniqueness constraint (if specified)
/* XXX: TODO:  To refine...
		if (true) {
			String unique = "LOCAL:san:MMSI".trim();
			String[] part = unique.split(":", 2);
			String scope, pkey;
			if (part.length>1) {
				scope = part[0].trim().toUpperCase();
				if (!scope.equals("LOCAL") && !scope.equals("ENTITY") && !scope.equals("GLOBAL")) scope = "ENTITY";
				pkey = part[1].trim();
			} else {
				scope = "ENTITY";
				pkey = unique;
			}
			Context checkCtx = null;
			boolean found = false;
			if (scope.equals("LOCAL")) {
				checkCtx = context;
			} else
			if (scope.equals("ENTITY")) {
				checkCtx = context.getParentContext();
			} else
			if (scope.equals("GLOBAL")) {
				checkCtx = context.getGlobalContext();
			}
			Object val = checkCtx.getItem(pkey);
org.iccs.san.util.ActionHelper.getInstance().alert(">>>>>>>>> scope="+scope+", pkey="+pkey+", val="+val);
			if (val!=null) {
				if (val.getClass().isArray()) {
					Object[] arr = (Object[])val;
					if (arr.length>0) {
						val = arr[0];
					}
				}
				if (val!=null) {
					// query local RDF repository for 'pkey'
					String qs = "SELECT ?uri ?pkeyVal WHERE { ?uri "+pkey+" ?pkeyVal }";
org.iccs.san.util.ActionHelper.getInstance().alert(">>>>>>>>> qs="+qs);
					List<HashMap> result = sg.runSPARQL(qs);
					if (result==null) {
						SANThread.getErr().println("RDFContextualizer: contextualize: Unique Constraint Query returned no results");
					}
					Iterator<HashMap> iterator = result.iterator();
					// For each tuple check unique constraint...
org.iccs.san.util.ActionHelper.getInstance().alert(">>>>>>>>> BEFORE LOOP");
					while (iterator.hasNext()) {
						HashMap hm = iterator.next();
						// ...against each bound variable (column) into hashtable
						String uri = getString( hm.get("uri").toString() );
						String pkeyVal = getString( hm.get("pkeyVal").toString() );
org.iccs.san.util.ActionHelper.getInstance().alert(">>>>>>>>> ITER: pval="+pkeyVal+", uri="+uri);
						if (pkeyVal.equals(val)) {
org.iccs.san.util.ActionHelper.getInstance().alert(">>>>>>>>> FOUND");
							found = true;
							SANThread.getOut().println("RDFContextualizer: contextualize: Unique Constraint: Another instance of "+pkey+" = "+val+" already exists in "+scope+" context. Clashing with "+pkey+" of item: uri="+uri+". Ignoring this event");
							return;
						}
					}
				}
			}
		}
*/
		
		// Run each query and store the resulting name-value pairs in a hashtable
		Hashtable<String,Vector<String>> attrib = new Hashtable<String,Vector<String>>();
		boolean rr = false;
		for (Query q : queries) {
			attrib.clear();
			
			// Get query language and definition (as an expression)
			String qryLang = q.getQueryLanguage();
			Expression qryExpr = q.getQueryExpression();
			if (qryLang==null || qryExpr==null) {
				SANThread.getErr().println("RDFContextualizer: contextualize: Missing Query LANGUAGE or Query EXPRESSION in RDF contextualizer");
				continue;
			}
			String qs = (String)SANThread.current().configurator.engine.evaluateExpression(qryExpr);
			
			// If it is a SPARQL query...
			if (qryLang.equals("SPARQL")) {
				// ...run it and retrieve results
				if (isDebugOn()) SANThread.getOut().println("RDFContextualizer: contextualize: Query to run on event paylod: ("+qryLang+") "+q.getQueryUri());
				if (isDebugOn()) SANThread.getOut().println(namespaces+qs);
				List<HashMap> result = sg.runSPARQL( namespaces + qs );
				if (result==null) {
					SANThread.getErr().println("RDFContextualizer: contextualize: Query returned no results");
					if (isDebugOn()) SANThread.getErr().println("Query: \n"+namespaces + qs);
					continue;
				}
				Iterator<HashMap> iterator = result.iterator();
				// For each tuple store...
				boolean empty = true;
				while (iterator.hasNext()) {
					HashMap hm = iterator.next();
					empty = false;
					// ...each bound variable (column) into hashtable
					for (Object key : hm.keySet()) {
						String name = (String)key;
						Vector<String> values = attrib.get(name);
						// ...for each bound variable create a vector to store the column values (across several tuples)
						if (values==null) {
							values = new Vector<String>();
							attrib.put(name, values);
						}
						String val = getString( hm.get(name).toString() );
						values.add(val);
					}
				}
				if (empty) {
					SANThread.getErr().println("RDFContextualizer: contextualize: Query returned an empty result set");
					if (isDebugOn()) SANThread.getErr().println("Query: \n"+namespaces + qs);
					continue;
				}
			} else {
				SANThread.getErr().println("RDFContextualizer: contextualize: Unknown query language '"+qryLang+"' for query");
			}
			
			// Store name-value pairs into context
			Context queryCtx = context;
			String ctx = q.getQueryContext();
			if (ctx==null) {
				ctx = descriptor.getContext();
				if (ctx==null || ctx.trim().equals("")) {
// XXX: TODO:  get default from Config, else use ENTITY
// XXX: TODO:  ADDITIONAL:  check Goal, RootGoal, Entity, Global metadata and/or 'CONTEXT-SCOPE' context item to get target scope
					ctx = "ENTITY";
				} else {
					ctx = ctx.trim().toUpperCase();
					if (!ctx.equals("LOCAL") && !ctx.equals("ENTITY") && !ctx.equals("GLOBAL")) ctx = "ENTITY";
				}
			}
			ctx = ctx.trim().toUpperCase();
			if (ctx.equals("LOCAL")) {
				if (context.isLocalContext()) queryCtx = context;
// XXX: TODO:  find local context from entity context
				else if (context.isEntityContext()) queryCtx = context;
// XXX: TODO:  find local context from global context
				else if (context.isGlobalContext()) queryCtx = context;
			} else if (ctx.equals("ENTITY")) {
				if (context.isLocalContext()) queryCtx = context.getParentContext();
				else if (context.isEntityContext()) queryCtx = context;
// XXX: TODO:  find local context from global context
				else if (context.isGlobalContext()) queryCtx = context;
			} else if (ctx.equals("GLOBAL")) {
				queryCtx = context.getGlobalContext();
			} else {
				throw new RuntimeException("RDFContextualizer: contextualize: Invalid context specification '"+ctx+"' in Query: '"+q.getQueryUri()+"' of RDF Contextualizer Description: '"+descriptor.getURI()+"'");
			}
			
			for (Object key : attrib.keySet()) {
				String name = (String)key;
				Vector<String> values = attrib.get(name);
				String[] valArray = values.toArray(new String[values.size()]);
				
				addToContext(queryCtx, name, valArray, event, null);
				rr = true;
			}
		}
		
		// Dispose temporary RDF repository
		try {
			con.close();
		} catch (Exception e) {
			SANThread.getErr().println("RDFContextualizer: contextualize: Failed to dispose temporary RDF repository decently (P3). Reason: "+e);
			e.printStackTrace(SANThread.getErr());
		}
		
		return rr;
	}
	
	public String getString(String str) {
		try {
			if (str.equals("\"\"")) return "";
			String[] part = str.split("\"");
			return (part.length>1) ? part[1] : part[0]; 		// dirty hack to extract literal
																// from "value"^^xsd:string
		} catch (ArrayIndexOutOfBoundsException ex) {
			SANThread.getErr().println("RDFContextualizer: getString: ArrayIndexOutOfBoundsException: Parameter: "+str);
			throw ex;
		}
	}
	
	public static interface Descriptor extends Contextualizer.Descriptor {
		public abstract RDFContextualizer.Query[] getQueries();
	}
	
	public static interface Query {
		public abstract String getQueryUri();
		public abstract String getQueryLanguage();
		public abstract Expression getQueryExpression();
		public abstract String getQueryContext();
	}
}
