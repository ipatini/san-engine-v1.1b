package org.iccs.san.context;

import org.iccs.san.api.SANObject;
import org.iccs.san.cep.Event;
import java.util.Enumeration;
import java.util.Properties;

/**
 *	The Context interface
 */
public interface Context {
	public abstract Context getGlobalContext();	
	public abstract Context getEntityContext(String entityURI);	
	public abstract Context getLocalContext(String localURI);
	public abstract Context getParentContext();
	
	public abstract Enumeration entityContextsIds();
	public abstract Enumeration localContextsIds();
	
	public abstract Context createEntityContext(String entityURI);	
	public abstract Context removeEntityContext(String entityURI);	
	public abstract Context createLocalContext(String localURI);	
	public abstract Context removeLocalContext(String localURI);	
	
	public abstract boolean isGlobalContext();
	public abstract boolean isEntityContext();
	public abstract boolean isLocalContext();
	
	public abstract Properties getConfiguration();
	public abstract void setConfiguration(Properties props);
	
	public abstract String getURI();
	public abstract Enumeration getItems();
	public abstract Object getItem(String key);
	public abstract Object getItem(String key, int pos);
	public abstract Object setItem(String key, Object val);
	public abstract Object setItem(String key, Object val, Event event, SANObject node);
	public abstract Object removeItem(String key);
	
	public abstract String toString(boolean dumpSubcontexts);
	
// XXX: TODO:  remove or modify this method to become meaningful 
//             e.g. 'addEvent' to enqueue event in event history, or update statistics etc
	public abstract boolean mergeEvent(Event event);
}
