package org.iccs.san.context;

import org.iccs.san.util.Configurator;

/**
 *	The SAN Context Factory
 */
public class ContextFactory {
	protected Configurator configurator;
	protected Context globalContext;
	
	public static ContextFactory getContextFactory(Configurator configurator) {
		return new ContextFactory(configurator);
	}
	
	protected ContextFactory(Configurator configurator) {
		setConfigurator(configurator);
	}
	
	public Context getGlobalContext() throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		if (globalContext!=null) return globalContext;
		
		String className = configurator.configuration.getProperty("context.class");
		globalContext = (Context)Class.forName(className).newInstance();
		globalContext.setConfiguration(configurator.configuration);
		globalContext = globalContext.getGlobalContext();
		return globalContext;
	}
	
	public Configurator getConfigurator() { return this.configurator; }
	public void setConfigurator(Configurator configurator) { this.configurator = configurator; }
}
