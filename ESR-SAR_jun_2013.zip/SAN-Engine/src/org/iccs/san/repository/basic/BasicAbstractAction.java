package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicAbstractAction extends BasicAction implements org.iccs.san.api.AbstractAction {
	public ActionPool getActionPool() { return null; }
	public ActionPool getActionPool(String uri) { return null; }
	public String getSearchMethod() { return null; }
	public String getExecutionPolicy() { return null; }
	
	public void setActionPool(ActionPool pool)  { }
	public void setSearchMethod(String searchMethod)  { }
	public void setExecutionPolicy(String execPolicy) { }
}
