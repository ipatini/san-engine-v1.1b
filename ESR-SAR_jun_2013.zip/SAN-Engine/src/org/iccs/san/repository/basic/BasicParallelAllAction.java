package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicParallelAllAction extends BasicCompositeAction implements org.iccs.san.api.ParallelAllAction {
}
