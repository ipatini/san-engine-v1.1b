package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicAction extends BasicSANNode implements org.iccs.san.api.Action {
	public Expression getExpression() { return null; }
	public void setExpression(Expression expr) { }
}
