package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicParallelAnyAction extends BasicCompositeAction implements org.iccs.san.api.ParallelAnyAction {
}
