package org.iccs.san.repository.basic;

import org.iccs.san.api.*;
import org.iccs.san.context.Context;
import org.iccs.san.util.Metadata;
import java.util.Iterator;
import java.util.Properties;
import java.util.Hashtable;
import java.util.HashMap;
import java.util.Set;

public class BasicSANObject implements org.iccs.san.api.SANObject {
	protected String name;
	protected String uri;
	protected String type;
	protected Properties props;
	protected Hashtable<String,Metadata<?>> metadata;
	protected HashMap<String,Object> attached;
	
	public BasicSANObject() {
		this.props = new Properties();
		if (this instanceof BasicGoal) setProperty("type", "GOAL");
		else if (this instanceof BasicRootGoal) setProperty("type", "ROOT-GOAL");
		else if (this instanceof BasicSituation) setProperty("type", "SITUATION");
		else if (this instanceof BasicContextCondition) setProperty("type", "CONTEXT-CONDITION");
		else if (this instanceof BasicAction) setProperty("type", "ACTION");
		else if (this instanceof BasicDecorator) setProperty("type", "DECORATOR");
		else setProperty("type", this.getClass().getName());
		
		this.metadata = new Hashtable<String,Metadata<?>>();
	}
	
	public String getName() { return this.name; }
	public String getObjectURI() { return this.uri; }
	public String getType() { return this.type; }
	
	public void setName(String name) { this.name = name; }
	public void setObjectURI(String uri) { this.uri = uri; }
	public void setType(String type) { this.type = type; }
	
	public String getProperty(String key) { return props.getProperty(key); }
	public void setProperty(String key, String value) { props.setProperty(key, value); }
	
	// Metadata methods
	public Metadata<?> addMetadata(Metadata<?> meta) { this.metadata.put(meta.getName(), meta); return meta; }
	public Metadata<?> replaceMetadata(Metadata<?> metaOld, Metadata<?> metaNew) { return this.metadata.put(metaOld.getName(), metaNew); }
	public Metadata<?> replaceMetadata(String metaOldName, Metadata<?> metaNew) { return this.metadata.put(metaOldName, metaNew); }
	public Metadata<?> removeMetadata(Metadata<?> meta) { return this.metadata.remove(meta.getName()); }
	public Metadata<?> removeMetadata(String metaName) { return this.metadata.remove(metaName); }
	public Metadata<?> getMetadata(String metaName) { return this.metadata.get(metaName); }
	public Iterator<Metadata<?>> getAllMetadata() { return this.metadata.values().iterator(); }
	
	// Attached objects methods
	public void attachObject(String name, Object object) { if (attached==null) attached = new HashMap<String,Object>(); attached.put(name, object); }
	public Object detachObject(String name) { if (attached==null) return null; return attached.remove(name); }
	public Object retrieveObject(String name) { if (attached==null) return null; return attached.get(name); }
	public Iterator<String> getObjectNames() { if (attached==null) return null; Set<String> keys = attached.keySet(); return (keys==null) ? null : keys.iterator(); }
	
	public String toString() {
		return getType()+" : "+getName()+" : "+getObjectURI();
	}
}
