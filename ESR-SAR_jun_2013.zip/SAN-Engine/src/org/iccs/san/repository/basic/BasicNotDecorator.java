package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicNotDecorator extends BasicDecorator implements org.iccs.san.api.NotDecorator {
}
