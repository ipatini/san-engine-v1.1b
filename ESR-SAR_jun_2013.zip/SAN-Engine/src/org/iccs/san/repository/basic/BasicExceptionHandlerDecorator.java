package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicExceptionHandlerDecorator extends BasicDecorator implements org.iccs.san.api.ExceptionHandlerDecorator {
	protected String exceptionType;
	protected SANNode failoverJob;
	
	public String getExceptionType() { return exceptionType; }
	public SANNode getFailoverJob() { return failoverJob; }

	public void setExceptionType(String exceptionType) { this.exceptionType = exceptionType; }
	public void setFailoverJob(SANNode failoverJob) { this.failoverJob = failoverJob; }
}
