
				***  SAR :  Nuclear use case  ***

CONTENTS
========
nuclear-SMP-adaptation.configuration.txt	Use case configuration file - VARIATION #1 without Action Pool
nuclear-SMP-adaptation.dsb.properties		Use case secondary (dsb intf. specific) configuration file - COMMON
nuclear-SMP-adaptation.n3			The file N3 SAN definition - VARIATION #1 without Action Pool
nuclear-with-action-pools.configuration.txt	Use case configuration file - VARIATION #2 with Action Pool
nuclear-with-action-pools.n3			The file N3 SAN definition - VARIATION #2 with Action Pool
README.txt					This file
run-action-pool.bat				Starts use case - VARIATION #2 with Action Pool
run-sar-dcep.bat				Starts an auxiliary san/cep programme
run.bat						Starts use case - VARIATION #1 without Action Pool
sar-dcep.configuration.txt			Use case configuration file for auxiliary san/cep programme
sar-dcep.n3					The file N3 SAN definition for auxiliary san/cep programme

templates					Directory containing templates of Advices, BPMN processes and recommendation events


================================   EXECUTION   ====================================

REQUIREMENTS
============

The Aop4Bpmn2 workflow engine must be installed (not necessarily on the same machine)
and execute the use case related processes (nuclear-SMP-adaptation, IRSN and Alerts)


SETUP
=====

The setting 'user.ADVICE_REPOSITORY' must be set in configuration files.
This setting contains the 'directory' where the SAR-generated Advice and Process BPMN files
are stored. This directory should be accessible by Aop4Bpmn2 w/f engine (either as a local/network
directory or as a URL). Aop4Bpmn2 w/f engine must also be configured accordingly


RUN
===

Double click on 'run.bat' or 'run-action-pool.bat' in '<SAN_HOME>\apps\nuclear\'

Double click on 'run-sar-dcep.bat' in '<SAN_HOME>\apps\nuclear\'


You should also execute the three (use case related) Aop4Bpmn2 w/f engine processes:
  nuclear-SMP-process (6).bpmn
  nuclear-IRSN-process.bpmn
  nuclear-alert-process-2.bpmn

See also Aop4Bpmn2 w/f engine instructions
