
				***  ESR :  AISHUB use case  ***

CONTENTS
========
aishub.configuration.txt		Use case configuration file
aishub.dsb.properties			Use case secondary (dsb intf. specific) configuration file
aishub_example.n3			The file N3 SAN definition exported from SAN editor and manually modified
README.txt				This file
run.bat					Double click it to start the use case


================================   EXECUTION   ====================================

REQUIREMENTS
============

The AISHUB adapter must be installed and active in order to publish AISHUB events to DSB


RUN
===

Double click on 'run.bat' in '<SAN_HOME>\apps\aishub\'

