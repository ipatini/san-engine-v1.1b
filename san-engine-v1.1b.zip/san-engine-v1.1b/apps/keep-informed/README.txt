
				***  ESR :  Keep Informed use case  ***

CONTENTS
========
keep-informed (at a xAMP server)	Contains files and data that should be placed on a W/LAMP server
test					Contains 2 test events for the use case

Keep Informed.san			The ESR SAN definition as produced with SAN editor
keep-informed.n3			The file N3 SAN definition exported from SAN editor and manually modified
keep-informed-action-pool.n3		A static action pool, if you wish to experiment without using a W/LAMP server
keep-informed-RECOM-template.txt	Recommendation event template (plz don't move)
keep-informed.configuration.txt		Use case (master) configuration file
keep-informed.dsb.properties		Use case secondary (dsb intf. specific) configuration file
README.txt				This file
run.bat					Double click it to start the use case


================================   DYNAMIC ACTION POOL VARIATION   ====================================

REQUIREMENTS
============

For this use case a PHP-enabled web server and a MySQL server are required.
Any L/WAMP should do.


SETUP UC
========

Create a new database in MySQL  (e.g. named 'sensors_db')

Load file 'keep-informed (at a xAMP server)\sensors.sql' into the newly created database and 
test that table 'sensors' has been created and populated

Copy directory 'keep-informed (at a xAMP server)' into the public folder of the PHP enabled Web server (e.g. Apache)
Optionally rename it to something like 'keep-informed'

Edit file 'keep-informed (at a xAMP server)\sensors-query.php' and set the correct values of variables 
$db_host, $db_user, $db_pwd, $database on the top of the file

Test that query service works properly, using a web browser. You should see an RDF/N3 listing
E.g.  http://localhost/keep-informed/sensors-query.php

Edit file 'keep-informed.configuration.txt' and set variable 'user.action-pool-service-url' at the end of the file
to contain the url of the query service (the one you used to test service).
E.g.
user.action-pool-service-url		http://localhost/keep-informed/sensors-query.php


RUN
===

Double click on 'run.bat' in '...\apps\keep-informed\'

Double click on 'run.bat' in '...\bin\'

Use the console of the second 'run.bat' to send two events using the next commands:
e GUID KEEP http://streams.event-processing.org/ids/ situationalEvent @ ..\apps\keep-informed\test\keep-informed-event-1.txt

e GUID KEEP http://streams.event-processing.org/ids/ TaxiUCGeoLocation @ ..\apps\keep-informed\test\keep-informed-event-2.txt

Now you should see three recommendation events in the ESRRecom topic



================================   STATIC ACTION POOL VARIATION   ====================================

REQUIREMENTS
============

None


SETUP UC
========

Edit file 'keep-informed.n3' :
a.  comment out lines 133, 155  and
b.  uncomment lines 135, 157


RUN
===

Run like the dynamic action pool case

