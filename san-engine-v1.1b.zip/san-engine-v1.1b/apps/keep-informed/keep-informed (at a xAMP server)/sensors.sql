-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Σύστημα: localhost
-- Χρόνος δημιουργίας: 20 Δεκ 2012, στις 03:39 PM
-- Έκδοση Διακομιστή: 5.0.51
-- Έκδοση PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Βάση: `sensors_db`
-- 

-- --------------------------------------------------------

-- 
-- Δομή Πίνακα για τον Πίνακα `sensors`
-- 

CREATE TABLE `sensors` (
  `sid` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `lat` double NOT NULL,
  `lon` double NOT NULL,
  `manufacturer` varchar(100) NOT NULL,
  `owner` varchar(100) NOT NULL,
  `throughput` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `accuracy` varchar(100) NOT NULL,
  PRIMARY KEY  (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- 'Αδειασμα δεδομένων του πίνακα `sensors`
-- 

INSERT INTO `sensors` VALUES (1, 'Sensor #1', 43.6085806, 7.0594214, 'MANUFACTURER #1', 'University', '15', '8', '0.7');
INSERT INTO `sensors` VALUES (2, 'Sensor #2', 43, 7, 'MANUFACTURER #2', 'Company', '3', '4', '0.8');
INSERT INTO `sensors` VALUES (3, 'Sensor #3', 44, 8, 'NONAME', 'Household', '7', '3', '0.4');
INSERT INTO `sensors` VALUES (4, 'Sensor #4', 0, 0, 'MANUFACTURER #1', 'Research Center', '50', '1', '0.001');
INSERT INTO `sensors` VALUES (5, 'Sensor #5', 43.5, 7.5, 'NONAME', 'Unknown', '2', '8', '0.9');
INSERT INTO `sensors` VALUES (6, 'Sensor #6', 43.3, 7.3, 'MANUFACTURER #1', 'University', '90', '0.6', '0.01');
