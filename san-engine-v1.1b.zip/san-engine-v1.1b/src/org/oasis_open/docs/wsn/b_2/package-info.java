@javax.xml.bind.annotation.XmlSchema(namespace = "http://docs.oasis-open.org/wsn/b-2", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.oasis_open.docs.wsn.b_2;
