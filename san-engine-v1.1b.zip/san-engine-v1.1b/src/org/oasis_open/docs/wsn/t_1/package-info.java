@javax.xml.bind.annotation.XmlSchema(namespace = "http://docs.oasis-open.org/wsn/t-1", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.oasis_open.docs.wsn.t_1;
