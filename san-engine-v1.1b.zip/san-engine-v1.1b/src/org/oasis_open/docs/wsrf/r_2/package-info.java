@javax.xml.bind.annotation.XmlSchema(namespace = "http://docs.oasis-open.org/wsrf/r-2")
package org.oasis_open.docs.wsrf.r_2;
