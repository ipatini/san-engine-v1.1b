@javax.xml.bind.annotation.XmlSchema(namespace = "http://docs.oasis-open.org/wsrf/bf-2", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.oasis_open.docs.wsrf.bf_2;
