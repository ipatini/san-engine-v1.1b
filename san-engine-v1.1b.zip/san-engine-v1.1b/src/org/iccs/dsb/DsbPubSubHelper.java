/**
 *	DSB Pub/Sub helper
 */
package org.iccs.dsb;

import org.iccs.san.cep.ReplayCapable;
import org.iccs.san.util.Configurator;
import org.iccs.san.util.NetworkHelper;
import org.iccs.san.util.SANThread;

import org.iccs.dsb.DSBProperties;
import org.iccs.dsb.webservices.NotificationConsumerService;
//XXX: import org.iccs.dsb.DSBClient;
import org.iccs.dsb.EventReceiver;

import java.io.IOException;
import java.io.PrintStream;
import java.io.*;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;
import java.util.concurrent.*;

import javax.xml.namespace.QName;
import javax.xml.ws.Endpoint;
//XXX:import javax.xml.ws.wsaddressing.W3CEndpointReference;
import javax.xml.transform.TransformerException;
import javax.xml.parsers.*;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

//XXX: import org.oasis_open.docs.wsn.b_2.SubscribeResponse;
import org.petalslink.dsb.notification.client.http.simple.HTTPConsumerClient;
//XXX:import org.petalslink.dsb.notification.client.http.simple.HTTPProducerClient;
//XXX:import org.petalslink.dsb.notification.client.http.simple.HTTPProducerRPClient;
//XXX:
import org.petalslink.dsb.notification.client.http.simple.HTTPSubscriptionManagerClient;
import org.petalslink.dsb.notification.commons.NotificationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import com.ebmwebsourcing.easycommons.xml.XMLHelper;
import com.ebmwebsourcing.wsstar.basefaults.datatypes.impl.impl.WsrfbfModelFactoryImpl;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.NotificationMessageHolderType;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.NotificationMessageHolderType.Message;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.Notify;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.TopicExpressionType;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.Unsubscribe;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.refinedabstraction.RefinedWsnbFactory;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.utils.WsnbException;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.impl.impl.WsnbModelFactoryImpl;
import com.ebmwebsourcing.wsstar.resource.datatypes.impl.impl.WsrfrModelFactoryImpl;
import com.ebmwebsourcing.wsstar.resourcelifetime.datatypes.impl.impl.WsrfrlModelFactoryImpl;
import com.ebmwebsourcing.wsstar.resourceproperties.datatypes.impl.impl.WsrfrpModelFactoryImpl;
import com.ebmwebsourcing.wsstar.topics.datatypes.impl.impl.WstopModelFactoryImpl;
import com.ebmwebsourcing.wsstar.wsnb.services.impl.util.Wsnb4ServUtils;
import com.ebmwebsourcing.wsstar.wsrfbf.services.faults.AbsWSStarFault;

// XXX: Logger for PLAY central integration test
import org.iccs.san.util.sesame.SesameGraph;
import org.iccs.san.util.sesame.SesameRDFRepository;
import org.openrdf.rio.RDFFormat;
import java.util.Iterator;
import java.util.HashMap;
import org.iccs.san.util.HtmlEntities;

// XXX: New PLAY/DSB client
/*import org.ow2.play.platform.api.bean.Subscription;
import org.ow2.play.platform.api.bean.SubscriptionResult;
import org.ow2.play.platform.api.bean.Topic;
import org.ow2.play.platform.client.ws.PlatformClient;
*/

// XXX: Newer (11-03-2013) PLAY/DSB client (using Governance stable API)
import org.ow2.play.governance.api.GovernanceExeption;
import org.ow2.play.governance.api.bean.Subscription;
import org.ow2.play.governance.api.bean.Topic;
import org.ow2.play.service.client.ClientException;
import org.ow2.play.service.client.PlayClient;


public class DsbPubSubHelper implements EventReceiver, ReplayCapable {
	
// XXX: Logger for PLAY central integration test
final static org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(DsbPubSubHelper.class);
final static Hashtable eventsLog = new Hashtable<String,String>();
	
	static {
        Wsnb4ServUtils.initModelFactories(new WsrfbfModelFactoryImpl(),
                new WsrfrModelFactoryImpl(), new WsrfrlModelFactoryImpl(),
                new WsrfrpModelFactoryImpl(), new WstopModelFactoryImpl(),
                new WsnbModelFactoryImpl());
    }
	protected static String defaultSubscriptionsFile = "subscriptions.txt";

	protected EventReceiver caller;
	protected Hashtable<String,Endpoint> endpoints;
	protected Hashtable<String,Executor> executors;
	protected DSBProperties dsbProperties;
	protected String ipAddress;
	
	protected String spoolFile;
	protected EventsReplayHelper replayHelper;
	protected boolean printEvent;
	
	public static DsbPubSubHelper getInstance(EventReceiver caller, Properties properties) throws IOException {
		boolean useLoopback = Configurator.checkBoolean(properties.getProperty("use-loopback-helper"), false);
		if (!useLoopback) {
			return new DsbPubSubHelper(caller, properties);
		} else {
			return new LoopbackPubSubHelper(caller, properties);
		}
	}
	
	protected DsbPubSubHelper() {
		// provided for use in LoopbackPubSubHelper
	}
	
	protected DsbPubSubHelper(EventReceiver caller, Properties properties) throws IOException {
		this.caller = caller;
		
    	this.dsbProperties = new DSBProperties(properties);
		// Set the local IP address for the notification consumer WS endpoint
		setIpAddress("NOTIFY_ENDPOINT");
		setIpAddress("NOTIFICATION_PRODUCER_ENDPOINT");
		// Print DSB properties
		boolean printProperties = Configurator.checkBoolean( dsbProperties.getProperty("PRINT_DSB_PROPERTIES"), false );
		if (printProperties) {
			out().println("-------------------------------------------------------------------------------");
			out().println("DSB properties:");
			this.dsbProperties.printProperties(out());
			out().println("-------------------------------------------------------------------------------");
		}
		
		// Set debug print flag
		printEvent = Configurator.checkBoolean( dsbProperties.getProperty("DEBUG_EVENTS"), false );
		
		// Events replay helper
		replayHelper = new EventsReplayHelper(this, this.dsbProperties);
	}
	
	protected void setIpAddress(String propName) {
		ipAddress = dsbProperties.getProperty("IP_ADDRESS");
		if (ipAddress!=null) {
			ipAddress = ipAddress.trim();
			if (ipAddress.toUpperCase().startsWith("NO")) return;
		}
		
		String str0 = dsbProperties.getProperty(propName).trim();
		if (str0.indexOf("%IP_ADDRESS%")>=0 || str0.indexOf("%IP_ADDR%")>=0) {
			if (ipAddress==null) {
				String filter = dsbProperties.getProperty("IP_ADDRESS_FILTER");
				filter = (filter==null || filter.trim().equals("")) ? "" : filter.trim();
				if (!filter.equals("")) out().println(getClass().getName()+": setIpAddress: Using IP Address filter: "+filter);
				List<InetAddress> addresses = NetworkHelper.getInetAddresses(filter);
				if (addresses.size()==0) throw new RuntimeException(getClass().getName()+": setIpAddress: No IP addresses found");
				ipAddress = addresses.get(0).toString().substring(1);
				if (addresses.size()>1) {
					out().println(getClass().getName()+": setIpAddress: "+addresses.size()+" IP addresses found. Using the first one: "+ipAddress);
				}
			}
			
			String str1 = str0.replace("%IP_ADDRESS%", ipAddress).replace("%IP_ADDR%", ipAddress);
			if (!str1.equals(str0)) dsbProperties.setProperty(propName, str1);
		}
	}
	
	// Start local notification consumer web service
	public void startEndpointWS() {
		if (replayHelper.isReplaying()) return;
		
		// Start event spooling (if configured)
		String sp = dsbProperties.getProperty("spool-file");
		if (sp!=null && !sp.trim().equals("")) spoolOn(sp);
    	
		// Publish notifications consumer endpoint
		String address = dsbProperties.getNotifyEndpoint();
    	try {
    		NotificationConsumerService implementor = new NotificationConsumerService(this);
			
			this.endpoints = new Hashtable<String,Endpoint>();
			this.executors = new Hashtable<String,Executor>();
			
			out().println("Starting NotificationConsumerService");    	
			
			Endpoint endpoint = Endpoint.create(implementor);
			Executor executor = Executors.newSingleThreadExecutor();
			this.endpoints.put(address, endpoint);
			this.executors.put(address, executor);
			endpoint.setExecutor(executor);
			endpoint.publish(address);
    	} catch (Exception e) {
    		err().println("** Cannot start notification consumer web-service at " + address);
			throw new RuntimeException(e);
    	}
	}
	
	// Stop local notification consumer web service
	public void stopEndpointWS() {
		if (replayHelper.isReplaying()) {
			replayHelper.stopReplay();
			return;
		}
		
    	String address = dsbProperties.getNotifyEndpoint();
    	out().println("Stopping NotificationConsumerService");    	
    	try {
			Endpoint endpoint = this.endpoints.get(address);
			if (endpoint!=null) {
				endpoint.stop();
				this.endpoints.remove(address);
			} else {
				err().println("Endpoint not found for " + address);
			}
			
			spoolOff();
    	} catch (Exception e) {
    		err().println("Cannot start web-service at " + address);
    	}
		
		this.endpoints = null;
		this.executors = null;
	}

// XXX: EXPERIMENT - Tmp implementation	
	public QName createTopic(String topicStr) {
		if (replayHelper.isReplaying()) {
			return replayHelper.createTopic(topicStr);
		}
		
		err().println("DsbPubSubHelper: createTopic: NOT YET IMPLEMENTED. Should be replaced by deployCEPAT(language,definition)");
org.iccs.san.util.ActionHelper.getInstance().alert("DsbPubSubHelper: createTopic: NOT YET IMPLEMENTED. Should be replaced by deployCEPAT(language,definition)");
		return null;
	}
	
// XXX: EXPERIMENT - Tmp implementation	
	public boolean destroyTopic(QName topic) {
		if (replayHelper.isReplaying()) {
			return replayHelper.destroyTopic(topic);
		}
		
		err().println("DsbPubSubHelper: destroyTopic: NOT YET IMPLEMENTED. Should be replaced by undeployCEPAT(CEPAT)");
org.iccs.san.util.ActionHelper.getInstance().alert("DsbPubSubHelper: destroyTopic: NOT YET IMPLEMENTED. Should be replaced by undeployCEPAT(CEPAT)");
		return false;
	}
	
/*	public String subscribeFor(QName topic) {
		if (replayHelper.isReplaying()) {
			return replayHelper.subscribe(topic);
		}
		
		out().println("** Subscribe to TOPIC="+topic);
		Topic topic1 = new Topic();
		topic1.name = topic.getLocalPart();
		topic1.ns = topic.getNamespaceURI();
		topic1.prefix = topic.getPrefix();
		
		String endpoint = dsbProperties.getSubscribeEndpoint();
		PlatformClient client = null;
		try {
			out().println("** Sending subscription request to : "+endpoint);
			client = new PlatformClient();
			client.connect(endpoint, null);
		} catch (Exception e) {
			err().println("DsbPubSubHelper: subscribeFor: Exception thrown while connecting to endpoint: "+e);
			err().println("DsbPubSubHelper: subscribeFor: Topic="+topic+", subscription service="+endpoint);
			e.printStackTrace(err());
			return null;
		}
		
		String receiveNotificationURL = dsbProperties.getNotifyEndpoint();
		out().println("** Receiving notifications at : " +receiveNotificationURL);
		Subscription subscription = new Subscription();
		subscription.subscriber = receiveNotificationURL;
		subscription.topic = topic1;
		
		String subscriptionID = null;
		try {
			SubscriptionResult result = client.getSubscriptionManager().subscribe(subscription);
			subscriptionID = result.subscriptionID;
			out().printf("** SUBSCRIBED!  Subscription ID :  %s\n", subscriptionID);
		} catch (Exception e) {
			err().println("DsbPubSubHelper: subscribeFor: Exception thrown while subscribing: "+e);
			err().println("DsbPubSubHelper: subscribeFor: Topic="+topic+", subscription service="+endpoint+", notification URL="+receiveNotificationURL);
			e.printStackTrace(err());
			return null;
		} finally {
			if (subscriptionID!=null) {
				saveSubscriptionId(subscriptionID, endpoint, "SUBSCRIBE using Platform-Client: "+topic);
			}
		}
		return subscriptionID;
	}
	
	public boolean unsubscribeFrom(QName topic, String UUID) {
		if (replayHelper.isReplaying()) {
			return replayHelper.unsubscribe(topic, UUID);
		}
		
		out().println("** Unubscribe from TOPIC="+topic+" with Subscription Id: "+UUID);
		String endpoint = dsbProperties.getSubscribeEndpoint();
		
		try {
			out().println("** Sending UNSubscription request to : "+endpoint);
			PlatformClient client = new PlatformClient();
			client.connect(endpoint, null);
			String subscriptionID = UUID;
			boolean result = client.getSubscriptionManager().unsubscribe(subscriptionID);
			out().println("** UNSUBSCRIBED!  Result:  "+result);
		} catch (Exception e) {
			e.printStackTrace(err());
			return false;
		}
		saveSubscriptionId(UUID, endpoint, "UNSUBSCRIBE from topic: "+topic);
		return true;
	}
*/	
	public String subscribeFor(QName topic) {
		if (replayHelper.isReplaying()) {
			return replayHelper.subscribe(topic);
		}
		
		out().println("** Subscribe to TOPIC="+topic);
		Topic topic1 = new Topic();
		topic1.setName(topic.getLocalPart());
		topic1.setNs(topic.getNamespaceURI());
		topic1.setPrefix(topic.getPrefix());
		
		String registryEndpoint = dsbProperties.getProperty("REGISTRY_ENDPOINT");
		out().println("** Registry service at : " +registryEndpoint);
		String subscribeToEndpoint = dsbProperties.getSubscribeEndpoint();
		out().println("** Subscription service at : " +subscribeToEndpoint);
		String receiveNotificationURL = dsbProperties.getNotifyEndpoint();
		out().println("** Receiving notifications at : " +receiveNotificationURL);
		
		String subscriptionID = null;
		try {
			Subscription subscription = new Subscription();
			subscription.setTopic(topic1);
			subscription.setProvider(subscribeToEndpoint);
			subscription.setSubscriber(receiveNotificationURL);

			PlayClient newclient = new PlayClient(registryEndpoint);
			Subscription result = newclient.getSubscriptionService().subscribe(subscription);
			subscriptionID = result.getId();
			out().printf("** SUBSCRIBED!  Subscription ID :  %s\n", subscriptionID);
		} catch (Exception e) {
			err().println("DsbPubSubHelper: subscribeFor: Exception thrown while subscribing: "+e);
			err().println("DsbPubSubHelper: subscribeFor: Topic="+topic+", subscription service="+subscribeToEndpoint+", notification URL="+receiveNotificationURL);
			e.printStackTrace(err());
			return null;
		} finally {
			if (subscriptionID!=null) {
				saveSubscriptionId(subscriptionID, subscribeToEndpoint, "SUBSCRIBE using PLAY-Client: "+topic);
			}
		}
		return subscriptionID;
	}
	
	public boolean unsubscribeFrom(QName topic, String UUID) {
		if (replayHelper.isReplaying()) {
			return replayHelper.unsubscribe(topic, UUID);
		}
		
		out().println("** Unubscribe from TOPIC="+topic+" with Subscription Id: "+UUID);
		String endpoint = dsbProperties.getSubscribeEndpoint();
		
		String subscribeToEndpoint = dsbProperties.getSubscribeEndpoint();
		HTTPSubscriptionManagerClient subscriptionManagerClient = null;
		try {
			out().println("** Creating subscription manager client for endpoint : " +subscribeToEndpoint);
			subscriptionManagerClient = new HTTPSubscriptionManagerClient(subscribeToEndpoint);
		} catch (Exception e) {
			err().println("DsbPubSubHelper: unsubscribeFrom: Exception thrown while unsubscribing: "+e);
			err().println("DsbPubSubHelper: unsubscribeFrom: Topic="+topic+", subscription service="+endpoint);
			e.printStackTrace(err());
			return false;
		}
		
		boolean result = false;
		try {
			out().println("** Sending UNSubscription request to : "+endpoint+"  for UUID: "+UUID+"  and Topic: "+topic);
			String subscriptionID = UUID;
			// not implemented yet by christophe with client.getSubscriptionService().unsubscribe(sub);
			//result = client.getSubscriptionManager().unsubscribe(subscriptionID);
			subscriptionManagerClient.unsubscribe(UUID); //old version
			result = true;
			out().println("** UNSUBSCRIBED!  Result:  "+result);
		} catch (Exception e) {
			e.printStackTrace(err());
			return false;
		}
		saveSubscriptionId(UUID, endpoint, "UNSUBSCRIBE from topic: "+topic);
		return result;
	}
	
	public void eventReceived(String notify) {
// XXX: Logger for PLAY central integration test
boolean duplicate = logEventEntry( notify, dsbProperties );
if (duplicate) return;
		this.caller.eventReceived(notify);
	}
	
	public void eventReceived(Notify notify) throws WsnbException {
// XXX: Logger for PLAY central integration test
boolean duplicate = logEventEntry( notify2string(notify), dsbProperties );
if (duplicate) return;
		this.caller.eventReceived(notify);
	}
	
	public boolean publishEvent(QName topic, String content) {
		boolean allowSendEventsWhileReplay = Configurator.checkBoolean( dsbProperties.getProperty("replay-allow-send-events"), true );
		if (!allowSendEventsWhileReplay) {
			if (replayHelper.isReplaying()) {
				return replayHelper.publishEvent(topic, content);
			}
		}
		
		String pub_endpoint = dsbProperties.getPublishEndpoint();
		HTTPConsumerClient pub_client = new HTTPConsumerClient(pub_endpoint);
		Document eventXML = null;
		try {
			// this is just the business message content, the client will wrap
			// it like required...
			//eventXML = XMLHelper.createDocumentFromString("<event-body>"+content+"</event-body>");
			eventXML = XMLHelper.createDocumentFromString(content);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		/*
		 * see doc/topics
		 * example:
		 * <dsb:TaxiUCIMP xmlns:taxi="http://www.petalslink.org/resources/event/1.0"
			xmlns:dsb="http://www.petalslink.org/dsb/topicsns/" wstop:topic="true" />
		 */		
		QName pub_topic = topic;
		
		try {
			/*out().println(
					String.format("Publishing event : %s - %s\n", 
							pub_topic, 
							XMLHelper.createStringFromDOMDocument(eventXML)));*/
			
			pub_client.notify(eventXML, pub_topic);
// XXX: Logger for PLAY central integration test
logEventExit( content, dsbProperties );
			if (printEvent) {
				out().println(
					String.format("Published event : %s - %s\n", 
							pub_topic, 
							XMLHelper.createStringFromDOMDocument(eventXML)));
			}
			/*
			 * DSB last N web page : http://46.105.181.221:9000/last
			 */
			 return true;
		} catch (NotificationException e) {			
			err().println("NotificationException");
			e.printStackTrace(err());
		} catch (Exception e) {
			e.printStackTrace(err());
		}
		return false;
	}
	
	/*
	 *  Event spooling methods
	 */
	protected synchronized void spoolOn(String fileName) {
		spoolFile = fileName;
		String line = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
		line += "<!-- Spool started: "+(new Date())+" -->\n";
		line += "<event-list>\n";
		if (!writeToFile(spoolFile, line, false)) {
			spoolFile = null;
		} else {
			out().println("** SPOOLING EVENTS to: "+spoolFile);    	
		}
	}
	
	protected synchronized void spoolOff() {
		if (spoolFile==null) return;
		String line = "<!-- Spool ended: "+(new Date())+" -->\n";
		line += "</event-list>\n";
		writeToFile(spoolFile, line, true);
		spoolFile = null;
		out().println("** SPOOLING EVENTS : STOPPED");    	
	}
	
	protected void spoolEvent(Notify notify) {
		if (spoolFile==null) return;
		try {
			// get the DOM from the bean
			Document dom = Wsnb4ServUtils.getWsnbWriter().writeNotifyAsDOM(notify);
			String notifyXml = null;
			try {
				notifyXml = XMLHelper.createStringFromDOMDocument(dom);
				notifyXml = "<!-- Event: "+(new Date())+" -->\n" + notifyXml;
				writeToFile(spoolFile, notifyXml, true);
				out().println("** EVENT SPOOLED");    	
			} catch (TransformerException e) {
				err().println("DsbPubSubHelper: spoolEvent: Exception while spooling event: "+e);
			}
		} catch (WsnbException e) {
			err().println("DsbPubSubHelper: spoolEvent: Exception while spooling event: "+e);
		}
	}
	
	/*
	 *  ReplayCapable methods
	 */
	public boolean isReplaying() { return replayHelper.isReplaying(); }
	public boolean isBatchReplay() { return replayHelper.isBatchReplay(); }
	public boolean exitAfterReplay() { return replayHelper.exitAfterReplay(); }
	public boolean hasNextEvent() { return replayHelper.hasNextEvent(); }
	public boolean hasCompleted() { return replayHelper.hasCompleted(); }
	public boolean replayNextEvent() { return replayHelper.replayNextEvent(); }
	public boolean replayNextEvents(int num) { return replayHelper.replayNextEvents(num); }
	public void startReplay() { replayHelper.startReplay(); }
	public void stopReplay() { replayHelper.stopReplay(); }
	
	/*
	 *  Subscription UUID save and clear methods
	 */
	protected void saveSubscriptionId(String UUID, String endpoint, String comment) {
		if (UUID==null || UUID.trim().equals("")) return;
		String line = (new Date())+"\t"+UUID+"\t"+endpoint+"\t"+comment+"\n";
		writeToFile(defaultSubscriptionsFile, line, true);
	}
	
	public static void clearSubscriptions(String fileName) {
		if (fileName==null) fileName = defaultSubscriptionsFile;
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			String s;
			Vector<String> unsubUUIDs = new Vector<String>();
// XXX: Newer (11-03-2013) PLAY/DSB client (using Governance stable API)
String old_endpoint = null;
HTTPSubscriptionManagerClient subscriptionManagerClient = null;
			while((s = br.readLine()) != null) {
				if (s.trim().equals("")) continue;
				
				// parse line
				String p[] = s.split("\t");
				if (p.length<3) continue;
				p[1] = p[1].trim();
				p[2] = p[2].trim();
				if (p[1].equals("") || p[2].equals("")) continue;
				if (unsubUUIDs.contains(p[1])) continue;
				
				// unsubscribe
				String UUID = p[1].trim();
				String endpoint = p[2].trim();
/*				try {
					PlatformClient client = new PlatformClient();
					client.connect(endpoint, null);
					String subscriptionID = UUID;
					boolean result = client.getSubscriptionManager().unsubscribe(subscriptionID);
					System.out.println("Unsubscribed using ID: "+UUID+", from: "+endpoint+".  Result: "+result);
					unsubUUIDs.add(UUID);
				} catch (Exception e) {
					System.err.println("clearSubscriptions: UNSUBSCRIPTION EXCEPTION: "+e);
					e.printStackTrace(err());
				}*/
				
// XXX: Newer (11-03-2013) PLAY/DSB client (using Governance stable API)
if (subscriptionManagerClient==null || old_endpoint!=null && !old_endpoint.equals(endpoint)) {
	try {
		subscriptionManagerClient = new HTTPSubscriptionManagerClient(endpoint);
		old_endpoint = endpoint;
	} catch (Exception e) {
		System.err.println("clearSubscriptions: Exception thrown while creating subscription manager client: "+e);
		e.printStackTrace(System.err);
	}
}

boolean result = false;
try {
	String subscriptionID = UUID;
	// not implemented yet by christophe with client.getSubscriptionService().unsubscribe(sub);
	//result = client.getSubscriptionManager().unsubscribe(subscriptionID);
	subscriptionManagerClient.unsubscribe(UUID); //old version
	result = true;
	System.out.println("Unsubscribed using ID: "+UUID+", from: "+endpoint+".  Result: "+result);
	unsubUUIDs.add(UUID);
} catch (Exception e) {
	e.printStackTrace(System.err);
}
			}
			br.close();
			fr.close();
			
			try {
				File f = new File(fileName);
				f.renameTo(new File(fileName+".UNSUB"));
				System.err.println("clearSubscriptions: subscriptions file renamed to="+fileName+".UNSUB");
			} catch (Exception ex) {
				System.err.println("clearSubscriptions: EXCEPTION: Cannot rename subscriptions file: from="+fileName+", to="+fileName+".UNSUB");
				System.err.println(ex);
			}
		} catch (FileNotFoundException ex) {
			System.err.println("clearSubscriptions: EXCEPTION: "+ex);
		} catch (IOException ex) {
			System.err.println("clearSubscriptions: EXCEPTION: "+ex);
		}
	}
	
	/*
	 *  File helper methods
	 */
	protected static String readFromFile(String fileName) {
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			String s;
			StringBuffer sb = new StringBuffer();
			while((s = br.readLine()) != null) {
				sb.append(s);
				sb.append('\n');
			}
			br.close();
			fr.close();
			return sb.toString();
		} catch (Exception ex) {
			err().println("readFromFile: Cannot read from file '"+fileName+"' : "+ex);
			return null;
		}
	}
	
	protected static boolean writeToFile(String fileName, String content, boolean append) {
		try {
			FileWriter fw = new FileWriter(fileName, append);
			PrintWriter out = new PrintWriter(fw);
			out.print(content);
			out.close();
			fw.close();
			return true;
		} catch (IOException ex) {
			err().println("writeToFile: Cannot write to file '"+fileName+"' : "+ex);
			return false;
		}
	}
	
	/*
	 *  Other methods
	 */
	protected static PrintStream out() {
		return SANThread.getOut();
	}
	
	protected static PrintStream err() {
		return SANThread.getErr();
	}
	
	protected static String notify2string(Notify notify) {
		List<NotificationMessageHolderType> messages = notify.getNotificationMessage();
		for (NotificationMessageHolderType notificationMessageHolderType : messages) {
			Element businessMessage = notificationMessageHolderType.getMessage().getAny();
			try {
				return XMLHelper.createStringFromDOMNode(businessMessage);
			} catch (TransformerException e) {
				err().println("notify2string: Exception caught: "+e);
				e.printStackTrace(err());
			}
		}
		return null;
	}
	
// XXX: Logger for PLAY central integration test
	protected synchronized boolean logEventEntry(String payload, DSBProperties dsbProperties) {
		return logEvent(" Entry ", payload, dsbProperties);
	}
	
// XXX: Logger for PLAY central integration test
	protected synchronized boolean logEventExit(String payload, DSBProperties dsbProperties) {
		return logEvent(" Exit ", payload, dsbProperties);
	}

// XXX: Logger for PLAY central integration test
	protected synchronized boolean logEvent(String mesg, String payload, DSBProperties dsbProperties) {
		// check if logging is active
		if (!Configurator.checkBoolean(dsbProperties.getProperty("logging"), false)) return false;
		
		// log event
		String eid = getEventIdFromContent(payload);
		if (eid!=null) {
			String componentName = dsbProperties.getProperty("logging.name");
			boolean suppressDuplicates = Configurator.checkBoolean(dsbProperties.getProperty("logging.suppress-duplicates"), false);
			if (suppressDuplicates) {
				if (eventsLog.containsKey(eid)) return true;
				eventsLog.put(eid, eid);
			}
			
			if (componentName==null) componentName = "SAN";
			System.out.println("--------------------------------------------------------------------------");
			System.out.println("@@@  LOGGER: "+componentName+mesg+eid);
			System.out.println("--------------------------------------------------------------------------");
			logger.info(componentName+mesg+eid);
		}
		return false;
	}

// XXX: Logger for PLAY central integration test
	protected static String getEventIdFromContent(String payload) {
		if (payload==null || payload.trim().equals("")) return null;
		
		SesameRDFRepository rep = null;
		SesameGraph sg = null;
		String rdfTxt = null;
		try {
			// extract RDF from event payload
			String rdfString = null;
			if (payload.indexOf("<mt:nativeMessage")>=0) {
				int p1 = payload.indexOf(">");
				int p2 = payload.lastIndexOf("</mt:nativeMessage>");
				if (p1>=0 && p2>p1) {
					rdfString = payload.substring(p1+1, p2);
					if (rdfString==null || rdfString.trim().equals("")) rdfString = null;
				}
			}
			String NSP = 
				"@prefix sioc: <http://rdfs.org/sioc/ns#> . \n" +
				"@prefix : <http://events.event-processing.org/types/> . \n" +
				"@prefix uctelco: <http://events.event-processing.org/uc/telco/> . \n" +
				"@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> . \n" +
				"@prefix geo: <http://www.w3.org/2003/01/geo/wgs84_pos#> . \n" +
				"@prefix e: <http://events.event-processing.org/ids/> . \n" +
				"@prefix s: <http://streams.event-processing.org/ids/> . \n" +
				"@prefix esr: <http://imu.ntua.gr/play/esr/examples/2#> . \n" +
				"@prefix xsd: <http://www.w3.org/2001/XMLSchema#> . \n" +
				"@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> . \n" +
				"@prefix src: <http://sources.event-processing.org/ids/> . \n" +
				"@prefix user: <http://graph.facebook.com/schema/user#> . \n\n";
			if (rdfString==null) {
				if (payload.trim().startsWith("@prefix")) rdfString = payload;
				else rdfString = NSP+payload;
			}
			
			// convert special characters
			rdfString = HtmlEntities.decode(rdfString);
			
			// get a sesame repository
			rep = new SesameRDFRepository(false);	// false = not inferencing
			sg = new SesameGraph(rep.getRepository());
			
			// load event content
			RDFFormat rdfFormat = sg.TRIG;		// in PLAY only RDF/TRiG format is used
			sg.addString(rdfTxt = rdfString, rdfFormat);

/*			java.io.OutputStream out = new java.io.ByteArrayOutputStream();
			sg.dumpRDF(out, sg.N3);
			System.out.println( out.toString() );*/
			
			// extract event id (from subject??? or a specific tag??)
			String qs = "select ?x ?y WHERE { ?x a ?y }";
			List<HashMap> result = sg.runSPARQL(qs);
			Iterator<HashMap> iterator = result.iterator();
			// normally only one record will match per event
			while (iterator.hasNext()) {
				HashMap hm = iterator.next();
				String uri = hm.get("x").toString();
				if (uri!=null && uri.trim().startsWith("http:")) {
					return uri;
				}
			}
			
		} catch (Throwable e) {
			System.err.println("DsbPubSubHelper.getEventIdFromContent:  Exception: "+e+"\nEvent payload:\n"+rdfTxt+"\n");
		} finally {
			// clear and release repository
			sg = null;
			rep = null;
		}
		
		return null;
	}
	
	
	/*
	 *  CLI to DsbPubSubHelper
	 */
	public static void main(String[] args) {
		if (args.length==0) {
			System.out.println("DsbPubSubHelper utility");
			System.out.println("Usage: java "+Thread.currentThread().getStackTrace()[1].getClassName()+" clearsubs [subscriptions file]\n");
			return;
		}
		
		if (args[0].trim().equalsIgnoreCase("clearsubs")) {
			String file = null;
			if (args.length>1) file = args[1].trim();
			clearSubscriptions(file);
		}
	}
}
