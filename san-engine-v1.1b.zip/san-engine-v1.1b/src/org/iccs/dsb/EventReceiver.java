package org.iccs.dsb;

import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.Notify;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.utils.WsnbException;

public interface EventReceiver {
	public void eventReceived(String notify);
	public void eventReceived(Notify notify) throws WsnbException;
}
