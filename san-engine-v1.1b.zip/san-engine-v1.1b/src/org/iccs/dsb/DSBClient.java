/**
 *	DSBClient
 */
package org.iccs.dsb;

import org.iccs.san.util.SANThread;

import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.ws.Endpoint;
import javax.xml.ws.wsaddressing.W3CEndpointReference;
import javax.xml.ws.wsaddressing.W3CEndpointReferenceBuilder;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.oasis_open.docs.wsn.b_2.NotificationMessageHolderType;
import org.oasis_open.docs.wsn.b_2.Notify;
import org.oasis_open.docs.wsn.b_2.TopicExpressionType;
import org.oasis_open.docs.wsn.t_1.TopicSetType;

import org.oasis_open.docs.wsn.b_2.FilterType;
import org.oasis_open.docs.wsn.b_2.ObjectFactory;
import org.oasis_open.docs.wsn.b_2.Subscribe;
import org.oasis_open.docs.wsn.b_2.Subscribe.SubscriptionPolicy;
import org.oasis_open.docs.wsn.b_2.SubscribeResponse;
import org.oasis_open.docs.wsn.b_2.TopicExpressionType;
import org.oasis_open.docs.wsn.brw_2.NotificationBroker;

//import org.ow2.petals.components.petals_se_wsnotificationbroker.NotificationBroker;
import org.ow2.petals.components.petals_se_wsnotificationbroker.NotificationBrokerService;
import org.ow2.petals.components.petals_se_wsnotificationbroker.SupportedTopicsService;
import org.ow2.petals.components.petals_se_wsnotificationbroker.SupportedTopicsSet;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class DSBClient {
	/**
	 * subscribe
	 * 
	 * @param eventTypeTopic
	 * @param subscriberUrl
	 * @param dsbURL
	 * @return
	 */
	// CXF version
	public static SubscribeResponse subscribe(String eventTypeTopic,
			QName TOPIC_NS, String subscriberUrl, String dsbURL, 
			boolean printMsgsFlag)
	{
		URL url;
		try {
			url = new URL(dsbURL+"?wsdl");

			//NotificationBrokerService pub = new NotificationBrokerService(url);
			
			/*
			NotificationBrokerService pub = new NotificationBrokerService(
					url,
					new QName(
							"http://petals.ow2.org/components/petals-se-WsNotificationBroker",
							"NotificationBrokerService"));
			*/
			NotificationBrokerService pub = new NotificationBrokerService(
					url,
					new QName(
							"http://docs.oasis-open.org/wsn/b-2",
							"NotificationProducerService"));
			
			NotificationBroker port = pub.getNotificationBrokerServiceEndpoint();
			//debug : intercept & print input - ouput
			Client client = ClientProxy.getClient(port);
			if (printMsgsFlag) {
				client.getInInterceptors().add(new LoggingInInterceptor(new PrintWriter(SANThread.getOut())));
				client.getOutInterceptors().add(new LoggingOutInterceptor(new PrintWriter(SANThread.getOut())));
			}
	        //
	        //create the payload of subscribe request
			Subscribe subscribe = new Subscribe();

			W3CEndpointReferenceBuilder builder = new W3CEndpointReferenceBuilder();
			builder.address(subscriberUrl);
			// Create the endpoint reference from the builder object
			W3CEndpointReference epr = builder.build();
			subscribe.setConsumerReference(epr);

			FilterType filterType = new FilterType();
			ObjectFactory obj = new ObjectFactory();
			TopicExpressionType topic = new TopicExpressionType();
			topic.setDialect("http://www.w3.org/TR/1999/REC-xpath-19991116");

			final Map<QName, String> objFromModel = topic.getOtherAttributes();
			if (objFromModel != null) { //
				topic.getOtherAttributes().put(TOPIC_NS, "xmlns");
			}

			// set content : must be added to other element :
			final List<Object> objFromModel2 = topic.getContent();
			if (objFromModel2 != null) {
				if (objFromModel2.size() > 0) {
					objFromModel2.clear();
				} //
				objFromModel2.add(0, TOPIC_NS.getPrefix() + ":"+ eventTypeTopic);
			}

			JAXBElement<TopicExpressionType> jaxTop = obj
					.createTopicExpression(topic);

			filterType.getAny().add(0, jaxTop);

			// subscribe.withFilter(filterType);
			subscribe.setFilter(filterType);

			ObjectFactory ob = new ObjectFactory();
			JAXBElement<String> iniTerminationTime = ob
					.createSubscribeInitialTerminationTime("PT1H");
			// subscribe.withInitialTerminationTime(iniTerminationTime);
			subscribe.setInitialTerminationTime(iniTerminationTime);

			SubscribeResponse response = port.subscribe(subscribe);

			W3CEndpointReference ref = response.getSubscriptionReference();

			//SANThread.getOut().println("Subscription referencce =" + ref.toString());

			//SANThread.getOut().println("You just subscribed to " + eventTypeTopic);

			return response;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace(SANThread.getErr());
		}
		return null;
	}

	/*
	 * public static SubscribeResponse subscribe(String eventTypeTopic, QName
	 * TOPIC_NS, String subscriberUrl, String dsbURL) { // petals service try {
	 * 
	 * URL url = new URL(dsbURL);
	 * 
	 * NotificationBrokerService pub = new NotificationBrokerService( url, new
	 * QName( "http://petals.ow2.org/components/petals-se-WsNotificationBroker",
	 * "NotificationBrokerService")); NotificationBroker man =
	 * pub.getNotificationBrokerServiceEndpoint();
	 * 
	 * org.oasis_open.docs.wsn.b_2.Subscribe subscribe = new
	 * org.oasis_open.docs.wsn.b_2.Subscribe(); // new code for ws-addr in
	 * JAX-WS // Create the builder object W3CEndpointReferenceBuilder builder =
	 * new W3CEndpointReferenceBuilder();
	 * 
	 * // Modify builder properties builder.address(subscriberUrl);
	 * 
	 * // Create the endpoint reference from the builder object
	 * W3CEndpointReference epr = builder.build();
	 * 
	 * subscribe.setConsumerReference(epr);
	 * 
	 * FilterType filterType = new FilterType();
	 * 
	 * ObjectFactory obj = new ObjectFactory();
	 * 
	 * TopicExpressionType topic = new TopicExpressionType(); // set dialect :
	 * topic.setDialect("http://www.w3.org/TR/1999/REC-xpath-19991116");
	 * //.setDialect("http://docs.oasis-open.org/wsn/t-1/TopicExpression/Full");
	 * 
	 * // set TopicNamespace : final Map<QName, String> objFromModel =
	 * topic.getOtherAttributes(); if (objFromModel != null) { //
	 * topic.getOtherAttributes().put(SYNERGY_NS, "xmlns");
	 * topic.getOtherAttributes().put(TOPIC_NS, "xmlns"); }
	 * 
	 * // set content : must be added to other element : final List<Object>
	 * objFromModel2 = topic.getContent(); if (objFromModel2 != null) { if
	 * (objFromModel2.size() > 0) { objFromModel2.clear(); } //
	 * objFromModel2.add(0, SYNERGY_NS.getLocalPart() + ":" + //
	 * eventTypeTopic); objFromModel2.add(0, TOPIC_NS.getLocalPart() + ":" +
	 * eventTypeTopic); }
	 * 
	 * JAXBElement<TopicExpressionType> jaxTop = obj
	 * .createTopicExpression(topic);
	 * 
	 * filterType.getAny().add(0, jaxTop);
	 * 
	 * // subscribe.withFilter(filterType); subscribe.setFilter(filterType);
	 * 
	 * ObjectFactory ob = new ObjectFactory(); JAXBElement<String>
	 * iniTerminationTime = ob .createSubscribeInitialTerminationTime("PT1H");
	 * // subscribe.withInitialTerminationTime(iniTerminationTime);
	 * subscribe.setInitialTerminationTime(iniTerminationTime);
	 * 
	 * // QName policyRuleEltQName = new //
	 * QName("http://www.ebmwebsourcing.com/wsnotification/specificTypes"
	 * ,"TransformPolicy","ebm"); // // DOMParser parser = new DOMParser(); //
	 * parser.parse("../modules/src/test/resources/policyRule_grdr-etape1.xsl");
	 * // Document doc = parser.getDocument(); // Element docElement =
	 * doc.getDocumentElement(); // JAXBElement<Object> policyRuleElt = new //
	 * JAXBElement
	 * <Object>(policyRuleEltQName,Object.class,((Object)docElement)); // //
	 * Element processPolicy = // doc.createElementNS(
	 * "http://www.ebmwebsourcing.com/wsnotification/specificTypes", //
	 * "ProcessPolicy"); // processPolicy.setPrefix("ebm"); //
	 * processPolicy.setAttribute("action", "reset"); // Element contextPolicy =
	 * // doc.createElementNS(
	 * "http://www.ebmwebsourcing.com/wsnotification/specificTypes", //
	 * "contextPolicy"); // contextPolicy.setPrefix("ebm"); //
	 * contextPolicy.setAttribute("correlationId", "false"); //
	 * contextPolicy.setAttribute("endpoint", "false"); //
	 * contextPolicy.setAttribute("interface", "false"); //
	 * contextPolicy.setAttribute("meuuid", "false"); //
	 * contextPolicy.setAttribute("notifDate", "false"); //
	 * contextPolicy.setAttribute("service", "false"); //
	 * contextPolicy.setAttribute("status", "false"); // // SubscriptionPolicy
	 * policy = new SubscriptionPolicy(); // // // set content : must be added
	 * to other element : // final List<Object> objFromModelPolicy =
	 * policy.getAny(); // if (objFromModelPolicy != null) { // if
	 * (objFromModelPolicy.size() > 0) { // objFromModelPolicy.clear(); // } //
	 * objFromModelPolicy.add(0, policyRuleElt); // objFromModelPolicy.add(1,
	 * processPolicy); // objFromModelPolicy.add(2, contextPolicy); // } //
	 * subscribe.withSubscriptionPolicy(policy);
	 * 
	 * SubscribeResponse response = man.subscribe(subscribe);
	 * 
	 * W3CEndpointReference ref = response.getSubscriptionReference();
	 * 
	 * System.out.println(ref.toString());
	 * 
	 * System.out.println("You just subscribed to " + eventTypeTopic);
	 * 
	 * return response;
	 * 
	 * } catch (Exception e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); } return null; }
	 */
}
