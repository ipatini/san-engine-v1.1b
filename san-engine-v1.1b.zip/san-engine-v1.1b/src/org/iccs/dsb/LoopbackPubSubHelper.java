/**
 *	Loopback Pub/Sub helper
 */
package org.iccs.dsb;

import org.iccs.san.cep.ReplayCapable;
import org.iccs.san.util.Configurator;
import org.iccs.san.util.NetworkHelper;
import org.iccs.san.util.SANThread;

import org.iccs.dsb.DSBProperties;
import org.iccs.dsb.webservices.NotificationConsumerService;
import org.iccs.dsb.DSBClient;
import org.iccs.dsb.EventReceiver;

import java.io.IOException;
import java.io.PrintStream;
import java.io.*;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;
import java.util.concurrent.*;

import javax.xml.namespace.QName;
import javax.xml.ws.Endpoint;
import javax.xml.ws.wsaddressing.W3CEndpointReference;
import javax.xml.transform.TransformerException;
import javax.xml.parsers.*;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import org.oasis_open.docs.wsn.b_2.SubscribeResponse;
import org.petalslink.dsb.notification.client.http.simple.HTTPConsumerClient;
import org.petalslink.dsb.notification.client.http.simple.HTTPProducerClient;
import org.petalslink.dsb.notification.client.http.simple.HTTPProducerRPClient;
import org.petalslink.dsb.notification.client.http.simple.HTTPSubscriptionManagerClient;
import org.petalslink.dsb.notification.commons.NotificationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;


public class LoopbackPubSubHelper extends DsbPubSubHelper implements ReplayCapable, Runnable {
	
	protected EventReceiver caller;
	protected DSBProperties dsbProperties;
	protected String prefix = "TOPIC";
	protected String workdir;
	protected boolean printEvent;
	
	protected Hashtable<QName,Hashtable<String,Object>> subscriptions;
	protected Hashtable<QName,FileMonitor> monitors;
	
	protected Thread runner;
	protected boolean keepRunning;
	protected String eventDelim = "<!-- EVENT SEPARATOR -->\n";
	protected String eventSep = "\n\n"+eventDelim+"\n";
	protected long delay = 500;
	
	public LoopbackPubSubHelper(EventReceiver caller, Properties properties) throws IOException {
		this.caller = caller;
		
    	this.dsbProperties = new DSBProperties(properties);
		
		// Print DSB properties
		boolean printProperties = Configurator.checkBoolean( dsbProperties.getProperty("PRINT_DSB_PROPERTIES"), false );
		if (printProperties) {
			out().println("-------------------------------------------------------------------------------");
			out().println("Loopback DSB properties:");
			this.dsbProperties.printProperties(out());
			out().println("-------------------------------------------------------------------------------");
		}
		
		// Set debug print flag
		printEvent = Configurator.checkBoolean( dsbProperties.getProperty("DEBUG_EVENTS"), false );
	}
	
	// Start local notification consumer web service
	public void startEndpointWS() {
		// Get working parameters
		String workdir = dsbProperties.getProperty("loopback.work-dir");
    	try {
			java.io.File wdir = new java.io.File(workdir);
			if (wdir.exists()) {
				out().println("** LoopbackPubSubHelper initialized at work directory : "+workdir);
				this.workdir = workdir;
			} else {
				err().println("** Cannot initialize LoopbackPubSubHelper : Work directory does not exist : " + workdir);
			}
    	} catch (Exception e) {
    		err().println("** Cannot initialize LoopbackPubSubHelper at work directory : " + workdir+": EXCEPTION: "+e);
			throw new RuntimeException(e);
    	}
		
		String pref = dsbProperties.getProperty("loopback.topic-file-prefix");
		if (pref!=null && !(pref=pref.trim()).equals("")) {
			this.prefix = pref;
		}
		
		// initialize variables
		subscriptions = new Hashtable<QName,Hashtable<String,Object>>();
		monitors = new Hashtable<QName,FileMonitor>();
		
		// start topic files monitoring thread
		runner = new Thread(this);
		runner.setDaemon(true);
		runner.start();
	}
	
	// Stop local notification consumer web service
	public void stopEndpointWS() {
		keepRunning = false;
		while (runner!=null) try { Thread.currentThread().sleep(500); } catch (Exception e) {};
		subscriptions = null;
		monitors = null;
    	this.workdir = null;
		this.prefix = "TOPIC";
		out().println("** LoopbackPubSubHelper stopped");
	}

	protected String getTopicFile(QName topic) {
		String ns = topic.getNamespaceURI();
		String lp = topic.getLocalPart();
		String pf = topic.getPrefix();
		ns = (ns==null) ? "" : ns.trim().replaceAll("[^A-Za-z0-9]", "_");
		lp = (lp==null) ? "" : lp.trim().replaceAll("[^A-Za-z0-9]", "_");
		pf = (pf==null) ? "" : pf.trim().replaceAll("[^A-Za-z0-9]", "_");
		String fname = String.format("%s/%s-%s-%s-%s.txt", workdir, prefix, pf, lp, ns);
		return fname;
	}
	
// XXX: USED INSTEAD OF THE PROPER DCEP API (till DCEP API is ready)
	public boolean createTopic(QName topic) {
		String topicFile = getTopicFile(topic);
		FileMonitor fm = new FileMonitor(topicFile, delay);
		monitors.put(topic, fm);
		try {
			fm.start();
		} catch (IOException e) {
			monitors.remove(topic);
			err().println("LoopbackPubSubHelper: createTopic: Failed to create Topic: "+topic+"   topic file="+topicFile);
e.printStackTrace();
			throw new RuntimeException(e);
		}
		out().println("LoopbackPubSubHelper: createTopic: Topic created : "+topic);
		
		return true;
	}
	
// XXX: USED INSTEAD OF THE PROPER DCEP API (till DCEP API is ready)
	public boolean destroyTopic(QName topic) {
		FileMonitor fm = monitors.remove(topic);
		if (fm==null) return false;
		try {
			fm.stop();
		} catch (IOException e) {
			err().println("LoopbackPubSubHelper: destroyTopic: Failed to destroy Topic: "+topic);
			throw new RuntimeException(e);
		}
		out().println("LoopbackPubSubHelper: destroyTopic: Topic destroyed : "+topic);
		
		return true;
	}
	
	public String subscribeFor(QName topic) {
        out().println("** Subscribe for TOPIC="+topic);
        
		if (!monitors.containsKey(topic)) {
			createTopic(topic);		// XXX: USED INSTEAD OF THE PROPER DCEP API (till DCEP API is ready)
		}
		if (!subscriptions.containsKey(topic)) {
			subscriptions.put(topic, new Hashtable<String,Object>());
		}
		
		Hashtable<String,Object> subscrUUIDs = subscriptions.get(topic);
		String uuid = org.iccs.san.util.ActionHelper.getGUID();
		subscrUUIDs.put(uuid, uuid);
		
		return uuid;
	}
	
	public boolean unsubscribeFrom(QName topic, String UUID) {
        out().println("** Unubscribe from TOPIC="+topic+", subscription id (UUID): "+UUID);
    	
		if (!subscriptions.containsKey(topic)) return false;
		
		Hashtable<String,Object> subscrUUIDs = subscriptions.get(topic);
		if (!subscrUUIDs.contains(UUID)) return false;
		subscrUUIDs.remove(UUID);
		
		if (subscrUUIDs.isEmpty()) {
			subscriptions.remove(topic);
			destroyTopic(topic);		// XXX: USED INSTEAD OF THE PROPER DCEP API (till DCEP API is ready)
		}
		
		return true;
	}
	
	public void eventReceived(String notify) {
// XXX: Logger for PLAY central integration test
boolean duplicate = logEventEntry( notify, dsbProperties );
if (duplicate) return;
		this.caller.eventReceived(notify);
	}
	
	public boolean publishEvent(QName topic, String content) {
		FileMonitor fm = monitors.get(topic);
		if (fm==null) fm = new FileMonitor(getTopicFile(topic), delay);
		if (content==null || content.trim().equals("")) return true;
		try { fm.append(content + eventSep); }
		catch (IOException e) { throw new RuntimeException(e); }
// XXX: Logger for PLAY central integration test
logEventExit( content, dsbProperties );
		return true;
	}
	
	/*
	 *  Topic file monitor
	 */
	
	public void run() {
		keepRunning = true;
		while (keepRunning) {
			// scan all topic files with subscriptions for new input
			for (QName topic : subscriptions.keySet()) {
				// get new content
				FileMonitor fm = monitors.get(topic);
				String newContent = null;
				try { newContent = fm.readNewNoWait(); }
				catch (IOException e) { throw new RuntimeException(e); }
				if (newContent==null || newContent.trim().equals("")) continue;
				
				// deliver received events to higher level (DCEP interface)
				String eventHeader = "{"+topic.getNamespaceURI()+" "+topic.getLocalPart()+" "+topic.getPrefix()+"}\n";
				String[] event = newContent.split(eventDelim);
				for (int i=0; i<event.length; i++) {
					event[i] = event[i].trim();
					if (event[i].equals("")) continue;
					event[i] = eventHeader + event[i].trim();
					if (!event[i].equals("")) {
						eventReceived(event[i]);
					}
				}
			}
			
			// wait for a while
			try { Thread.currentThread().sleep(500); } catch (InterruptedException e) { }
		}
		runner = null;
	}
	
	/*
	 *  File helper methods
	 */
	protected static String readFromFile(String fileName) {
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			String s;
			StringBuffer sb = new StringBuffer();
			while((s = br.readLine()) != null) {
				sb.append(s);
				sb.append('\n');
			}
			br.close();
			fr.close();
			return sb.toString();
		} catch (Exception ex) {
			err().println("readFromFile: Cannot read from file '"+fileName+"' : "+ex);
			return null;
		}
	}
	
	protected static boolean writeToFile(String fileName, String content, boolean append) {
		try {
			FileWriter fw = new FileWriter(fileName, append);
			PrintWriter out = new PrintWriter(fw);
			out.print(content);
			out.close();
			fw.close();
			return true;
		} catch (IOException ex) {
			err().println("writeToFile: Cannot write to file '"+fileName+"' : "+ex);
			return false;
		}
	}
	
	/*
	 *  ReplayCapable methods (not implemeneted)
	 */
	public boolean isReplaying() { return false; }
	public boolean isBatchReplay() { return false; }
	public boolean exitAfterReplay() { return false; }
	public boolean hasNextEvent() { return false; }
	public boolean hasCompleted() { return false; }
	public boolean replayNextEvent() { return false; }
	public boolean replayNextEvents(int num) { return false; }
	public void startReplay() { }
	public void stopReplay() { }
	
	/*
	 *  Other methods
	 */
	protected static PrintStream out() {
		return SANThread.getOut();
	}
	
	protected static PrintStream err() {
		return SANThread.getErr();
	}
	
	
	/*
	 *  FileMonitor helper class
	 */
	public static class FileMonitor {
		protected File file;
		protected long delay;
		protected FileReader reader;
		protected long size;
		
		public FileMonitor(String fname, long delay) {
			this.file = new File(fname);
			this.delay = (delay<0) ? 0: delay;
			reader = null;
			size = -1;
		}
		
		public String getFilename() {
			try {
				return file.getCanonicalPath();
			} catch (IOException e) {
				return null;
			}
		}
		
		public boolean createFile() throws IOException {
			return file.createNewFile();
		}
		
		public boolean append(String content) throws IOException {
			if (!file.exists()) if (!createFile()) return false;
			return writeToFile(file.getCanonicalPath(), content, true);
		}
		
		public void start() throws IOException {
			if (reader!=null) return;
			if (!file.exists()) createFile();
			reader = new FileReader(file);
			size = file.length();
			reader.skip(size);
			//System.out.println("Initial file size: "+size);
		}
		
		public void stop() throws IOException {
			if (reader==null) return;
			reader.close();
			reader = null;
			size = -1;
		}
		
		public String readNew() throws IOException {
			while (true) {
				try { Thread.sleep(delay); } catch (Exception e) {}
				long newSize = file.length();
				long diff = newSize-size;
				size = newSize;
				//System.out.println(newSize+"   "+diff);
				if (diff>0) {
					String newContent = readFromFile(reader);
					//System.out.println(newSize+"   "+diff+"  >>");
					//System.out.println(newContent );
					return newContent;
				}
			}
		}
		
		public String readNewNoWait() throws IOException {
			long newSize = file.length();
			long diff = newSize-size;
			size = newSize;
			//System.out.println(newSize+"   "+diff);
			if (diff>0) {
				String newContent = readFromFile(reader);
				//System.out.println(newSize+"   "+diff+"  >>");
				//System.out.println(newContent );
				return newContent;
			}
			return null;
		}
		
		protected static String readFromFile(FileReader fr) throws IOException {
			BufferedReader br = new BufferedReader(fr);
			String s;
			StringBuffer sb = new StringBuffer();
			while((s = br.readLine()) != null) {
				sb.append(s);
				sb.append('\n');
			}
			return sb.toString();
		}
		
		protected static boolean writeToFile(String fileName, String content, boolean append) throws IOException {
			FileWriter fw = new FileWriter(fileName, append);
			PrintWriter out = new PrintWriter(fw);
			out.print(content);
			out.close();
			fw.close();
			return true;
		}
	}
}
