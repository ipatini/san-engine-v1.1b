package org.iccs.san.api;


public interface CounterDecorator extends Decorator {
	public abstract String getVariable();
	public abstract int getStartCount();
	public abstract int getStep();
	public abstract void setVariable(String varName);
	public abstract void setStartCount(int startValue);
	public abstract void setStep(int step);
}
