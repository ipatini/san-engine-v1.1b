package org.iccs.san.api;


public interface PrimitiveAction extends Action {
	public abstract String getCommand();
	public abstract String[] getBoundVarNames();
	public abstract String getBoundVar(String key);

	public abstract void setCommand(String cmd);
	public abstract void setBoundVars(java.util.Hashtable h);
	public abstract void setBoundVar(String key, String value);
}
