package org.iccs.san.api;


public interface LoopDecorator extends Decorator {
	public abstract Expression getLoopExpression();
	public abstract void setLoopExpression(Expression expr);
}
