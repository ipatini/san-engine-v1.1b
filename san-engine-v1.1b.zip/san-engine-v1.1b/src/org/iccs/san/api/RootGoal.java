package org.iccs.san.api;


public interface RootGoal extends Goal {		// MARKS a TOP-LEVEL-SAN root goal
	public static final int EXEC_DEFAULT = 0;
	public static final int EXEC_PERSISTENT = 0;
	public static final int EXEC_ONCE = 1;
	
	public abstract boolean isAutoStart();
	public abstract void setAutoStart(boolean autoStart);
	public abstract boolean getMultipleInstancesAllowed();
	public abstract void setMultipleInstancesAllowed(boolean allow);
	public abstract int getExecMode();
	public abstract void setExecMode(int execMode);
}
