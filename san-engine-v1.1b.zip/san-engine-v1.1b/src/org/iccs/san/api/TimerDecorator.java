package org.iccs.san.api;


public interface TimerDecorator extends Decorator {
	public abstract long getTimeout();
	public abstract int getReturnCode();
	public abstract void setTimeout(long msec);
	public abstract void setReturnCode(int returnCode);
}
