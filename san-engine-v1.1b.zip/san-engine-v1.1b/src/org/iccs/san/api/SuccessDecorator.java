package org.iccs.san.api;


public interface SuccessDecorator extends Decorator {
}
