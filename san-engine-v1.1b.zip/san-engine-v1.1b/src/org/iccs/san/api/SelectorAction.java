package org.iccs.san.api;


public interface SelectorAction extends CompositeAction {
	public static final int ORDER_UNSPECIFIED = 0;
	public static final int ORDER_SEQUENTIAL = 1;
	public static final int ORDER_RANDOM = 2;
	public static final int ORDER_PROBABLISTIC = 3;

	public abstract int getSelectionMethod();
	public abstract void setSelectionMethod(int method);
}
