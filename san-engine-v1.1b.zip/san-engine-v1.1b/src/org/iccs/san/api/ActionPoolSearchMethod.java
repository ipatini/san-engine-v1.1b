package org.iccs.san.api;

import org.iccs.san.context.Context;
import java.util.Iterator;

public interface ActionPoolSearchMethod {
	public abstract Iterator<Result> searchAndOrderJobs(ActionPool actionPool, Context localContext, SANObject caller);
	
	public static interface Result {
		public abstract SANNode getJob();
		public abstract int getRank();
		public abstract double getRelevance();
		public abstract String getDescription();
	}
}
