package org.iccs.san.api;


public interface ConditionDecorator extends Decorator {
	public abstract Expression getCondition();
	public abstract void setCondition(Expression expr);
}
