package org.iccs.san.api;


public interface SequenceAction extends CompositeAction {
}
