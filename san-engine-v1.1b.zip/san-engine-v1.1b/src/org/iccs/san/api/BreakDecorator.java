package org.iccs.san.api;


public interface BreakDecorator extends Decorator {
	public abstract String getMessage();
	public abstract void setMessage(String message);
}
