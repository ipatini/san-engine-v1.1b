package org.iccs.san.api;


public interface Action extends SANNode {
	public abstract Expression getExpression();
	public abstract void setExpression(Expression expr);
}
