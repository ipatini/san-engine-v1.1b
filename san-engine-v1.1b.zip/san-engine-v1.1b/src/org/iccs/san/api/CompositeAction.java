package org.iccs.san.api;


public interface CompositeAction extends Action {
	public abstract SANNode[] getJobs();	// Dinei ta jobs me ti seira pou prepei. P.x.
						// gia sequence action:  order
						// gia selector action:  order 'h probability 'h random
						// gia parallel action:  den paizei rolo
	public abstract void setJobs(SANNode[] jobs);
	public abstract void addJob(SANNode job);

// ENALLAKTIKO ACTION API
	public abstract SANNode getFirstJob();
	public abstract void setFirstJob(SANNode firstJob);
}
