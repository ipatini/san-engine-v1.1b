package org.iccs.san.api;


public interface ParallelAnyAction extends CompositeAction {
}
