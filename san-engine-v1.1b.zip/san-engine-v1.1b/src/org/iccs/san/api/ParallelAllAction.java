package org.iccs.san.api;


public interface ParallelAllAction extends CompositeAction {
}
