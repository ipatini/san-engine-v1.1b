package org.iccs.san.api;

import org.iccs.san.api.SANNode;
import org.iccs.san.cep.Event;

public interface Manager {
	public abstract void notify(String src, String dest, String type, String mesg);
	public abstract void notifyNodeStart(SANNode node, String mesg);
	public abstract void notifyNodeEnd(SANNode node, String mesg);
	public abstract void notifyEventSend(Event event, String mesg);
	public abstract void notifyEventReceive(Event event, String mesg);
}
