package org.iccs.san.api;


public interface MountAction extends Action {
	public abstract String getReferencedSAN();
	public abstract void setReferencedSAN(String rootGoal);
}
