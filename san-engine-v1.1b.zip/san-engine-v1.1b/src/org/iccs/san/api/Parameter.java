package org.iccs.san.api;


public interface Parameter extends SANObject {
	public abstract String getSource();
	public abstract void setSource(String source);
}
