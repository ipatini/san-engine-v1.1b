package org.iccs.san.api;


public interface Goal extends SANNode {
	public abstract Situation getSituation();
	public abstract ContextCondition getContextCondition();
	public abstract SANNode getJob();	// JOB: ennoei Goal, Decorator 'h Action

	public abstract void setSituation(Situation s);
	public abstract void setContextCondition(ContextCondition cc);
	public abstract void setJob(SANNode job);
	
	public abstract void stopGoal();
}
