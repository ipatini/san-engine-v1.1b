package org.iccs.san.api;

import org.iccs.san.context.contextualizer.Contextualizer;

public interface Situation extends SANNode {
	public static enum Policy {
		UNDEFINED, CONTINUE_ON_EVENT, CONTINUE_ON_CONTEXT_CHANGE
	};

	public abstract CEPAT getCEPAT();
	public abstract void setCEPAT(CEPAT c);
	public abstract Contextualizer.Descriptor getContextualizerDescriptor(Contextualizer ctxlzr);
	public abstract Policy getPolicy();
}
