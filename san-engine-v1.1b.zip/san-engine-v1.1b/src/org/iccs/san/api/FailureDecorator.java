package org.iccs.san.api;


public interface FailureDecorator extends Decorator {
}
