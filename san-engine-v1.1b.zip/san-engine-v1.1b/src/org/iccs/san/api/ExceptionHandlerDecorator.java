package org.iccs.san.api;


public interface ExceptionHandlerDecorator extends Decorator {
	public abstract String getExceptionType();
	public abstract SANNode getFailoverJob();

	public abstract void setExceptionType(String exceptionType);
	public abstract void setFailoverJob(SANNode failoverJob);
}
