package org.iccs.san.api;

import org.iccs.san.util.Metadata;
import java.util.Iterator;

public interface SANObject {
	public abstract String getName();
	public abstract String getObjectURI();
	public abstract String getType();

	public abstract void setName(String name);
	public abstract void setObjectURI(String uri);
	public abstract void setType(String type);
	
	public abstract String getProperty(String key);
	public abstract void setProperty(String key, String value);
	
	public abstract Metadata<?> addMetadata(Metadata<?> meta);
	public abstract Metadata<?> replaceMetadata(Metadata<?> metaOld, Metadata<?> metaNew);
	public abstract Metadata<?> replaceMetadata(String metaOldName, Metadata<?> metaNew);
	public abstract Metadata<?> removeMetadata(Metadata<?> meta);
	public abstract Metadata<?> removeMetadata(String metaName);
	public abstract Metadata<?> getMetadata(String metaName);
	public abstract Iterator<Metadata<?>> getAllMetadata();
	
	public abstract void attachObject(String name, Object object);
	public abstract Object detachObject(String name);
	public abstract Object retrieveObject(String name);
	public abstract Iterator<String> getObjectNames();
}
