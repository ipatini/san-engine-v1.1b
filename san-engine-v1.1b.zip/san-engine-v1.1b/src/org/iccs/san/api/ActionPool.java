package org.iccs.san.api;


public interface ActionPool extends SANObject {
	public abstract SANNode[] getPoolJobs();
	public abstract void setPoolJobs(SANNode[] jobs);
}
