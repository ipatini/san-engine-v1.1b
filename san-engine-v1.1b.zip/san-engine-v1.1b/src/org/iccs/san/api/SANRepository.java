package org.iccs.san.api;

import org.iccs.san.util.Configurator;
import java.util.Properties;

public interface SANRepository {
/*	public abstract SANEntity[] getAllEntities();
	public abstract SANObject[] getAllObjects();
	
	public abstract SANEntity getEntity(String entityURI);
	public abstract SANEntity getEntityByName(String name);
	public abstract SANObject getSANObject(String objectURI);
	public abstract SANObject getSANObjectByName(String name);
*/
	public abstract SANEntity[] getAutoStartEntities();
	public abstract SANEntity getEntity(String entityURI);
	public abstract SANEntity[] getEntityByName(String name);
	public abstract RootGoal[] getEntityRootGoals(String entityURI);
	
	public abstract SANObject[] getAllObjects();
	
	public abstract Goal getSAN(String objectURI);
	public abstract SANObject getSANObject(String objectURI);
	public abstract Goal getSANByName(String name);
	public abstract SANObject[] getSANObjectByName(String name);
	
	public abstract String getSource();
	public abstract void setSource(String source);
	public abstract void addSource(String source);
	
	public abstract String getRepositoryContents();
	public abstract String getRepositoryContents(Object format);
	public abstract Object[] getRepositoryFormats();
	
	public abstract Configurator getConfigurator();
	public abstract void setConfigurator(Configurator configurator);
}
