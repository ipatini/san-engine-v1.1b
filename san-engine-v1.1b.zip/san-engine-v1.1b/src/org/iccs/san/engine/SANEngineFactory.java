package org.iccs.san.engine;

import org.iccs.san.api.SANEngine;
import org.iccs.san.util.Configurator;

/**
 *	The SAN Execution Engine Factory
 */
public class SANEngineFactory {
	public static SANEngine getInstance(Configurator configurator) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		String className = configurator.configuration.getProperty("engine.class");
		SANEngine engine = getInstance(className);
		engine.setConfigurator(configurator);
		return engine;
	}
	
	public static SANEngine getInstance(String className) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		return (SANEngine)Class.forName(className).newInstance();
	}
}
