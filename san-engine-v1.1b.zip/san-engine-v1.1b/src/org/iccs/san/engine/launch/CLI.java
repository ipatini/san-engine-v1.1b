package org.iccs.san.engine.launch;

import org.iccs.san.api.SANEngine;
import org.iccs.san.api.SANEntity;
import org.iccs.san.api.CEPAT;
import org.iccs.san.cep.CEPEngine;
import org.iccs.san.cep.ReplayCapable;
import org.iccs.san.cep.SimpleEvent;
import org.iccs.san.context.Context;
import org.iccs.san.util.Configurator;
import org.iccs.san.util.DateParser;
import org.iccs.san.util.SANHelper;
import org.iccs.san.util.SANThread;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Date;
import java.util.Enumeration;
import java.util.Properties;
import java.util.UUID;
import javax.xml.namespace.QName;

/**
 *	The command-line entry-point to SAN Engine
 */
public class CLI {
	protected static String version = "v1.1, with DSB support";
	protected static String dates = "Jun 2011-Apr 2012";
	protected static String banner = "SAN Engine "+version+", "+dates+"\n"+
									 "(C) 2011-2012, Institute of Communication and Computer Systems (ICCS)\n"+
									 "Visit us at: http://imu.ntua.gr/\n";
	protected static TelnetServer telnet;
	
	public static void main(String[] args) throws Exception {
		Date dt;
		out().println(banner);
		out().println((dt=new Date())+" ("+dt.getTime()+")\n");
		
		// Load configuration
		String configFile = null;
		for (int i=0; i<args.length; i++) {
			if (args[i].trim().toLowerCase().equals("-config") && i<args.length-1) {
				configFile = args[i+1].trim();
				args[i] = args[i+1] = "";
			}
		}
		
		while (runEngine(configFile, args)) out().println("\nRestarting engine...\n");
		
		// Shutdown telnet server if active
		if (telnet!=null) {
			telnet.stop();
			telnet = null;
		}
		
		out().println("\n"+(dt=new Date())+" ("+dt.getTime()+")");
		out().println("\nBye");
		
		// Necessary to terminate system, because Jetty & WS threads do not exit
		System.exit(0);
	}
	
	protected static String[] defaultConfigFile = { "configuration.txt", "config"+System.getProperty("file.separator")+"configuration.txt" };
	protected static InputStream in() { return System.in; }
	protected static PrintStream out() { return System.out; }
	protected static PrintStream err() { return System.err; }
	
	protected static boolean runEngine(String configFile, String[] args) throws Exception {
		boolean reload = false;
		
		Configurator config = null;
		
		// Create SAN engine
		SANEngine engine;
		CEPEngine cep;
		try {
			// Initialize configurator
			config = new Configurator();
			if (configFile!=null) {
				// User have specified a config file
				config.initialize(configFile, args);
			} else {
				// Try default config file locations if user have not provided one
				for (int i=0; i<defaultConfigFile.length; i++) {
					try {
						config.initialize(defaultConfigFile[i], args);
						configFile = defaultConfigFile[i];
						break;
					} catch (Exception ex) { configFile = null; }
				}
			}
			if (configFile!=null) {
				out().println("Configuration:      "+configFile);
			} else {
				err().println("Configuration file not found. Exiting...");
				return false;
			}
			
			// Initialize Telnet server if configured
			if (config.getBoolean("telnet.enable", false)) {
				if (telnet==null) {
					telnet = new TelnetServer(config);
					telnet.start();
				} else {
					telnet.setConfigurator(config);
				}
			} else {
				if (telnet!=null) {
					telnet.stop();
					telnet = null;
				}
			}
			
			// Print config information
			engine = config.engine;
			cep = config.cep;
			out().println("Using Engine:       "+engine.getClass().getName());
			out().println("Using Repository:   "+config.repository.getClass().getName());
			out().println("Repository source:  "+config.repository.getSource());
			out().println("CEP Engine intf:    "+cep.getClass().getName());
			if (telnet!=null) 
				out().println("Telnet on port:     "+telnet.getPort());
			out().println();
		} catch (Exception ex) {
			err().println("Could not read configuration file. Reason:\n  "+ex.getMessage());
			return false;
		}
		
		// Run designated CEP & SAN engine
		try {
			out().println("\nStarting CEP engine...");
			cep.startEngine();
			out().println("\nStarting SAN engine...");
			engine.startExecution();
			out().println("\nEngines started");
			out().println();
		} catch (Exception ex) {
			//err().println( ex.getMessage() );
			//return ;
			throw ex;
		}
		
		// Offer a prompt and wait for user commands ('quit' and 'creating-event-file' commands are currently supported)
		Thread.sleep(500);
		boolean dontLoop = false;
		if (cep instanceof ReplayCapable && ((ReplayCapable)cep).isReplaying() && ((ReplayCapable)cep).isBatchReplay()) {
			while ( ((ReplayCapable)cep).hasNextEvent() ) {
				try { Thread.currentThread().sleep(100); }
				catch (InterruptedException ex) { break; }
			}
			if (((ReplayCapable)cep).exitAfterReplay()) dontLoop = true;
		}
		
		// Get repository formats (used in printHelp)
		Object[] repositoryFormats = config.repository.getRepositoryFormats();
		
		long cliDelay = 0;
		try {
			if (config.get("cli.delay")!=null && !config.get("cli.delay").trim().equals("")) {
				cliDelay = Long.parseLong(config.get("cli.delay"));
				if (cliDelay<0) cliDelay = 0;
			}
		} catch (Exception e) {}
		java.util.Scanner scan = null;
		if (!dontLoop)
		do {
			try { Thread.sleep(cliDelay); } catch (InterruptedException e) {}
			
			out().print("Write 'quit' to exit or '?' for more commands  : ");
			out().flush();
			if (scan==null) scan = new java.util.Scanner(in());
			String line = scan.nextLine().trim();
			String[] part = line.split("[ \t]");
			String cmd = part[0].trim().toLowerCase();
			if (cmd.equals("")) continue;
			else if (cmd.equals("quit") || cmd.equals("q")) break;
			else if (cmd.equals("context") || cmd.equals("x")) dumpContexts(engine, part);
			else if (cmd.equals("continue") || cmd.equals("c")) engine.resume();
			else if (cmd.equals("help") || cmd.equals("?")) printHelp(repositoryFormats);
			else if (cmd.equals("reload") || cmd.equals("r")) { reload = true; break; }
			else if (cmd.equals("cepats") || cmd.equals("p")) listCEPATs(config.cep);
			else if (cmd.equals("source") || cmd.equals("s")) { changeSource(args); reload = true; break; }
			else if (cmd.equals("load") || cmd.equals("l")) { addSource(config); }
			else if (cmd.equals("dump") || cmd.equals("d")) {
				if (part.length>1) dumpRepository(config, part[1].trim());
				else dumpRepository(config, "N3");
			}
			
			// send event using the underlaying CEP engine abstraction layer
			else if (cmd.equals("event") || cmd.equals("e")) {
				try {
					boolean showUsage = false;
					part = line.split("[ \t]+", 6);
					if (part.length==6) {
						String id = part[1];
						String source = part[2];
						String namespaceURI = part[3];
						String localPart = part[4];
						String prefix = "s";
						String content = part[5];
						QName topic = new QName(namespaceURI, localPart, prefix);
						
						// Get a unique event id (GUID) if requested
						if (id.equalsIgnoreCase("GUID")) id = UUID.randomUUID().toString();
						
						// If content specifies a file name then load content from file
						if (content.trim().startsWith("@")) {
							String fname = content.trim().substring(1).trim();
							try {
								content = SANHelper.loadFile(fname);
								content = content.replace("%ID%", id.replace("-","_"));
								content = content.replace("%TIMESTAMP_UTC%", DateParser.formatW3CDateTime(new Date()));
								content = content.replace("%TIMESTAMP_NUM%", Long.toString(System.currentTimeMillis()));
							} catch (Exception e) {
								err().println("Error while reading event payload file '"+fname+"' : "+e);
								content = null;
							}
						}
						
						if (content!=null) {
							SimpleEvent event = new SimpleEvent(id, source, topic, content);
							out().println("Publishing event (Id: "+id+")...");
							boolean r = config.cep.sendEvent(event);
							if (r) out().println("Event publishing... SUCCESSFULL");
							else out().println("Event publishing... FAILED");
						}
					} else
					if (part.length==2) {
						String param = part[1].trim().toUpperCase();
						if (param.equals("ON")) { cep.setOnline(true); out().println("CEP engine status set to ON"); }
						else if (param.equals("OFF")) { cep.setOnline(false); out().println("CEP engine status set to OFF"); }
						else if (param.equals("STATUS")) { String stat = cep.isOnline() ? "ON" : "OFF"; out().println("CEP engine status: "+stat); }
						else showUsage = true;
					} else {
						showUsage = true;
					}
					if (showUsage) {
						out().println("Usage:  event <ID> <SOURCE> <EVENT-TYPE> <TOPIC> [<EVENT-CONTENT> | @<FILE-NAME>]");
						out().println("  or  event <ID> <SOURCE> <TOPIC-NS> <TOPIC-ID> [<EVENT-CONTENT> | @<FILE-NAME>]");
						out().println("  or  event [on|off|status]");
						out().println("Instead of <ID> you may use \"GUID\" option to generate a globally unique GUID");
						out().println("EVENT-CONTENT can be read from a file, specified after a @");
					}
				} catch (Exception e) {
					err().println("CLI: An error occurred while sending event");
					e.printStackTrace(err());
				}
			}
			// list entities
			else if (cmd.equals("entities") || cmd.equals("n")) listEntities(engine);
			// replay next event
			else if (cmd.equals("next") || cmd.equals(".")) {
				if (cep instanceof ReplayCapable) {
					ReplayCapable replay = (ReplayCapable)cep;
					if (replay.isReplaying() && !replay.isBatchReplay()) {
						if (replay.hasNextEvent()) {
							boolean moreEventsExist = replay.replayNextEvent();
							if (!moreEventsExist) out().println("CEP engine: no more events to replay");
							if (replay.exitAfterReplay() && !moreEventsExist) break;
						} else {
							out().println("CEP engine: no next event to replay");
							if (replay.exitAfterReplay()) break;
						}
					} else {
						out().println("CEP engine is not replaying or is replaying in batch mode");
					}
				} else {
					out().println("CEP engine cannot replay events");
				}
			}
		} while (true);
		
		// Terminate SAN engine execution
		out().println("\nExiting SAN Engine...");
		engine.stopExecution();
		out().println("\nExiting CEP Engine...");
		cep.stopEngine();
		out().println("\nEngines stopped");
		
		// Ask user if he wants to see the context
/*		out().print("\nDo you want to see contexts? [y/n]: ");
		if ((new java.util.Scanner(in())).nextLine().trim().equalsIgnoreCase("y")) {
			dumpContexts(engine);
		}*/
		
		return reload;		// if 'true' the engine will be restarted (with the same command-line arguments) and reload configuration
	}
	
	protected static void dumpContexts(SANEngine engine, String[] p_param) {
		int cntNonBlank = 0;
		for (int i=0; i<p_param.length; i++) if (!p_param[i].trim().equals("")) cntNonBlank++;
		String[] param = new String[cntNonBlank];
		for (int i=0, j=0; i<p_param.length; i++) if (!p_param[i].trim().equals("")) param[j++] = p_param[i].trim();
		
		if (param.length<2) {
			out().println( );
			out().println( "*********  Dumping Contexts  *********\n" );
			out().print( engine.getGlobalContext() );
			out().println( "*********   End of Dumping   *********\n" );
			return;
		} else
		if (param[1].trim().equalsIgnoreCase("list") && param.length>2) {
			param[2] = param[2].trim();
			if (param[2].equalsIgnoreCase("entities")) {
				out().println( "\n*********  Dumping Entity Contexts IDs  *********" );
				Enumeration en = engine.getGlobalContext().entityContextsIds();
				while (en.hasMoreElements()) {
					String uri = (String)en.nextElement();
					out().println("\t"+uri);
				}
				out().println( "*********   End of Dumping   *********\n" );
				return;
			} else 
			if (param[2].equalsIgnoreCase("locals")) {
				out().println( "\n*********  Dumping Local Contexts IDs  *********" );
				Enumeration en = engine.getGlobalContext().localContextsIds();
				while (en.hasMoreElements()) {
					String uri = (String)en.nextElement();
					out().println("\t"+uri);
				}
				out().println( "*********   End of Dumping   *********\n" );
				return;
			} else {
				out().println("Invalid option '"+param[2]+"' for LIST");
			}
		} else
		if (param.length==2 && !param[1].trim().equals("")) {
			out().println( "*********  Dumping Context  *********\n" );
			String uri = param[1].trim();
			if (uri.equalsIgnoreCase("global")) {
				out().println( engine.getGlobalContext().toString(false) );
			} else {
				Context c = engine.getGlobalContext().getEntityContext(uri);
				if (c==null) c = engine.getGlobalContext().getLocalContext(uri);
				if (c!=null) {
					out().println( c.toString(false) );
				} else {
					out().println( "Context NOT FOUND: "+uri);
				}
			}
			out().println( "*********   End of Dumping   *********\n" );
			return;
		}
		// Wrong command usage
		out().println("Wrong usage of 'context' command.");
		out().println("To get a list with the entity or local contexts URIs, give:");
		out().println("\tcontext list <entities or locals>");
		out().println("To see the contents of a single context use");
		out().println("\tcontext <URI or global>");
	}
	
	protected static void printHelp(Object[] repositoryFormats) {
		out().println("\n  ***  SAN engine CLI commands  ***\n\n"+
				"  (x)  context   Prints current context(s) values\n"+
				"                 Usage: context                prints values of ALL contexts\n"+
				"                        context <URI>          prints values of referred context\n"+
				"                        context global         prints values of Global context\n"+
				"                        context list entities  lists all entity context URIs\n"+
				"                        context list locals    lists all local context URIs\n"+
				"  (p)  cepats    Lists the deployed CEPATs with status info\n"+
				"  (c)  continue  Resumes SAN execution after a BREAK decorator\n"+
				"  (?)  help      This help screen\n"+
				"  (q)  quit      Exits SAN engine\n"+
				"  (r)  reload    Reloads config by restarting engine. Contexts are preserved\n"+
				"  (s)  source    Changes source file and restarts engine.Contexts are preserved\n"+
				"  (l)  load      Loads an additional source file. No engine restart occurs\n"+
				"  (d)  dump      Dump current repository contents\n"+
				"                 Usage: dump           prints contents in the default format\n"+
				"                        dump <format>  prints contents in the specified format\n");
		
		// print supported repository formats
		if (repositoryFormats!=null && repositoryFormats.length>0) {
			out().println(
				"                 For current repository valid formats are:"
			);
			for (int i=0; i<repositoryFormats.length; i++) {
				out().println(
				"                    - "+repositoryFormats[i]
				);
			}
		}
		
		out().println(
				"  (e)  event     Publishes an event, using the underlying CEP engine facility\n"+
				"                 Usage: event <ID> <NAMESPACE> <TOPIC> <PREFIX> <EVENT_CONTENT>\n"+
				"                  -if DummyCEPEngine: Writes an event file in 'locks' directory\n"+
				"                  -if DsbCEPEngine: Publishes an event to DSB\n"+
				"       OR        Queries/sets the online status of CEP engine\n"+
				"                 Usage: event [on|off|status]\n"+
				"  (n)  entities  Lists the active entities in SAN engine\n"+
				"  (.)  next      Replay next event, if replaying is configured in manual mode\n"+
				"\n");
	}
	
	protected static void listCEPATs(CEPEngine cep) {
		out().println("\n  ***  Deployed CEPATs  *** \n");
		CEPAT[] cepat = cep.getDeployedCEPAT();
		int cnt = 0;
		if (cepat!=null) {
			cnt = cepat.length;
			out().println( "Num CEPAT name                                 CEPAT URI" );
			out().println( "-------------------------------------------------------------------------------" );
			for (int i=0; i<cnt; i++) {
				Properties prop = cep.getCEPATStatus(cepat[i]);
				String uri = prop.getProperty("uri");
				String lock = prop.getProperty("lock-file");
				String cepat_name = prop.getProperty("cepat-name");
				String cepat_uri = prop.getProperty("cepat-uri");
				String lockThread = prop.getProperty("lock-thread");
				lock = lock!=null ? lock : "";
				cepat_name = cepat_name!=null ? cepat_name : "";
				lockThread = lockThread!=null ? lockThread : "";
				out().println( String.format("%2d. %s %s", i+1, cepat_name, uri) );
				
				// Print waiting threads per CEPAT
				SANThread[] waitingThread = cep.getCEPATWaitingThreads(cepat[i]);
				if (waitingThread!=null && waitingThread.length>0) {
					out().println( "    Thread                                Lock file" );
					out().println( "    -----------------------------------------------------------------------" );
					for (int j=0; j<waitingThread.length; j++) {
						String threadName = waitingThread[j].toString();
						String threadLock = waitingThread[j].lock;
						String threadStatus = waitingThread[j].isAlive() ? "ALIVE" : waitingThread[j].interrupted() ? "INTERRUPTED" : "ENDED";
						Context ctx = waitingThread[j].context;
						out().println( String.format("    %s [%s]\t%s  ", threadName, threadStatus, threadLock) );
						out().println( "      "+ctx.getURI() );
					}
				} else {
					out().println("\n\tINTERNAL ERROR: No waiting threads on this CEPAT.\n");
				}
				
				out().println();
			}
		}
		out().println("  ***  "+cnt+" CEPATs are deployed ***\n");
	}
	
	protected static void changeSource(String[] args) {
		out().print("Source file: ");
		out().flush();
		java.util.Scanner scan = new java.util.Scanner(in());
		String src = scan.nextLine().trim();
		for (int i=0; i<args.length; i++) {
			if (args[i].equalsIgnoreCase("-source")) {
				args[i+1] = src;
				break;
			}
		}
	}
	
	protected static void addSource(Configurator config) {
		out().print("Add source file: ");
		out().flush();
		java.util.Scanner scan = new java.util.Scanner(in());
		String src = scan.nextLine().trim();
		try {
			//out().println("Loading additional SAN source from "+src+"...");
			config.repository.addSource(src);
			//out().println("Loading additional SAN source from "+src+"... Done");
		} catch (Exception e) {
			err().println("Loading additional SAN source from "+src+"... Failed");
			err().println("Reason: "+e);
			e.printStackTrace(err());
		}
	}
	
	protected static void dumpRepository(Configurator config, String format) {
		try {
			out().println("Current SAN repository contents");
			out().println("-------------------------------------------------------------------------------");
			out().println( config.repository.getRepositoryContents(format) );
			out().println("-------------------------------------------------------------------------------");
		} catch (Exception e) {
			err().println("Could not dump SAN repository contents");
			e.printStackTrace(err());
		}
	}
	
	protected static void listEntities(SANEngine engine) {
		Enumeration<SANEntity> en = engine.getEntities();
		int i = 0;
		out().println( "  Num Entity     URI                                      Status" );
		out().println( "  -------------------------------------------------------------------------" );
		while (en.hasMoreElements()) {
			i++;
			SANEntity entity = en.nextElement();
			out().println( String.format("  %2d. %-10s %-40s %s", i, entity.getName(), entity.getObjectURI(), "NOT IMPLEMENTED") );
		}
		if (i==0) out().println( "  No entities exist" );
		out().println();
	}
}
