package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import org.iccs.san.util.SANThread;


public abstract class NaiveEngineSANNode extends NaiveEngineSANObject {
	public static final int UNSPECIFIED = SANNode.UNSPECIFIED;
	public static final int SUCCESS = SANNode.SUCCESS;
	public static final int FAILURE = SANNode.FAILURE;
	public static final int ERROR = SANNode.ERROR;
	public static final int EXCEPTION = SANNode.EXCEPTION;
	public static final int BREAK = 5;
	public static final int RUNNING_JOB = 6;
	public static final int CHECKING_CONTEXT_CONDITION = 7;
	public static final int WAITING_FOR_SITUATION = 8;
	public static final int NOT_STARTED = 9;
	
	protected static final String[] returnCodeDescr =	{
															"UNSPECIFIED STATE",
															"SUCCESS",
															"FAILURE",
															"ERROR",
															"EXCEPTION",
															"BREAK",
															"RUNNING JOB",
															"CHECKING CONTEXT CONDITION",
															"WAITING FOR SITUATION EVENT",
															"NOT YET STARTED"
														};
	
	protected int returnCode;
	
	public NaiveEngineSANNode(SANNode node, NaiveEngineSANObject parent) {
		super(node, parent);
		if (SANThread.current()!=null) SANThread.current().node = node;
	}
	
	public int getReturnCode() { return this.returnCode; }

// XXX - TODO	
	public int execute() throws InterruptedException { return this.returnCode; }		// Used in Goal, Action and Decorator nodes
	
	public static NaiveEngineSANNode getInstance(SANNode job, NaiveEngineSANObject parent) {
		NaiveEngineSANNode newNode;
		if (job instanceof Goal) {
			newNode = new NaiveEngineGoal((Goal)job, parent);
		} else
		if (job instanceof Action) {
			if (job instanceof PrimitiveAction) {
				newNode = new NaiveEnginePrimitiveAction((Action)job, parent);
			} else if (job instanceof MountAction) {
				newNode = new NaiveEngineMountAction((Action)job, parent);
			} else if (job instanceof AbstractAction) {
				newNode = new NaiveEngineAbstractAction((Action)job, parent);
			} else if (job instanceof ParallelAllAction) {
				newNode = new NaiveEngineParallelAllAction((Action)job, parent);
			} else if (job instanceof ParallelAnyAction) {
				newNode = new NaiveEngineParallelAnyAction((Action)job, parent);
			} else if (job instanceof ParallelTimeoutAction) {
				newNode = new NaiveEngineParallelTimeoutAction((Action)job, parent);
			} else if (job instanceof SelectorAction) {
				newNode = new NaiveEngineSelectorAction((Action)job, parent);
			} else if (job instanceof SequenceAction) {
				newNode = new NaiveEngineSequenceAction((Action)job, parent);
			} else if (job instanceof CalculationAction) {
				newNode = new NaiveEngineCalculationAction((Action)job, parent);
			} else {
				throw new RuntimeException("NaiveEngineSANNode: getInstance:  INVALID Action type : "+job.getClass().getName());
			}
		} else
		if (job instanceof Decorator) {
			if (job instanceof LoopDecorator) {
				newNode = new NaiveEngineLoopDecorator((Decorator)job, parent);
			} else if (job instanceof CounterDecorator) {
				newNode = new NaiveEngineCounterDecorator((Decorator)job, parent);
			} else if (job instanceof TimerDecorator) {
				newNode = new NaiveEngineTimerDecorator((Decorator)job, parent);
			} else if (job instanceof BreakDecorator) {
				newNode = new NaiveEngineBreakDecorator((Decorator)job, parent);
			} else if (job instanceof PrintDecorator) {
				newNode = new NaiveEnginePrintDecorator((Decorator)job, parent);
			} else if (job instanceof SuccessDecorator) {
				newNode = new NaiveEngineSuccessDecorator((Decorator)job, parent);
			} else if (job instanceof FailureDecorator) {
				newNode = new NaiveEngineFailureDecorator((Decorator)job, parent);
			} else if (job instanceof NotDecorator) {
				newNode = new NaiveEngineNotDecorator((Decorator)job, parent);
			} else if (job instanceof ExceptionHandlerDecorator) {
				newNode = new NaiveEngineExceptionHandlerDecorator((Decorator)job, parent);
			} else if (job instanceof ConditionDecorator) {
				newNode = new NaiveEngineConditionDecorator((Decorator)job, parent);
			} else {
				throw new RuntimeException("NaiveEngineSANNode: getInstance:  INVALID Decorator type : "+job.getClass().getName());
			}
		} else {
			throw new RuntimeException("NaiveEngineSANNode: getInstance:  INVALID SANNode type : "+job.getClass().getName());
		}
		return newNode;
	}
	
	public static String getReturnCodeString(int code) {
		int rc = code;
		if (rc<0 || rc>8) throw new IllegalArgumentException("NaiveEngineSANNode: getReturnCodeString:  Invalid Return Code : "+code);
		return returnCodeDescr[rc];
	}
}
