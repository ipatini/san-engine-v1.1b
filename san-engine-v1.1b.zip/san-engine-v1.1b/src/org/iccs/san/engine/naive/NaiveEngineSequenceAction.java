package org.iccs.san.engine.naive;

import org.iccs.san.api.*;


public class NaiveEngineSequenceAction extends NaiveEngineCompositeAction {
	public NaiveEngineSequenceAction(Action action, NaiveEngineSANObject parent) {
		super(action, parent);
	}
	
	public int execute() throws InterruptedException {
		logInfo("Executing SEQUENCE ACTION ...");
		SANNode job = ((CompositeAction)action).getFirstJob();
		int rc = FAILURE;
		if (job==null) {
			logError("No jobs were found");
			return rc;
		}
		
		int i=0;
		while (job!=null) {
			logInfo("....Starting child action #"+(i+1)+" :");
			NaiveEngineSANNode node = NaiveEngineSANNode.getInstance((SANNode)job, this);
			rc = node.execute();
			logInfo("....Child action #"+(i+1)+" ended with return code : "+getReturnCodeString(rc));
			if (rc!=SUCCESS) break;
			job = job.getNextJob();
			i++;
		}
		return rc;
	}
}
