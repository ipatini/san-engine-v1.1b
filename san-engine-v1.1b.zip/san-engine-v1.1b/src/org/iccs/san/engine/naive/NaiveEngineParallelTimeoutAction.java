package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import org.iccs.san.util.SANThread;
import org.iccs.san.util.SANThreadFactory;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;
import java.util.concurrent.*;

public class NaiveEngineParallelTimeoutAction extends NaiveEngineCompositeAction {
	public NaiveEngineParallelTimeoutAction(Action action, NaiveEngineSANObject parent) {
		super(action, parent);
	}
	
	public int execute() throws InterruptedException {
		SANNode[] jobs = getCompositeActionJobs((CompositeAction)action);
		int rc = FAILURE;
		if (jobs==null) return rc;
		
		long timeout = ((ParallelTimeoutAction)action).getTimeout();
		if (timeout<=0) {
			throw new RuntimeException("NaiveEngineParallelTimeoutAction: execute: Timeout is zero or negative: "+timeout);
		}
		
		ExecutorService es = Executors.newCachedThreadPool(new SANThreadFactory<ExecutionContext>());
		ExecutorCompletionService<ParallelActionCallable> ecs = new ExecutorCompletionService<ParallelActionCallable>(es);
		
		logInfo("Executing PARALLEL TIMEOUT ACTION with '"+jobs.length+"' child jobs and timeout limit "+((double)timeout/1000d)+" secs");
		Vector<Future<ParallelActionCallable>> task = new Vector<Future<ParallelActionCallable>>();
		for (int i=0; i<jobs.length; i++) {
			logInfo("....Starting child action #"+(i+1)+" : "+jobs[i].getName());
			NaiveEngineSANNode node;
			task.add( ecs.submit(new ParallelActionCallable(node = NaiveEngineSANNode.getInstance(jobs[i], this), jobs[i])) );
		}
		
		Timer timer = new Timer("PARALLEL TIMEOUT with timeout "+timeout+" millis", true);
		TimerTask timerTask = new ParallelTimeoutTask(this, SANThread.current());
		timer.schedule(timerTask, timeout);
		int succJobs = 0;
		int failJobs = 0;
		
		logInfo("\nWaiting for jobs to end or reach timeout limit...\n");
		try {
			for (int i=0; i<jobs.length; i++) {
				try {
					Future<ParallelActionCallable> finishedTask = ecs.take();
					ParallelActionCallable pca = (ParallelActionCallable)finishedTask.get();
					NaiveEngineSANNode node = pca.getNode();
					int rc2 = pca.getReturnCode();
					logInfo("....Child action '"+node.getName()+"' ended with return code : "+getReturnCodeString(rc2));
					if (rc2==SUCCESS) {
						succJobs++;
					} else 
					if (rc2==FAILURE) {
						failJobs++;
					}
				} catch (ExecutionException ex) {
					logInfo("NaiveEngineParallelTimeoutAction: execute: A job raised an Exception. Stopping the remaining jobs...");
					logError(ex);
					if (timer!=null) timer.cancel();
					for (Future<ParallelActionCallable> t : task) {
						t.cancel(true);
					}
					es.shutdown();
					logInfo("Done");
					return EXCEPTION;
				}
			}
		} catch (InterruptedException ex) {
			rc = returnCode;
			if (timer!=null) timer.cancel();
			logInfo("PARALLEL TIMEOUT interrupted because timeout period expired");
			
			// Stop running jobs
			for (Future<ParallelActionCallable> t : task) {
				t.cancel(true);
			}
			es.shutdown();
			logInfo("Done");
		}
		
		if (timer!=null) timer.cancel();
		es.shutdown();
		
		rc = (succJobs>0) ? SUCCESS : FAILURE;
		logInfo("PARALLEL TIMEOUT : "+succJobs+" jobs succedded and "+failJobs+" jobs failed");
		logInfo("PARALLEL TIMEOUT returns : "+getReturnCodeString(rc));
		return rc;
	}
	
	protected static class ParallelTimeoutTask extends TimerTask {
		protected NaiveEngineParallelTimeoutAction action;
		protected Thread thread;
		
		public ParallelTimeoutTask(NaiveEngineParallelTimeoutAction action, Thread thread) {
			this.action = action;
			this.thread = thread;
		}
		
		public void run() {
			this.thread.interrupt();
		}
	}
}
