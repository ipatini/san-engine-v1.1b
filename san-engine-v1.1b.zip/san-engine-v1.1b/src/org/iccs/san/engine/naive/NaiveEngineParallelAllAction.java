package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import org.iccs.san.util.SANThreadFactory;
import java.util.Vector;
import java.util.concurrent.*;

public class NaiveEngineParallelAllAction extends NaiveEngineCompositeAction {
	public NaiveEngineParallelAllAction(Action action, NaiveEngineSANObject parent) {
		super(action, parent);
	}
	
	public int execute() throws InterruptedException {
		SANNode[] jobs = getCompositeActionJobs((CompositeAction)action);
		int rc = FAILURE;
		if (jobs==null) return rc;
		
		ExecutorService es = Executors.newCachedThreadPool(new SANThreadFactory<ExecutionContext>());
		ExecutorCompletionService<ParallelActionCallable> ecs = new ExecutorCompletionService<ParallelActionCallable>(es);
		
		logInfo("Executing PARALLEL ALL ACTION with '"+jobs.length+"' child jobs");
		Vector<Future<ParallelActionCallable>> task = new Vector<Future<ParallelActionCallable>>();
		for (int i=0; i<jobs.length; i++) {
			logInfo("....Starting child action #"+(i+1)+" : "+jobs[i].getName());
			NaiveEngineSANNode node;
			task.add( ecs.submit(new ParallelActionCallable(node = NaiveEngineSANNode.getInstance(jobs[i], this), jobs[i])) );
		}
		
		logInfo("\nWaiting for ALL jobs to succeed...\n");
		for (int i=0; i<jobs.length; i++) {
			try {
				Future<ParallelActionCallable> finishedTask = ecs.take();
				ParallelActionCallable pca = (ParallelActionCallable)finishedTask.get();
				NaiveEngineSANNode node = pca.getNode();
				int rc2 = pca.getReturnCode();
				logInfo("....Child action '"+node.getName()+"' ended with return code : "+getReturnCodeString(rc2));
				if (rc2!=SUCCESS) {
					rc = pca.getReturnCode();
					logInfo("PARALLEL ALL Action: A job failed. Stopping the remaining jobs...");
					for (Future<ParallelActionCallable> t : task) {
						t.cancel(true);
					}
					es.shutdown();
					logInfo("Done");
					return rc;
				}
			} catch (ExecutionException ex) {
				logInfo("NaiveEngineParallelAllAction: execute: A job raised an Exception. Stopping the remaining jobs...");
				logError(ex);
				for (Future<ParallelActionCallable> t : task) {
					t.cancel(true);
				}
				es.shutdown();
				logInfo("Done");
				return EXCEPTION;
			}
		}
		es.shutdown();
		return SUCCESS;
	}
}
