package org.iccs.san.engine.naive;

import org.iccs.san.api.*;


public class NaiveEngineLoopDecorator extends NaiveEngineDecorator {
	protected LoopDecorator decorator;
	
	public NaiveEngineLoopDecorator(Decorator decorator, NaiveEngineSANObject parent) {
		super(decorator, parent);
		this.decorator = (LoopDecorator)decorator;
	}
	
	public int execute() throws InterruptedException {
		Expression expr = decorator.getLoopExpression();
		if (expr==null) {	// execute once
			logInfo("LOOP DECORATOR has no Loop Condition. Executing job '"+getJob().getName()+"' only once");
			logInfo("Executing LOOP DECORATOR Job '"+getJob().getName()+"'");
			int rc = super.execute();
			logInfo("LOOP DECORATOR Job ended with : "+getReturnCodeString(rc));
			return rc;
		} else {			// execute in a WHILE-loop
			NaiveEngineExpression expr1 = new NaiveEngineExpression( this, expr );
			if (!expr1.isBoolean()) {
				logError("LOOP DECORATOR has Loop Condition that IS NOT a Boolean Expression : "+expr);
				throw new RuntimeException("NaiveEngineLoopDecorator: execute: Loop Condition MUST BE a Boolean Expression");
			}
			
			logInfo("LOOP DECORATOR has a valid Loop Condition. Executing job '"+getJob().getName()+"' in a WHILE-loop");
			int rc = SUCCESS;
			int cnt = 1;
			while (((Boolean)expr1.evaluate()).booleanValue()) {
				logInfo("Executing LOOP DECORATOR Job '"+getJob().getName()+"', iteration "+cnt);
				rc = super.execute();
				logInfo("LOOP DECORATOR Job iteration "+cnt+" ended with : "+getReturnCodeString(rc));
				cnt++;
				if (rc!=SUCCESS) {
					logInfo("Exiting loop because the return code is not SUCCESS");
					return rc;
				}
			}
			logInfo("Exiting loop because Loop Condition was evaluated to FALSE");
			return rc;
		}
	}
}
