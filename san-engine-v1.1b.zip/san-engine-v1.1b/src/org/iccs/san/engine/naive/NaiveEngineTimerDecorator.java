package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import java.util.Timer;
import java.util.TimerTask;

public class NaiveEngineTimerDecorator extends NaiveEngineDecorator {
	protected TimerDecorator decorator;
	
	public NaiveEngineTimerDecorator(Decorator decorator, NaiveEngineSANObject parent) {
		super(decorator, parent);
		this.decorator = (TimerDecorator)decorator;
	}
	
	public int execute() throws InterruptedException {
		long timeout = decorator.getTimeout();
		int returnCode = decorator.getReturnCode();
		Timer timer = null;
		logInfo("Executing TIMER DECORATOR Job '"+getJob().getName()+"'");
		if (timeout>0) {
			logInfo("TIMER DECORATOR starts timer for "+timeout+" millis. On timeout returns "+getReturnCodeString(returnCode));
			timer = new Timer("TIMER DECORATOR for Job '"+getJob().getName()+"' with timeout "+timeout+" millis", true);
			TimerTask timerTask = new TimerDecoratorTask(this, Thread.currentThread());
			timer.schedule(timerTask, timeout);
		} else {
			logInfo("TIMER DECORATOR timer is disabled  (zero or negative timeout)");
		}
		int rc;
		try {
			rc = super.execute();
			if (timer!=null) timer.cancel();
			logInfo("TIMER DECORATOR Job ended in-time with : "+getReturnCodeString(rc));
		} catch (InterruptedException ex) {
			rc = returnCode;
			if (timer!=null) timer.cancel();
			logInfo("TIMER DECORATOR Job interrupted because timeout period expired");
			logInfo("TIMER DECORATOR returns : "+getReturnCodeString(rc));
		}
		return rc;
	}
	
	protected static class TimerDecoratorTask extends TimerTask {
		protected NaiveEngineTimerDecorator deco;
		protected Thread thread;
		
		public TimerDecoratorTask(NaiveEngineTimerDecorator deco, Thread thread) {
			this.deco = deco;
			this.thread = thread;
		}
		
		public void run() {
			this.thread.interrupt();
		}
	}
}
