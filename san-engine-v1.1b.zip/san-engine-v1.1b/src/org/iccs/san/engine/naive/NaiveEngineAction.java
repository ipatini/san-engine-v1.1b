package org.iccs.san.engine.naive;

import org.iccs.san.api.*;


public class NaiveEngineAction extends NaiveEngineSANNode {
	public static final int NOT_STARTED = 0;
	public static final int STARTED = 1;
	public static final int ENDED = 2;
	
	protected Action action;
	protected int status;
	
	public NaiveEngineAction(Action action, NaiveEngineSANObject parent) {
		super(action, parent);
		this.action = action;
		this.status = 0;
	}
}
