package org.iccs.san.engine.naive;

import org.iccs.san.api.*;


public class NaiveEngineSuccessDecorator extends NaiveEngineDecorator {
	public NaiveEngineSuccessDecorator(Decorator decorator, NaiveEngineSANObject parent) {
		super(decorator, parent);
	}
	
	public int execute() throws InterruptedException {
		logInfo("Executing SUCCESS DECORATOR Job '"+getJob().getName()+"'");
		int rc = super.execute();
		logInfo("SUCCESS DECORATOR Job ended with : "+getReturnCodeString(rc));
		return SUCCESS;
	}
}
