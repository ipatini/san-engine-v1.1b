package org.iccs.san.engine.naive;

import org.iccs.san.api.*;

public class NaiveEngineConditionDecorator extends NaiveEngineDecorator {
	protected ConditionDecorator decorator;
	
	public NaiveEngineConditionDecorator(Decorator decorator, NaiveEngineSANObject parent) {
		super(decorator, parent);
		this.decorator = (ConditionDecorator)decorator;
	}
	
	public int execute() throws InterruptedException {
		Expression condition = decorator.getCondition();
		boolean result;
		int rc;
		if (condition==null) {	// return true
			logInfo("CONDITION DECORATOR has no Condition. Assuming condition as TRUE");
			result = true;
		} else {				// evaluate expression
			NaiveEngineExpression expr = new NaiveEngineExpression( this, condition );
			if (!expr.isBoolean()) {
				logError("CONDITION DECORATOR has Condition that IS NOT a Boolean Expression : "+condition);
				throw new RuntimeException("NaiveEngineConditionDecorator: execute: Condition MUST BE a Boolean Expression");
			}
			
			result = ((Boolean)expr.evaluate()).booleanValue();
			logInfo("CONDITION DECORATOR has a valid Condition that evaluates to '"+result+"'");
		}
		
		if (result) {
			logInfo("Executing CONDITION DECORATOR Job '"+getJob().getName()+"'");
			rc = super.execute();
			logInfo("CONDITION DECORATOR Job ended with : "+getReturnCodeString(rc));
			return rc;
		} else {
			logInfo("CONDITION DECORATOR Job is NOT executed");
			return FAILURE;
		}
	}
}
