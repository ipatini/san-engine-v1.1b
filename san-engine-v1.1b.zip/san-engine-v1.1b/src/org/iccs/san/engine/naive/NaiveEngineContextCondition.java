package org.iccs.san.engine.naive;

import org.iccs.san.api.*;


public class NaiveEngineContextCondition extends NaiveEngineSANNode {
	protected ContextCondition contextCondition;
	protected NaiveEngineExpression expression;
	
	public NaiveEngineContextCondition(ContextCondition contextCondition, NaiveEngineSANObject parent) {
		super(contextCondition, parent);
		this.contextCondition = contextCondition;
	}
	
	protected NaiveEngineExpression getExpression() { return this.expression; }
	
	protected void setExpression(Expression expression) {
		this.expression = new NaiveEngineExpression( this, expression );
	}
	
	public boolean checkCondition() {
		logInfo("Checking context-condifiton '"+contextCondition.getName()+"' : ");
		setExpression( contextCondition.getExpression() );
/*		if (this.expression.isBoolean()) {
			boolean rr = ((Boolean)(this.expression.evaluate())).booleanValue();
			logInfo(Boolean.toString(rr));
			return rr;
		} else {
			throw new RuntimeException("Non-Boolean Expression in Context Condition");
		}*/
		Object result = this.expression.evaluate();
		if (result!=null) {
			Class clss = result.getClass();
			if (clss.equals(Boolean.class) || clss.equals(boolean.class)) {
				boolean rr = ((Boolean)result).booleanValue();
				logInfo(Boolean.toString(rr));
				return rr;
			} else {
				throw new RuntimeException("Expression evaluated to a Non-Boolean ("+clss.getName()+") in Context Condition: "+clss.getName()+": "+result+"\nEXPRESSION DEFINITION: "+this.expression.getExpression().getDefinition());
			}
		} else {
			throw new RuntimeException("Expression evaluated to NULL in Context Condition");
		}
	}
}
