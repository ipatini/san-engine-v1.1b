package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import java.util.Vector;

public class NaiveEngineCompositeAction extends NaiveEngineAction {
	public NaiveEngineCompositeAction(Action action, NaiveEngineSANObject parent) {
		super(action, parent);
	}
	
	public SANNode[] getCompositeActionJobs(CompositeAction action) {
/*		SANNode job = action.getFirstJob();
		if (job==null) return null;
		
		Vector<SANNode> tmp = new Vector<SANNode>();
		while (job!=null) {
			tmp.add(job);
			job = job.getNextJob();
		}
		SANNode[] arr = new SANNode[tmp.size()];
		return tmp.toArray(arr);*/
		return action.getJobs();
	}
}
