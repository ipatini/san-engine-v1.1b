package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import org.iccs.san.util.*;
import org.iccs.san.context.Context;
import org.iccs.san.util.Metadata;
import org.iccs.san.util.SANThread;
import java.util.Iterator;

public class NaiveEngineSANObject implements SANObject {
	protected SANObject object;
	protected NaiveEngineSANObject parent;
	
	public NaiveEngineSANObject(SANObject object, NaiveEngineSANObject parent) {
		this.object = object;
		this.parent = parent;
		
		// load additional resources if required
		if (!(object instanceof NaiveEngineSANObject)) {
			Metadata meta = this.object.getMetadata("load-resource");
			if (meta!=null && object!=null) {
				Object value = meta.getValue( SANThread.current().context );
				if (value!=null) {
					String resource = value.toString();
					if (!resource.trim().equals("")) {
						SANThread.current().getOut().println( getClass().getName()+": NaiveEngineSANObject<super>: "+
								"Object '"+object.getClass().getName()+"' require loading of resource '"+resource+"'");
						SANThread.current().configurator.repository.addSource(resource);
					}
				}
			}
		}
	}
	
	public NaiveEngineSANObject getParent() { return parent; }
	public SANObject getSANObject() { return object; }
	
	public String getName() { return object.getName(); }
	public String getObjectURI() { return object.getObjectURI(); }
	public String getType() { return object.getType(); }
	
	public void setName(String name) { throw new RuntimeException("NaiveEngineSANObject: setName: It is not allowed to change object name using this method. Use repository object's setter methods instead"); }
	public void setObjectURI(String uri) { throw new RuntimeException("NaiveEngineSANObject: setObjectURI: It is not allowed to change object URI using this method. Use repository object's setter methods instead"); }
	public void setType(String type) { throw new RuntimeException("NaiveEngineSANObject: setType: It is not allowed to change object type using this method. Use repository object's setter methods instead"); }

	public String getProperty(String key) { return object.getProperty(key); }
	public void setProperty(String key, String value) { throw new RuntimeException("NaiveEngineSANObject: setProperty: It is not allowed to change object properties using this method. Use repository object's setter methods instead"); }
	
	// Provided in order to comply to interface SANObject
	public Metadata<?> addMetadata(Metadata<?> meta) { throw new RuntimeException(getClass().getName()+": METADATA methods are not implemented in NaiveEngine classes"); }
	public Metadata<?> replaceMetadata(Metadata<?> metaOld, Metadata<?> metaNew) { throw new RuntimeException(getClass().getName()+": METADATA methods are not implemented in NaiveEngine classes"); }
	public Metadata<?> replaceMetadata(String metaOldName, Metadata<?> metaNew) { throw new RuntimeException(getClass().getName()+": METADATA methods are not implemented in NaiveEngine classes"); }
	public Metadata<?> removeMetadata(Metadata<?> meta) { throw new RuntimeException(getClass().getName()+": METADATA methods are not implemented in NaiveEngine classes"); }
	public Metadata<?> removeMetadata(String metaName) { throw new RuntimeException(getClass().getName()+": METADATA methods are not implemented in NaiveEngine classes"); }
	public Metadata<?> getMetadata(String metaName) { throw new RuntimeException(getClass().getName()+": METADATA methods are not implemented in NaiveEngine classes"); }
	public java.util.Iterator<Metadata<?>> getAllMetadata() { throw new RuntimeException(getClass().getName()+": METADATA methods are not implemented in NaiveEngine classes"); }
	
	// Provided in order to comply to interface SANObject
	public void attachObject(String name, Object object) { }
	public Object detachObject(String name) { return null; }
	public Object retrieveObject(String name) { return null; }
	public Iterator<String> getObjectNames() { return null; }
	
	/* Logging methods */
	protected void logInfo() { SANThread.getOut().println(); }
	protected void logInfo(String mesg) { SANThread.getOut().println(mesg); }
	protected void logInfo(Exception ex) { SANThread.getOut().println(ex); }
	protected void logError() { SANThread.getErr().println(""); }
	protected void logError(String mesg) { SANThread.getErr().println(mesg); }
	protected void logError(Exception ex) { ex.printStackTrace(SANThread.getErr()); }
}
