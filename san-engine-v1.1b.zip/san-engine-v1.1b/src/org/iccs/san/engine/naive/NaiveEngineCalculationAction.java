package org.iccs.san.engine.naive;

import org.iccs.san.api.*;


public class NaiveEngineCalculationAction extends NaiveEngineAction {
	public NaiveEngineCalculationAction(Action action, NaiveEngineSANObject parent) {
		super(action, parent);
	}
	
	public void evaluate() {
		logInfo("Calculation Action is being processed...");
		NaiveEngineExpression expr = new NaiveEngineExpression( this, ((CalculationAction)action).getExpression() );
		Object result = expr.evaluate();
		logInfo("Calculation Action expression evaluated to: "+result);
	}
	
	public int execute() throws InterruptedException {
		evaluate();
		return SUCCESS;
	}
}
