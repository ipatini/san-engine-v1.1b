package org.iccs.san.engine.naive;

import org.iccs.san.api.*;


public class NaiveEngineFailureDecorator extends NaiveEngineDecorator {
	public NaiveEngineFailureDecorator(Decorator decorator, NaiveEngineSANObject parent) {
		super(decorator, parent);
	}
	
	public int execute() throws InterruptedException {
		logInfo("Executing FAILURE DECORATOR Job '"+getJob().getName()+"'");
		int rc = super.execute();
		logInfo("FAILURE DECORATOR Job ended with : "+getReturnCodeString(rc));
		return FAILURE;
	}
}
