package org.iccs.san.engine.naive;

import org.iccs.san.util.SANThread;

public class TestExpression {
	public boolean checkSomething() {
		SANThread.getOut().println("***  Test Expression :: checkSomething()  ***");
		SANThread.getOut().println("***  Something was checked and found  OK  ***");
		
		return true;
	}
}
