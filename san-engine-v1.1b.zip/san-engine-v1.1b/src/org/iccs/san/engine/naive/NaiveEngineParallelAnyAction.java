package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import org.iccs.san.util.SANThreadFactory;
import java.util.Vector;
import java.util.concurrent.*;


public class NaiveEngineParallelAnyAction extends NaiveEngineCompositeAction {
	public NaiveEngineParallelAnyAction(Action action, NaiveEngineSANObject parent) {
		super(action, parent);
	}
	
	public int execute() throws InterruptedException {
		SANNode[] jobs = getCompositeActionJobs((CompositeAction)action);
		int rc = FAILURE;
		if (jobs==null) return rc;
		
		ExecutorService es = Executors.newCachedThreadPool(new SANThreadFactory<ExecutionContext>());
		ExecutorCompletionService<ParallelActionCallable> ecs = new ExecutorCompletionService<ParallelActionCallable>(es);
		
		logInfo("Executing PARALLEL ANY ACTION with '"+jobs.length+"' child jobs");
		Vector<Future<ParallelActionCallable>> task = new Vector<Future<ParallelActionCallable>>();
		for (int i=0; i<jobs.length; i++) {
			logInfo("....Starting child action #"+(i+1)+" : "+jobs[i].getName());
			NaiveEngineSANNode node;
			task.add( ecs.submit(new ParallelActionCallable(node = NaiveEngineSANNode.getInstance(jobs[i], this), jobs[i])) );
		}
		
		logInfo("\nWaiting for ANY job to succeed...\n");
		for (int i=0; i<jobs.length; i++) {
			try {
				Future<ParallelActionCallable> finishedTask = ecs.take();
				ParallelActionCallable pca = (ParallelActionCallable)finishedTask.get();
				NaiveEngineSANNode node = pca.getNode();
				rc = pca.getReturnCode();
				logInfo("....Child action '"+node.getName()+"' ended with return code : "+getReturnCodeString(rc));
				if (rc==SUCCESS) {
					logInfo("A job succeeded. Stopping the remaining jobs...");
					for (Future<ParallelActionCallable> t : task) {
						t.cancel(true);
					}
					es.shutdown();
					logInfo("Done");
					return SUCCESS;
				}
			} catch (ExecutionException ex) {
				logInfo("NaiveEngineParallelAnyAction: execute: A job raised an Exception. Continuing with the remaining jobs.");
				logError(ex);
			}
		}
		es.shutdown();
		return FAILURE;
	}
}
