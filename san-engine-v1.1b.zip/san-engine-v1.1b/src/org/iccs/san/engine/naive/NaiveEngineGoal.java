package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import org.iccs.san.context.Context;
import org.iccs.san.util.SANThread;

public class NaiveEngineGoal extends NaiveEngineSANNode implements Runnable {
	protected Goal goal;
	protected NaiveEngineSituation situation;
	protected NaiveEngineContextCondition contextCondition;
	protected NaiveEngineSANNode job;
	protected boolean bypassSituation = false;
	protected boolean stopFlag;
	protected SANThread goalThread;

	public NaiveEngineGoal(Goal goal, NaiveEngineSANObject parent) {
		super(goal, parent);
		this.goal = goal;
		this.returnCode = NOT_STARTED;
		stopFlag = false;
	}
	
	public NaiveEngineGoal(Goal goal, NaiveEngineSANObject parent, boolean bypassSituation) {
		this(goal, parent);
		this.bypassSituation = bypassSituation;
	}
	
	public NaiveEngineSituation getSituation() { if (this.situation==null) setSituation(goal.getSituation()); return this.situation; }
	public NaiveEngineContextCondition getContextCondition() { if (this.contextCondition==null) setContextCondition(goal.getContextCondition()); return this.contextCondition; }
	public NaiveEngineSANNode getJob() { if (this.job==null) setJob(goal.getJob()); return this.job; }		// JOB can be a Goal, a Decorator or an Action

	public void setSituation(Situation situation) { this.situation = new NaiveEngineSituation( situation, this ); }
	public void setContextCondition(ContextCondition contextCondition) { this.contextCondition = new NaiveEngineContextCondition( contextCondition, this ); }
	public void setJob(SANNode job) { this.job = NaiveEngineSANNode.getInstance( job, this ); }
	
	public int execute() throws InterruptedException {
		boolean cc;
		logInfo("Running Goal '"+goal.getName()+"'");
		// executing situation child node (unless bypassSituation is true, i.e. it is Root Goal)
		if (!this.bypassSituation) {
			if (this.situation==null) setSituation(goal.getSituation());
			
			// Wait for event
			this.returnCode = WAITING_FOR_SITUATION;
			this.situation.waitForSituation();
		}
		// executing context condition child node
		if (this.contextCondition==null) setContextCondition(goal.getContextCondition());
		this.returnCode = CHECKING_CONTEXT_CONDITION;
		cc = this.contextCondition.checkCondition();
		if (cc==false) {
			this.returnCode = FAILURE;
			return this.returnCode;
		}
		// executing job child node
		if (this.job==null) setJob(goal.getJob());
		this.returnCode = RUNNING_JOB;
		this.returnCode = this.job.execute();
		logInfo("Goal '"+goal.getName()+"' terminated with '"+getReturnCodeString(returnCode)+"'");
		
		return this.returnCode;
	}
	
	public synchronized void run() {
		Context ctx = SANThread.current().context;
		try {
			goalThread = SANThread.current();
			int rc = execute();
			logInfo("Thread of Root Goal '"+goal.getName()+"' terminated");
			ctx.setItem("Return-Code", getReturnCodeString(rc));
		} catch (InterruptedException ex) {
			if (stopFlag) {
				logError("Goal '"+goal.getName()+"' was stopped");
			} else {
				logError("Thread of Goal '"+goal.getName()+"' was interrupted");
				ctx.setItem("Exception", ex);
				ctx.setItem("Return-Code", "EXCEPTION");
			}
		} finally {
			ctx.setItem("End-Timestamp", new java.util.Date());
		}
	}
	
	public void stopGoal() {
		if (goalThread!=null) {
			stopFlag = true;
			goalThread.interrupt();
			logError("Stop signal was sent to Goal '"+goal.getName()+"'");
		} else {
			logError("Goal '"+goal.getName()+"' cannot be stopped because it has not be started");
		}
	}
}
