package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import org.iccs.san.context.Context;
import org.iccs.san.util.SANThread;
import java.util.*;

public class TestSearchMethod implements ActionPoolSearchMethod {
	public Iterator<Result> searchAndOrderJobs(ActionPool actionPool, Context localContext, SANObject caller) {
		SANNode[] jobs = actionPool.getPoolJobs();
		if (jobs==null || jobs.length==0) return null;
		Result[] result = new Result[ jobs.length ];
		for (int i=0; i<jobs.length; i++) {
			result[i] = new TestResult(jobs[i], i, 0, "0");
		}
		return Arrays.asList(result).iterator();
	}
	
	public static class TestResult implements Result {
		protected SANNode job;
		protected int rank;
		protected double relevance;
		protected String description;
		
		public TestResult(SANNode job, int rank, double rel, String descr) {
			this.job = job;
			this.rank = rank;
			this.relevance = rel;
			this.description = descr;
		}
		
		public SANNode getJob() { return this.job; }
		public int getRank() { return this.rank; }
		public double getRelevance() { return this.relevance; }
		public String getDescription() { return this.description; }
	}
}
