package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import org.iccs.san.cep.CEPEngine;
import org.iccs.san.cep.Event;
import org.iccs.san.util.SANHelper;
import org.iccs.san.util.SANThread;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;

public class NaiveEngineCEPAT extends NaiveEngineSANObject {
	protected CEPAT cepatClass;					// CEPAT class, as returned from SAN repository
	protected NaiveEngineCEPATInstance cepat;	// CEPAT instance. Definition expression is evaluated IMMEDIATELY
	
	public NaiveEngineCEPAT(CEPAT cepatClass, NaiveEngineSANObject parent) {
		super(cepatClass, parent);
		this.cepatClass = cepatClass;
		this.cepat = new NaiveEngineCEPATInstance(cepatClass);
	}
	
	public void deploy() {
		if (isNullCEPAT() || isSpecialCEPAT()) return;
		CEPEngine cep = SANThread.current().configurator.cep;
		cep.deployCEPAT(cepat);
	}
	
	public void undeploy() {
		if (isNullCEPAT() || isSpecialCEPAT()) return;
		CEPEngine cep = SANThread.current().configurator.cep;
		cep.undeployCEPAT(cepat);
	}
	
	public void subscribe() {
		if (isNullCEPAT() || isSpecialCEPAT()) return;
		CEPEngine cep = SANThread.current().configurator.cep;
		cep.registerToCEPAT(cepat);
	}
	
	public void unsubscribe() {
		if (isNullCEPAT() || isSpecialCEPAT()) return;
		CEPEngine cep = SANThread.current().configurator.cep;
		cep.unregisterFromCEPAT(cepat);
	}
	
	protected boolean isSpecialCEPAT() {
		Object v = cepat.getDefinition().getValue();
		if (v==null || v.toString().equals("")) return true;
		if (v.toString().toUpperCase().startsWith("DELAY ")) return true;
		if (v.toString().toUpperCase().startsWith("GUI ")) return true;
		return false;
	}
	
	protected boolean isNullCEPAT() {
		Object v = cepat.getDefinition().getValue();
		if (v==null || v.toString().equals("")) return true;
		return false;
	}
	
	public Event waitForEvent() throws InterruptedException {
		// If NULL CEPAT
		Object v = cepat.getDefinition().getValue();
		if (v==null || v.toString().equals("")) return null;
		// If DELAY CEPAT
		if (v.toString().toUpperCase().startsWith("DELAY ")) {
			String param = v.toString().substring(6);
			int delay = 1000;
			if (param!=null) {
				try {
					delay = Integer.parseInt( param );
				} catch (Exception ex) { }
			}
			Thread.currentThread().sleep(delay);
			return null;
		}
		// If GUI CEPAT
		if (v.toString().toUpperCase().startsWith("GUI ")) {
			String param = v.toString().substring(4);
			param = (param!=null) ? param : "";
			param += "\nClick OK to unblock Situation";
			javax.swing.JOptionPane.showMessageDialog(null, param, "CEPAT: "+cepat.getName(), javax.swing.JOptionPane.QUESTION_MESSAGE);
			return null;
		}
		// Not NULL CEPAT
		CEPEngine cep = SANThread.current().configurator.cep;
		return cep.waitForEvent(cepat);
	}
	
	/*
	 *  CEPAT Instance
	 */
	public static class NaiveEngineCEPATInstance extends org.iccs.san.repository.basic.BasicCEPAT {
		protected CEPAT cepatClass;
		protected Expression expr;
		
		protected static int unique = 0;
		
		public NaiveEngineCEPATInstance(CEPAT cepatClass) {
			this.cepatClass = cepatClass;
			setDefinition( cepatClass.getDefinition() );
			setName( cepatClass.getName()+"#"+(unique) );
			setObjectURI( cepatClass.getObjectURI()+"#"+(unique++) );
			setType( cepatClass.getType() );
		}
		
		public Expression getDefinition() {
			return expr;
		}
		
		public void setDefinition(Expression definition) {
			if (expr!=null) return;
			expr = new org.iccs.san.repository.basic.BasicExpression();
			expr.setDialect( definition.getDialect() );
			expr.setDefinition( definition.getDefinition() );
			if (definition.getParameters()!=null) {
				Iterator<Parameter> it = definition.getParameters();
				while (it.hasNext()) {
					expr.addParameter(it.next());
				}
			}
			Object value = SANThread.current().configurator.engine.evaluateExpression(expr);
			expr.setValue(value);
		}
		
		public String[] getInputEventTypes() { return null; }
		public String[] getOutputEventTypes() { return null; }
		public void setInputEventTypes(String[] types) { }
		public void setOutputEventTypes(String[] types) { }
	}
}
