package org.iccs.san.engine.naive;

import org.iccs.san.context.Context;

abstract class NaiveEngineEvaluator {
	public abstract boolean isBoolean(NaiveEngineSANObject owner, String definition, Context context);
	public abstract Object evaluate(NaiveEngineSANObject owner, String definition, Context context);
}
