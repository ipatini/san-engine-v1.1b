package org.iccs.san.engine.naive;

import org.iccs.san.api.*;


public class NaiveEngineDecorator extends NaiveEngineSANNode {
	protected Decorator decorator;
	protected NaiveEngineSANNode job;	// The job following this decorator
	
	public NaiveEngineDecorator(Decorator decorator, NaiveEngineSANObject parent) {
		super(decorator, parent);
		this.decorator = decorator;
		setDecoratorType( decorator.getType() );
		this.returnCode = NOT_STARTED;
	}
	
	protected String getDecoratorType() { return this.decorator.getDecoratorType(); }
	protected NaiveEngineSANNode getJob() { if (this.job==null) setJob( decorator.getJob() ); return this.job; }
	
	protected void setDecoratorType(String type) { this.decorator.setDecoratorType(type); }
	protected void setJob(SANNode job) { this.job = NaiveEngineSANNode.getInstance( job, this ); }
	
	public int execute() throws InterruptedException {
		// executing job child node
		if (this.job==null) setJob(decorator.getJob());
		this.returnCode = RUNNING_JOB;
		this.returnCode = this.job.execute();
		logInfo("Decorator '"+decorator.getName()+"' job terminated with '"+getReturnCodeString(returnCode)+"'");
		return this.returnCode;
	}
}
