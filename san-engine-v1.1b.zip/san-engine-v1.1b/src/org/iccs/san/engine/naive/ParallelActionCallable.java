package org.iccs.san.engine.naive;

import java.util.concurrent.*;


class ParallelActionCallable extends NaiveEngineSANObject implements Callable<ParallelActionCallable> {
	protected NaiveEngineSANNode node;
	protected int returnCode;
	
	public ParallelActionCallable(NaiveEngineSANNode node) {
		super(node, node.getParent());	//super(null);
		this.node = node;
		this.returnCode = NaiveEngineSANNode.UNSPECIFIED;
	}
	
	public ParallelActionCallable(NaiveEngineSANNode node, org.iccs.san.api.SANNode node1) {
		super(node1, node.getParent());	//super(null);
		this.node = node;
		this.returnCode = NaiveEngineSANNode.UNSPECIFIED;
	}
	
	public ParallelActionCallable call() throws InterruptedException {
		try {
			returnCode = node.execute();
			return this;
		} catch (InterruptedException ex) {
			logInfo("ParallelActionCallable: call: Parallel Action '"+node.getName()+"' was interrupted");
			throw ex;
		}
	}
	
	public NaiveEngineSANNode getNode() { return this.node; }
	
	public int getReturnCode() { return this.returnCode; }
}
