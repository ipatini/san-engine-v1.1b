package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import org.iccs.san.cep.Event;
import org.iccs.san.util.SANThread;

public class NaiveEngineRootSituation extends NaiveEngineSituation {
	protected NaiveEngineRootSituation(Situation situation, NaiveEngineSANObject parent) {
		super(situation, parent);
	}
	
	public void deployCEPAT() {
		logInfo("Root Situation '"+situation.getName()+"' deploys CEPAT");
		if (this.cepat==null) setCEPAT( situation.getCEPAT() );
		
		this.cepat.deploy();
		this.cepat.subscribe();
	}
	
	public void undeployCEPAT() {
		logInfo("Root Situation '"+situation.getName()+"' undeploys CEPAT");
		if (this.cepat==null) setCEPAT( situation.getCEPAT() );
		
		this.cepat.unsubscribe();
		this.cepat.undeploy();
	}
	
	public Event waitForSituation() throws InterruptedException {
		logInfo("Root Situation '"+situation.getName()+"' waits for Event");
		if (this.cepat==null) setCEPAT( situation.getCEPAT() );
		
		return waitAndProcessEvent();
	}
}
