package org.iccs.san.engine.naive;

import org.iccs.san.api.*;


public class NaiveEnginePrintDecorator extends NaiveEngineDecorator {
	protected PrintDecorator decorator;
	
	public NaiveEnginePrintDecorator(Decorator decorator, NaiveEngineSANObject parent) {
		super(decorator, parent);
		this.decorator = (PrintDecorator)decorator;
	}
	
	public int execute() throws InterruptedException {
		String mesg = decorator.getMessage();
		logInfo("*******************************************************");
		logInfo("DEBUG PRINT DECORATOR :   "+mesg);
		logInfo("*******************************************************");
		logInfo("Executing DEBUG PRINT DECORATOR Job '"+getJob().getName()+"'");
		int rc = super.execute();
		logInfo("DEBUG PRINT DECORATOR Job ended with : "+getReturnCodeString(rc));
		return rc;
	}
}
