package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import org.iccs.san.context.Context;
import org.iccs.san.util.SANThread;
import java.util.Iterator;
import java.util.Hashtable;
import java.util.Properties;

public class NaiveEngineExpression extends NaiveEngineSANObject {
	protected static Hashtable<String,NaiveEngineEvaluator> evaluators;
	
	protected Expression expression;
	protected Properties properties;
	protected Context localContext;
	protected NaiveEngineSANObject owner;
	
	public NaiveEngineExpression(NaiveEngineSANObject owner, Expression expression) {
		super(expression, owner);
		this.expression = expression;
		this.properties = new Properties();
		this.localContext = null;
		this.owner = owner;
		
		if (evaluators==null) evaluators = new Hashtable<String,NaiveEngineEvaluator>();
	}
	
	public NaiveEngineExpression(NaiveEngineSANObject owner, Expression expression, Context localContext) {
		this(owner, expression);
		this.localContext = localContext;
	}
	
	public Expression getExpression() {
		return expression;
	}
	
	public String getProperty(String key) { return properties.getProperty(key); }
	public void setProperty(String key, String value) { properties.setProperty(key, value); }
	
	public boolean isBoolean() {
		String dialect = expression.getDialect().trim();
		String definition = expression.getDefinition().trim();
		if (dialect.equals("") || dialect.equalsIgnoreCase("default")) {
			return (definition.equalsIgnoreCase("true") || definition.equalsIgnoreCase("false"));
		} else {
			Context ctx;
			ctx = (localContext!=null) ? localContext : SANThread.current().context;
			return getEvaluator(dialect).isBoolean(owner, definition, ctx);
		}
	}
	
	public Object evaluate() {
		Object val = _evaluate();
		expression.setValue(val);
		return val;
	}
	
	protected Object _evaluate() {
		String dialect = expression.getDialect().trim();
		String definition = expression.getDefinition().trim();
// XXX: USE LOGGER
//		logInfo("\nNaiveEngineExpression: evaluate:  Evaluating '"+dialect+"' expression: "+definition);
		
		if (dialect.equals("") || dialect.equalsIgnoreCase("default")) {
			if (definition.equalsIgnoreCase("true")) {
				return new Boolean(true);
			} else if (definition.equalsIgnoreCase("false")) {
				return new Boolean(false);
			} else {
				// replace placeholders (enclosed in %) with parameter values
				String str = definition;
				String[] part = str.split("%");
				String value = part[0];
				boolean isPlaceholder = true;
				for (int i=1; i<part.length; i++) {
					if (isPlaceholder) {
						if (i+1==part.length) {
							if (str.endsWith("%")) {
								value += getPlaceholderValue(part[i]);
							} else {
								value += "%"+part[i];
							}
						} else {
							value += getPlaceholderValue(part[i]);
						}
					} else {
						value += part[i];
					}
					// flip mode
					isPlaceholder = !isPlaceholder;
				}
/*				for (int i=1; i<part.length; i+=2) {
					if (i+1==part.length) {
						value += "%"+part[i];
					} else
					if (part[i].equals("")) {
						value += "%";
					} else {
						String param = part[i].trim();
						int p = param.indexOf(':');
						String scope;
						if (p>-1) {
							scope = param.substring(0,p).trim().toUpperCase();
							param = param.substring(p+1);
						} else {
							scope = "LOCAL";
						}
						if (!param.trim().equals("")) {
							if (scope.equals("GLOBAL") || scope.equals("ENTITY") ||
								scope.equals("LOCAL") || scope.equals("CONFIG"))
							{
								Context ctx = (localContext!=null) ? localContext : SANThread.current().context;
								if (scope.equals("LOCAL")) { }
								else if (scope.equals("ENTITY")) ctx = ctx.getParentContext();
								else if (scope.equals("GLOBAL")) ctx = ctx.getGlobalContext();
								else ctx = null;
								
								if (ctx!=null) {
									Object v = ctx.getItem(param);
									if (v instanceof Object[] && ((Object[])v).length>0) v = ((Object[])v)[0];
									value += v.toString();
								} else {
									value += SANThread.current().configurator.get(param);
								}
							}
						}
					}
					
					if (i+1<part.length) {
						value += part[i+1];
					}
				}*/
				str = value;
				return str;
			}
		} else {
			Context ctx;
			ctx = SANThread.current().context;
			return getEvaluator(dialect).evaluate(owner, definition, ctx);
		}
	}
	
	protected String getPlaceholderValue(String placeholder) {
		String param = placeholder.trim();
		int p = param.indexOf(':');
		String scope;
		if (p>-1) {
			scope = param.substring(0,p).trim().toUpperCase();
			param = param.substring(p+1);
		} else {
			scope = "LOCAL";
		}
		String value = "%";
		if (!param.trim().equals("")) {
			if (scope.equals("GLOBAL") || scope.equals("ENTITY") ||
				scope.equals("LOCAL") || scope.equals("CONFIG"))
			{
				Context ctx = (localContext!=null) ? localContext : SANThread.current().context;
				if (scope.equals("LOCAL")) { }
				else if (scope.equals("ENTITY")) ctx = ctx.getParentContext();
				else if (scope.equals("GLOBAL")) ctx = ctx.getGlobalContext();
				else ctx = null;
				
				if (ctx!=null) {
					Object v = ctx.getItem(param);
					if (v instanceof Object[] && ((Object[])v).length>0) v = ((Object[])v)[0];
					value = (v!=null) ? v.toString() : "";
				} else {
					value = SANThread.current().configurator.get(param);
				}
			}
		}
		return value;
	}
	
	protected NaiveEngineEvaluator getEvaluator(String dialect) {
		NaiveEngineEvaluator eval = evaluators.get(dialect);
		if (eval==null) {
			try {
				String evalClass = getClass().getPackage().getName()+".NaiveEngine"+dialect+"Evaluator";
				logInfo("NaiveEngineExpression: getEvaluator: Looking for Evaluator for dialect '"+dialect+"'. Trying "+evalClass+"...");
				eval = (NaiveEngineEvaluator)Class.forName(evalClass).newInstance();
				evaluators.put(dialect, eval);
				logInfo("NaiveEngineExpression: getEvaluator: An Evaluator for dialect '"+dialect+"' was found and registered.");
			} catch (Exception ex) {
				logError("NaiveEngineExpression: getEvaluator: Could not find an Evaluator for dialect '"+dialect+"' : "+ex.getMessage());
				throw new RuntimeException(ex);
			}
		}
		return eval;
	}
}
