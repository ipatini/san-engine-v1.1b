package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import org.iccs.san.cep.Event;
import org.iccs.san.cep.SimpleEvent;
import org.iccs.san.context.Context;
import org.iccs.san.context.contextualizer.Contextualizer;
import org.iccs.san.context.contextualizer.ContextualizerFactory;
import org.iccs.san.util.Configurator;
import org.iccs.san.util.SANThread;

public class NaiveEngineSituation extends NaiveEngineSANNode {
	protected Situation situation;
	protected NaiveEngineCEPAT cepat;
	
	protected NaiveEngineSituation(Situation situation, NaiveEngineSANObject parent) {
		super(situation, parent);
		this.situation = situation;
	}
	
	protected NaiveEngineCEPAT getCEPAT() { return this.cepat; }
	protected void setCEPAT(CEPAT cepat) { this.cepat = new NaiveEngineCEPAT( cepat, this ); }
	
	public Event waitForSituation() throws InterruptedException {
		if (this.cepat==null) setCEPAT( situation.getCEPAT() );
		
		long startTime = System.currentTimeMillis();

		logInfo("Situation '"+situation.getName()+"' deploys CEPAT");
		this.cepat.deploy();
		this.cepat.subscribe();
		
		Event evt = null;
		try{
			logInfo("Situation '"+situation.getName()+"' waits for Event");
			evt = waitAndProcessEvent();
		} finally {
			logInfo("Situation '"+situation.getName()+"' undeploys CEPAT");
			this.cepat.unsubscribe();
			this.cepat.undeploy();
			
			long endTime = System.currentTimeMillis();
			long diff = endTime - startTime;
		}
		
		return evt;
	}
	
	protected Event waitAndProcessEvent() throws InterruptedException {
		// check if CEPAT dialect or expression is empty (i.e. NULL Situation)
		if (this.cepat.isNullCEPAT()) {
			return new SimpleEvent(null, null);
		}
		
		// get continuation policy
		Situation.Policy policy = situation.getPolicy();
		if (policy==Situation.Policy.UNDEFINED) policy = Situation.Policy.CONTINUE_ON_EVENT;
		
		while (true) {
			// wait for event
			Event evt = this.cepat.waitForEvent();
			Context ctx = SANThread.current().context;
			
			// check if it is a dummy event signaling a NULL Situation
			if (evt==null || evt.getEventId()==null || evt.getCEPAT()==null) {
				return evt;
			}
			
// XXX: TODO: add event to events history
			//ctx.mergeEvent( evt );
			
			// Contextualize event
			String type = evt.getPayloadType();
			if (type==null || type.trim().equals("")) {
				logError("Contextualization FAILED. Reason: Event payload type is missing or empty");
				if (policy==Situation.Policy.CONTINUE_ON_EVENT) return evt;
				else continue;
			}
			
			Configurator config = SANThread.current().configurator;
			ContextualizerFactory factory = ContextualizerFactory.getContextualizerFactory(config);
			Contextualizer ctxlzr = factory.getContextualizer(type);
			if (ctxlzr==null) {
				logError("Contextualization FAILED. Reason: No contextualizer found for Event payload type: "+type);
				if (policy==Situation.Policy.CONTINUE_ON_EVENT) return evt;
				else continue;
			}
			Contextualizer.Descriptor dscr = situation.getContextualizerDescriptor(ctxlzr);
			ctxlzr.setDescriptor(dscr);
			boolean rr = false;
			if (ctxlzr!=null) rr = ctxlzr.contextualize(evt, ctx);
			if (rr==false && policy!=Situation.Policy.CONTINUE_ON_EVENT) continue;
			
			return evt;
		}
	}
}
