package org.iccs.san.engine.naive;

import org.iccs.san.context.Context;
import org.iccs.san.util.ActionHelper;
import org.iccs.san.util.SANThread;
import org.mozilla.javascript.*;
import java.io.PrintStream;

class NaiveEngineJSEvaluator extends NaiveEngineEvaluator {
	public boolean isBoolean(NaiveEngineSANObject owner, String definition, org.iccs.san.context.Context context) {
		Class rtype = evaluate(owner, definition, context).getClass();
		return rtype.equals(Boolean.class) || rtype.equals(boolean.class);
	}
	
	public Object evaluate(NaiveEngineSANObject owner, String definition, org.iccs.san.context.Context context) {
		org.mozilla.javascript.Context cx = org.mozilla.javascript.Context.enter();
		try {
			// Initialize the standard objects (Object, Function, etc.)
			// This must be done before scripts can be executed. Returns
			// a scope object that we use in later calls.
			Scriptable scope = cx.initStandardObjects();
			
			PrintStream out = SANThread.current().configurator.io.out;
			Object wrappedOut = org.mozilla.javascript.Context.javaToJS(out, scope);
			Object wrappedCtx = org.mozilla.javascript.Context.javaToJS(context, scope);
			Object wrappedUtil = org.mozilla.javascript.Context.javaToJS(ActionHelper.getInstance(), scope);
			Object wrappedOwner = org.mozilla.javascript.Context.javaToJS(owner, scope);
			ScriptableObject.putProperty(scope, "out", wrappedOut);
			ScriptableObject.putProperty(scope, "context", wrappedCtx);
			ScriptableObject.putProperty(scope, "ctx", wrappedCtx);
			ScriptableObject.putProperty(scope, "util", wrappedUtil);
			ScriptableObject.putProperty(scope, "node", wrappedOwner);

			// Now evaluate the string we've colected.
			Object result = cx.evaluateString(scope, definition, "<JS>", 1, null);

			return result;
		} finally {
			org.mozilla.javascript.Context.exit();
		}
	}
}
