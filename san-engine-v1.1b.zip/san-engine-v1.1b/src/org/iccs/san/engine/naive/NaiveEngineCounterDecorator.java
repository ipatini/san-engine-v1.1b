package org.iccs.san.engine.naive;

import org.iccs.san.api.*;
import org.iccs.san.context.Context;
import org.iccs.san.util.SANThread;

public class NaiveEngineCounterDecorator extends NaiveEngineDecorator {
	protected CounterDecorator decorator;
	
	public NaiveEngineCounterDecorator(Decorator decorator, NaiveEngineSANObject parent) {
		super(decorator, parent);
		this.decorator = (CounterDecorator)decorator;
	}
	
	public int execute() throws InterruptedException {
		synchronized (decorator) {
			String varName = decorator.getVariable();
			String[] var = varName.split(":");
			
			String scope = (var.length==1) ? "LOCAL" : var[0].trim();
			scope = (scope.equals("")) ? "LOCAL" : scope;
			scope = scope.toUpperCase();
			String name = (var.length==1) ? var[0].trim() : var[1].trim();
			name = name.toUpperCase();
			
			if (name.equals("")) throw new RuntimeException("NaiveEngineCounterDecorator: execute: Counter Context Variable is empty");
			if (!scope.equals("LOCAL") && !scope.equals("ENTITY") && !scope.equals("GLOBAL")) throw new RuntimeException("NaiveEngineCounterDecorator: execute: Invalid Context Scope '"+scope+"' in Counter Context Variable : "+varName);
			
			Context ctx;
			if (scope.equals("LOCAL")) {
				ctx = SANThread.current().context;
			} else
			if (scope.equals("ENTITY")) {
				ctx = SANThread.current().context.getParentContext();
			} else {
				ctx = SANThread.current().context.getGlobalContext();
			}
			
			if (ctx.getItem(name)==null) {
				ctx.setItem(name, new Integer(decorator.getStartCount()));
				logInfo("COUNTER DECORATOR : counter in '"+varName+"' is set to "+decorator.getStartCount());
			} else {
				int count = ((Integer)ctx.getItem(name)).intValue();
				int step = decorator.getStep();
				logInfo("COUNTER DECORATOR : count in '"+varName+"' changes from "+count+" to "+(count+step));
				count += step;
				ctx.setItem(name, new Integer(count));
			}
		}
		logInfo("Executing COUNTER DECORATOR Job '"+getJob().getName()+"'");
		int rc = super.execute();
		logInfo("COUNTER DECORATOR Job ended with : "+getReturnCodeString(rc));
		return rc;
	}
}
