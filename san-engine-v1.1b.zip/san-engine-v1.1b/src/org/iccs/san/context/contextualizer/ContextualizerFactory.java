package org.iccs.san.context.contextualizer;

import org.iccs.san.util.Configurator;

/**
 *	The Contextualizer Factory
 */
public class ContextualizerFactory {
	protected Configurator configurator;
	
	public static ContextualizerFactory getContextualizerFactory(Configurator configurator) {
		return new ContextualizerFactory(configurator);
	}
	
	protected ContextualizerFactory(Configurator configurator) {
		setConfigurator(configurator);
	}
	
	public Contextualizer getContextualizer(String type) {
		if (type==null || type.trim().equals("")) throw new IllegalArgumentException("Null or empty contextualizer type");
		type = type.toUpperCase();
		
		try {
			String className = configurator.configuration.getProperty("contextualizer."+type+".class");
			if (className==null || className.trim().equals("")) {
				className = this.getClass().getPackage().getName()+"."+type+"Contextualizer";
			}
			Contextualizer ctxlzr = (Contextualizer)Class.forName(className).newInstance();
// XXX: ctxlzr.setConfigurator(configurator.configuration);
			return ctxlzr;
		} catch (ClassNotFoundException ex) {
			return null;
		} catch (InstantiationException ex) {
			throw new RuntimeException(ex);
		} catch (IllegalAccessException ex) {
			throw new RuntimeException(ex);
		}
	}
	
	public Configurator getConfigurator() { return this.configurator; }
	public void setConfigurator(Configurator configurator) { this.configurator = configurator; }
}
