package org.iccs.san.context.contextualizer;

import org.iccs.san.api.Expression;
import org.iccs.san.cep.Event;
import org.iccs.san.context.Context;
import org.iccs.san.util.SANThread;

import java.util.Iterator;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;
import java.io.StringReader;

import com.ebmwebsourcing.easycommons.xml.XMLHelper;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.*;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class XMLContextualizer extends AbstractContextualizer {
	public XMLContextualizer() {
		setType("XML");
	}
	
	@SuppressWarnings("unchecked")
	public boolean contextualize(Event event, Context context) {
		checkType(event);
		
		// Get XML queries used for contextualization
		XMLContextualizer.Descriptor descriptor = (XMLContextualizer.Descriptor)getDescriptor();
		if (descriptor==null) {
			SANThread.getErr().println("XMLContextualizer: contextualize: No XML Contextualizer Descriptor returned from SAN repository");
			return false;
		}
		Query[] queries = descriptor.getQueries();
		if (queries==null || queries.length==0) {
			SANThread.getErr().println("XMLContextualizer: contextualize: No queries found in XML Contextualizer Descriptor returned from SAN repository");
			return false;
		}
		
		// Get event payload
		Object payload = event.getPayload();
		if (payload==null) {
			SANThread.getErr().println("XMLContextualizer: contextualize: Event payload is NULL");
			return false;
		}
		
		// Initialize business message as XML DOM
		Node businessMessage = null;
		if (payload instanceof Node) {
			businessMessage = (Node)payload;
		} else
		if (payload instanceof String) {
			try {
//				businessMessage = XMLHelper.createDocumentFromString((String)payload).getDocumentElement();
				
				DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
				domFactory.setNamespaceAware(true); 
				DocumentBuilder builder = domFactory.newDocumentBuilder();
				Document doc = builder.parse( new InputSource( new StringReader((String)payload) ) );
				businessMessage = doc.getDocumentElement();
			} catch (Exception ex) {
				SANThread.getErr().println("XMLContextualizer: contextualize: Failed to convert Event XML payload from plain XML text into DOMNode. Reason: "+ex);
				ex.printStackTrace(SANThread.getErr());
				SANThread.getErr().println("Event Payload: "+businessMessage);
				return false;
			}
		} else {
			SANThread.getErr().println("XMLContextualizer: contextualize: Cannot handle event payload of type: "+payload.getClass().getName());
			return false;
		}
		
		// Dump event payload XML DOM Node
		SANThread.getOut().println("XMLContextualizer: contextualize: Event XML payload:");
		SANThread.getOut().println("--------------------------------------------------------");
		try {
			String xml = XMLHelper.createStringFromDOMNode(businessMessage);
			SANThread.getOut().println(xml);
		} catch (Exception ex) {
			SANThread.getErr().println("XMLContextualizer: contextualize: Failed to convert Event XML payload from DOMNode into plain XML text. Reason: "+ex);
			ex.printStackTrace(SANThread.getErr());
			SANThread.getErr().println("Event Payload: "+payload);
			return false;
		}
		SANThread.getOut().println("--------------------------------------------------------");
		
		// Check uniqueness constraint (if specified)
// XXX: Not implemented, neither in RDFContextualizer nor in XMLContextualizer
		
		// Run each query and store the resulting name-value pairs in a hashtable
		XPath xpath = XPathFactory.newInstance().newXPath();
		Hashtable<String,Vector<String>> attrib = new Hashtable<String,Vector<String>>();
		boolean rr = false;
		for (Query q : queries) {
			attrib.clear();		// remove previous context elements
			
			// Get query language and definition (as an expression)
			String qryLang = q.getQueryLanguage();
			Expression qryExpr = q.getQueryExpression();
			if (qryLang==null || qryExpr==null) {
				SANThread.getErr().println("XMLContextualizer: contextualize: Query '"+q.getQueryUri()+"' : Missing Query LANGUAGE or Query EXPRESSION in XML contextualizer");
				continue;
			}
			String qs = (String)SANThread.current().configurator.engine.evaluateExpression(qryExpr);
			
			// If it is an XPATH query...
			if (qryLang.equalsIgnoreCase("XPATH") || qryLang.equalsIgnoreCase("X-PATH")) {
				String[] part = qs.split("[=:]", 2);
				if (part.length==1) {
					SANThread.getErr().println("XMLContextualizer: contextualize: Query '"+q.getQueryUri()+"' : Query does not specify context element name or XPath for value retrieval");
					continue;
				}
				
				String name = part[0].trim();
				String xpathQry = part[1].trim();
				SANThread.getOut().println("XMLContextualizer: contextualize: Query '"+q.getQueryUri()+"' : context-element="+name+", XPath="+xpathQry);
				
				try {
					XPathExpression expr = xpath.compile(xpathQry);
					Object result = expr.evaluate(businessMessage, XPathConstants.NODESET);
					if (result==null) {
						SANThread.getErr().println("XMLContextualizer: contextualize: Query '"+q.getQueryUri()+"' : XPath returned no results");
						continue;
					}
					NodeList nodes = (NodeList) result;
					SANThread.getOut().println("XPath query results:");
					// for each node...
					for (int i = 0; i < nodes.getLength(); i++) {
						Vector<String> values = attrib.get(name);
						// ...create a vector to store CE values (in case of multiple results)
						if (values==null) {
							values = new Vector<String>();
							attrib.put(name, values);
						}
						String val = getString( nodes.item(i).getNodeValue() ).trim();
						SANThread.getOut().println("\t"+val);
						values.add(val);
					}
				} catch (XPathExpressionException ex) {
					SANThread.getErr().println("XMLContextualizer: contextualize: Query '"+q.getQueryUri()+"' : Exception during XPath compile or query: "+ex);
					continue;
				}
			} else {
				SANThread.getErr().println("XMLContextualizer: contextualize: Unknown query language '"+qryLang+"' for query");
			}
			
			// Store name-value pairs into context
			Context queryCtx = context;
			String ctx = q.getQueryContext();
			if (ctx==null) {
				ctx = descriptor.getContext();
				if (ctx==null || ctx.trim().equals("")) {
// XXX: TODO:  get default from Config, else use ENTITY
// XXX: TODO:  ADDITIONAL:  check Goal, RootGoal, Entity, Global metadata and/or 'CONTEXT-SCOPE' context item to get target scope
					ctx = "ENTITY";
				} else {
					ctx = ctx.trim().toUpperCase();
					if (!ctx.equals("LOCAL") && !ctx.equals("ENTITY") && !ctx.equals("GLOBAL")) ctx = "ENTITY";
				}
			}
			ctx = ctx.trim().toUpperCase();
			if (ctx.equals("LOCAL")) {
				if (context.isLocalContext()) queryCtx = context;
// XXX: TODO:  find local context from entity context
				else if (context.isEntityContext()) queryCtx = context;
// XXX: TODO:  find local context from global context
				else if (context.isGlobalContext()) queryCtx = context;
			} else if (ctx.equals("ENTITY")) {
				if (context.isLocalContext()) queryCtx = context.getParentContext();
				else if (context.isEntityContext()) queryCtx = context;
// XXX: TODO:  find local context from global context
				else if (context.isGlobalContext()) queryCtx = context;
			} else if (ctx.equals("GLOBAL")) {
				queryCtx = context.getGlobalContext();
			} else {
				throw new RuntimeException("XMLContextualizer: contextualize: Invalid context specification '"+ctx+"' in Query: '"+q.getQueryUri()+"' of XML Contextualizer Description: '"+descriptor.getURI()+"'");
			}
			
			for (Object key : attrib.keySet()) {
				String name = (String)key;
				Vector<String> values = attrib.get(name);
				String[] valArray = values.toArray(new String[values.size()]);
				
				addToContext(queryCtx, name, valArray, event, null);
				rr = true;
			}
		}
		return rr;
	}
	
	public String getString(String str) {
		try {
			if (str.equals("\"\"")) return "";
			String[] part = str.split("\"");
			return (part.length>1) ? part[1] : part[0]; 		// dirty hack to extract literal
																// from "value"^^xsd:string
		} catch (ArrayIndexOutOfBoundsException ex) {
			SANThread.getErr().println("XMLContextualizer: getString: ArrayIndexOutOfBoundsException: Parameter: "+str);
			throw ex;
		}
	}
	
	public static interface Descriptor extends Contextualizer.Descriptor {
		public abstract XMLContextualizer.Query[] getQueries();
	}
	
	public static interface Query {
		public abstract String getQueryUri();
		public abstract String getQueryLanguage();
		public abstract Expression getQueryExpression();
		public abstract String getQueryContext();
	}
}
