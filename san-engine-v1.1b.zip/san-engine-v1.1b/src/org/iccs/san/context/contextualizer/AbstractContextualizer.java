package org.iccs.san.context.contextualizer;

import org.iccs.san.api.Situation;
import org.iccs.san.cep.Event;
import org.iccs.san.context.Context;
import org.iccs.san.util.SANThread;
import java.util.Arrays;

public abstract class AbstractContextualizer implements Contextualizer {
	protected String type;
	protected Contextualizer.Descriptor descriptor;
	protected boolean debugOn;
	
	public String getType() { return type; }
	public void setType(String type) { this.type = type; }
	public abstract boolean contextualize(Event event, Context context);
	public Contextualizer.Descriptor getDescriptor() { return descriptor; }
	public void setDescriptor(Contextualizer.Descriptor dscr) { this.descriptor = dscr; }
	
	public boolean isDebugOn() { return debugOn; }
	public void setDebugOn(boolean val) { debugOn = val; }
	
	protected void checkType(Event evt) {
		if (evt==null) throw new RuntimeException(this.getClass().getName()+": checkType: Event is NULL");
		String type = evt.getPayloadType();
		if (type==null) throw new RuntimeException(this.getClass().getName()+": checkType: Event payload type is NULL");
		type = type.trim();
		if (!type.equalsIgnoreCase(getType())) throw new RuntimeException(this.getClass().getName()+": checkType: Event payload type ("+type+") does NOT match to this contextualizer's type ("+getType()+")");
	}
	
	protected void addToContext(Context ctx, String key, Object value, Event event, Situation node) {
		String scope;
		if (key.indexOf(":")>-1) {
			String[] p = key.split(":", 2);
			scope = p[0].trim().toUpperCase();
			if (!scope.equals("LOCAL") && !scope.equals("ENTITY") && !scope.equals("GLOBAL")) scope = "ENTITY";
			key = p[1].trim();
		} else {
			scope = ctx.isLocalContext() ? "LOCAL" : (ctx.isEntityContext() ? "ENTITY" : (ctx.isGlobalContext() ? "GLOBAL" : null));
			if (scope==null) throw new RuntimeException(this.getClass().getSimpleName()+": addToContext: Invalid context: "+ctx);
		}
		if (scope.equals("LOCAL")) {
			ctx.setItem(key, value, event, node);
		} else
		if (scope.equals("ENTITY")) {
			if (ctx.isLocalContext()) {
				ctx.getParentContext().setItem(key, value, event, node);
			} else {
				ctx.setItem(key, value, event, node);
			}
		} else
		if (scope.equals("GLOBAL")) {
			ctx.getGlobalContext().setItem(key, value, event, node);
		} else {
			throw new RuntimeException(this.getClass().getSimpleName()+": addToContext: Invalid context scope: "+scope);
		}
		debug(scope, key, value, event, node);
	}
	
	protected void debug(String scope, String key, Object value, Event evt, Situation node) {
		if (!debugOn) return;
		
		String valueStr = value!=null ? (value.getClass().isArray() ? Arrays.toString((Object[])value) : value.toString()) : "null";
		String evtStr = evt!=null ? evt.getEventId() : "null";
		String nodeStr = node!=null ? node.getObjectURI() : "null";
		SANThread.getOut().printf(this.getClass().getSimpleName()+": addToContext: Adding to %s context:\n\t%s = %s,\n\tevent=%s,\n\tnode=%s\n", scope, key, valueStr, evtStr, nodeStr);
	}
}
