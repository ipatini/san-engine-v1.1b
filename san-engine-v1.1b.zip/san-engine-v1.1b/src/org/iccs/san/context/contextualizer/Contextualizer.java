package org.iccs.san.context.contextualizer;

import org.iccs.san.cep.Event;
import org.iccs.san.context.Context;

public interface Contextualizer {
	public abstract String getType();
	public abstract boolean contextualize(Event event, Context context);
	public abstract Contextualizer.Descriptor getDescriptor();
	public abstract void setDescriptor(Contextualizer.Descriptor dscr);
	
	public static interface Descriptor {
		public abstract String getURI();
		public abstract String getContext();
	}
}
