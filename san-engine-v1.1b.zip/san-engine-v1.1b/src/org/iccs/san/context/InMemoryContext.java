package org.iccs.san.context;

import org.iccs.san.api.SANObject;
import org.iccs.san.cep.Event;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Stack;

/**
 *	A context implementation using Hashtable for in-memory context management
 */
public class InMemoryContext implements Context {
	protected static InMemoryContext globalContext;
	protected static Hashtable<String,InMemoryContext> entityContexts;
	protected static Hashtable<String,InMemoryContext> localContexts;
	protected static Properties configuration;
	protected static int uniqueCounter = 0;
	
	protected Hashtable<String,Stack<Record>> context;
	protected boolean isLocal;
	protected String uri;
	protected InMemoryContext parentEntityContext;
	
	public Context getGlobalContext() {
		if (globalContext==null) globalContext = new InMemoryContext();
		return globalContext;
	}
	
	public Context getEntityContext(String entityURI) {
		if (this!=globalContext) throw new RuntimeException("InMemoryContext: getEntityContext: This method can only be called by 'global context' singleton object");
		String key = entityURI.trim().toUpperCase();
		if (key.equals("")) throw new RuntimeException("InMemoryContext: getEntityContext: Argument cannot be empty");
		if (entityContexts==null) entityContexts = new Hashtable<String,InMemoryContext>();
		InMemoryContext c = entityContexts.get(key);
		return c;
	}
	
	public Context createEntityContext(String entityURI) {
		if (this!=globalContext) throw new RuntimeException("InMemoryContext: createEntityContext: This method can only be called by 'global context' singleton object");
		String key = entityURI.trim().toUpperCase();
		if (key.equals("")) throw new RuntimeException("InMemoryContext: createEntityContext: Argument cannot be empty");
		if (entityContexts==null) entityContexts = new Hashtable<String,InMemoryContext>();
		InMemoryContext c = entityContexts.get(key);
		if (c==null) {
			c = new InMemoryContext(false);
			c.uri = key;
			c.setConfiguration(configuration);
			entityContexts.put(key, c);
		}
		return c;
	}
	
	public Context removeEntityContext(String entityURI) {
		if (this!=globalContext) throw new RuntimeException("InMemoryContext: removeEntityContext: This method can only be called by 'global context' singleton object");
		String key = entityURI.trim().toUpperCase();
		if (key.equals("")) throw new RuntimeException("InMemoryContext: removeEntityContext: Argument cannot be empty");
		if (entityContexts==null) entityContexts = new Hashtable<String,InMemoryContext>();
		InMemoryContext c = entityContexts.get(key);
		if (c!=null) {
			entityContexts.remove(key);
		}
		return c;
	}
	
	protected String getUniqueId() {
		return "#"+(new Date()).getTime()+"#"+(uniqueCounter++);
	}
	
	public Context getLocalContext(String localURI) {
		if (this!=globalContext) throw new RuntimeException("InMemoryContext: getLocalContext(<String>): This method can only be called by 'global context' singleton object");
		String key = localURI.trim().toUpperCase();
		if (key.equals("")) throw new RuntimeException("InMemoryContext: getLocalContext(<String>): Argument cannot be empty");
		if (localContexts==null) localContexts = new Hashtable<String,InMemoryContext>();
		InMemoryContext c = localContexts.get(key);
		return c;
	}
	
	public Context createLocalContext(String localURI) {
		if (this.isLocal || this==globalContext) throw new RuntimeException("InMemoryContext: createLocalContext: This method can only be called by 'Entity context' objects");
		String key = localURI;
		if (key==null) {
			key = this.uri+"#"+getUniqueId();
		}
		if (localContexts==null) localContexts = new Hashtable<String,InMemoryContext>();
		InMemoryContext c = new InMemoryContext(true);
		c.uri = key;
		c.parentEntityContext = this;
		c.setConfiguration(configuration);
		localContexts.put(key, c);
		return c;
	}
	
	public Context removeLocalContext(String localURI) {
		if (this.isLocal || this==globalContext) throw new RuntimeException("InMemoryContext: removeLocalContext: This method can only be called by 'Entity context' objects");
		String key = localURI.trim().toUpperCase();
		if (key.equals("")) throw new RuntimeException("InMemoryContext: removeLocalContext: Argument cannot be empty");
		if (localContexts==null) localContexts = new Hashtable<String,InMemoryContext>();
		InMemoryContext c = localContexts.get(key);
		if (c!=null) {
			localContexts.remove(key);
		}
		return c;
	}
	
	public Context getParentContext() {
		if (this==globalContext) return null;
		if (!isLocal) return globalContext;
		return parentEntityContext;
	}
	
	public Enumeration entityContextsIds() {
		return entityContexts.keys();
	}
	
	public Enumeration localContextsIds() {
		return localContexts.keys();
	}
	
	protected InMemoryContext() {
		this(false);
	}
	
	protected InMemoryContext(boolean isLocal) {
		this.context = new Hashtable<String,Stack<Record>>();
		this.isLocal = isLocal;
	}
	
	public Properties getConfiguration() {
		return (Properties)configuration.clone();
	}
	
	public void setConfiguration(Properties props) {
		if (configuration!=null) return;
		configuration = props;
	}
	
	public String getURI() {
		return this.uri;
	}
	
	public boolean isGlobalContext() {
		return (this==globalContext);
	}
	
	public boolean isEntityContext() {
		return (this!=globalContext && !isLocal);
	}
	
	public boolean isLocalContext() {
		return this.isLocal;
	}
	
	public Enumeration getItems() {
		return context.keys();
	}
	
	public Object getItem(String key) {
		Stack<Record> history = context.get(key);
		if (history==null) return null;
		return history.peek().value;
	}
	
	public Object getItem(String key, int pos) {
		Object val = _getItem(key, pos);
		if (val!=null) return val;
		if (this!=globalContext && isLocal) {
			val = ((InMemoryContext)getParentContext())._getItem(key, pos);
			if (val!=null) return val;
		}
		if (this!=globalContext) return globalContext._getItem(key, pos);
		return null;
	}
	
	protected Object _getItem(String key, int pos) {
		Stack<Record> history = context.get(key);
		if (history==null) return null;
		int sz = history.size();
		if (pos>=sz) return null;
		return history.elementAt(sz-pos-1).value;
	}
	
	public Object setItem(String key, Object val) {
		return setItem(key, val, null, null);
	}
	
	public synchronized Object setItem(String key, Object val, Event srcEvent, SANObject srcNode) {
		Record rc = new Record(val, srcEvent, srcNode, new Date());
		Stack<Record> history = context.get(key);
		if (history==null) {
			history = new Stack<Record>();
			context.put(key, history);
		}
		history.push(rc);
		return val;
	}
	
	public synchronized Object removeItem(String key) {
		Stack<Record> history = context.remove(key);
		if (history==null) return null;
		if (history.empty()) return null;
		return history.pop().value;
	}
	
	public boolean mergeEvent(Event evt) {
		String base = "Event."+evt.getSource()+"@"+evt.getEventId()+".";
		setItem(base+"id", evt.getEventId());
		setItem(base+"source", evt.getSource());
		setItem(base+"send-timestamp", evt.getSendTimestamp());
		setItem(base+"receive-timestamp", evt.getReceiveTimestamp());
		setItem(base+"is-complex", Boolean.toString(evt.isComplex()));
		setItem(base+"cepat", (evt.getCEPAT()!=null ? evt.getCEPAT().getName()+" /// "+evt.getCEPAT().getObjectURI() : "null"));
		
		Properties payload = evt.getSemantics();
		Enumeration en = payload.propertyNames();
		while (en.hasMoreElements()) {
			String key = (String)en.nextElement();
			String val = payload.getProperty(key);
			
			setItem(base+key, val);
		}
		
		return true;
	}
	
	public String toString() {
		return toString(true);
	}
	
	public String toString(boolean dumpSubcontexts) {
		StringBuffer sb = dumpContext(null, this);
		if (dumpSubcontexts) {
			if (isGlobalContext()) {
				if (entityContexts!=null)
					for (InMemoryContext ctx : entityContexts.values()) dumpContext(sb, ctx);
				if (localContexts!=null)
					for (InMemoryContext ctx : localContexts.values()) dumpContext(sb, ctx);
			} else
			if (isEntityContext()) {
				if (localContexts!=null)
					for (InMemoryContext ctx : localContexts.values()) dumpContext(sb, ctx);
			}
		}
		return sb.toString();
	}
	
	public static StringBuffer dumpContext(StringBuffer sb, InMemoryContext ctx) {
		if (sb==null) sb = new StringBuffer();
		
		if (ctx==globalContext) sb.append("GLOBAL CONTEXT \n{\n");
		else if (!ctx.isLocalContext()) sb.append("ENTITY CONTEXT ["+ctx.uri+"] \n{\n");
		else sb.append("LOCAL CONTEXT ["+ctx.uri+"]\n  with parent ["+ctx.parentEntityContext.uri+"] \n{\n");
		
		Enumeration<String> en = ctx.context.keys();
		while (en.hasMoreElements()) {
			String key = en.nextElement();
			sb.append("    ");
			sb.append(key);
			sb.append(" = [\n");
			//sb.append(ctx.context.get(key));
			Stack<Record> history = ctx.context.get(key);
			for (int i=0, n=history.size(); i<n; i++) {
				Record rc = history.elementAt(i);
				sb.append("\t");
				sb.append(i); sb.append("\t");
				if (rc.value instanceof Object[]) {
					Object[] arr = (Object[])rc.value;
					boolean first = true;
					sb.append("[");
					for (int j=0; j<arr.length; j++) {
						if (!first) { sb.append(", "); first=false; }
						sb.append(arr[j]);
					}
					sb.append("]");
				} else {
					sb.append(rc.value);
				}
				sb.append("\n\t    ");
				sb.append(rc.timestamp); sb.append("\t");
				sb.append(rc.source); sb.append("\t");
				sb.append(rc.event); sb.append("\n");
			}
			sb.append("    ] // end of "+key+"\n");
		}
		
		sb.append("} // end of context: "+ctx.uri+"\n\n");
		
		return sb;
	}
	
	protected static class Record {
		public Object value;
		public Event event;
		public SANObject source;
		public Date timestamp;
		
		public Record(Object v, Event e, SANObject s, Date tm) {
			this.value = v;
			this.event = e;
			this.source = s;
			this.timestamp = tm;
		}
	}
}
