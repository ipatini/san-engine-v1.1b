package org.iccs.san.io;

import org.iccs.san.util.ActionHelper;
import org.iccs.san.util.Configurator;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

/**
 *  Bundles together input/output/error stream as well as logging functionality
 */
public class FileIOSystem extends IOSystem {
	protected TeeStream tee;
	
	public FileIOSystem(Configurator configurator) throws IOException {
		PrintStream newOut = System.out;
		String fileName = configurator.configuration.getProperty("io-system.file");
		SimpleDateFormat sdf = new SimpleDateFormat(fileName);
		fileName = sdf.format(new Date());
		if (fileName!=null && !fileName.trim().equals("")) {
			newOut = new PrintStream(new FileOutputStream(fileName));
			out.println("FileIOSystem: redirecting output/errors to file: "+fileName);
		}
		out = newOut;
		err = newOut;
		System.setOut(new TeeStream(newOut, System.out));
		System.setErr(new TeeStream(newOut, System.err));
	}
	
	protected class TeeStream extends PrintStream {
		PrintStream out;
		public TeeStream(PrintStream out1, PrintStream out2) {
			super(out1);
			this.out = out2;
		}
		public void write(byte buf[], int off, int len) {
			try {
				super.write(buf, off, len);
				out.write(buf, off, len);
			} catch (Exception e) {
			}
		}
		public void flush() {
			super.flush();
			out.flush();
		}
	}
}
