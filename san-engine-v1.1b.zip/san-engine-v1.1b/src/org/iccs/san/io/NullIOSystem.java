package org.iccs.san.io;

import org.iccs.san.util.Configurator;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

/**
 *  Bundles together input/output/error stream as well as logging functionality
 */
public class NullIOSystem extends IOSystem {
	public NullIOSystem() throws IOException {
		PrintStream newOut = new PrintStream( new java.io.OutputStream() { public void write (int b) { } } );
		out = newOut;
		err = newOut;
		System.setOut(newOut);
		System.setErr(newOut);
	}
}
