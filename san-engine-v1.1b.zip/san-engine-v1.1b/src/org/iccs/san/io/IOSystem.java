package org.iccs.san.io;

import org.iccs.san.util.Configurator;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.IOException;
import java.util.Properties;
import java.lang.reflect.Constructor;

/**
 *  Bundles together input/output/error stream as well as logging functionality
 */
public class IOSystem {
	public InputStream in;
	public PrintStream out;
	public PrintStream err;
	
	public IOSystem() {
		in = System.in;
		out = System.out;
		err = System.err;
	}
	
	public static IOSystem getInstance(Configurator configurator) {
		Properties config = configurator.configuration;
		String clss = config.getProperty("io-system.class");
		if (clss==null || clss.trim().equals("")) {
			System.err.println("IOSystem: getInstance: No IO system specified in configuration ('io-system.class' directive)");
			System.err.println("IOSystem: getInstance: Using standard IO system");
			return new IOSystem();
		}
		try {
			Class c = Class.forName(clss);
			try {
				Constructor cons = c.getDeclaredConstructor(Configurator.class);
				if (cons!=null) return (IOSystem)cons.newInstance(configurator);
			} catch (Exception ex) {
				System.err.println("IOSystem: "+ex);
				ex.printStackTrace(System.err);
			}
			return (IOSystem)c.newInstance();
		} catch (Exception ex) {
			System.err.println("IOSystem: getInstance: Could not load '"+clss+"' IO system : "+ex);
			System.err.println("IOSystem: getInstance: Using standard IO system instead");
			return new IOSystem();
		}
	}
}
