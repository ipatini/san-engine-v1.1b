package org.iccs.san.util;

import java.util.concurrent.*;

/**
 *	An SAN thread factory
 */
public class SANThreadFactory<E> implements ThreadFactory {
	@SuppressWarnings("unchecked")
	public SANThread<E> newThread(Runnable r) {
		SANThread<E> thread = new SANThread<E>(r);
		SANThread<E> curr = (SANThread<E>)SANThread.current();
		if (curr!=null) {
			thread.configurator = curr.configurator;
			thread.data = curr.data;
			thread.context = curr.context;
		}
		return thread;
	}
}
