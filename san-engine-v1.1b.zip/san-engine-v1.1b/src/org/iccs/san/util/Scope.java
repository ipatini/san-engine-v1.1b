package org.iccs.san.util;

import java.util.Enumeration;
import java.util.Hashtable;

/**
 *  Loads and parses configuration settings from properties files
 *  Configuration is a tree-like hierarchy of Hashtables and provides
 *  a mechanism to access the stored values using paths (like folders)
 */
public class Scope extends Hashtable<String,Object> {
	protected String PathDelim = "\\.";
	protected String DefaultLeaf = ".";
	protected boolean overwrite = false;
	protected Scope root;
	
	public static Scope load(String definition) {
		Scope tree = new Scope();
		if (!tree.parse(definition)) return null;
		return tree;
	}
	
	public boolean parse(String definition) {
		return parse(definition, this.overwrite);
	}
	
	public boolean parse(String definition, boolean overwrite) {
		// Split input into separate lines
		String[] line = definition.split("\n");
		for (int i=0, n=line.length; i<n; i++) {
			line[i] = line[i].trim();
			if (line[i].startsWith("#")) line[i] = null;
		}
		
		for (int i=0; i<line.length; i++) {
			int lineNum = i+1;
			if (line[i]==null || line[i].equals("")) continue;	// Skip empty lines
		}
		
		for (int i=0; i<line.length; i++) {
			int lineNum = i+1;
			if (line[i]==null || line[i].equals("")) continue;	// Skip empty lines
			
			// Get 'key' and 'value' parts (i.e. before and after the first occurence of '=')
			int p = line[i].indexOf("=");
			String key, value;
			if (p>=0) {
				key = line[i].substring(0, p).trim();
				value = line[i].substring(p+1).trim();
			} else {
				key = line[i];
				value = "";
			}
			
			// Split key into its path parts ('.' is the default delimeter)
			String[] path = key.trim().toUpperCase().split(PathDelim);
			
			// Follow path in configuration tree and create nodes whenever they don't already exist
			// Path parts are always nodes. The value will be assigned in a leaf with key '.'
			try {
				Scope scope = createScope(this, path, overwrite);
				scope.put(DefaultLeaf, value);
			} catch (RuntimeException ex) {
				throw new RuntimeException(ex.getMessage()+" at line "+line);
			}
		}
		
		return true;
	}
	
	protected Scope createScope(Scope scope, String[] path, boolean overwrite) {
		for (int i=0; i<path.length; i++) {
			// Check path part
			path[i] = path[i].trim();
			if (path[i].equals("")) continue;
			
			// Get scope
			Object tmp = scope.get(path[i]);
			if (tmp!=null) {
				if (tmp instanceof Hashtable || overwrite) {
					scope = (Scope)tmp;
				} else {
					StringBuffer sb = new StringBuffer();
					for (int j=0; j<i; j++) {
						if (path[j].equals("")) continue;
						sb.append(path[j]);
						sb.append(".");
					}
					sb.append(path[i]);
					throw new RuntimeException("Key '"+sb.toString()+"' is already defined and overwrite is not allowed");
				}
			} else {
				// Create scope if it does not already exist
				Scope tmp2 = new Scope();
				scope.put(path[i], tmp2);
				scope = tmp2;
			}
		}
		return scope;
	}
	
	public Scope getScope(String key) {
		Scope scope = this;
		
		// Split path into its parts ('.' is the default delimeter)
		String[] path = key.trim().toUpperCase().split(PathDelim);
		
		for (int i=0; i<path.length; i++) {
			// Check path part
			path[i] = path[i].trim();
			if (path[i].equals("")) continue;
			
			Object tmp = scope.get(path[i]);
			if (tmp==null) return null;
			if (tmp instanceof Hashtable) {
				scope = (Scope)tmp;
			} else {
				throw new RuntimeException("getScope: Invalid node type '"+tmp.getClass().getName()+"' in configuration tree, at #"+(i+1)+" part ("+path[i]+") of path '"+key+"'");
			}
		}
		return scope;
	}
	
	public String getValue(String key) {
		Scope scope = this;
		Scope tmp = scope.getScope(key);
		if (tmp==null) return null;
		return (String)tmp.get(DefaultLeaf);
	}
	
	public String getValue(String key, String defValue) {
		String val = getValue(key);
		return (val!=null) ? val : defValue;
	}
	
	public static String toString(Scope tree) {
		return tree.toString();
	}
	
	public String toString() {
		StringBuffer sb = new StringBuffer("CONFIGURATION-TREE = {\n");
		dumpScope(this, sb, " ", " ");
		sb.append("}");
		return sb.toString();
	}
	
	protected StringBuffer dumpScope(Scope scope, StringBuffer sb, String ident, String identStr) {
		Enumeration<String> en = scope.keys();
		while (en.hasMoreElements()) {
			String key = en.nextElement();
			Object val = scope.get(key);
			sb.append(ident);
			sb.append(key);
			sb.append(" = ");
			if (val instanceof Hashtable) {
				sb.append("{\n");
				dumpScope((Scope)val, sb, ident+identStr, identStr);
				sb.append(ident);
				sb.append("}\n");
			} else {
				sb.append(val);
				sb.append("\n");
			}
		}
		return sb;
	}
}
