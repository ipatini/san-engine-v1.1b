package org.iccs.san.util;

import org.iccs.san.api.Manager;
import org.iccs.san.api.SANEngine;
import org.iccs.san.api.SANRepository;
import org.iccs.san.cep.CEPEngine;
import org.iccs.san.cep.CEPEngineFactory;
import org.iccs.san.context.Context;
import org.iccs.san.context.ContextFactory;
import org.iccs.san.engine.SANEngineFactory;
import org.iccs.san.io.IOSystem;
import org.iccs.san.repository.RepositoryFactory;
import org.iccs.san.util.ActionHelper;
import org.iccs.san.util.SANThread;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;

/**
 *	A class managing all major configuration-dependent system components
 */
public class Configurator {
	public Properties configuration;
	public SANEngine engine;
	public SANRepository repository;
	public Context globalContext;
	public IOSystem io;
	public CEPEngine cep;
	public ActionHelper actionHelper;
	public Manager manager;
	
	public Configurator initialize(String configFile) throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		Properties config = SANHelper.loadConfiguration(configFile);
		return initialize(config, null);
	}
	
	public Configurator initialize(String configFile, String[] args) throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		Properties config = SANHelper.loadConfiguration(configFile, args);
		return initialize(config, args);
	}
	
	public Configurator initialize(Properties config, String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		_processConfigProperties(config, args);
		
		// Get engine IO system and logger
		this.io = IOSystem.getInstance(this);
		
		// initialize SANThread class
		SANThread.defaultConfigurator = this;
		
		// Create a SAN engine instance
		this.engine = SANEngineFactory.getInstance(this);
		this.engine.setConfigurator(this);
		
		// Get a SAN repository instance
		this.repository = RepositoryFactory.getRepository(this);
		this.repository.setConfigurator(this);
		
		// Prepare global context
		this.globalContext = ContextFactory.getContextFactory(this).getGlobalContext();
		
		// Prepare CEP Engine
		this.cep = CEPEngineFactory.getCEPEngineFactory(this).getCEPEngine();
		this.cep.setConfigurator(this);
		
		// Prepare action helper object
		this.actionHelper = new ActionHelper(this);
		ActionHelper.setInstance(this.actionHelper);
		
		return this;
	}
	
	protected void _processConfigProperties(Properties config, String[] args) {
		this.configuration = new Properties();
		Enumeration en = config.propertyNames();
		while (en.hasMoreElements()) {
			String key = (String)en.nextElement();
			String val = config.getProperty(key);
			if (key.trim().startsWith("@")) _processCommand("", (key+" "+val).trim(), args);
			else if (val.trim().startsWith("@")) _processCommand(key.trim(), val.trim(), args);
			else this.configuration.put(key, val);
		}
	}
	
	protected void _processCommand(String scope, String command, String[] args) {
		String[] part = command.split("[ \t]", 2);
		String   cmd = part[0].trim().toLowerCase();
		
		if (cmd.equals("@include")) {
			if (part.length==1) {
				System.err.println("Configurator: _processCommand: Missing argument at @include command at property '"+scope+"'. One properties file should be specified. Ignoring this property.");
			} else {
				String propFile = part[1].trim();
				try {
					System.out.println("Loading file: "+propFile);
					//Properties prop = SANHelper.loadProperties(propFile);
					Properties prop = SANHelper.loadConfiguration(propFile, args);
					if (prop==null) {
						System.err.println("Configurator: _processCommand: Could not load properties file '"+propFile+"' specified at @include command at property '"+scope+"'. Ignoring this property.");
						System.err.println("Reason: properties returned is null");
					} else {
						Enumeration en = prop.propertyNames();
						String base = (scope.equals("")) ? "" : scope+".";
						while (en.hasMoreElements()) {
							String key = (String)en.nextElement();
							String val = prop.getProperty(key);
							this.configuration.put(base+key, val);
						}
					}
				} catch (Exception ex) {
					System.err.println("Configurator: _processCommand: Could not load properties file '"+propFile+"' specified at @include command at property '"+scope+"'. Ignoring this property.");
					System.err.println("Reason: "+ex.getMessage());
				}
			}
		} else {
			System.err.println("Configurator: _processCommand: Unknown command '"+part[0].trim()+"' at property '"+scope+"'. Ignoring this property.");
		}
	}
	
	public String get(String key) {
		return configuration.getProperty(key);
	}
	
	public boolean getBoolean(String key, boolean defValue) {
		String value = get(key);
		return checkBoolean(value, defValue);
	}
	
	public static boolean checkBoolean(String value, boolean defValue) {
		if (value==null || value.trim().equals("")) return defValue;
		value = value.trim().toLowerCase();
		if (value.equals("yes") || value.equals("true") || value.equals("on") || value.equals("1")) return true;
		if (value.equals("no") || value.equals("false") || value.equals("off") || value.equals("0")) return false;
		return defValue;
	}
	
	public Properties getScope(String scope, boolean stripPrefix) {
		scope = (scope==null || scope.trim().equals("")) ? "" : scope.trim();
		scope = scope.endsWith(".") ? scope.substring(0, scope.length()-1) : scope;
		String prefix = scope+".";
		
		Properties prop = new Properties();
		Enumeration en = this.configuration.propertyNames();
		while (en.hasMoreElements()) {
			String key = (String)en.nextElement();
			String val = this.configuration.getProperty(key);
			
			if (key.startsWith(prefix)) {
				if (stripPrefix && !key.equals(prefix)) {
					key = key.substring(prefix.length());
				}
				prop.put(key, val);
			} else
			if (key.equals(scope)) {
				if (stripPrefix) key = "";
				prop.put(key, val);
			}
		}
		return prop;
	}
}
