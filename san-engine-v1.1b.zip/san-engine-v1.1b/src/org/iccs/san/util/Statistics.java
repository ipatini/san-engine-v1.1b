package org.iccs.san.util;

import java.io.IOException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Hashtable;
import java.util.Vector;
import java.text.SimpleDateFormat;

/**
 *  Maintains and prints statistics
 */
public class Statistics {
	public static final int WRITE_ON_CHANGE = 0;
	public static final int WRITE_ON_REQUEST = 1;
	public static final int WRITE_ON_CLOSE = 2;
	
	protected static Statistics	instance;
	protected static Hashtable<String,Statistics> namedInstances;
	
	protected Vector<String> counters;
	protected int[]	counterArr;
	protected boolean includeSystemStats;
	protected PrintWriter	out;
	protected int	writeMode;
	protected SimpleDateFormat dateFmt;
	protected Runtime rt;
	protected boolean active;
	protected long rowCount;
	protected String sep;
	protected int updateFreq;
	protected int updateCnt;
	
	public Statistics() {
		counters = new Vector<String>();
		counterArr = new int[1024];
		includeSystemStats = false;
		out = null;
		writeMode = WRITE_ON_CLOSE;
		dateFmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		active = true;
		rowCount = 0;
		sep = "; ";
		updateFreq = 5;
		updateCnt = 0;
	}
	
	public Statistics(boolean sysStats) {
		this();
		includeSystemStats = sysStats;
		rt = Runtime.getRuntime();
	}
	
	public Statistics(String statFile, int mode, boolean sysStats) throws IOException {
		this(sysStats);
		if (mode!=WRITE_ON_CHANGE && mode!=WRITE_ON_REQUEST && mode!=WRITE_ON_CLOSE) throw new IllegalArgumentException("Statistics: <init>(String,int): Illegal mode argument: "+mode);
		writeMode = mode;
		SimpleDateFormat sdf = new SimpleDateFormat(statFile);
		statFile = sdf.format(new Date());
		out = new PrintWriter(new FileWriter(statFile));
	}
	
	public synchronized void close() {
		if (out!=null) {
			if (writeMode==WRITE_ON_CLOSE) {
				writeStats();
			}
			if (writeMode==WRITE_ON_CHANGE && updateCnt!=0) {
				writeStats();
			}
			out.close();
		}
		
		counters = null;
		counterArr = null;
		includeSystemStats = false;
		out = null;
		writeMode = -1;
		dateFmt = null;
		rt = null;
		active = false;
	}
	
	public static synchronized Statistics getInstance() {
		if (instance!=null) return instance;
		return (instance=new Statistics());
	}
	
	public static synchronized Statistics getInstance(String name) {
		Statistics st = null;
		if (namedInstances==null) {
			namedInstances = new Hashtable<String,Statistics>();
		} else {
			st = namedInstances.get(name);
		}
		if (st==null) {
			st = new Statistics();
			namedInstances.put(name, st);
		}
		return st;
	}
	
	public static synchronized Statistics getInstance(String statFile, int mode, boolean sysStats) throws IOException {
		if (instance!=null) return instance;
		return (instance=new Statistics(statFile, mode, sysStats));
	}
	
	public static synchronized Statistics getInstance(String name, String statFile, int mode, boolean sysStats) throws IOException {
		Statistics st = null;
		if (namedInstances==null) {
			namedInstances = new Hashtable<String,Statistics>();
		} else {
			st = namedInstances.get(name);
		}
		if (st==null) {
			st = new Statistics(statFile, mode, sysStats);
			namedInstances.put(name, st);
		}
		return st;
	}
	
	public synchronized int createCounter(String name) {
		if (counters.contains(name)) throw new RuntimeException("Statistics: createCounter: Counter already exists: "+name);
		if (counters.size()+1==counterArr.length) {
			int[] tmp = new int[ 2*counterArr.length ];
			for (int i=0; i<counterArr.length; i++) tmp[i] = counterArr[i];
			counterArr = tmp;
		}
		counters.add(name);
		int cid = counters.indexOf(name);
		writeHeaders();
		writeStats();
		return cid;
	}
	
	public synchronized int getCounterId(String name) {
		return getCounterId(name, true);
	}
	
	public synchronized int getCounterId(String name, boolean createIfNotExist) {
		int cid = counters.indexOf(name);
		if (cid==-1) {
			if (createIfNotExist) cid = createCounter(name);
		}
		return cid;
	}
	
	public synchronized boolean isActive() { return active; }
	public synchronized void setActive(boolean active) { this.active = active; }
	
	public synchronized int get(int cid) {
		return counterArr[cid];
	}
	
	public synchronized int get(String name) {
		int sid = getCounterId(name, true);
		return get(sid);
	}
	
	public synchronized int set(int cid, int value) {
		int old = counterArr[cid];
		counterArr[cid] = value;
		if (writeMode==WRITE_ON_CHANGE)
			if ((updateCnt++)==updateFreq) writeStats();
		return old;
	}
	
	/*
	 *  Statistics update methods
	 */
	public synchronized int set(String name, int value) {
		int sid = getCounterId(name, true);
		return set(sid, value);
	}
	
	public synchronized int inc(int cid) {
		if (!active) return -1;
		counterArr[cid]++;
		if (writeMode==WRITE_ON_CHANGE) 
			if ((updateCnt++)==updateFreq) writeStats();
		return counterArr[cid];
	}
	
	public synchronized int inc(String name) {
		int sid = getCounterId(name, true);
		return inc(sid);
	}
	
	public synchronized int dec(int cid) {
		if (!active) return -1;
		counterArr[cid]--;
		if (writeMode==WRITE_ON_CHANGE) 
			if ((updateCnt++)==updateFreq) writeStats();
		return counterArr[cid];
	}
	
	public synchronized int dec(String name) {
		int sid = getCounterId(name, true);
		return dec(sid);
	}
	
	public synchronized int add(int cid, int value) {
		if (!active) return -1;
		counterArr[cid] += value;
		if (writeMode==WRITE_ON_CHANGE) 
			if ((updateCnt++)==updateFreq) writeStats();
		return counterArr[cid];
	}
	
	public synchronized int add(String name, int value) {
		int sid = getCounterId(name, true);
		return add(sid, value);
	}
	
	/*
	 *  Statistics write methods
	 */
	public synchronized void writeComment(String str) {
		if (!str.startsWith("#")) str = "# "+str;
		write(str);
	}
	
	public synchronized void write(String str) {
		if (out==null) return;
		out.println(str);
		out.flush();
	}
	
	public synchronized void writeHeaders() {
		if (out==null) return;
		out.print("'Row'");
		out.print(sep);
		out.print("'Date/Time'"); 
		for (int i=0, n=counters.size(); i<n; i++) {
			String name = counters.elementAt(i);
			out.print(sep);
			out.print("'"+name+"'");
		}
		if (includeSystemStats) {
			out.print(sep);
			out.print("'Free Memory'");
			out.print(sep);
			out.print("'Max Memory'");
			out.print(sep);
			out.print("'Total Memory'");
		}
		out.println();
		out.flush();
	}
	
	public synchronized void writeStats() {
		updateCnt = 0;
		if (out==null) return;
		out.print(rowCount++);
		out.print(sep);
		out.print(dateFmt.format(new Date()));
		for (int i=0, n=counters.size(); i<n; i++) {
			out.print(sep);
			out.print(counterArr[i]);
		}
		if (includeSystemStats) {
			out.print(sep);
			out.print(rt.freeMemory());
			out.print(sep);
			out.print(rt.maxMemory());
			out.print(sep);
			out.print(rt.totalMemory());
		}
		out.println();
		out.flush();
	}
}
