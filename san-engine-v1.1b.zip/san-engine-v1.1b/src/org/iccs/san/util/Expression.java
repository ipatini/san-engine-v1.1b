package org.iccs.san.util;

import org.iccs.san.context.Context;

/**
 *  Represents an Expression
 */
public class Expression<E> {
	protected org.iccs.san.api.Expression expression;
	
	public Expression(org.iccs.san.api.Expression expr) {
		expression = expr;
	}
	
	public org.iccs.san.api.Expression getExpression() {
		return expression;
	}
	
	public E evaluate(Context ctx) {
		return (E)SANThread.current().configurator.engine.evaluateExpression(expression, ctx);
	}
}
