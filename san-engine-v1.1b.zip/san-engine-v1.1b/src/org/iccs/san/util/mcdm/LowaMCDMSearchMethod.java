package org.iccs.san.util.mcdm;

import org.iccs.san.api.*;
import org.iccs.san.context.Context;
import org.iccs.san.util.Metadata;
import org.iccs.san.util.SANThread;
import java.util.*;

/**
 *  Implements a LOWA-based Multi-Criteria search and selection algorithm
 *  for Action Pool look-ups
 *
 *  LOWA is a weighted average method for linguistic (ordinal) data
 */
public class LowaMCDMSearchMethod implements ActionPoolSearchMethod {
	@SuppressWarnings("unchecked")
	public Iterator<Result> searchAndOrderJobs(ActionPool actionPool, Context localContext, SANObject caller) {
		// Get Action Pool MCDM criteria
		Metadata mcdmMeta = caller.getMetadata("LOWA CRITERIA");
		String mcdmStr = (mcdmMeta!=null) ? (String)mcdmMeta.getValue(localContext) : null;
		// FOR BACKWARD COMPATIBILITY, check if criteria are defined at Action Pool at MCDM metadata
		if (mcdmStr==null || mcdmStr.trim().equals("")) {
			mcdmMeta = actionPool.getMetadata("MCDM");
			mcdmStr = (mcdmMeta!=null) ? (String)mcdmMeta.getValue(localContext) : null;
		}
		if (mcdmStr==null || mcdmStr.trim().equals("")) return null;
		String[] mcdmCriteria = mcdmStr.split("\\s*[,;]\\s*");
		int nCrit = mcdmCriteria.length;
		Metadata[] apCriteria = new Metadata[nCrit];
		for (int j=0; j<nCrit; j++) {
			mcdmCriteria[j] = mcdmCriteria[j].trim();
			apCriteria[j] = actionPool.getMetadata(mcdmCriteria[j]);
		}
		
		// Get the allowed linguistic values (in order) from Abstract Action
		Metadata metaAllowed = caller.getMetadata("Allowed Values");
		String labelStr = (metaAllowed!=null) ? (String)metaAllowed.getValue(localContext) : null;		// added 'localContext'
		// FOR BACKWARD COMPATIBILITY, check if Allowed Values are defined at Action Pool
		if (labelStr==null || labelStr.trim().equals("")) {
			metaAllowed = actionPool.getMetadata("Allowed Values");
			labelStr = (metaAllowed!=null) ? (String)metaAllowed.getValue(localContext) : null;			// added 'localContext'
		}
		if (labelStr==null || labelStr.trim().equals("")) return null;
		String[] label = labelStr.trim().split("[,;]");
		for (int i=0; i<label.length; i++) {
			if (label[i]==null || label[i].trim().equals("")) return null;
			label[i] = label[i].trim();
		}
		
		// Get real value-to-linguistic term mapping (if any) from caller (abstract action)
		String mapStr = null;
		Object[] mappings = null;
		Metadata metaMap = caller.getMetadata("Mapping");
		if (metaMap!=null) {
			mapStr = (String)metaMap.getValue(localContext);
		}
		if (mapStr!=null) {
			mappings = new Object[nCrit];
			// one criterion mapping per line (e.g. Manufacturer, Age, Accuracy mapping in different lines)
			String[] critMapStr = mapStr.split("\n");
			for (int i=0; i<critMapStr.length; i++) {
				// split line into "criterion name" and "criterion mappings"
				String[] part = critMapStr[i].trim().split("[=]",2);
				if (part.length==1)		// criterion name or mappings part is missing
					throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Line is not valid: "+critMapStr[i]);
				String critName = part[0].trim();
				int critPos = -1;
				for (int j=0; j<mcdmCriteria.length; j++) {
					if (mcdmCriteria[j].equalsIgnoreCase(critName)) critPos = j;
				}
				if (critPos==-1) 	// criterion name not found
					throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Criterion not found in Action Pool: "+critName);
				if (part[1].trim().equals("")) continue;	// no mappings for this criterion
				// split mappings part to values
				String[] vals = part[1].split("[,;]");
				// get criterion type from metadata
				String critType = apCriteria[critPos].getType();
				// process mappings
				if (critType==null || critType.trim().equals("")) critType = "string";
				else critType = critType.toLowerCase();

				if ("numeric".equals(critType) || "number".equals(critType)) {
/*					boolean increasing = true;
					String[] tmp = vals[0].trim().split("[ \t]+",2);
					if (tmp.length>1) {
						String dir = tmp[0].trim().toUpperCase();
						vals[0] = tmp[1].trim();
						if (dir.equals("")) {
							increasing = true;
						} else
						if (dir.equals("DEC") || dir.equals("DECREASE") || dir.equals("DECREASING") || 
						    dir.equals("DESC") || dir.equals("DESCEND") || dir.equals("DESCENDING"))
						{
							increasing = false;
						} else
						if (dir.equals("INC") || dir.equals("INCREASE") || dir.equals("INCREASING") || 
						    dir.equals("ASC") || dir.equals("ASCEND") || dir.equals("ASCENDING"))
						{
							increasing = true;
						} else {
							throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Invalid limit list direction '"+dir+"' for 'numeric' criterion : "+critName+"\n"+critMapStr[i]);
						}
					}
					
					if (vals.length!=label.length-1)		// invalid mapping for criterion
						throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Invalid mapping for 'numeric' criterion : "+critName+"\n"+critMapStr[i]);
					
					double[] limit = new double[vals.length];
					for (int j=0; j<vals.length; j++) {
						try { limit[j] = Double.parseDouble(vals[j]); }
						catch (NumberFormatException e) {
							throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Non-numeric limit at mapping #"+(j+1)+" for 'numeric' criterion : "+critName+"\n"+critMapStr[i], e);
						}
						if (increasing) {
							if (j>0 && limit[j-1]>=limit[j])	// limit out of order or equal limits
								throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Item out of order in Increasing limits list at position #"+(j+1)+" for 'numeric' criterion : "+critName+"\n"+critMapStr[i]);
						} else {
							if (j>0 && limit[j-1]<=limit[j])	// limit out of order or equal limits
								throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Item out of order in Decreasing list at position #"+(j+1)+" for 'numeric' criterion : "+critName+"\n"+critMapStr[i]);
						}
					}
					// store limits list in criteria mappings
					Object[] rr = new Object[2];
					rr[0] = limit;
					rr[1] = increasing;
					mappings[critPos] = rr;*/
					
					double[][] limit = new double[vals.length][2];
					boolean[][] limitIncl = new boolean[vals.length][2];
					String[] limitValue = new String[vals.length];
					int wildcardPos = -1;
					for (int j=0; j<vals.length; j++) {
						String[] tmp = vals[j].trim().split("[:]",2);
						if (tmp.length!=2) throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Invalid range specification at position #"+(j+1)+" for 'numeric' criterion : "+critName+"\n"+critMapStr[i]);
						
						// process range specification
						vals[j] = tmp[0].trim();
						if (vals[j].equals("*")) {
							wildcardPos = j;
						} else {
							if (vals[j].charAt(0)=='[') limitIncl[j][0] = true;
							else if (vals[j].charAt(0)=='(') limitIncl[j][0] = false;
							else throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Invalid range start at position #"+(j+1)+" for 'numeric' criterion : "+critName+"\n"+critMapStr[i]);
							if (vals[j].charAt(vals[j].length()-1)==']') limitIncl[j][1] = true;
							else if (vals[j].charAt(vals[j].length()-1)==')') limitIncl[j][1] = false;
							else throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Invalid range end at position #"+(j+1)+" for 'numeric' criterion : "+critName+"\n"+critMapStr[i]);
							vals[j] = vals[j].substring(1, vals[j].length()-1).trim();
							int p = vals[j].indexOf("..");
							String[] lmt;
							if (p>-1) {
								lmt = new String[2];
								lmt[0] = vals[j].substring(0, p);
								lmt[1] = vals[j].substring(p+2);
							} else {
								lmt = new String[1];
								lmt[0] = vals[j];
							}
							if (lmt.length>2) throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Many range separators at position #"+(j+1)+" for 'numeric' criterion : "+critName+"\n"+critMapStr[i]);
							
							if (lmt.length==2) {
								if ((lmt[0]=lmt[0].trim()).isEmpty() || (lmt[1]=lmt[1].trim()).isEmpty()) throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Missing limits in range specification at position #"+(j+1)+" for 'numeric' criterion : "+critName+"\n"+critMapStr[i]);
								
								lmt[0] = lmt[0].toLowerCase().replaceAll("inf", String.valueOf(Double.MIN_VALUE));
								try { limit[j][0] = Double.parseDouble(lmt[0]); }
								catch (NumberFormatException e) {
									throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Non-numeric lower limit at mapping #"+(j+1)+" for 'numeric' criterion : "+critName+"\n"+critMapStr[i], e);
								}
								lmt[1] = lmt[1].toLowerCase().replaceAll("inf", String.valueOf(Double.MAX_VALUE));
								try { limit[j][1] = Double.parseDouble(lmt[1]); }
								catch (NumberFormatException e) {
									throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Non-numeric upper limit at mapping #"+(j+1)+" for 'numeric' criterion : "+critName+"\n"+critMapStr[i], e);
								}
								
								// check if lower limit <= upper limit
								if (limit[j][0] > limit[j][1])
									throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Lower limit is greater than upper limit at mapping #"+(j+1)+" for 'numeric' criterion : "+critName+"\n"+critMapStr[i]);
							} else {
								if ((lmt[0]=lmt[0].trim()).isEmpty()) throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Missing value in single number range specification at position #"+(j+1)+" for 'numeric' criterion : "+critName+"\n"+critMapStr[i]);
								
								if (lmt[0].toLowerCase().indexOf("inf")>-1)
									throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Single value range cannot be infinite at mapping #"+(j+1)+" for 'numeric' criterion : "+critName+"\n"+critMapStr[i]);
								if (!limitIncl[j][0] || !limitIncl[j][1])
									throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Single value range cannot cannot have exclusive bounds, i.e. ( or ) at mapping #"+(j+1)+" for 'numeric' criterion : "+critName+"\n"+critMapStr[i]);
								
								try { limit[j][0] = limit[j][1] = Double.parseDouble(lmt[0]); }
								catch (NumberFormatException e) {
									throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Non-numeric single value range at mapping #"+(j+1)+" for 'numeric' criterion : "+critName+"\n"+critMapStr[i], e);
								}
							}
							
							// check for overlaps with previous ranges
							for (int x=0; x<j; x++) {
								if (limit[x][0]<limit[j][0] && limit[j][0]<limit[x][1] ||
									limit[x][0]==limit[j][0] && limitIncl[x][0] && limitIncl[j][0] ||
									limit[x][1]==limit[j][0] && limitIncl[x][1] && limitIncl[j][0] ||
									limit[x][0]<limit[j][1] && limit[j][1]<limit[x][1] ||
									limit[x][0]==limit[j][1] && limitIncl[x][0] && limitIncl[j][1] ||
									limit[x][1]==limit[j][1] && limitIncl[x][1] && limitIncl[j][1])
								{
									throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Mapping range #"+(j+1)+" overlaps with range #"+(x+1)+" for 'numeric' criterion : "+critName+"\n"+critMapStr[i]);
								}
							}
						}
						
						// process range value (linguistic term)
						tmp[1] = tmp[1].trim();
						if (tmp.equals("")) throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Missing range linguistic value at position #"+(j+1)+" for 'numeric' criterion : "+critName+"\n"+critMapStr[i]);
						// check if label is in Allowed Values
						limitValue[j] = null;
						for (int x=0; x<label.length; x++) {
							if (label[x].equals( tmp[1] )) {
								limitValue[j] = tmp[1];
								break;
							}
						}
						if (limitValue[j]==null) throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Not allowed linguistic value '"+tmp[1]+"' at position #"+(j+1)+" for 'numeric' criterion : "+critName+"\n"+critMapStr[i]);
					}
					// store limits list in criteria mappings
					if (limit.length>0) {
						NumericMapping nm = new NumericMapping(limit, limitIncl, limitValue, wildcardPos);
						mappings[critPos] = nm;
					}
					
				} else
				if ("string".equals(critType)) {
					if (vals.length>0) {
						HashMap critMap = new HashMap();
						for (int j=0; j<vals.length; j++) {
							String[] vv = vals[j].split("[:]", 2);
							if (vv.length==1)		// mapping is invalid
								throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Mapping #"+(j+1)+" at 'string' criterion '"+critName+"' is not valid : "+vals[j]);
							
							String tag = vv[0].trim();
							String lbl = vv[1].trim();
							if (tag.equals("") || lbl.equals(""))	// mapping is invalid
								throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Mapping #"+(j+1)+" at 'string' criterion '"+critName+"' is not valid : "+vals[j]);
							
							// check if label is in Allowed Values
							boolean found = false;
							for (int x=0; x<label.length; x++) {
								if (label[x].equals( lbl )) {
									found = true;
									break;
								}
							}
							if (!found) throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Not allowed linguistic value '"+lbl+"' at position #"+(j+1)+" for 'string' criterion : "+critMapStr[i]);
							
							critMap.put(tag, lbl);
						}
						if (critMap.size()>0) {
							// store tag-to-label mappings in criteria mappings
							mappings[critPos] = critMap;
						}
					}
				} else {
					throw new RuntimeException("LOWA: Configuration error at Abstract Action: line #"+(i+1)+": Criteria of type '"+critType+"' are not supported : "+critMapStr[i]);
				}
			}
		}
		
		// Get results filter
		String filterStr = null;
		boolean[] filter = null;
		if (caller.getMetadata("Results Filter")!=null) {
			filterStr = (String)caller.getMetadata("Results Filter").getValue(localContext);
		}
		if (filterStr!=null && !filterStr.trim().equals("")) {
			String[] fltArr = filterStr.split("[ \t]", 2);
			boolean notIn = false;
			if (fltArr.length>1 && fltArr[0].trim().equalsIgnoreCase("NOT")) {
				notIn = true;
				filterStr = fltArr[1].trim();
			}
			
			fltArr = filterStr.trim().split("[,;]");
			filter = new boolean[ label.length ];
			for (int i=0; i<fltArr.length; i++) {
				fltArr[i] = fltArr[i].trim();
				for (int j=0; j<label.length; j++) {
					if (label[j].equalsIgnoreCase(fltArr[i])) {
						filter[j] = true;
					}
				}
			}
			
			if (notIn) {
				for (int i=0; i<filter.length; i++) {
					filter[i] = !filter[i];
				}
			}
		}
		
		// Get results count
		String countStr = null;
		boolean countAll = true;
		boolean countRangeTop = true;
		boolean isPercent = false;
		double countValue = 0;
		if (caller.getMetadata("Results Count")!=null) {
			countStr = (String)caller.getMetadata("Results Count").getValue(localContext);			// added 'localContext'
		}
		if (countStr!=null && !countStr.trim().equals("") && !countStr.trim().equalsIgnoreCase("ALL")) {
			countStr = countStr.trim().toUpperCase();
			String[] cntArr = countStr.split("[ \t]");
			if (cntArr.length>1) {
				countAll = false;
				
				// get range
				if (cntArr[0].equals("TOP")) {
					countRangeTop = true;
				} else
				if (cntArr[0].equals("BOTTOM")) {
					countRangeTop = false;
				} else {
					countAll = true;
				}
				
				// check if count is percentage or a fixed value
				isPercent = false;
				if (cntArr[1].endsWith("%") || cntArr.length>2 && cntArr[2].equals("%")) {
					// count is a percentage
					isPercent = true;
					cntArr[1] = cntArr[1].substring(0, cntArr[1].length()-1);
				}
				//else
					// count is a fixed value
				
				// get count value
				try { countValue = Double.parseDouble(cntArr[1]); }
				catch (Exception e) { countAll = true; countValue = 100; }
				
				if (countValue<0) {
					isPercent = false;
					countValue = 1;
				}
				if (isPercent && countValue>100) {
					countAll = true;
				}
			}
		}
		
		// Get results order
		boolean orderAsc = (Boolean)caller.getMetadata("Ascending Order").getValue(localContext);		// added 'localContext'
		
		// Get results order by distance from...
		Metadata metaDistFrom = caller.getMetadata("Order By Distance From");
		String distFrom = (metaDistFrom!=null) ? (String)metaDistFrom.getValue(localContext) : null;	// added 'localContext'
		boolean distFromCriteria = false;
		int[] distanceCritPos = null;
		int distanceFrom = -1;
		if (distFrom!=null && !(distFrom=distFrom.trim()).isEmpty()) {
			String[] part = distFrom.split("[ \t\n]+", 2);
			part[0] = part[0].trim().toUpperCase();
			String val = null;
			if (part[0].equals("CONTEXT") && part.length==1) {
				distFromCriteria = true;
				distanceCritPos = new int[nCrit];
			} else if (part[0].equals("CONTEXT") && part.length==2) {
				val = (String)getContextValue(localContext, part[1]);
			} else if (part[0].equals("VALUE") && part.length==2) {
				val = part[1].trim();
			}
			if (val!=null) {
				// get the ordinal position of value
				for (int k=0; k<label.length; k++) {
					if (label[k].equals(val)) {
						distanceFrom = k;
						break;
					}
				}
			}
		}
		
		// Get weights from Caller
		double[] weight = new double[nCrit];
		double[] weightBackup = new double[nCrit];
		double wsum = 0;
		for (int j=0; j<nCrit; j++) {
			Metadata callerMeta = caller.getMetadata(mcdmCriteria[j]);
			if (callerMeta==null) throw new RuntimeException("LOWA: Configuration error at Abstract Action Metadata: Criterion weight Metadata is MISSING for criterion : "+mcdmCriteria[j]);
			Object value = callerMeta.getValue(localContext);
			if (value==null) throw new RuntimeException("LOWA: Configuration error at Abstract Action Metadata: Criterion weight Metadata is NULL for criterion : "+mcdmCriteria[j]);
			// Format: <weight> ; <extra>  i.e.  <double> ; <string>
			String[] part = value.toString().split("[;]", 2);
			part[0] = part[0].trim();
			if (part.length>1) part[1] = part[1].trim();
			if (part[0].isEmpty())
				throw new RuntimeException("LOWA: Configuration error at Abstract Action Metadata: Criterion weight is EMPTY for criterion : "+mcdmCriteria[j]);
			// get weight
			boolean err = false;
			try {
				weight[j] = Double.parseDouble(part[0]);
				err = (weight[j]<0 || weight[j]>1);
				wsum += weight[j];
			} catch (NumberFormatException e) { err = true; }
			if (err) {
				throw new RuntimeException("LOWA: Configuration error at Abstract Action Metadata: Criterion weight is invalid or not in [0..1] interval : "+mcdmCriteria[j]+" = "+part[0]);
			}
			weightBackup[j] = weight[j];
			// get extra data (used for distance from criteria value ordering)
			if (distFromCriteria) {
				err = false;
				if (part[1].isEmpty()) err = true;
				else {
					Object o = getContextValue(localContext, part[1]);
					if (o==null) err = true;
					else {
						String val = null;
						try { val = (String)o; } catch (Exception e) { val = null; }
						if (val==null || (val=val.trim()).isEmpty()) err = true;
						else {
							distanceCritPos[j] = -1;
							for (int k=0; k<label.length; k++) {
								if (label[k].equals(val)) {
									distanceCritPos[j] = k;
									break;
								}
							}
							if (distanceCritPos[j]==-1) err = true;
						}
					}
				}
				if (err) {
					throw new RuntimeException("LOWA: Configuration error at Abstract Action Metadata: Criterion extra data is invalid for 'Distance From Context' use : "+mcdmCriteria[j]+" = "+part[1]);
				}
			}
		}
		if (Math.abs(wsum-1)>0.0000001) {
			throw new RuntimeException("LOWA: Configuration error at Abstract Action Metadata: Sum of criteria weights sum to "+wsum+" instead of 1.0");
		}
		
		// Get results order by distance from... ( CONTINUED )
		if (distanceCritPos!=null) {
			// compute LOWA value from criteria (context) data
			int lowa = calculateLOWA(distanceCritPos, weight, label.length);
			distanceFrom = lowa;
			
			// restore weights vector
			for (int j=0; j<weight.length; j++)
				weight[j] = weightBackup[j];
SANThread.getOut().println(printLowaVectors("LOWA: Distance From Context Values : ", label, distanceCritPos, weight, lowa));
		}
		
		// Search through Action Pool contents
		SANNode[] jobs = actionPool.getPoolJobs();
		if (jobs==null || jobs.length==0) return null;
		
		Vector<Result> results = new Vector<Result>();
		int[] value = new int[nCrit];
		int[] valueBackup = new int[nCrit];
		int resultCount = 0;
		for (int i=0; i<jobs.length; i++) {
			// Get item's metadata
			int critCnt = 0;
			for (int j=0; j<nCrit; j++) {
				Metadata jobMeta = jobs[i].getMetadata(mcdmCriteria[j]);
				if (jobMeta==null) break;
				//String nn = jobMeta.getName().trim();
				Object oo = jobMeta.getValue(localContext);
				if (oo==null) break;
				String vv = oo.toString().trim();
				if (vv==null || vv.equals("")) break;
				critCnt++;
				
				// translate real value to a label using mapping (if any for this criterion)
				if (mappings!=null) {
					String old_vv = vv;
					Object critMap = mappings[j];
					if (critMap==null) {
						;				// nothing to do
					} else
					if (critMap instanceof HashMap) {
						HashMap map = (HashMap)critMap;
						String new_vv = (String)map.get(vv);
						if (new_vv==null) new_vv = (String)map.get("*");
						if (new_vv!=null) vv = new_vv;
					} else
					if (critMap instanceof NumericMapping) {
						// retrieve criterion mappings
						NumericMapping nm = (NumericMapping)critMap;
						double[][] limit = nm.limit;
						boolean[][] limitIncl = nm.limitIncl;
						String[] limitValue = nm.limitValue;
						int wildcardPos = nm.wildcardPos;
						
						// convert item value to double
						double d_vv = Double.parseDouble(vv);
						
						// find in which range value lays
						int range = -1;
						for (int x=0, ll=limit.length; x<ll; x++) {
							if (x==wildcardPos) continue;
							if (limit[x][0]<d_vv && d_vv<limit[x][1]) range = x;
							else if (limit[x][0]==d_vv && limitIncl[x][0]) range = x;
							else if (limit[x][1]==d_vv && limitIncl[x][1]) range = x;
						}
						// if not found use wildcard
						if (range==-1 && wildcardPos>=0) {
							range = wildcardPos;
						}
						
						// get the label of the matching range
						if (range>-1) {
							vv = limitValue[range];
						} else
							throw new RuntimeException("LOWA: Encountered item value '"+vv+"' not listed in mapping ranges for criterion #"+(j+1)+" at item : "+jobs[i].getName());
					}
/*					} else {
						Object[] rr = (Object[])critMap;
						double[] limit = (double[])rr[0];
						boolean increasing = (boolean)rr[1];
						double d_vv = Double.parseDouble(vv);
						int labelPos = 0;
						if (increasing) {
							for (int k=0; k<limit.length; k++) {
								if (d_vv < limit[k]) {
									break;
								}
								labelPos++;
							}
						} else {
							for (int k=0; k<limit.length; k++) {
								if (d_vv > limit[k]) {
									break;
								}
								labelPos++;
							}
						}
						vv = label[labelPos];
					}*/
/*System.out.println("** LOWA: value translation:  "+
					"\n\tPool item : "+jobs[i].getName()+
					"\n\tCriterion : "+mcdmCriteria[j]+
					"\n\tValue     : "+old_vv+" --> "+vv);*/
				}
				
				// Find the linguistic value's ordinal position
				value[j] = -1;
				for (int k=0; k<label.length; k++) {
					if (label[k].equalsIgnoreCase(vv)) {
						value[j] = k;
					}
				}
				if (value[j]==-1) {
					critCnt--;
					break;
				}
				valueBackup[j] = value[j];
			}
			
			// If we have (liguistic) values for all criteria, we can apply LOWA
			if (critCnt==nCrit) {
				// Use LOWA to calc linguistic OWA
				int lowa = calculateLOWA(value, weight, label.length);

				// restore weights vector
				for (int j=0; j<weight.length; j++)
					weight[j] = weightBackup[j];
				
SANThread.getOut().println("LOWA: "+printLowaVectors(jobs[i].getName(), label, valueBackup, weight, lowa));
				
				// Check result filter
				if (filter==null || filter!=null && lowa>=0 && lowa<=filter.length && filter[lowa]) {
					double rel = lowa;
					// if ordering by distance
					if (distanceFrom>-1) rel = Math.abs(distanceFrom - lowa);
					
					// if accepted store this result
					results.add( new LowaMCDMResult(jobs[i], resultCount++, rel, label[lowa]) );
//System.out.println("\tFilter    : ACCEPTED");
				}
			}
		}
		// Sort results in ascending or descending order
		// Ties can appear in unpredicted order
		Collections.sort((Vector)results);
		if (!orderAsc) Collections.reverse((Vector)results);
		// update ranks
		int rnk = 0;
		for (Result res : results) { ((LowaMCDMResult)res).setRank(rnk++); }
		
		// keep TOP / BOTTOM k results
		if (!countAll) {
			int howmany = isPercent ? (int)(resultCount*countValue) : (int)countValue;
			if (howmany<resultCount) {
				if (countRangeTop) {
					results.subList(howmany, resultCount).clear();
				} else {
					results.subList(0, howmany).clear();
				}
			}
		}
		
		// Set the ranks in the ordered list of results
		for (int i=0, n=results.size(); i<n; i++) {
			((LowaMCDMResult)results.get(i)).setRank(i);
		}
		
		return results.iterator();
	}
	
	protected static String printLowaVectors(String item, String[] label, int[] value, double[] weight, int lowa) {
		double acc = 1000;
		StringBuilder sb = new StringBuilder(item);
		sb.append(": [ ");
		for (int i=0; i<value.length; i++) {
			if (i>0) sb.append(", ");
			sb.append(((int)(weight[i]*acc))/acc);
			sb.append("/");
			sb.append(label[value[i]]);
		}
		sb.append(" ]");
		if (lowa>=0) {
			sb.append("  ==>  ");
			sb.append(label[lowa]);
		}
		return sb.toString();
	}
	
	protected Object getContextValue(Context localContext, String elem) {
		Context ctx = localContext;
		String[] part = elem.trim().split("[:]", 2);
		String item;
		if ((part[0]=part[0].trim()).isEmpty() || part.length==1) {
			item = part[0];
		} else {
			part[0] = part[0].toUpperCase();
			if (part[0].equals("LOCAL")) ctx = localContext;
			else if (part[0].equals("ENTITY")) ctx = localContext.getParentContext();
			else if (part[0].equals("GLOBAL")) ctx = localContext.getGlobalContext();
			
			item = part[1];
		}
		
		if (!(item=item.trim()).isEmpty()) {
			return ctx.getItem(item);
		}
		
		return null;
	}
	
	// Correct LOWA implementation
	protected static int calculateLOWA( int[] value, double[] weight, int maxpos ) {
		// Check parameters
		if (value==null || value.length==0) throw new RuntimeException("LOWA: Values array is empty ");
		if (value.length!=weight.length) throw new RuntimeException("LOWA: The sizes of values and weights arrays are different ");
		if (maxpos<=0) throw new RuntimeException("LOWA: Zero or negative Maximum position ("+maxpos+" provided) ");
		
		// Order values to descending order
		LowaEntry[] le = new LowaEntry[value.length];
		for (int i=0; i<value.length; i++) {
			le[i] = new LowaEntry(i, value[i], weight[i]);
		}
		java.util.Arrays.sort(le);
		int len = le.length;
		for (int i=0; i<le.length; i++) {
			value[len-i-1]  = le[i].value;
			weight[len-i-1] = le[i].weight;
		}
		
		return _calculateLOWA(value, weight, maxpos, 0);
	}
	
	protected static int _calculateLOWA( int[] value, double[] weight, int T, int offset ) {
		int m = value.length - offset;
		
		if (m<1) {
			throw new RuntimeException("LOWA: Empty values array");
		} else
		if (m==1) {
			return value[0];
		} else {
			int j = value[offset];
			int i;
			if (m==2) {
				i= value[offset+1];
			} else {
				// recalculate weight for [offset+1 .. end]
				double sum = 0;
				for (int x=offset+1; x<value.length; x++) {
					sum += weight[x];
				}
				for (int x=offset+1; x<value.length; x++) {
					weight[x] /= sum;
				}
				
				// calculate LOWA for the lower values
				i = _calculateLOWA(value, weight, T, offset+1);
			}
			int k = (int)Math.min( T, i + Math.round( weight[offset]*(j-i) ) );
			return k;
		}
	}
	
	
	protected static class LowaEntry implements Comparable {
		public int pos;
		public int value;
		public double weight;
		
		public LowaEntry(int p, int v, double w) {
			pos = p; value = v; weight = w;
		}
		
		public int compareTo(Object o) {
			LowaEntry e = (LowaEntry)o;
			int v = e.value;
			if (this.value<v) return -1;
			else if (this.value>v) return +1;
			else return 0;
		}
	}
	
	public static class LowaMCDMResult implements Result, Comparable {
		protected SANNode job;
		protected int rank;
		protected double relevance;
		protected String description;
		
		public LowaMCDMResult(SANNode job, int rank, double rel, String descr) {
			this.job = job;
			this.rank = rank;
			this.relevance = rel;
			this.description = descr;
		}
		
		public SANNode getJob() { return this.job; }
		public int getRank() { return this.rank; }
		public double getRelevance() { return this.relevance; }
		public String getDescription() { return this.description; }
		
		public void setJob(SANNode job) { this.job = job; }
		public void setRank(int rank) { this.rank = rank; }
		public void setRelevance(double relevance) { this.relevance = relevance; }
		public void setDescription(String descr) { this.description = descr; }
		
		public int compareTo(Object r){
			double u1 = this.getRelevance();        
			double u2 = ((LowaMCDMResult)r).getRelevance();

			if (u1 > u2)
				return 1;
			else if(u1 < u2)
				return -1;
			else
				return 0;
		}
		
		public String toString() {
			return "LowaMCDMSearchMethod.MCDMResult: {rank="+rank+", position="+(int)relevance+", label="+description+", object="+job+"}";
		}
	}
	
	protected  static class NumericMapping {
		public double[][] limit;
		public boolean[][] limitIncl;
		public String[] limitValue;
		public int wildcardPos = -1;
		
		public NumericMapping(double[][] limit, boolean[][] limitIncl, String[] limitValue, int wildcardPos) {
			this.limit = limit;
			this.limitIncl = limitIncl;
			this.limitValue = limitValue;
			this.wildcardPos = wildcardPos;
		}
		
		public String toString() {
			if (limit==null || limitIncl==null || limitValue==null) return null;
			
			StringBuffer sb = new StringBuffer("NumericMappings {\n");
			for (int x=0; x<limit.length; x++) {
				sb.append("\t");
				if (limitIncl[x][0]) sb.append("["); else sb.append("("); 
				sb.append(limit[x][0]);
				if (limit[x][0]<limit[x][1]) {
					sb.append("..");
					sb.append(limit[x][1]);
				}
				if (limitIncl[x][1]) sb.append("]"); else sb.append(")"); 
				sb.append(" : ");
				sb.append(limitValue[x]);
				sb.append("\n");
			}
			sb.append("}");
			
			return sb.toString();
		}
	}
}
