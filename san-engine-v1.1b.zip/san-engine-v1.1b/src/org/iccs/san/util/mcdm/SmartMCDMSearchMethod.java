package org.iccs.san.util.mcdm;

import org.iccs.san.api.*;
import org.iccs.san.context.Context;
import org.iccs.san.util.Metadata;
import org.iccs.san.util.SANThread;
import java.util.*;

/**
 *  Implements SMART Multi-Criteria search and selection algorithm
 *  for Action Pool look-ups
 */
public class SmartMCDMSearchMethod implements ActionPoolSearchMethod {
	@SuppressWarnings("unchecked")
	public Iterator<Result> searchAndOrderJobs(ActionPool actionPool, Context localContext, SANObject caller) {
		// Get Action Pool MCDM criteria
		Metadata mcdmMeta = caller.getMetadata("SMART CRITERIA");
		String mcdmStr = (mcdmMeta!=null) ? (String)mcdmMeta.getValue(localContext) : null;
		// FOR BACKWARD COMPATIBILITY, check if criteria are defined at Action Pool at MCDM metadata
		if (mcdmStr==null || mcdmStr.trim().equals("")) {
			mcdmMeta = actionPool.getMetadata("MCDM");
			mcdmStr = (mcdmMeta!=null) ? (String)mcdmMeta.getValue(localContext) : null;
		}
		if (mcdmStr==null || mcdmStr.trim().equals("")) return null;
		String[] mcdmCriteria = mcdmStr.split("(\\s*[,;]\\s*)+");
		int nCrit = mcdmCriteria.length;
		Metadata[] apCriteria = new Metadata[nCrit];
		for (int j=0; j<nCrit; j++) {
			mcdmCriteria[j] = mcdmCriteria[j].trim();
			apCriteria[j] = actionPool.getMetadata(mcdmCriteria[j]);
		}
		
		// Get results count
		String countStr = null;
		boolean countAll = true;
		boolean countRangeTop = true;
		boolean isPercent = false;
		double countValue = 0;
		if (caller.getMetadata("Results Count")!=null) {
			countStr = (String)caller.getMetadata("Results Count").getValue(localContext);			// added 'localContext'
		}
		if (countStr!=null && !countStr.trim().equals("") && !countStr.trim().equalsIgnoreCase("ALL")) {
			countStr = countStr.trim().toUpperCase();
			String[] cntArr = countStr.split("[ \t]");
			if (cntArr.length>1) {
				countAll = false;
				
				// get range
				if (cntArr[0].equals("TOP")) {
					countRangeTop = true;
				} else
				if (cntArr[0].equals("BOTTOM")) {
					countRangeTop = false;
				} else {
					countAll = true;
				}
				
				// check if count is percentage or a fixed value
				isPercent = false;
				if (cntArr[1].endsWith("%") || cntArr.length>2 && cntArr[2].equals("%")) {
					// count is a percentage
					isPercent = true;
					cntArr[1] = cntArr[1].substring(0, cntArr[1].length()-1);
				}
				//else
					// count is a fixed value
				
				// get count value
				try { countValue = Double.parseDouble(cntArr[1]); }
				catch (Exception e) { countAll = true; countValue = 100; }
				
				if (countValue<0) {
					isPercent = false;
					countValue = 1;
				}
				if (isPercent && countValue>100) {
					countAll = true;
				}
			}
		}
		
		// Get results order
		boolean orderAsc = (Boolean)caller.getMetadata("Ascending Order").getValue(localContext);		// added 'localContext'
		
		// Get results order by distance from...
		Metadata metaDistFrom = caller.getMetadata("Order By Distance From");
		String distFrom = (metaDistFrom!=null) ? (String)metaDistFrom.getValue(localContext) : null;	// added 'localContext'
		boolean distFromCriteria = false;
		double[] distanceCritValue = null;
		double distanceFrom = 0;
		boolean useDistanceFrom = false;
		if (distFrom!=null && !(distFrom=distFrom.trim()).isEmpty()) {
			String[] part = distFrom.split("[ \t\n]+", 2);
			part[0] = part[0].trim().toUpperCase();
			String val = null;
			if (part[0].equals("CONTEXT") && part.length==1) {
				distFromCriteria = true;
				distanceCritValue = new double[nCrit];
			} else if (part[0].equals("CONTEXT") && part.length==2) {
				val = (String)getContextValue(localContext, part[1]);
			} else if (part[0].equals("VALUE") && part.length==2) {
				val = part[1].trim();
			}
			if (val!=null) {
				distanceFrom = Double.parseDouble(val);
				useDistanceFrom = true;
			}
		}
		
		// Get weights from Caller
		double[] weight = new double[nCrit];
		double wsum = 0;
		for (int j=0; j<nCrit; j++) {
			Metadata callerMeta = caller.getMetadata(mcdmCriteria[j]);
			if (callerMeta==null) throw new RuntimeException("SMART: Configuration error at Abstract Action Metadata: Criterion weight metadata is MISSING for criterion : "+mcdmCriteria[j]);
			Object value = callerMeta.getValue(localContext);
			if (value==null) throw new RuntimeException("SMART: Configuration error at Abstract Action Metadata: Criterion weight metadata is NULL for criterion : "+mcdmCriteria[j]);
			// Format: <weight> ; <extra>  i.e.  <double> ; <string>
			String[] part = value.toString().split("[;]", 2);
			part[0] = part[0].trim();
			if (part.length>1) part[1] = part[1].trim();
			if (part[0].isEmpty())
				throw new RuntimeException("SMART: Configuration error at Abstract Action Metadata: Criterion weight is EMPTY for criterion : "+mcdmCriteria[j]);
			// get weight
			boolean err = false;
			try {
				weight[j] = Double.parseDouble(part[0]);
				err = (weight[j]<0 || weight[j]>1);
				wsum += weight[j];
			} catch (NumberFormatException e) { err = true; }
			if (err) {
				throw new RuntimeException("SMART: Configuration error at Abstract Action Metadata: Criterion weight is invalid or not in [0..1] interval : "+mcdmCriteria[j]+" = "+part[0]);
			}
			// get extra data (used for distance from criteria value ordering)
			if (distFromCriteria) {
				err = false;
				if (part[1].isEmpty()) err = true;
				else {
					Object o = getContextValue(localContext, part[1]);
					if (o==null) err = true;
					else {
						String val = null;
						try { val = (String)o; } catch (Exception e) { val = null; }
						if (val==null || (val=val.trim()).isEmpty()) err = true;
						else {
							try { distanceCritValue[j] = Double.parseDouble(val); } catch (Exception e) { err = true; }
						}
					}
				}
				if (err) {
					throw new RuntimeException("SMART: Configuration error at Abstract Action Metadata: Criterion extra data is invalid for 'Distance From Context' use : "+mcdmCriteria[j]+" = "+part[1]);
				}
			}
		}
		if (Math.abs(wsum-1)>0.0000001) {
			throw new RuntimeException("SMART: Configuration error at Abstract Action Metadata: Sum of criteria weights sum to "+wsum+" instead of 1.0");
		}
		
		// Get results order by distance from... ( CONTINUED )
		if (distanceCritValue!=null) {
			// compute SMART value from criteria (context) data
			double utility = 0;
			for (int j=0; j<nCrit; j++) {
				utility += weight[j] * distanceCritValue[j];
			}
			distanceFrom = utility;
SANThread.getOut().println(printVectors("SMART: Distance From Context Values : ", distanceCritValue, weight, utility));
		}
		
		// Search through Action Pool contents
		SANNode[] jobs = actionPool.getPoolJobs();
		if (jobs==null || jobs.length==0) return null;
		
		Vector<Result> results = new Vector<Result>();
		int resultCount = 0;
		double[] valuesArr = new double[nCrit];
		for (int i=0; i<jobs.length; i++) {
			// Get item's metadata
			int critCnt = 0;
			double utility = 0;
			for (int j=0; j<nCrit; j++) {
				Metadata jobMeta = jobs[i].getMetadata(mcdmCriteria[j]);
				if (jobMeta==null) break;
				//String nn = jobMeta.getName().trim();
				Object value = jobMeta.getValue(localContext);
				if (value==null) break;
				String vv = value.toString().trim();
				if (vv==null || vv.equals("")) break;
				critCnt++;
				valuesArr[j] = ((Double)value).doubleValue();
				utility += weight[j] * valuesArr[j];
			}
			
			// If we have values for all criteria, then 'utility' contains the SMART result
			if (critCnt==nCrit) {
				double rel = utility;
				// if ordering by distance
				if (useDistanceFrom) rel = Math.abs(distanceFrom - utility);
				
SANThread.getOut().println(printVectors("SMART: ", valuesArr, weight, utility));
				
				// store this result
				results.add( new MCDMResult(jobs[i], resultCount++, rel) );
			}
		}
		// Sort results in ascending or descending order
		// Ties can appear in unpredicted order
		Collections.sort((Vector)results);
		if (!orderAsc) Collections.reverse((Vector)results);
		// update ranks
		int rnk = 0;
		for (Result res : results) { ((MCDMResult)res).setRank(rnk++); }
		
		// keep TOP / BOTTOM k results
		if (!countAll) {
			int howmany = isPercent ? (int)(resultCount*countValue) : (int)countValue;
			if (howmany<resultCount) {
				if (countRangeTop) {
					results.subList(howmany, resultCount).clear();
				} else {
					results.subList(0, howmany).clear();
				}
			}
		}
		
		// Set the ranks in the ordered list of results
		for (int i=0, n=results.size(); i<n; i++) {
			((MCDMResult)results.get(i)).setRank(i);
		}
		
		return results.iterator();
	}
	
	protected static String printVectors(String item, double[] value, double[] weight, double utility) {
		double acc = 1000;
		StringBuilder sb = new StringBuilder(item);
		sb.append(": [ ");
		for (int i=0; i<value.length; i++) {
			if (i>0) sb.append(", ");
			sb.append(((int)(weight[i]*acc))/acc);
			sb.append("/");
			sb.append(value[i]);
		}
		sb.append(" ]");
		sb.append("  ==>  ");
		sb.append(utility);
		return sb.toString();
	}
	
	protected Object getContextValue(Context localContext, String elem) {
		Context ctx = localContext;
		String[] part = elem.trim().split("[:]", 2);
		String item;
		if ((part[0]=part[0].trim()).isEmpty() || part.length==1) {
			item = part[0];
		} else {
			part[0] = part[0].toUpperCase();
			if (part[0].equals("LOCAL")) ctx = localContext;
			else if (part[0].equals("ENTITY")) ctx = localContext.getParentContext();
			else if (part[0].equals("GLOBAL")) ctx = localContext.getGlobalContext();
			
			item = part[1];
		}
		
		if (!(item=item.trim()).isEmpty()) {
			return ctx.getItem(item);
		}
		
		return null;
	}
	
	public static class MCDMResult implements Result, Comparable {
		protected SANNode job;
		protected int rank;
		protected double relevance;
		
		public MCDMResult(SANNode job, int rank, double rel) {
			this.job = job;
			this.rank = rank;
			this.relevance = rel;
		}
		
		public SANNode getJob() { return this.job; }
		public int getRank() { return this.rank; }
		public double getRelevance() { return this.relevance; }
		public String getDescription() { return Double.toString(relevance); }
		
		public void setJob(SANNode job) { this.job = job; }
		public void setRank(int rank) { this.rank = rank; }
		public void setRelevance(double relevance) { this.relevance = relevance; }
		
		public int compareTo(Object r){
			double u1 = this.getRelevance();        
			double u2 = ((MCDMResult)r).getRelevance();

			if (u1 > u2)
				return 1;
			else if(u1 < u2)
				return -1;
			else
				return 0;
		}
		
		public String toString() {
			return "SmartMCDMSearchMethod.MCDMResult: {rank="+rank+", utility="+relevance+", object="+job+"}";
		}
	}
}
