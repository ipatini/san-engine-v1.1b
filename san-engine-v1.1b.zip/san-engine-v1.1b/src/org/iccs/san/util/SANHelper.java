package org.iccs.san.util;

import java.io.*;
import java.util.Enumeration;
import java.util.Properties;

/**
 *	A collection of useful methods such as file and properties loading
 */
public class SANHelper {
	public static String loadFile(String file) throws IOException {
//		java.net.URL url = ClassLoader.getSystemResource(file);
//		if (url==null) {
//			throw new RuntimeException("Could not find file : "+file);
//		}
//		InputStream stream = url.openStream();
		InputStream stream = getResourceAsStream(file);
		if (stream==null) throw new RuntimeException("SANHelper: loadFile: Could not find file: "+file);
		InputStreamReader reader = new InputStreamReader(stream);
		StringBuffer buff = new StringBuffer();
		char[] cbuf = new char[4096];
		int n;
		do {
			n = reader.read(cbuf, 0, cbuf.length);
			if (n>0) {
				buff.append(cbuf, 0, n);
			}
		} while (n>=0);
		reader.close();
		
		return buff.toString();
	}
	
	public static Properties loadProperties(String file) throws IOException {
		Properties props = new Properties();
		java.net.URL url = ClassLoader.getSystemResource(file);
		if (url==null) return null;
		props.load(url.openStream());
		return props;
	}
	
	public static Properties loadConfiguration(String propsName) throws java.io.IOException {
		Properties props = new Properties();
//		java.net.URL url = ClassLoader.getSystemResource(propsName);
//		if (url==null) throw new RuntimeException("SANHelper: loadConfiguration: Could not find resource: "+propsName);
//		props.load(url.openStream());
		InputStream inp = getResourceAsStream(propsName);
		if (inp==null) throw new RuntimeException("SANHelper: loadConfiguration: Could not find resource: "+propsName);
		props.load(inp);
		return props;
	}
	
	public static Properties loadConfiguration(String[] args) {
		Properties props = new Properties();
		for (int i=0, n=args.length; i<n; i++) {
			if (args[i].startsWith("-")) {
				String key = args[i].substring(1);
				String value =  ((i+1<n) && !args[i+1].startsWith("-")) ? args[i+1] : "";
				props.setProperty(key, value);
			}
		}
		return props;
	}
	
	public static Properties loadConfiguration(String propsName, String[] args) throws java.io.IOException {
		// Load configuration from properties file and
		// replace placeholders from command-line options
		Properties props = loadConfiguration(propsName);
		Enumeration en = props.propertyNames();
		while (en.hasMoreElements()) {
			String key = (String)en.nextElement();
			String option = props.getProperty(key);
			if (option.indexOf("%")>=0) {
				String[] part = option.split("%", -10);
				String newOption = part[0];
				
				boolean isVar = true;
				for (int i=1; i<part.length; i++) {
					if (isVar) {
						if (part[i].equals("")) { newOption+="%"; continue; }
						if (i==part.length-1) { newOption+="%"+part[i]; break; }
						
						String search = "-"+part[i];
						boolean found = false;
						for (int j=0, n=args.length; j<n; j++) {
							if (search.equalsIgnoreCase(args[j]) && (j+1<n)) {
								newOption += args[j+1];
								found = true;
								break;
							}
						}
						if (!found) newOption += "%"+part[i]+"%";
					} else {
						newOption += part[i];
					}
					isVar = !isVar;
				}
				if (!option.equals(newOption)) props.setProperty(key, newOption);
			}
		}
		
		// Merge with command-line properties
		Properties overideConfig = loadConfiguration(args);
		en = overideConfig.propertyNames();
		while (en.hasMoreElements()) {
			String key = (String)en.nextElement();
			String value = overideConfig.getProperty(key);
			props.setProperty(key, value);
		}
		
		return props;
	}
	
	// ADDITION: 03/07/2012
	public static InputStream getResourceAsStream(String url) {
		try {
			java.net.URL url_0 = new java.net.URL(url);
			return url_0.openStream();
		} catch (Exception e) {	}
		
		try {
			return new FileInputStream(new File(url));
		} catch (Exception ex) { }
		
		try {
			InputStream in = (new Object() { }.getClass().getEnclosingClass()).getResourceAsStream(url);
			if (in!=null) return in;
		} catch (Exception ex) { }
		
		try {
			InputStream in = ClassLoader.getSystemResourceAsStream(url);
			if (in!=null) return in;
		} catch (Exception ex) { }
		
		return null;
	}
	
	public static String getResourceContent(String url) {
		InputStream is = getResourceAsStream(url);
		if (is==null) return null;
		
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(is));
			StringBuilder stringBuilder = new StringBuilder();
			String line = null;
			String NL = System.getProperty("line.separator");
			
			while( ( line = reader.readLine() ) != null ) {
				stringBuilder.append( line );
				stringBuilder.append( NL );
			}
			
			return stringBuilder.toString();
		} catch (Exception e) {
			return null;
		}
	}
	
	// ADDITION: 18/7/2012
	public static String readFromFile(String fileName) throws IOException {
		FileReader fr = new FileReader(fileName);
		BufferedReader br = new BufferedReader(fr);
		String s;
		StringBuffer sb = new StringBuffer();
		while((s = br.readLine()) != null) {
			sb.append(s);
			sb.append('\n');
		}
		br.close();
		fr.close();
		return sb.toString();
	}
	
	public static void writeToFile(String fileName, String content, boolean append) throws IOException {
		FileWriter fw = new FileWriter(fileName, append);
		PrintWriter out = new PrintWriter(fw);
		out.print(content);
		out.close();
		fw.close();
	}
}
