package org.iccs.san.util;

import java.util.Enumeration;
import java.util.Vector;

/**
 *	Thread Pool that manages threads
 */
public class SANThreadPool<E> extends Vector<SANThread<E>> {
	protected SANThreadFactory<E> factory = null;
	
	public synchronized SANThread<E> run(Runnable runnable) {
		SANThread<E> thread = create(runnable);
		thread.start();
		return thread;
	}
	
	public synchronized SANThread<E> create(Runnable runnable) {
		if (factory==null) factory = new SANThreadFactory<E>();
		SANThread<E> thread = factory.newThread(runnable);
		this.add( thread );
		return thread;
	}
	
	public synchronized void startAll() {
		Enumeration<SANThread<E>> en = elements();
		while (en.hasMoreElements()) {
			SANThread<E> thread = en.nextElement();
			thread.start();
		}
	}

	public synchronized void stopAll() {
		Enumeration<SANThread<E>> en = elements();
		while (en.hasMoreElements()) {
			SANThread<E> thread = en.nextElement();
			thread.interrupt();
		}
	}

	public synchronized void killAll() {
		Enumeration<SANThread<E>> en = elements();
		while (en.hasMoreElements()) {
			SANThread<E> thread = en.nextElement();
			//thread.stop();
		}
	}

	public synchronized void waitFor(int millis) {
		try {
			Thread.currentThread().sleep(millis);
		} catch (InterruptedException ex) { }
	}
}
