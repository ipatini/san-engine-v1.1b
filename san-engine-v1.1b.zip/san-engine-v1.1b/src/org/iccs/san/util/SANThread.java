package org.iccs.san.util;

import org.iccs.san.api.SANNode;
import org.iccs.san.context.Context;
import java.io.*;

/**
 *	An SAN thread carrying thread-specific data
 */
public class SANThread<E> extends Thread {
	public static final ThreadGroup defaultThreadGroup = new ThreadGroup("SAN Default Thread Group");
	public static Configurator defaultConfigurator;
	
	public Configurator configurator;
	public E data;
	public SANNode node;
	public String lock;
	public Context context;
	public boolean contextOwner;
	
	public SANThread(Runnable r) {
		super(defaultThreadGroup, r);
		init();
	}
	
	public SANThread(ThreadGroup group, Runnable r) {
		super(group, r);
		init();
	}
	
	protected void init() {
		setDaemon(true);
	}
	
	public void run() {
		// Do the job
		super.run();
// XXX: TODO: UNTESTED - dispose local context if configured
		if (contextOwner) {
			try {
				if (SANThread.current().configurator.getBoolean("context.dispose-contexts", false)) {
					Context ctx = SANThread.current().context;
					String uri = ctx.getURI();
					Context entCtx = ctx.getParentContext();
					if (entCtx!=null) entCtx.removeLocalContext(uri);
					getOut().println("Local context '"+uri+"' has been disposed");
				}
			} catch (Exception ex) { }
		}
	}
	
	public static SANThread current() {
		Thread thread = Thread.currentThread();
		if (thread instanceof SANThread) {
			return (SANThread)thread;
		}
		return null;
	}
	
	public static void killAll() {
		for (int i=0; i<10; i++) {
			if (defaultThreadGroup.activeCount()>0 || defaultThreadGroup.activeGroupCount()>0) {
				defaultThreadGroup.interrupt();
			}
		}
	}
	
	public static PrintStream getOut() {
		SANThread thread = SANThread.current();
		if (thread==null) {
			if (defaultConfigurator!=null && defaultConfigurator.io!=null && defaultConfigurator.io.out!=null) {
				return defaultConfigurator.io.out;
			}
			return System.out;
		} else {
			return thread.configurator.io.out;
		}
	}
	
	public static PrintStream getErr() {
		SANThread thread = SANThread.current();
		if (thread==null) {
			if (defaultConfigurator!=null && defaultConfigurator.io!=null && defaultConfigurator.io.err!=null) {
				return defaultConfigurator.io.err;
			}
			return System.err;
		} else {
			return thread.configurator.io.err;
		}
	}
}
