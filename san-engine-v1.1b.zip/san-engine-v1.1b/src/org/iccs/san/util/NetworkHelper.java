package org.iccs.san.util;

import java.net.*;
import java.util.*;

public class NetworkHelper {
	
	public static void main(String[] args) {
		String filter = (args.length>0) ? args[0] : "";
		for (InetAddress addr : getInetAddresses(filter)) {
			System.out.println(addr);
		}
	}
	
	public static List<InetAddress> getInetAddresses(String filter) {
		filter = ".*"+filter.trim()+".*";
		List<InetAddress> addresses = new ArrayList<InetAddress>();
		for (InetAddress addr : getInetAddresses()) {
			if (addr.toString().substring(1).matches(filter)) {
				addresses.add(addr);
			}
		}
		return addresses;
	}
	
	public static List<InetAddress> getInetAddresses() {
		List<InetAddress> addresses = new ArrayList<InetAddress>();
		try {
			Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
			while (en.hasMoreElements()) {
				NetworkInterface intf = en.nextElement();
				try {
					if (!intf.isUp()) continue;
					if (intf.isLoopback()) continue;
				} catch (SocketException ex2) {
					continue;
				}
				
				Enumeration<InetAddress> en2 = intf.getInetAddresses();
				while (en2.hasMoreElements()) {
					InetAddress addr = en2.nextElement();
					if (!(addr instanceof Inet4Address)) continue;
					if (addr.isLoopbackAddress()) continue;
					addresses.add(addr);
				}
			}
			return addresses;
		} catch (SocketException ex) {
			return addresses;
		}
	}
}