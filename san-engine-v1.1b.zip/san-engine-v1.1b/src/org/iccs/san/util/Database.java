package org.iccs.san.util;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;

public class Database {
	protected String connectionString;
	protected String username, password;
	protected Connection connection;
	protected Hashtable<String,PreparedStatement> prepared;
	
	public Database() {
		this.prepared = new Hashtable<String,PreparedStatement>();
	}
	
	public Database(String connStr, String username, String password) {
		this();
		setConnectionString(connStr);
		setUsername(username);
		setPassword(password);
	}
	
	/*
	 *	Connection methods
	 */
	
	public String getUserName() { return this.username; }
	public void setUsername(String username) { this.username = username; }
	public void setPassword(String password) { this.password = password; }
	public String getConnectionString() { return this.connectionString; }
	public void setConnectionString(String connStr) { this.connectionString = connStr; }
	
	public synchronized void openConnection() throws SQLException {
		if (this.connection!=null) closeConnection();
		
		Properties connectionProps = new Properties();
		connectionProps.put("user", this.username);
		connectionProps.put("password", this.password);
		
		this.connection = DriverManager.getConnection(connectionString, connectionProps);
		this.prepared.clear();
	}
	
	public synchronized void closeConnection() throws SQLException {
		if (this.connection==null) return;
		
		Iterator<PreparedStatement> it = this.prepared.values().iterator();
		while (it.hasNext()) {
			try {
				it.next().close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		this.prepared.clear();
		
		this.connection.close();
		this.connection = null;
	}
	
	protected void finalize() {
		try {
			closeConnection();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	/*
	 *  Query and Statement methods
	 */
	
	public List<Object[]> query(String query) throws SQLException {
		Statement stmt = this.connection.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		ResultSetMetaData meta = rs.getMetaData();
		int nCol = meta.getColumnCount();
		List<Object[]> rows = new ArrayList<Object[]>();
		while (rs.next()) {
			Object[] row = new Object[nCol];
			for (int i=1; i<=nCol; i++) {
				row[i-1] = rs.getObject(i);
			}
			rows.add(row);
		}
		rs.close();
		stmt.close();
		return rows;
	}
	
	public List<Hashtable> queryAssoc(String query) throws SQLException {
		Statement stmt = this.connection.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		ResultSetMetaData meta = rs.getMetaData();
		int nCol = meta.getColumnCount();
		String[] colName = new String[nCol];
		for (int i=1; i<=nCol; i++) {
			colName[i-1] = meta.getColumnLabel(i);
		}
		List<Hashtable> rows = new ArrayList<Hashtable>();
		while (rs.next()) {
			Hashtable<String,Object> row = new Hashtable<String,Object>();
			for (int i=1; i<=nCol; i++) {
				row.put( colName[i-1], rs.getObject(i) );
			}
			rows.add(row);
		}
		rs.close();
		stmt.close();
		return rows;
	}
	
	public Object queryValue(String query) throws SQLException {
		Statement stmt = this.connection.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		Object value = null;
		if (rs.next()) {
			value = rs.getObject(1);
		}
		rs.close();
		stmt.close();
		return value;
	}
	
	public void execute(String sql) throws SQLException {
		Statement stmt = this.connection.createStatement();
		stmt.executeUpdate(sql);
	}
	
	/*
	 *	Methods for Prepared Queries and Statements
	 */
	
	public synchronized void prepare(String key, String sql) throws SQLException {
		if (this.connection==null) return;
		
		PreparedStatement prev = this.prepared.get(key);
		if (prev!=null) prev.close();
		if (sql!=null) {
			PreparedStatement pstmt = this.connection.prepareStatement(sql);
			this.prepared.put(key, pstmt);
		} else {
			this.prepared.remove(key);
		}
	}
	
	protected PreparedStatement getPreparedStatement(String key, Object... params) throws SQLException {
		PreparedStatement pstmt = this.prepared.get(key);
		pstmt.clearParameters();
		int i=1;
		for (Object p : params) {
			pstmt.setObject(i++, p);
		}
		return pstmt;
	}
	
	public List<Object[]> p_query(String key, Object... params) throws SQLException {
		PreparedStatement pstmt = getPreparedStatement(key, params);
		ResultSet rs = pstmt.executeQuery();
		ResultSetMetaData meta = rs.getMetaData();
		int nCol = meta.getColumnCount();
		List<Object[]> rows = new ArrayList<Object[]>();
		while (rs.next()) {
			Object[] row = new Object[nCol];
			for (int i=1; i<=nCol; i++) {
				row[i-1] = rs.getObject(i);
			}
			rows.add(row);
		}
		rs.close();
		return rows;
	}
	
	public List<Hashtable> p_queryAssoc(String key, Object... params) throws SQLException {
		PreparedStatement pstmt = getPreparedStatement(key, params);
		ResultSet rs = pstmt.executeQuery();
		ResultSetMetaData meta = rs.getMetaData();
		int nCol = meta.getColumnCount();
		String[] colName = new String[nCol];
		for (int i=1; i<=nCol; i++) {
			colName[i-1] = meta.getColumnLabel(i);
		}
		List<Hashtable> rows = new ArrayList<Hashtable>();
		while (rs.next()) {
			Hashtable<String,Object> row = new Hashtable<String,Object>();
			for (int i=1; i<=nCol; i++) {
				row.put( colName[i-1], rs.getObject(i) );
			}
			rows.add(row);
		}
		rs.close();
		return rows;
	}
	
	public Object p_queryValue(String key, Object... params) throws SQLException {
		PreparedStatement pstmt = getPreparedStatement(key, params);
		ResultSet rs = pstmt.executeQuery();
		Object value = null;
		if (rs.next()) {
			value = rs.getObject(1);
		}
		rs.close();
		return value;
	}
	
	public void p_execute(String key, Object... params) throws SQLException {
		PreparedStatement pstmt = getPreparedStatement(key, params);
		pstmt.execute();
	}
}