package org.iccs.san.util;

import org.iccs.san.context.Context;
import org.iccs.san.util.Expression;

/**
 *  Represents a piece of Metadata of a SAN object
 */
public class Metadata<E> {
	protected String name;
	protected String type;
	protected String unit;
	protected E value;
	protected Expression<E> expression;
	protected boolean is_expr;
	protected double rangeMin = -Double.MAX_VALUE;
	protected double rangeMax = Double.MAX_VALUE;
	protected double rangeStep = 0;
	
	public Metadata() {
	}
	
	public Metadata(String name, String type, E value) {
		this.name = name;
		this.type = type;
		this.value = value;
		this.is_expr = false;
	}
	
	public Metadata(String name, String type, Expression<E> expr) {
		this.name = name;
		this.type = type;
		this.expression = expr;
		this.is_expr = true;
	}
	
	public String getName() { return this.name; }
	public void setName(String name) { this.name = name; }
	public String getType() { return this.type; }
	public void setType(String type) { this.type = type; }
	public String getUnit() { return this.unit; }
	public void setUnit(String unit) { this.unit = unit; }
	public E getValue() { return this.value; }
	public void setValue(E value) { this.value = value; this.is_expr = false; }
	public Expression<E> getExpression() { return this.expression; }
	public void setExpression(Expression<E> expr) { this.expression = expr; this.is_expr = true; }
	public boolean isExpression() { return this.is_expr; }
	
	public E getValue(Context ctx) {
		if (!this.is_expr) return getValue();
		
		E value = (E)this.expression.evaluate(ctx);
		return value;
	}
	
	public double getRangeMin() { return this.rangeMin; }
	public double getRangeMax() { return this.rangeMax; }
	public double getRangeStep() { return this.rangeStep; }
	public void setRangeMin(double min) { this.rangeMin = min; }
	public void setRangeMax(double max) { this.rangeMax = max; }
	public void setRangeStep(double step) { this.rangeStep = step; }
	
	public String toString() {
		return "METADATA: {name="+name+", type="+type+", unit="+unit+", "+(is_expr?("expression="+expression):("value="+value))+", range=["+rangeMin+".."+rangeMax+"] by step="+rangeStep+" } ";
	}
}
