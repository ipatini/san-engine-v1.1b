package org.iccs.san.util;

import org.iccs.san.api.SANEngine;
import org.iccs.san.api.SANEntity;
import org.iccs.san.context.Context;
import org.iccs.san.cep.SimpleEvent;
import org.iccs.san.cep.ReplayCapable;
import org.iccs.san.util.Configurator;
import org.iccs.san.util.DateParser;
import org.iccs.san.util.SANThread;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.Map;
import java.util.UUID;
import java.text.SimpleDateFormat;
import javax.xml.namespace.QName;
import javax.swing.JOptionPane;

// used in formatXml method
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.stream.StreamResult;
import org.xml.sax.InputSource;

/**
 *	Methods exposed to Actions and Expressions for usage by users/developers
 */
public class ActionHelper {
	protected static ActionHelper globalInstance;
	protected Configurator configurator;
	protected SANEngine engine;
	protected boolean useGui;
	
	public static ActionHelper getInstance() { return globalInstance; }
	public static void setInstance(ActionHelper global) { globalInstance = global; }
	
	public ActionHelper(Configurator config) {
		this.configurator = config;
		this.engine = config.engine;
		this.useGui = config.getBoolean("helper.action.use-gui", true);
	}
	
	// Entity management methods
	public SANEntity createEntity(String entityURI) {
		return engine.createEntity(entityURI);
	}
	
	public SANEntity createEntity(String entityURI, boolean autoStartRootGoals) {
		return engine.createEntity(entityURI, autoStartRootGoals);
	}
	
	public SANEntity destroyEntity(String entityURI) {
		return engine.destroyEntity(entityURI);
	}
	
	// Root Goal management methods
	public void startRootGoal(String rootURI, String entityURI) {
		SANEngine eng = SANThread.current().configurator.engine;
		eng.startRootGoal(rootURI, entityURI);
	}
	
	public void stopRootGoal(String rootURI) {
		SANEngine eng = SANThread.current().configurator.engine;
		eng.stopRootGoal(rootURI);
	}
	
	// Event publishing methods
	public static boolean sendEvent(String sender, String namespaceURI, String localPart, String prefix, String payload) {
		String id = getUniqueEventId();
		return sendEvent(id, sender, namespaceURI, localPart, prefix, payload);
	}
	
	public static boolean sendEvent(String id, String sender, String namespaceURI, String localPart, String prefix, String payload) {
		QName topic = new QName(namespaceURI, localPart, prefix);
		return sendEvent(id, sender, topic, payload);
	}
	
	public static boolean sendEvent(String sender, QName topic, String payload) {
		String id = getUniqueEventId();
		return sendEvent(id, sender, topic, payload);
	}
	
	public static boolean sendEvent(String id, String sender, QName topic, String payload) {
		SimpleEvent event = new SimpleEvent(id, sender, topic, payload);
		return SANThread.current().configurator.cep.sendEvent(event);
	}
	
	public static String getUniqueEventId() {
		return Long.toString(Math.round((1000000*(new Date()).getTime()+Math.random())));
	}
	
	// JS helper methods - JS dialog boxes
	public void alert(String mesg) {
		writeGUIMessage("ALERT", mesg);
		if (!useGui) {
			SANThread.getOut().println(mesg);
			return;
		}
		JOptionPane.showMessageDialog(null, mesg, "Alert", JOptionPane.INFORMATION_MESSAGE);
	}
	
	public boolean confirm(String mesg) {
		if (!useGui) {
			SANThread.getOut().println(mesg+" [Y/N]: YES");
			writeGUIMessage("CONFIRM", mesg+" : "+"YES");
			return true;
		}
		int rr = JOptionPane.showConfirmDialog(null, mesg, "Confirm", JOptionPane.YES_NO_OPTION);
		writeGUIMessage("CONFIRM", mesg+" : "+(rr==JOptionPane.YES_OPTION ? "YES" : "NO"));
		return (rr==JOptionPane.YES_OPTION);
	}
	
	public String prompt(String mesg, String defValue) {
		if (!useGui) {
			SANThread.getOut().println(mesg+" : "+defValue);
			writeGUIMessage("PROMPT", mesg+" : "+defValue);
			return defValue;
		}
		String ret = javax.swing.JOptionPane.showInputDialog(null, mesg, defValue);
		writeGUIMessage("PROMPT", mesg+" : "+ret);
		return ret;
	}
	
	protected void writeGUIMessage(String dlg, String mesg) {
		String line = dlg.toUpperCase()+" : "+mesg;
		String file = configurator.get("helper.action.gui-file");
		if (file==null || file.trim().equals("")) return;
		try {
			SANThread.getOut().println("ActionHelper: writeGUIMessage: "+line);
			writeFile(file, line+"\n", true);
		} catch (Exception e) {
			SANThread.getErr().println("ActionHelper: writeGUIMessage: Could not write message: "+e);
			e.printStackTrace( SANThread.getErr() );
		}
	}
	
	// JS helper methods - other methods
	public static Object v(Context ctx, String attrName) {
		return v(ctx, attrName, 0, null);
	}
	
	public static Object v(Context ctx, String attrName, Object defValue) {
		return v(ctx, attrName, 0, defValue);
	}
	
	public static Object v(Context ctx, String attrName, int index) {
		return v(ctx, attrName, index, null);
	}
	
	public static Object v(Context ctx, String attrName, int index, Object defValue) {
		Object tmp = ctx.getItem(attrName);
		if (tmp!=null) {
			if (tmp.getClass().isArray()) {
				return ((Object[])tmp)[index];
			} else {
				return tmp;
			}
		} else {
			return defValue;
		}
	}
	
	public static Date parseDate(String dateText) {
		return DateParser.parseW3CDateTime(dateText);
	}
	
	public static String formatDate(Date date, String formatter) {
		SimpleDateFormat sdf = new SimpleDateFormat(formatter);
		String str = sdf.format(date);
		int len = str.length();
		if (len>4) {	// Fix timezone spec of java (e.g. +0200) to comply to UTC format (+02:00)
			char c = str.charAt(len-4);
			if (c=='+' || c=='-') {
				str = str.substring(0, len-1)+":00";
			}
		}
		return str;
	}
	
	public static String formatW3CDateTime(Date date) {
		return DateParser.formatW3CDateTime(date);
	}
	
	public static String getGUID() {
		return UUID.randomUUID().toString();
	}
	
	public String getConfig(String key) {
		return SANThread.current().configurator.get(key);
	}
	
	// HTTP call methods and Web Service invocation methods
	public static String getURLContents(String address) {
		try {
			URL url = new URL(address);
			StringBuffer cn = new StringBuffer();
			BufferedReader in = new BufferedReader( new InputStreamReader( url.openStream() ) );
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				cn.append(inputLine);
			}
			in.close();
			return cn.toString();
		} catch (Exception ex) {
			SANThread.getErr().println("ActionHelper: getURLContents: param URL="+address+". Exception: "+ex);
			ex.printStackTrace( SANThread.getErr() );
			return null;
		}
	}
	
	// XML methods
    public static String formatXml(String xml){
        try{
            Transformer serializer= SAXTransformerFactory.newInstance().newTransformer();
            serializer.setOutputProperty(OutputKeys.INDENT, "yes");
            serializer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			serializer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			serializer.setOutputProperty(OutputKeys.INDENT, "yes");
            serializer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            //serializer.setOutputProperty("{http://xml.customer.org/xslt}indent-amount", "2");
            Source xmlSource=new SAXSource(new InputSource(new ByteArrayInputStream(xml.getBytes())));
            StreamResult res =  new StreamResult(new ByteArrayOutputStream());            
            serializer.transform(xmlSource, res);
            return new String(((ByteArrayOutputStream)res.getOutputStream()).toByteArray());
        }catch(Exception e){
            return xml;
        }
    }
	
	// File methods
	public static String readFile(String file) {
		try {
			return SANHelper.readFromFile(file);
		} catch (IOException e) {
			return null;
		}
	}
	
	public static boolean writeFile(String file, String content, boolean append) {
		try {
			SANHelper.writeToFile(file, content, append);
			return true;
		} catch (IOException e) {
			return false;
		}
	}
	
	// Text preparation methods
	public static String prepareFromTemplate(String templateUrl, Map vars, boolean stripEmpty) {
		String template = SANHelper.getResourceContent(templateUrl);
		if (template==null) return null;
		return prepareText(template, vars, stripEmpty);
	}
	
	public static String prepareFromTemplate(String templateUrl, Context localContext, boolean stripEmpty) {
		String template = SANHelper.getResourceContent(templateUrl);
		if (template==null) return null;
		if (localContext==null || !localContext.isLocalContext()) return null;
		return prepareText(template, localContext, stripEmpty);
	}
	
	public static String prepareText(String text, Map vars, boolean stripEmpty) {
		// replace placeholders with actual values
		String[] part = text.split("%");
		StringBuilder sb = new StringBuilder();
		for (int i=0; i<part.length; i++) {
			if (i%2==0) sb.append(part[i]);
			else if (part[i].equals("")) sb.append("%");
			else {
				Object v = vars.get(part[i]);
				if (v!=null) sb.append(v.toString());
				else if (stripEmpty) ;	// strip placeholder
				else {
					sb.append("%"); sb.append(part[i]); sb.append("%");
				}
			}
		}
		
		return sb.toString();
	}
	
	public static String prepareText(String text, Context ctx, boolean stripEmpty) {
		// replace placeholders with actual context values
		String[] part = text.split("%");
		StringBuilder sb = new StringBuilder();
		for (int i=0; i<part.length; i++) {
			if (i%2==0) sb.append(part[i]);
			else if (part[i].equals("")) sb.append("%");
			else {
				Object v = getPlaceholderValue(part[i], ctx);
				if (v!=null) sb.append(v.toString());
				else if (stripEmpty) ;	// strip placeholder
				else {
					sb.append("%"); sb.append(part[i]); sb.append("%");
				}
			}
		}
		
		return sb.toString();
	}
	
	public static String getPlaceholderValue(String placeholder, Context ctx) {
		String scope;
		String name;
		
		int p = placeholder.indexOf(':');
		if (p>-1) {
			scope = placeholder.substring(0,p).trim().toUpperCase();
			name = (p+1<placeholder.length()) ? placeholder.substring(p+1).trim() : "";
		} else {
			scope = "LOCAL";
			name = placeholder.trim();
		}
		
		if (!scope.equals("LOCAL") && !scope.equals("ENTITY") && 
		   !scope.equals("GLOBAL") && !scope.equals("CONFIG"))
		{
			throw new IllegalArgumentException("Invalid placeholder scope : "+scope+"  at placeholder : "+placeholder);
		}
		
		Context localCtx = (ctx.isLocalContext()) ? ctx : null;
		Context entityCtx = (ctx.isEntityContext()) ? ctx : ((ctx.isLocalContext()) ? ctx.getParentContext() : null);
		Context globalCtx = ctx.getGlobalContext();
		
		Object tmp = null;
		String value = null;
		if (scope.equals("LOCAL")) tmp = localCtx.getItem(name);
		else if (scope.equals("ENTITY")) tmp = entityCtx.getItem(name);
		else if (scope.equals("GLOBAL")) tmp = globalCtx.getItem(name);
		else if (scope.equals("CONFIG")) value = SANThread.current().configurator.get(name);
		
		if (tmp!=null && tmp instanceof Object[]) tmp = ((Object[])tmp)[0];
		if (tmp!=null) value = tmp.toString();
		
		return value;
	}
	
	// XXX: 2013-01-11:  +++++    NEEDS IMPROVEMENT !!!!
	public static Object retrieveAttachedObject(org.iccs.san.engine.naive.NaiveEngineSANObject owner, String name, boolean scanHierarchy) {
		if (owner==null) return null;
		Object obj = owner.retrieveObject(name);
		obj = (obj==null) ? owner.getSANObject().retrieveObject(name) : obj;
		if (obj==null && scanHierarchy) {
			org.iccs.san.engine.naive.NaiveEngineSANObject node = owner;
			while ((node=node.getParent())!=null) {
				obj = node.retrieveObject(name);
				obj = (obj==null) ? owner.getSANObject().retrieveObject(name) : obj;
				if (obj!=null) break;
			}
		}
		return obj;
	}
	
	// Other methods
	public void sleep(long millis) {
		try { Thread.currentThread().sleep(millis); }
		catch (InterruptedException e) {}
	}
	
	public void startReplay() {
		if (configurator.cep instanceof ReplayCapable) {
			((ReplayCapable)configurator.cep).startReplay();
		}
	}
}
