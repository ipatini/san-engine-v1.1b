package org.iccs.san.util.sesame;

import org.iccs.san.util.SANThread;

import org.openrdf.model.vocabulary.*;
import org.openrdf.repository.*;
import org.openrdf.repository.http.HTTPRepository;
import org.openrdf.repository.sail.SailRepository;
import org.openrdf.sail.inferencer.fc.ForwardChainingRDFSInferencer;
import org.openrdf.sail.memory.MemoryStore;
import org.openrdf.rio.*;

public class SesameRDFRepository {

	protected Repository therepository= null; 
	
	//useful -local- constants
	public static final RDFFormat NTRIPLES = RDFFormat.NTRIPLES;
	public static final RDFFormat N3 = RDFFormat.N3;
	public static final RDFFormat RDFXML = RDFFormat.RDFXML;
	public static final String RDFTYPE =  RDF.TYPE.toString();
	
	/**
	 *  In memory Sesame repository without type inferencing
	 */
	public SesameRDFRepository(){
		this(false);
	}
	
	/**
	 * In memory Sesame Repository with optional inferencing
	 * @param inferencing
	 */
	public SesameRDFRepository(boolean inferencing){
		try {
			if (inferencing){
				therepository = new SailRepository(new ForwardChainingRDFSInferencer(new MemoryStore()));
			} else {
				therepository = new SailRepository(new MemoryStore());
			}
			therepository.initialize();
		} catch (RepositoryException e) {
			printErr(e);
		}
	}
	
	/**
	 * Connect to remote repository
	 * @param  sesameServer eg. http://localhost:8080/openrdf-sesame
	 * @param  repositoryID
	 */
	public SesameRDFRepository(String sesameServer, String repositoryID) {
		try { 
			therepository = new HTTPRepository(sesameServer, repositoryID);
			therepository.initialize();
		} catch (RepositoryException e) {
			printErr(e);
		}
	}
	
	public Repository getRepository() {
		return this.therepository;
	}
	
	public void setNamespace(String prefix, String name) {
		try {
			RepositoryConnection con = therepository.getConnection();
			try {
				con.setNamespace(prefix, name);
			} finally {
				con.close();
			}
		} catch (Exception e) {
			printErr(e);
		}		
	}
	
	// Print in Error stream
	protected void printErr(Exception e) {
		e.printStackTrace(SANThread.getErr());
	}
}
