package org.iccs.san.util.sesame;

import org.iccs.san.util.SANThread;

import java.io.ByteArrayOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.openrdf.model.Statement;
import org.openrdf.model.URI;
import org.openrdf.model.Value;
import org.openrdf.model.vocabulary.RDF;
import org.openrdf.model.vocabulary.RDFS;
import org.openrdf.repository.RepositoryConnection;
import org.openrdf.repository.RepositoryException;
import org.openrdf.repository.RepositoryResult;
import org.openrdf.rio.RDFFormat;
import javax.xml.datatype.XMLGregorianCalendar;


public class RDFHelper {
	
	public static URI newURI(SesameGraph sg, String base_uri) {
		Calendar now = Calendar.getInstance();
		String key = now.get(now.YEAR) + "-" + now.get(now.MONTH) + "-"
				+ now.get(now.DATE) + "." + now.getTimeInMillis();
		// long key = (new Date()).getTime();
		URI uri = sg.URIref(base_uri + "#" + key);
		// Alternatively we could use blank nodes
		return uri;
	}
	
	public static XMLGregorianCalendar XMLNow() {
		GregorianCalendar gcal = new GregorianCalendar();
		try {
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);
		} catch (DatatypeConfigurationException e) {
			// TODO Auto-generated catch block
			printErr(e);
			return null;
		}
	}
	
	public static void writeTriple(SesameGraph sg, String s, String p, String o) {
		sg.add(sg.URIref(s), sg.URIref(p), sg.URIref(o));
	}
	
	public static void writeTriple(SesameGraph sg, URI s, URI p, URI o) {
		sg.add(s, p, o);
	}
	
	public static void writeNode(SesameGraph sg, String base_uri, String type, Hashtable props) {
		try {
			URI nodeURI = RDFHelper.newURI(sg, base_uri);
			
			sg.add(nodeURI, sg.URIref(SesameGraph.RDFTYPE), sg.URIref(type));
			Iterator it = props.keySet().iterator();
			while (it.hasNext()) {
				Object k = it.next();
				Object v = props.get(k);
				if (k instanceof String && ((String)k).equalsIgnoreCase("timestamp") && v==null) {
					v = RDFHelper.XMLNow();
				}
				sg.add(nodeURI, sg.URIref((String)k), sg.Literal((String)v));
			}
			//sg.add(nodeURI, sg.URIref("log:refers-to"), sg.URIref(nodeURI));

			OutputStream out = new ByteArrayOutputStream();
			sg.dumpRDF(out, sg.N3);
			printOut(out.toString());
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
	}

	protected static void printOut(String mesg) {
		SANThread.getOut().println(mesg);
	}
	
	protected static void printErr(String mesg) {
		SANThread.getErr().println(mesg);
	}
	
	protected static void printErr(Exception ex) {
		ex.printStackTrace(SANThread.getErr());
	}
}
