package org.iccs.san.cep;

import org.iccs.san.api.CEPAT;
import org.iccs.san.api.Expression;
import org.iccs.san.util.Configurator;
import org.iccs.san.util.SANHelper;
import org.iccs.san.util.SANThread;
import java.io.StringReader;
import java.io.IOException;
import java.util.Date;
import java.util.Hashtable;
import java.util.Properties;

/**
 *	A file-based implementation of CEP engine abstraction layer
 */
public class FileCEPEngine implements CEPEngine {
	protected Configurator config;
	protected Hashtable<String,CEPAT> cepats;
	protected Hashtable<String,Properties> properties;
	protected boolean online;
	
	public FileCEPEngine() {
		cepats = new Hashtable<String,CEPAT>();
		properties = new Hashtable<String,Properties>();
		online = true;
	}
	
	public Configurator getConfigurator() { return config; }
	public void setConfigurator(Configurator cfg) { config = cfg; }
	
	public void startEngine() { }
	public void stopEngine() { }
	public boolean isOnline() { return this.online; }
	public void setOnline(boolean onOff) { this.online = onOff; }
	
	public synchronized void deployCEPAT(CEPAT cepat) {
		// Check if CEPAT is already deployed
		String uri = cepat.getObjectURI();
		if (cepats.containsKey(uri)) {
			logError("FileCEPEngine: deployCEPAT: CEPAT already exists: URI = "+uri);
			throw new RuntimeException("FileCEPEngine: deployCEPAT: CEPAT already exists: URI = "+uri);
		}
		
		// Evaluate CEPAT expression
		Expression expr = cepat.getDefinition();
		Object val = config.engine.evaluateExpression(expr);
		expr.setValue( val );
		logInfo("FileCEPEngine: deployCEPAT: dialect='"+expr.getDialect()+"', definition='"+expr.getDefinition()+"'");
		logInfo("FileCEPEngine: deployCEPAT: CEPAT='"+expr.getValue()+"'");
		
		// Deploy new CEPAT
		Properties prop = new Properties();
		prop.put("uri", uri);
		prop.put("iterations", "0");
		prop.put("deployment-time", (new Date()).toString());
		
		cepats.put(uri, cepat);
		properties.put(uri, prop);
		
		logInfo("FileCEPEngine: deployCEPAT: CEPAT '"+uri+"' deployed");
	}
	
	public synchronized void undeployCEPAT(CEPAT cepat) {
		String uri = cepat.getObjectURI();
		if (cepats.containsKey(uri)) {
			// Interrupt any waiting thread or Cancel CEPAT undeploy by throwing an Exception
// TODO : see the comment above
			
			// Undeploy CEPAT
			cepats.remove(uri);
			properties.remove(uri);
			logInfo("FileCEPEngine: deployCEPAT: CEPAT '"+uri+"' undeployed");
		} else {
			logError("FileCEPEngine: deployCEPAT: CEPAT '"+uri+"' was NOT FOUND");
		}
	}
	
	public void registerToCEPAT(CEPAT cepat) { }
	public void unregisterFromCEPAT(CEPAT cepat) { }
	
	public Event waitForEvent(CEPAT cepat) throws InterruptedException {
		String uri = cepat.getObjectURI();
		String nam = cepat.getName();
		nam = (nam!=null) ? nam+" " : "";
		
		Properties prop = properties.get(uri);
		int iter = Integer.parseInt( prop.getProperty("iterations") );
		
		String fileName;
		String eventsDir = config.get("cep-engine.file.events-dir").trim();
		String sep = System.getProperty("file.separator");
		sep = (sep==null || sep.trim().equals("")) ? "/" : sep;
		String cmdFile = eventsDir+sep+Integer.toString((int)(Math.abs(Math.random()*1000)+iter))+".txt";
		iter++;
		prop.setProperty("iterations", Integer.toString(iter));
		Properties eventProps = null;
		
		do {
			synchronized (properties) {
// XXX - TODO : Normally we MUST NOT do this. Multiple waits on a single CEPAT are allowed
				if (prop.containsKey("lock-file")) throw new RuntimeException("FileCEPEngine: waitForEvent: ANOTHER THREAD IS WAITING ON THIS CEPAT: "+uri);
				prop.put("lock-file", cmdFile);
				prop.put("lock-thread", org.iccs.san.util.SANThread.current().toString());
				prop.put("cepat-name", cepat.getName());
				prop.put("cepat-uri", cepat.getObjectURI());
			}
			
			logInfo("FileCEPEngine: waitForEvent: Waiting for an event on CEPAT: "+nam);
			logInfo("Write the path to event file, in command file: "+cmdFile);
			do {
				try {
					fileName = SANHelper.loadFile(cmdFile);
					if (!this.online) fileName = null;
				} catch (Exception ex) { fileName = null; }
				Thread.currentThread().sleep(1000);
				if (fileName!=null && fileName.trim().equals("")) fileName = null;
			} while (fileName==null);
			
			logInfo("");
			logInfo("FileCEPEngine: waitForEvent: Event received on CEPAT: "+nam);
			try {
				eventProps = processEventFile(fileName);
			} catch (Exception ex) {
				logError(ex);
				eventProps = null;
			}
			if (eventProps==null) logError("File could not be processed: "+fileName);
			
			synchronized (properties) {
				prop.remove("lock-file");
				prop.remove("lock-thread");
				prop.remove("cepat-name");
				prop.remove("cepat-uri");
			}
		} while (eventProps==null);
		logInfo("FileCEPEngine: waitForEvent: Event received and processed on CEPAT: "+nam);
		
		// Create Complex Event
		SimpleEvent event = new SimpleEvent(cmdFile+" /// "+cepat.getName(), cepat.getObjectURI());
		event.setReceiveTimestamp( new Date() );
		event.setComplex(true);
		event.setCEPAT(cepat);
		event.setSemantics(new Properties());
		event.setPayload(eventProps);
		event.setPayloadType("NVP");		// NVP: Name-Value Pairs
		
		return event;
	}
	
	protected Properties processEventFile(String fileName) {
		try {
			String contents = SANHelper.loadFile(fileName);
			logInfo("FileCEPEngine: processEventFile: filename="+fileName+"\n");
			logInfo(contents+"\n");
			Properties payload = new Properties();
			payload.load(new StringReader(contents));
			
			return payload;
		} catch (Exception ex) {
			logError(ex);
			return null;
		}
	}
	
	public boolean sendEvent(Event event) {
		try {
			String id = event.getEventId();
			if (id==null) {
				logError("Event Id is NULL");
				return false;
			}
			String cmd = config.get("cep-engine.file.cmd");
			if (cmd==null) {
				logError("No command is defined in configuration file (at 'cep-engine.file.cmd' entry)");
				return false;
			}
			cmd = cmd.format(cmd, id);
			logInfo("Issuing command to system: "+cmd);
			Runtime.getRuntime().exec(cmd);
			return true;
		} catch (IOException ex) {
			logError(ex);
			return false;
		}
	}
	
	public void eventReceived(String notify) {
		// NOT IMPLEMENTED
	}
	
	public CEPAT[] getDeployedCEPAT() {
		if (cepats==null || cepats.size()==0) return null;
		
		CEPAT[] tmp = new CEPAT[ cepats.size() ];
		return cepats.values().toArray(tmp);
	}
	
	public Properties getCEPATStatus(CEPAT cepat) {
		if (!cepats.containsKey(cepat.getObjectURI())) return null;
		return properties.get(cepat.getObjectURI());
	}
	
	public SANThread[] getCEPATWaitingThreads(CEPAT cepat) {
		if (!cepats.containsKey(cepat.getObjectURI())) return null;
		throw new RuntimeException("FileCEPEngine: getCEPATWaitingThreads: NOT YET IMPLEMENTED!!!");
	}
	
	protected void logInfo(String mesg) {
		SANThread.getOut().println(mesg);
	}
	
	protected void logError(String mesg) {
		SANThread.getErr().println(mesg);
	}
	
	protected void logError(Exception ex) {
		ex.printStackTrace(SANThread.getErr());
	}
}
