/**
 *	CEP engine abstraction layer for DSB Pub/Sub
 */
package org.iccs.san.cep;

import org.iccs.san.api.CEPAT;
import org.iccs.san.api.Expression;
import org.iccs.san.util.Configurator;
import org.iccs.san.util.SANHelper;
import org.iccs.san.util.SANThread;
import org.iccs.san.util.sesame.*;
import org.iccs.dsb.DsbPubSubHelper;
import org.iccs.dsb.LoopbackPubSubHelper;
import org.iccs.dsb.EventReceiver;

import java.io.StringReader;
import java.io.IOException;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

import javax.xml.XMLConstants;
import javax.xml.namespace.QName;
import javax.xml.transform.TransformerException;
import com.ebmwebsourcing.easycommons.xml.XMLHelper;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.NotificationMessageHolderType;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.NotificationMessageHolderType.Message;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.Notify;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.TopicExpressionType;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.abstraction.Unsubscribe;
import com.ebmwebsourcing.wsstar.basenotification.datatypes.api.utils.WsnbException;
import com.ebmwebsourcing.wsstar.wsnb.services.impl.util.Wsnb4ServUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import org.openrdf.model.Resource;
import org.openrdf.repository.Repository;
import org.openrdf.repository.RepositoryConnection;
import org.openrdf.rio.RDFFormat;

/**
 *	Pub/Sub implementation of CEP engine abstraction layer, for DSB communication
 */
public class DsbCEPEngine implements CEPEngine, EventReceiver, ReplayCapable {
	
	protected Configurator config;
	protected Hashtable<String,CEPAT>  cepats;
	protected Hashtable<String,Vector<SANThread>>  blockedThreads;
	protected Hashtable<String,Properties> properties;
	protected Hashtable<String,Event> events;
	protected Hashtable<String,Vector<String>> topics;
	protected Hashtable<String,String> UUIDs;
	protected Object lock;
	protected DsbPubSubHelper dsbHelper;
	protected boolean debugEvents;
	protected boolean printXml;
	protected boolean online;
	
	protected Hashtable<String,EventManager>	managers;
	
	// Sesame repository for storing events' RDF payloads
	public static final SesameRDFRepository rep = new SesameRDFRepository(false);
	public static final SesameGraph sg = new SesameGraph(rep.getRepository());
	
	public DsbCEPEngine() {
	}
	
	public Configurator getConfigurator() { return config; }
	public void setConfigurator(Configurator cfg) { config = cfg; }
	
	public void startEngine() {
		cepats = new Hashtable<String,CEPAT>();
		blockedThreads = new Hashtable<String,Vector<SANThread>>();
		properties = new Hashtable<String,Properties>();
		events = new Hashtable<String,Event>();
		topics = new Hashtable<String,Vector<String>>();
		UUIDs = new Hashtable<String,String>();
		lock = new Object();
		online = true;
		managers = new Hashtable<String,EventManager>();
		
		debugEvents = config.getBoolean("cep-engine.dsb.DEBUG_EVENTS", false);
		printXml = config.getBoolean("cep-engine.dsb.PRINT_XML", false);
		
		// Start DSB notification consumer WS...
		try {
			Properties dsbProperties = config.getScope("cep-engine.dsb", true);
			dsbHelper = DsbPubSubHelper.getInstance(this, dsbProperties);
			dsbHelper.startEndpointWS();
		} catch (Exception ex) {
			throw new RuntimeException("DsbCEPEngine: startEngine: Failed to start DSB notification consumer WS. Reason:", ex);
		}
	}
	
	public void stopEngine() {
		managers = null;
		online = false;
		
		dsbHelper.stopEndpointWS();
		dsbHelper = null;
		
		cepats = null;
		blockedThreads = null;
		properties = null;
		events = null;
		topics = null;
		UUIDs = null;
		lock = null;
	}
	
	public boolean isOnline() { return this.online; }
	public void setOnline(boolean onOff) { this.online = onOff; }
	
	public void deployCEPAT(CEPAT cepat) {
		synchronized (lock) {
			// Check if CEPAT is already deployed
			String uri = cepat.getObjectURI();
			if (cepats.containsKey(uri)) {
				logError("DsbCEPEngine: deployCEPAT: CEPAT already deployed: URI = "+uri);
				return;
			}
			
			// Evaluate new CEPAT
			Expression expr = cepat.getDefinition();
			String dialect = expr.getDialect();
			String definition = expr.getDefinition();
			Object val = config.engine.evaluateExpression(expr);
			expr.setValue( val );
			String name = cepat.getName();
			name = (name==null) ? uri : name;
			logInfo("DsbCEPEngine: deployCEPAT: CEPAT name='"+name+"', dialect='"+expr.getDialect()+"', definition='"+expr.getDefinition()+"'");
			logInfo("DsbCEPEngine: deployCEPAT: CEPAT name='"+name+"', value='"+expr.getValue()+"'");
			
			// Deploy new CEPAT
			Properties prop = new Properties();
			prop.put("uri", uri);
			prop.put("iterations", "0");
			prop.put("deployment-time", (new Date()).toString());

// XXX: EXPERIMENT: Deploy cepat to DCEP
if (isReplaying()) {
	QName newTopic = dsbHelper.createTopic( (String)expr.getValue() );
	prop.put("topic", newTopic.toString());
}
			
			cepats.put(uri, cepat);
			blockedThreads.put(uri, new Vector<SANThread>());
			properties.put(uri, prop);
			
// XXX: DEVEL
			// Create an event manager for CEPAT
			managers.put(cepat.getObjectURI(), new EventManager());
			
			logInfo("DsbCEPEngine: deployCEPAT: CEPAT '"+uri+"' deployed");
		}
	}
	
	public void undeployCEPAT(CEPAT cepat) {
		synchronized (lock) {
			String uri = cepat.getObjectURI();
			if (cepats.containsKey(uri)) {
// XXX: EXPERIMENT: Undeploy cepat to DCEP
if (isReplaying()) {
	String oldTopic = null;
	Properties prop = properties.get(uri);
	if (prop!=null) oldTopic = prop.getProperty("topic");
	if (oldTopic!=null && !oldTopic.equals("")) {
//org.iccs.san.util.ActionHelper.getInstance().alert("Dcep: undeployCEPAT:\nOld topic="+oldTopic);
		QName topic = QName.valueOf(oldTopic);
		dsbHelper.destroyTopic(topic);
		prop.remove("topic");
	}
}
				
// XXX: DEVEL
				// Dispose event manager for CEPAT
// XXX: commented to bypass a concurrency bug
//				managers.remove(cepat.getObjectURI());
				
				// Check if other threads are waiting on this CEPAT
// XXX: EXPERIMENT: hack to bypass a bug!!
// XXX: SOS !!!!
/*				if (blockedThreads.get(uri).size()>0) {
					logInfo("DsbCEPEngine: undeployCEPAT: CEPAT '"+uri+"' is still in use");
					return;
				}*/
				
				// Undeploy CEPAT
				cepats.remove(uri);
				blockedThreads.remove(uri);
				properties.remove(uri);
				events.remove(uri);
				logInfo("DsbCEPEngine: undeployCEPAT: CEPAT '"+uri+"' undeployed");
			} else {
				logError("DsbCEPEngine: undeployCEPAT: CEPAT '"+uri+"' was NOT FOUND");
			}
		}
	}
	
	public void registerToCEPAT(CEPAT cepat) {
		synchronized (lock) {
			String uri = cepat.getObjectURI();
			if (cepats.containsKey(uri)) {
				if (!blockedThreads.get(uri).contains( SANThread.current() )) {
// XXX: MOVED TO waitForEvent
//					blockedThreads.get(uri).add( SANThread.current() );
					
					QName topic = getTopicFromCepat(cepat);
					String topicStr = topic.toString();
					Vector<String> v;
					if (!topics.containsKey(topicStr)) {
						v = new Vector<String>();
logInfo("AAAAAAAAA  "+topicStr);
						topics.put(topicStr, v);
					} else {
						v = topics.get(topicStr);
logInfo("BBBBBBBBBB  "+topicStr);
					}
					v.add(uri);
logInfo("CCCCCCCCCCC  "+uri);
					logInfo("DsbCEPEngine: registerToCEPAT: Registering for TOPIC="+topic);
					String UUID = dsbHelper.subscribeFor(topic);
					UUID = UUID!=null ? UUID : "";
					UUIDs.put(uri, UUID);
					
// XXX: DEVEL
					// add event listener
//					managers.get(cepat.getObjectURI()).addEventListener(SANThread.current());
					
					logInfo("DsbCEPEngine: registerToCEPAT: Thread registered to CEPAT '"+uri+"' for TOPIC="+topic);
				} else {
					logError("DsbCEPEngine: registerToCEPAT: Thread already registered to CEPAT '"+uri+"'");
				}
			} else {
				logError("DsbCEPEngine: registerToCEPAT: CEPAT '"+uri+"' was NOT FOUND");
			}
		}
	}
	
	public void unregisterFromCEPAT(CEPAT cepat) {
		synchronized (lock) {
			String uri = cepat.getObjectURI();
			if (cepats.containsKey(uri)) {
// XXX: MOVED TO waitForEvent
//				blockedThreads.get(uri).remove( SANThread.current() );
				
// XXX: DEVEL
				// remove event listener
//				managers.get(cepat.getObjectURI()).removeEventListener(SANThread.current());
				
				QName topic = getTopicFromCepat(cepat);
				String topicStr = topic.toString();
				logInfo("DsbCEPEngine: unregisterFromCEPAT: Unregistering from TOPIC="+topic);
				Vector<String> v = topics.get(topicStr);
				if (v!=null) {
					v.remove(uri);
					if (v.size()==0) topics.remove(topicStr);
					String UUID = UUIDs.remove(uri);
					if (UUID!=null && !UUID.equals("")) {
						if (dsbHelper.unsubscribeFrom(topic, UUID)) {
							logInfo("DsbCEPEngine: unregisterFromCEPAT: Thread unregistered from CEPAT '"+uri+"' for TOPIC="+topic);
						} else {
							logInfo("DsbCEPEngine: unregisterFromCEPAT: Thread FAILED to unregistered from CEPAT '"+uri+"' for TOPIC="+topic);
						}
					} else {
						logError("DsbCEPEngine: unregisterFromCEPAT: Subscription Id (UUID) NOT FOUND: "+UUID);
					}
				}
			} else {
				logError("DsbCEPEngine: unregisterFromCEPAT: CEPAT '"+uri+"' was NOT FOUND");
			}
		}
	}
	
	public Event waitForEvent(CEPAT cepat) throws InterruptedException {
		String uri = cepat.getObjectURI();
		String nam = cepat.getName();
		nam = (nam!=null) ? nam+" " : "";
		
		Properties prop = properties.get(uri);
		String val = prop.getProperty("waits");
		int iter = (val==null) ? 0 : Integer.parseInt( val );
		prop.setProperty("waits", Integer.toString(++iter));
		
		logInfo("DsbCEPEngine: waitForEvent: Waiting on CEPAT '"+nam+"': SAN execution blocks.");
		Event event = null;
		synchronized (cepat) {
			// populate cepat properties
			synchronized (properties) {
				QName topic = getTopicFromCepat(cepat);
				prop.put("topic", topic.toString());
				/*prop.put("lock-file", topic.getLocalPart());
				prop.put("lock-thread", SANThread.current().toString());*/
				prop.put("cepat-name", cepat.getName());
				prop.put("cepat-uri", cepat.getObjectURI());
				
				SANThread.current().lock = topic.getLocalPart();
				blockedThreads.get(uri).add( SANThread.current() );
			}
			
// XXX:  IMPROVE!!!   Prefer an AWT-style event listener model or a Producer-Consumer model (more preferrable)
			// wait for event
//			cepat.wait();
// XXX: DEVEL
			// wait for event
			String tmp = "{{ LOCK OBJECT: "+(new Date())+"/"+Math.random()+": cepat="+cepat.getName()+", uri="+cepat.getObjectURI()+", thread="+SANThread.current()+" }}";
			try {
				managers.get(cepat.getObjectURI()).addEventListener(tmp);
				event = managers.get(cepat.getObjectURI()).nextEvent(tmp);
			} finally {
				managers.get(cepat.getObjectURI()).removeEventListener(tmp);
			}
			
			// clear cepat properties
			synchronized (properties) {
				blockedThreads.get(uri).remove( SANThread.current() );
				
				/*prop.remove("topic");
				prop.remove("lock-file");
				prop.remove("lock-thread");
				prop.remove("cepat-name");
				prop.remove("cepat-uri");*/
			}
		}
		logInfo("");
		logInfo("DsbCEPEngine: waitForEvent: CEPAT '"+nam+"': SAN execution resumed.");
//		Event event = events.get(uri);
		
		return event;
	}
	
	public synchronized void eventReceived(Notify notify) throws WsnbException {
		if (debugEvents) {
			logInfo("DsbCEPEngine: EVENT RECEIVED: "+org.iccs.san.util.ActionHelper.formatW3CDateTime(new Date())+" :");
			
			/*
			 *	From Nick's code
			 */
			// get the DOM from the bean
			Document dom = Wsnb4ServUtils.getWsnbWriter().writeNotifyAsDOM(notify);
			String notifyXml = null;
			try {
				notifyXml = XMLHelper.createStringFromDOMDocument(dom);
				if (printXml) {
					logInfo("------------------------------------------------------------------------------");
					logInfo(notifyXml);
					logInfo("------------------------------------------------------------------------------");
				}
			} catch (TransformerException e) {
				//e.printStackTrace();
				logError(e);
			}
		}
		
		// check if engine is online
		if (!this.online) return;
		
		// get the topic
		List<NotificationMessageHolderType> messages = notify.getNotificationMessage();
		for (NotificationMessageHolderType notificationMessageHolderType : messages) {
			TopicExpressionType targetTopic = notificationMessageHolderType.getTopic();
			// topic content is something like 'prefix:Name'
			//logInfo("Target topic : " + targetTopic.getContent());
			// you must get the prefix and the NS from the topicNamespaces
			//logInfo(targetTopic.getTopicNamespaces().toString());
			
			// extract topic indices
			String namespaceURI = XMLConstants.NULL_NS_URI;
			String localPart = null;
			String prefix = XMLConstants.DEFAULT_NS_PREFIX;
			
			// get topic prefix and local part
			// targetTopic content is something like 'prefix:Name'
			String content = targetTopic.getContent();
			int p = content.indexOf(":");
			if (p>0) {
				localPart = content.substring(p+1);
				prefix = content.substring(0, p);
			} else {
				localPart = content;
				prefix = "";
			}
			
			// get topic namespace. If many namespaces exist then we choose the one 
			// with a prefix matching the local part's prefix. If no such namespace
			// exists then when leave NULL_NS_URI
			for (QName ns : targetTopic.getTopicNamespaces()) {
				String nsPrefix = ns.getLocalPart();
				if (nsPrefix.equals(prefix)) {
					namespaceURI = ns.getNamespaceURI();
					break;
				}
			}
			
			QName topic = new QName(namespaceURI, localPart, prefix);
			logInfo("TOPIC : " + topic);
			
			// find CEPAT's using this topic
logInfo("DDDDDDDDDDDDD  "+topic.toString());
			Vector<String> v = topics.get(topic.toString());
// dirty hack!!!!
// XXX: IMPROVE !!!!!
if (v==null) {
logInfo("EEEEEEEEEEEEE  IS NULL  "+topic.toString());
	String uuu = topic.getNamespaceURI();
	if (uuu.endsWith("/")) uuu = uuu.substring(0,uuu.length()-1);
	else uuu+="/";
	String ttt = "{"+uuu+"}"+topic.getLocalPart();
logInfo("FFFFFFFFFFFFFFF  ALSO TRYING  "+ttt);
	v = topics.get(ttt);
if (v==null)
logInfo("GGGGGGGGGGGGGGGGGGG  IS STILL NULL  for "+ttt);
}
			if (v==null) continue;
			Enumeration en = v.elements();
			while (en.hasMoreElements()) {
				String uri = (String)en.nextElement();
				if (uri==null) continue;
				CEPAT cepat = this.cepats.get(uri);
				if (cepat==null) continue;
				
				// Event filtering based on the XML payload content
				String filter = _getTopicFromCepat(cepat)[3];
				if (!filter.equals("")) {
					Element businessMessage = notificationMessageHolderType.getMessage().getAny();
					try {
						String xml = XMLHelper.createStringFromDOMNode(businessMessage);
						if (xml.indexOf(filter)<0) {
							if (debugEvents) logInfo("EVENT REJECTED:  due to filter: "+filter);
							continue;
						} else 
						if (debugEvents) {
							logInfo("EVENT ACCEPTED:");
						}
						
						if (printXml) {
							logInfo("------------------------------------------------------------------------------");
							logInfo(xml);
							logInfo("------------------------------------------------------------------------------");
						}
					} catch (TransformerException e) {
						logError(e);
					}
				}
				
				// Process the business message
				Message message = notificationMessageHolderType.getMessage();
				processMessage(message, cepat, topic);
			}
		}
	}
	
	protected void processMessage(Message message, CEPAT cepat, QName topic) {
		logInfo("\n@@  EVENT RECEIVED for CEPAT='"+cepat.getObjectURI()+"'");
		logInfo("@@  TOPIC : " + topic);
		
		// Print the business message elements
		if (config.getBoolean("cep-engine.dsb.PRINT_XML", false)) {
			logInfo("@@  The business message : ");
			Element businessMessage = message.getAny();
			try {
				String xml = XMLHelper.createStringFromDOMNode(businessMessage);
				logInfo(xml);
			} catch (TransformerException e) {
				//e.printStackTrace();
				logError(e);
			}
		}
		
		// Prepare event
		Event event = prepareEvent(message, cepat, topic);
		if (event==null) {
			logError("DsbCEPEngine: eventReceived: Event could not be processed");
			return;
		}
		String eid = event.getEventId();
		logInfo("DsbCEPEngine: eventReceived: Event received and processed: Event id: '"+eid+"'");
		
		// Get referred CEPAT
		cepat = event.getCEPAT();
		String uri = cepat.getObjectURI();
		String name = cepat.getName();
		
		if (cepat==null) {
			logError("DsbCEPEngine: eventReceived: Related CEPAT '"+name+"' was NOT FOUND, for event '"+eid+"'");
			return;
		}
		
// XXX: DEVEL
		// Notify registered threads
		managers.get(cepat.getObjectURI()).dispatchEvent(event);
		
		// Store event for thread processing
		/*events.put(uri, event);
		
		// Notify registered threads
		logInfo("DsbCEPEngine: eventReceived: Notifing threads waiting on related CEPAT '"+name+"', for event '"+eid+"'");
		synchronized (cepat) {
			cepat.notifyAll();
		}
		
		// Remove event after thread processing
// XXX: IMPROVE !!!!
		try { Thread.sleep(100); } catch (InterruptedException ex) {}
		events.remove(uri);
		*/
	}
	
	protected Event prepareEvent(Message message, CEPAT cepat, QName topic) {
		// Create and initialize an event object
		try {
			String uri = cepat.getObjectURI();
			String name = cepat.getName();
			
			SimpleEvent event = new SimpleEvent(name, uri, topic);
			event.setReceiveTimestamp( new Date() );
			event.setComplex(true);
			event.setCEPAT(cepat);
			event.setSemantics(new Properties());
			Element businessMessage = message.getAny();
			if (businessMessage!=null) {
				if (businessMessage.getLocalName().toUpperCase().equals("EVENT-BODY")) {
					Node node = businessMessage.getFirstChild();
					while (node!=null) {
						if (node.getNodeType()==node.ELEMENT_NODE) {
							businessMessage = (Element)node;
							break;
						}
						node = node.getNextSibling();
					}
					if (node==null) {
						businessMessage = null;
						throw new RuntimeException("DsbCEPEngine: prepareEvent: Unexpected Event XML format. Expected an XML ELEMENT inside EVENT-BODY");
					}
				}
				event.setPayload(businessMessage);
				event.setPayloadType("RDF");		// DSB delivers events with RDF payload
			}
			
			return event;
		} catch (Exception ex) {
			logError(ex);
			return null;
		}
	}
	
	/*
	 *  The next three methods are the Replay Mode counterparts of
	 *  eventReceived, processMessage, and prepareEvent
	 */
	public synchronized void eventReceived(String notify) {
		// check if engine is online
		if (!this.online) return;
		
		// extract topic indices
		String namespaceURI = XMLConstants.NULL_NS_URI;
		String localPart = null;
		String prefix = XMLConstants.DEFAULT_NS_PREFIX;
		
// XXX: TODO: REGEX gia na pernei to TOPIC
int p1;
String[] targetTopic = notify.substring(1, p1=notify.indexOf("}\n")).split(" ");
namespaceURI = targetTopic[0];
localPart = targetTopic[1];
prefix = targetTopic[2];
		
		QName topic = new QName(namespaceURI, localPart, prefix);
		
		// find CEPAT's using this topic
		Vector<String> v = topics.get(topic.toString());
		if (v==null) return;
// XXX: TODO:  REGEX gia na paroume to payload toy notification
String businessMessage = notify.substring(p1+2);
		Enumeration en = v.elements();
		while (en.hasMoreElements()) {
			String uri = (String)en.nextElement();
			if (uri==null) continue;
			CEPAT cepat = this.cepats.get(uri);
			if (cepat==null) continue;
			
			// Event filtering based on the XML payload content
			String filter = _getTopicFromCepat(cepat)[3];
			if (!filter.equals("")) {
				try {
					String xml = businessMessage;
					if (xml.indexOf(filter)<0) {
						if (debugEvents) logInfo("EVENT REJECTED:");
						continue;
					} else 
					if (debugEvents) {
						logInfo("EVENT ACCEPTED:");
					}
					
					if (printXml) {
						logInfo("------------------------------------------------------------------------------");
						logInfo(xml);
						logInfo("------------------------------------------------------------------------------");
					}
				} catch (Exception e) {
					logError(e);
				}
			}
			
			// Process the business message
			String message = businessMessage;
			processMessage(message, cepat, topic);
		}
	}
	
	protected void processMessage(String message, CEPAT cepat, QName topic) {
		logInfo("\n@@  EVENT RECEIVED for CEPAT='"+cepat.getObjectURI()+"'");
		logInfo("@@  TOPIC : " + topic);
		
		// Prepare event
		Event event = prepareEvent(message, cepat, topic);
		if (event==null) {
			logError("DsbCEPEngine: eventReceived: Event could not be processed");
			return;
		}
		String eid = event.getEventId();
		logInfo("DsbCEPEngine: eventReceived: Event received and processed: Event id: '"+eid+"'");
		
		// Get referred CEPAT
		cepat = event.getCEPAT();
		String uri = cepat.getObjectURI();
		String name = cepat.getName();
		
		if (cepat==null) {
			logError("DsbCEPEngine: eventReceived: Related CEPAT '"+name+"' was NOT FOUND, for event '"+eid+"'");
			return;
		}
		
// XXX: DEVEL
		// Notify registered threads
		managers.get(cepat.getObjectURI()).dispatchEvent(event);
	}
	
	protected Event prepareEvent(String message, CEPAT cepat, QName topic) {
		// Create and initialize an event object
		try {
			String uri = cepat.getObjectURI();
			String name = cepat.getName();
			
			SimpleEvent event = new SimpleEvent(name, uri, topic);
			event.setReceiveTimestamp( new Date() );
			event.setComplex(true);
			event.setCEPAT(cepat);
			event.setSemantics(new Properties());
			if (message!=null && !message.trim().equals("")) {
				event.setPayload(message);
				event.setPayloadType("RDF");
			}
			
			return event;
		} catch (Exception ex) {
			logError(ex);
			return null;
		}
	}
	
	// Publish an event to DSB
	public boolean sendEvent(Event event) {
		QName topic = event.getTopic();
		String content = event.getContent();
		if (topic==null || content==null) {
			logError("DsbCEPEngine: sendEvent: Event topic and content should NOT be null");
			return false;
		}
		return dsbHelper.publishEvent(topic, content);
	}
	
	protected QName getTopicFromCepat(CEPAT cepat) {
// XXX: EXPERIMENT: Get topic from CEPAT
String uri = cepat.getObjectURI();
Properties prop = properties.get(uri);
String topicStr = null;
if (prop!=null) topicStr = prop.getProperty("topic");
if (topicStr!=null) {
	QName topic = QName.valueOf(topicStr);
	return topic;
}
		
		String[] tmp = _getTopicFromCepat(cepat);
		return new QName(tmp[0], tmp[1], tmp[2]);
	}
	
	protected String[] _getTopicFromCepat(CEPAT cepat) {
// XXX: EXPERIMENT: Get topic from CEPAT
String uri = cepat.getObjectURI();
Properties prop = properties.get(uri);
String topicStr = null;
if (prop!=null) topicStr = prop.getProperty("topic");
if (topicStr!=null) {
	QName topic = QName.valueOf(topicStr);
	String[] topicPart = new String[4];
	topicPart[0] = topic.getNamespaceURI();
	topicPart[1] = topic.getLocalPart();
	topicPart[2] = topic.getPrefix();
	topicPart[3] = "";
	return topicPart;
}
		String dialect = cepat.getDefinition().getDialect();
		if (dialect!=null && !dialect.trim().equalsIgnoreCase("default")) return null;
		
		String cepatExpr = (String)cepat.getDefinition().getValue();
		if (cepatExpr==null) cepatExpr = (String)config.engine.evaluateExpression( cepat.getDefinition() );
		
		String[] tmp = cepatExpr.split("[ \t,]", 4);
		String[] topicPart = new String[4];
		topicPart[0] = XMLConstants.NULL_NS_URI;		// topic namespace uri
		topicPart[1] = "";								// topic local part
		topicPart[2] = XMLConstants.DEFAULT_NS_PREFIX;	// topic prefix
		topicPart[3] = "";								// additional content (non-topic related)
		
		if (tmp.length==1) {
			topicPart[1] = tmp[0].trim();	// local part
		} else 
		if (tmp.length==2) {
			topicPart[1] = tmp[0].trim();	// local part
			topicPart[3] = tmp[1].trim();	// additional content
		} else
		if (tmp.length==3) {
			topicPart[0] = tmp[0].trim();	// namespace uri
			topicPart[1] = tmp[1].trim();	// localpart
			topicPart[2] = tmp[2].trim();	// prefix
		} else {
			topicPart[0] = tmp[0].trim();	// namespace uri
			topicPart[1] = tmp[1].trim();	// localpart
			topicPart[2] = tmp[2].trim();	// prefix
			topicPart[3] = tmp[3].trim();	// additional content
		}
		return topicPart;
	}
	
	public CEPAT[] getDeployedCEPAT() {
		if (cepats==null || cepats.size()==0) return null;
		
		CEPAT[] tmp = new CEPAT[ cepats.size() ];
		return cepats.values().toArray(tmp);
	}
	
	public Properties getCEPATStatus(CEPAT cepat) {
		if (!cepats.containsKey(cepat.getObjectURI())) return null;
		return properties.get(cepat.getObjectURI());
	}
	
	public SANThread[] getCEPATWaitingThreads(CEPAT cepat) {
		if (!cepats.containsKey(cepat.getObjectURI())) return null;
		Vector<SANThread> vect = blockedThreads.get(cepat.getObjectURI());
		if (vect==null) return null;
		SANThread[] arr = new SANThread[vect.size()];
		return vect.toArray(arr);
	}
	
	// ReplayCapable methods
	public boolean isReplaying() { return dsbHelper.isReplaying(); }
	public boolean isBatchReplay() { return dsbHelper.isBatchReplay(); }
	public boolean exitAfterReplay() { return dsbHelper.exitAfterReplay(); }
	public boolean hasNextEvent() { return dsbHelper.hasNextEvent(); }
	public boolean hasCompleted() { return dsbHelper.hasCompleted(); }
	public boolean replayNextEvent() { return dsbHelper.replayNextEvent(); }
	public boolean replayNextEvents(int num) { return dsbHelper.replayNextEvents(num); }
	public void startReplay() { dsbHelper.startReplay(); }
	public void stopReplay() { dsbHelper.stopReplay(); }
	
	protected void logInfo(String mesg) {
		SANThread.getOut().println(mesg);
	}
	
	protected void logError(String mesg) {
		SANThread.getErr().println(mesg);
	}
	
	protected void logError(Exception ex) {
		ex.printStackTrace(SANThread.getErr());
	}
}
