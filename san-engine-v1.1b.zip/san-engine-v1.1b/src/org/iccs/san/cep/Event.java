package org.iccs.san.cep;

import org.iccs.san.api.CEPAT;
import java.util.Date;
import java.util.Properties;
import javax.xml.namespace.QName;

/**
 *	The Event interface
 */
public interface Event {
	public abstract String getEventId();
	public abstract String getSource();
	public abstract Date getSendTimestamp();
	public abstract Date getReceiveTimestamp();
	public abstract CEPAT getCEPAT();
	public abstract boolean isComplex();
	public abstract Properties getSemantics();
	public abstract String getContent();
	public abstract QName getTopic();
	public abstract Object getPayload();
	public abstract String getPayloadType();
}
