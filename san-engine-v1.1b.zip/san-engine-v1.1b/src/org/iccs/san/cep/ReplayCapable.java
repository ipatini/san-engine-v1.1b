package org.iccs.san.cep;

/**
 *	CEPEngines capable to replay past events should implement this interface
 */
public interface ReplayCapable {
	public abstract boolean isReplaying();
	public abstract boolean isBatchReplay();
	public abstract boolean exitAfterReplay();
	
	public abstract boolean hasNextEvent();
	public abstract boolean hasCompleted();
	public abstract boolean replayNextEvent();
	public abstract boolean replayNextEvents(int num);
	public abstract void startReplay();
	public abstract void stopReplay();
}
