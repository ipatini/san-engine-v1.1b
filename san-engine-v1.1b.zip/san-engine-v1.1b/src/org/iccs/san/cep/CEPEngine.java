package org.iccs.san.cep;

import org.iccs.san.api.CEPAT;
import org.iccs.san.util.Configurator;
import org.iccs.san.util.SANThread;
import java.util.Properties;

/**
 *	The CEPEngine interface
 */
public interface CEPEngine {
	public abstract Configurator getConfigurator();
	public abstract void setConfigurator(Configurator configurator);
	
	public abstract void startEngine();
	public abstract void stopEngine();
	
	public abstract boolean isOnline();
	public abstract void setOnline(boolean onOff);
	
	public abstract void deployCEPAT(CEPAT cepat);	
	public abstract void undeployCEPAT(CEPAT cepat);	
	public abstract void registerToCEPAT(CEPAT cepat);	
	public abstract void unregisterFromCEPAT(CEPAT cepat);	
	public abstract Event waitForEvent(CEPAT cepat) throws InterruptedException;	
	public abstract boolean sendEvent(Event event);
	public void eventReceived(String notify);
	
	public abstract CEPAT[] getDeployedCEPAT();
	public abstract Properties getCEPATStatus(CEPAT cepat);
	public abstract SANThread[] getCEPATWaitingThreads(CEPAT cepat);
}
