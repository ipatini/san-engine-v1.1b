package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;
import java.util.Iterator;
import java.util.Vector;

public class SesameExpression extends SesameSANObject implements org.iccs.san.api.Expression {
	protected String dialect;
	protected String definition;
	protected Vector<Parameter> parameters;
	protected Object value;
	
	public String getDialect() { return dialect; }
	public String getDefinition() { return definition; }
	public Iterator<Parameter> getParameters() { return parameters!=null ? parameters.iterator() : null; }
	public Object getValue() { return value; }
	
	public void setDialect(String dialect) { this.dialect = dialect; }
	public void setDefinition(String expr) { this.definition = expr; }
	public void addParameter(Parameter param) {
		if (parameters==null) parameters = new Vector<Parameter>();
		parameters.add(param);
	}
	public void deleteParameter(Parameter param) {
		if (parameters==null) ;
		parameters.remove(param);
	}
	public void setValue(Object value) { this.value = value; }
	
	public String toString() {
		return super.toString()+" : ["+dialect+"] "+definition;
	}
}
