package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;


public class SesameDecorator extends SesameSANNode implements org.iccs.san.api.Decorator {
	protected String decoratorType;
	
	public String getDecoratorType() { return decoratorType; }	// Isws na min xreiazetai
	
	public SANNode getJob() {		// The job following this decorator
		return this.repository.getGoalJob(this.getObjectURI());
	} // JOB, ennoei Goal, Decorator 'h Action
	
	public void setDecoratorType(String type) { decoratorType = type; }
	public void setJob(SANNode job) { }
}
