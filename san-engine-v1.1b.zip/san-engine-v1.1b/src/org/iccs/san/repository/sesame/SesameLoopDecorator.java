package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;


public class SesameLoopDecorator extends SesameDecorator implements org.iccs.san.api.LoopDecorator {
	public Expression getLoopExpression() { return this.repository.getExpression(getObjectURI(), "loop-condition"); }
	public void setLoopExpression(Expression expr) { }
}
