package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;
import java.util.Iterator;
import java.util.Vector;

public class SesameParameter extends SesameSANObject implements org.iccs.san.api.Parameter {
	protected String source;
	
	public String getSource() { return source; }
	
	public void setSource(String source) { }
	
	public String toString() {
		return super.toString()+" : Sesame-Parameter : source = '"+source+"'";
	}
}
