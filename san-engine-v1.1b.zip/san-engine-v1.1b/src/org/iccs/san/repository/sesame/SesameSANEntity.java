package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;
import org.iccs.san.util.Metadata;
import java.util.Iterator;
import java.util.Properties;

public class SesameSANEntity extends SesameSANObject implements org.iccs.san.api.SANEntity {
	public RootGoal[] getRootGoals() {
		return this.repository.getEntityRootGoals(getObjectURI());
	}
	
	public boolean isAutoStart() {
		return this.repository.getBoolean(getObjectURI(), "auto-start", false);
	}
}
