package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;
import org.iccs.san.context.contextualizer.*;

public class SesameSituation extends SesameSANNode implements org.iccs.san.api.Situation {
	protected CEPAT cepat;
	
	public CEPAT getCEPAT() {
		return cepat;
	}
	
	public void setCEPAT(CEPAT c) {
		this.cepat = c;
	}
	
	public Contextualizer.Descriptor getContextualizerDescriptor(Contextualizer ctxlzr) {
		String ctxlzrType = ctxlzr.getType().toUpperCase();
		
		String uri = this.repository.getObjectUri(getObjectURI(), "hasContextualizer");
		if (uri==null) return null;
		String type = this.repository.getValue(uri, "type");
		if (type==null || type.trim().equals("")) {
			throw new RuntimeException("SesameSituation: getContextualizer: Could not get Contextualizer type. Referenced object might not be a Contextualizer or its 'san:type' attribute might be missed");
		}
		if (!ctxlzrType.equalsIgnoreCase(type)) {
			throw new RuntimeException("SesameSituation: getContextualizer: Identified Contextualizer type ("+ctxlzrType+")  DOES NOT MATCH with Descriptor type ("+type+") in repository");
		}
		
		if (type.equals("RDF")) {
			return new RDFContextualizerDescriptor(uri, this.repository);
		} else
		if (type.equals("NVP")) {
			return new NVPContextualizerDescriptor(uri, this.repository);
		} else
		if (type.equals("XML")) {
			return new XMLContextualizerDescriptor(uri, this.repository);
		} else {
			throw new RuntimeException("SesameSituation: getContextualizerDescriptor: Unknown Contextualizer Descriptor type: "+type);
		}
	}
	
	public Situation.Policy getPolicy() {
		String policy = this.repository.getValue(getObjectURI(), "policy");
		if (policy==null || policy.trim().equals("")) {
			return Situation.Policy.UNDEFINED;
		}
		try {
			return Situation.Policy.valueOf(policy);
		} catch (Exception e) {
			throw new RuntimeException("SesameSituation: getPolicy: Invalid policy specification: "+policy, e);
		}
	}
	
	protected class BaseContextualizerDescriptor {
		protected String uri;
		protected SesameSANRepository repository;
		
		public BaseContextualizerDescriptor(String uri, SesameSANRepository rep) {
			this.uri = uri;
			this.repository = rep;
		}
		
		public String getURI() { return this.uri; }
		public String getContext() { return this.repository.getValue(this.uri, "context"); }
	}
	
	protected class RDFContextualizerDescriptor extends BaseContextualizerDescriptor implements RDFContextualizer.Descriptor 
	{
		public RDFContextualizerDescriptor(String uri, SesameSANRepository rep) { super(uri, rep); }
		
		public RDFContextualizer.Query[] getQueries() {
			String[] qryUri = this.repository.getObjectUriArray(uri, "contextualizer-query");
			if (qryUri==null || qryUri.length==0) {
				return null;
			}
			
			RDFContextualizer.Query[] query = new RDFContextualizer.Query[qryUri.length];
			int i = 0;
			for (String u : qryUri) {
				String qryLang = this.repository.getValue(u, "language");
				Expression qryExpr = this.repository.getExpression(u);
				String qryCtxScope = this.repository.getValue(u, "context");
				query[i++] = new RDFContextualizerDescriptorQuery(u, qryLang, qryExpr, qryCtxScope);
			}
			return query;
		}
	}
	
	protected class RDFContextualizerDescriptorQuery implements RDFContextualizer.Query {
		protected String uri;
		protected String language;
		protected Expression expression;
		protected String context;
		
		public RDFContextualizerDescriptorQuery(String uri, String lang, Expression expr, String ctx) {
			this.uri = uri;
			this.language = lang;
			this.expression = expr;
			this.context = ctx;
		}
		public String getQueryUri() { return this.uri; }
		public String getQueryLanguage() { return this.language; }
		public Expression getQueryExpression() { return this.expression; }
		public String getQueryContext() { return this.context; }
	}
	
	protected class NVPContextualizerDescriptor extends BaseContextualizerDescriptor implements NVPContextualizer.Descriptor 
	{
		public NVPContextualizerDescriptor(String uri, SesameSANRepository rep) { super(uri, rep); }
		
		public String[] getPairNames() {
			String names = this.repository.getValue(uri, "names").trim();
			if (names.equals("*")) { String[] r = new String[1]; r[0] = "*"; return r; }
			String[] name = names.split("[ \t:,=]");
			for (int i=0; i<name.length; i++) name[i] = name[i].trim();
			return name;
		}
	}
	
	protected class XMLContextualizerDescriptor extends BaseContextualizerDescriptor implements XMLContextualizer.Descriptor 
	{
		public XMLContextualizerDescriptor(String uri, SesameSANRepository rep) { super(uri, rep); }
		
		public XMLContextualizer.Query[] getQueries() {
			String[] qryUri = this.repository.getObjectUriArray(uri, "contextualizer-query");
			if (qryUri==null || qryUri.length==0) {
				return null;
			}
			
			XMLContextualizer.Query[] query = new XMLContextualizer.Query[qryUri.length];
			int i = 0;
			for (String u : qryUri) {
				String qryLang = this.repository.getValue(u, "language");
				Expression qryExpr = this.repository.getExpression(u);
				String qryCtxScope = this.repository.getValue(u, "context");
				query[i++] = new XMLContextualizerDescriptorQuery(u, qryLang, qryExpr, qryCtxScope);
			}
			return query;
		}
	}
	
	protected class XMLContextualizerDescriptorQuery implements XMLContextualizer.Query {
		protected String uri;
		protected String language;
		protected Expression expression;
		protected String context;
		
		public XMLContextualizerDescriptorQuery(String uri, String lang, Expression expr, String ctx) {
			this.uri = uri;
			this.language = lang;
			this.expression = expr;
			this.context = ctx;
		}
		public String getQueryUri() { return this.uri; }
		public String getQueryLanguage() { return this.language; }
		public Expression getQueryExpression() { return this.expression; }
		public String getQueryContext() { return this.context; }
	}
}
