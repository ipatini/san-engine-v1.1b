package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameMountAction extends SesameAction implements org.iccs.san.api.MountAction {
	public String getReferencedSAN() { return this.repository.getValue(getObjectURI(), "mount-san"); }
	public void setReferencedSAN(String rootGoal) { }
}
