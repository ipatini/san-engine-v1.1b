package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameTimerDecorator extends SesameDecorator implements org.iccs.san.api.TimerDecorator {
	public long getTimeout() { return Long.parseLong( this.repository.getValue(getObjectURI(), "timeout") ); }
	
	public int getReturnCode() {
		String rcStr = this.repository.getValue(getObjectURI(), "return-code");
		rcStr = (rcStr==null) ? "" : rcStr.trim().toUpperCase();
		int rc;
		if (rcStr.equals("SUCCESS")) {
			rc = SUCCESS;
		} else
		if (rcStr.equals("FAILURE")) {
			rc = FAILURE;
		} else {
			rc = FAILURE;
		}
		return rc;
	}
	
	public void setTimeout(long msec) { }
	public void setReturnCode(int returnCode) { }
}
