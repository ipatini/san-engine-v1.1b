package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameFailureDecorator extends SesameDecorator implements org.iccs.san.api.FailureDecorator {
}
