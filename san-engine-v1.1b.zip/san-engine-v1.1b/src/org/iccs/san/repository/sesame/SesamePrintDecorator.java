package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesamePrintDecorator extends SesameDecorator implements org.iccs.san.api.PrintDecorator {
	public String getMessage() { return this.repository.getValue(getObjectURI(), "message"); }
	public void setMessage(String message) { }
}
