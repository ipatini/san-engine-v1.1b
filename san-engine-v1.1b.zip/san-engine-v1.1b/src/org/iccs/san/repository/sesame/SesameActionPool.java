package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;


public class SesameActionPool extends SesameSANObject implements org.iccs.san.api.ActionPool {
	public SANNode[] getPoolJobs() {
		if (!isDynamic()) {
			return this.repository.getAllJobs(getObjectURI()); 
		} else {
			String query = this.repository.getValue(getObjectURI(), "query");
			String jobCol = this.repository.getValue(getObjectURI(), "job-column");
			return this.repository.getJobsByQuery(getObjectURI(), query, jobCol);
		}
	}
	public void setPoolJobs(SANNode[] jobs) { }
	
	protected boolean isDynamic() {
		String val = this.repository.getValue(getObjectURI(), "is-dynamic");
		if (val==null || val.trim().equals("")) return false;
		else return Boolean.parseBoolean(val);
	}
}
