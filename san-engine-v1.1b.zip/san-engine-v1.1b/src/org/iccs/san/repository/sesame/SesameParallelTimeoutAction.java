package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameParallelTimeoutAction extends SesameCompositeAction implements org.iccs.san.api.ParallelTimeoutAction {
	public long getTimeout() { return Long.parseLong( this.repository.getValue(getObjectURI(), "timeout") ); }
	public void setTimeout(long timeout) { }
}
