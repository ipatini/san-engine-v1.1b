package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameCEPAT extends SesameSANObject implements org.iccs.san.api.CEPAT {
	protected Expression expression = null;
	
	public Expression getDefinition() { 
		if (this.expression==null) this.expression = this.repository.getExpression(getObjectURI()); 
		return this.expression;
	}
	public String[] getInputEventTypes() { return null; }
	public String[] getOutputEventTypes() { return null; }

	public void setDefinition(Expression definition) { }
	public void setInputEventTypes(String[] types) { }
	public void setOutputEventTypes(String[] types) { }
}
