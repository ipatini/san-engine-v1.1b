package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameParallelAllAction extends SesameCompositeAction implements org.iccs.san.api.ParallelAllAction {
}
