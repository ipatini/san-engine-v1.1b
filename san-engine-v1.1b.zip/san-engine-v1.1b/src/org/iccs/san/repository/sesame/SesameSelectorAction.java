package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameSelectorAction extends SesameCompositeAction implements org.iccs.san.api.SelectorAction {
	protected int selectionMethod;
	
	public int getSelectionMethod() { return selectionMethod; }
	public void setSelectionMethod(int method) { selectionMethod = method; }
}
