package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameParallelAnyAction extends SesameCompositeAction implements org.iccs.san.api.ParallelAnyAction {
}
