package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameGoal extends SesameSANNode implements org.iccs.san.api.Goal {
	public Situation getSituation() {
		return this.repository.getSituation(this.getObjectURI());
	}
	
	public ContextCondition getContextCondition() {
		return this.repository.getContextCondition(this.getObjectURI());
	}
	
	public SANNode getJob() {
		return this.repository.getGoalJob(this.getObjectURI());
	} // JOB, ennoei Goal, Decorator 'h Action
	
	public void setSituation(Situation s) { }
	public void setContextCondition(ContextCondition cc) { }
	public void setJob(SANNode job) { }
	
	public void stopGoal() { throw new RuntimeException("SesameGoal: stopGoal: THIS METHOD SHOULD NOT BE INVOKED"); }
}
