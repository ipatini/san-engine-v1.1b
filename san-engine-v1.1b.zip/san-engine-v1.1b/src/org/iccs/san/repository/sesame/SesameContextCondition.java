package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;


public class SesameContextCondition extends SesameSANNode implements org.iccs.san.api.ContextCondition {
	public Expression getExpression() { return this.repository.getExpression(getObjectURI()); }
	public void setExpression(Expression expr) { }
}
