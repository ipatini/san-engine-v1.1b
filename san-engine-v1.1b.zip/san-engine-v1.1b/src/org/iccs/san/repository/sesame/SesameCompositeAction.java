package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameCompositeAction extends SesameAction implements org.iccs.san.api.CompositeAction {
	public SANNode[] getJobs() { return this.repository.getAllJobs(this.getObjectURI()); }
	public void setJobs(SANNode[] jobs) { throw new RuntimeException("SesameCompositeAction: setJobs: NOT IMPLEMENTED"); }
	public void addJob(SANNode job) { throw new RuntimeException("SesameCompositeAction: addJob: NOT IMPLEMENTED"); }

// ENALLAKTIKO ACTION API
	public SANNode getFirstJob() {
		// Query repository to get the first job of the action
		return this.repository.getFirstJob(this.getObjectURI());
	}
	
	public void setFirstJob(SANNode firstJob) { }
}
