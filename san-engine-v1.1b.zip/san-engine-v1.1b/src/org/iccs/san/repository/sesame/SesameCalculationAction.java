package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameCalculationAction extends SesameAction implements org.iccs.san.api.CalculationAction {
	public Expression getExpression() { return this.repository.getExpression(getObjectURI()); }
	public void setExpression(Expression expr) { }
}
