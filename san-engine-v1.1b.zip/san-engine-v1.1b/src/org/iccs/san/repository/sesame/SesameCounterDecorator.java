package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;


public class SesameCounterDecorator extends SesameDecorator implements org.iccs.san.api.CounterDecorator {
	public String getVariable() { return this.repository.getValue(getObjectURI(), "counter-variable"); }
	public int getStartCount() { return Integer.parseInt( this.repository.getValue(getObjectURI(), "counter-start") ); }
	public int getStep() { return Integer.parseInt( this.repository.getValue(getObjectURI(), "counter-step") ); }
	
	public void setVariable(String varName) { }
	public void setStartCount(int startValue) { }
	public void setStep(int step) { }
}
