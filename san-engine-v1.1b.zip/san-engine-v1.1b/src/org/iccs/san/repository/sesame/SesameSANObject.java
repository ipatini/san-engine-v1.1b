package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;
import org.iccs.san.util.Metadata;
import java.util.Iterator;
import java.util.Properties;
import java.util.HashMap;
import java.util.Set;

public class SesameSANObject implements org.iccs.san.api.SANObject {
	protected String objectName;
	protected String objectURI;
	protected String objectType;
	protected Properties objectProperties;
	protected HashMap<String,Object> attached;
	SesameSANRepository repository;
	
	public String getName() { return objectName; }
	public String getObjectURI() { return objectURI; }
	public String getType() { return objectType; }

	public void setName(String name) { objectName = name; }
	public void setObjectURI(String uri) { objectURI = uri; }
	public void setType(String type) { objectType = type; }
	
	public String getProperty(String key) { return this.repository.getValue(getObjectURI(), key); }
	public void setProperty(String key, String value) { }
	
	// Metadata methods
	public Metadata<?> addMetadata(Metadata<?> meta) { return null; }
	public Metadata<?> replaceMetadata(Metadata<?> metaOld, Metadata<?> metaNew) { return null; }
	public Metadata<?> replaceMetadata(String metaOldName, Metadata<?> metaNew) { return null; }
	public Metadata<?> removeMetadata(Metadata<?> meta) { return null; }
	public Metadata<?> removeMetadata(String metaName) { return null; }
	public Metadata<?> getMetadata(String metaName) {
		return this.repository.getMetadata(getObjectURI(), metaName);
	}
	public Iterator<Metadata<?>> getAllMetadata() {
		return this.repository.getAllMetadata(getObjectURI());
	}
	
	// Attached objects methods
	public void attachObject(String name, Object object) { if (attached==null) attached = new HashMap<String,Object>(); attached.put(name, object); }
	public Object detachObject(String name) { if (attached==null) return null; return attached.remove(name); }
	public Object retrieveObject(String name) { if (attached==null) return null; return attached.get(name); }
	public Iterator<String> getObjectNames() { if (attached==null) return null; Set<String> keys = attached.keySet(); return (keys==null) ? null : keys.iterator(); }
	
	public String toString() { return super.toString()+(getName()!=null ? ": "+getName() : ""); }
}
