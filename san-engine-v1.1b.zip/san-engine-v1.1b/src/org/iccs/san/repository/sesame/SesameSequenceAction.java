package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameSequenceAction extends SesameCompositeAction implements org.iccs.san.api.SequenceAction {
}
