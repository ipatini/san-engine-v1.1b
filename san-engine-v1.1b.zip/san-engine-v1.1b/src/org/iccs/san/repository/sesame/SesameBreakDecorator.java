package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameBreakDecorator extends SesameDecorator implements org.iccs.san.api.BreakDecorator {
	public String getMessage() { return this.repository.getValue(getObjectURI(), "message"); }
	public void setMessage(String message) { }
}
