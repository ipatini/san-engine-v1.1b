package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameExceptionHandlerDecorator extends SesameDecorator implements org.iccs.san.api.ExceptionHandlerDecorator {
	public String getExceptionType() { return this.repository.getValue(getObjectURI(), "exception-type"); }
	public SANNode getFailoverJob() {
		String failoverURI = this.repository.getValue(getObjectURI(), "failover-job");
		return this.repository.getJob( failoverURI );
	}

	public void setExceptionType(String exceptionType) { }
	public void setFailoverJob(SANNode failoverJob) { }
}
