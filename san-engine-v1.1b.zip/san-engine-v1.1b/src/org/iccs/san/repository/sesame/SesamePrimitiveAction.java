package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesamePrimitiveAction extends SesameAction implements org.iccs.san.api.PrimitiveAction {
	protected String command;
	
	public String getCommand() { return command; }
	public String[] getBoundVarNames() { return null; }
	public String getBoundVar(String key) { return null; }

	public void setCommand(String cmd) { command = cmd; }
	public void setBoundVars(java.util.Hashtable h) { }
	public void setBoundVar(String key, String value) { }
}
