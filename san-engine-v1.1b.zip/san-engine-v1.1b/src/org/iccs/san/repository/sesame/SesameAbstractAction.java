package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameAbstractAction extends SesameAction implements org.iccs.san.api.AbstractAction {
	public ActionPool getActionPool() {
		String uri = this.repository.getValue(getObjectURI(), "action-pool");
		return (ActionPool)this.repository.getSANObject(uri);
	}
	public ActionPool getActionPool(String uri) {
		return (ActionPool)this.repository.getSANObject(uri);
	}
	public String getSearchMethod() { return this.repository.getValue(getObjectURI(), "search-method"); }
	public String getExecutionPolicy() { return this.repository.getValue(getObjectURI(), "execution-policy"); }
	
	public void setActionPool(ActionPool pool)  { }
	public void setSearchMethod(String searchMethod) { }
	public void setExecutionPolicy(String execPolicy) { }
}
