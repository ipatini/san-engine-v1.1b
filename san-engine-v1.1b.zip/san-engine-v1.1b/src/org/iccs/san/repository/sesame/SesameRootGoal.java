package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameRootGoal extends SesameGoal implements org.iccs.san.api.RootGoal {	// MARKS a TOP-LEVEL-SAN root goal
	public boolean isAutoStart() { return this.repository.getBoolean(getObjectURI(), "auto-start", false); }
	public void setAutoStart(boolean autoStart) { }
	public boolean getMultipleInstancesAllowed() { return this.repository.getBoolean(getObjectURI(), "multiple-instances-allowed", true); }
	public void setMultipleInstancesAllowed(boolean allow) { }
	public int getExecMode() {
		String mode = this.repository.getValue(getObjectURI(), "execution-mode").trim().toUpperCase();
		if (mode.equals("DEFAULT")) {
			return RootGoal.EXEC_DEFAULT;
		} else
		if (mode.equals("PERSISTENT")) {
			return RootGoal.EXEC_PERSISTENT;
		} else
		if (mode.equals("ONCE")) {
			return RootGoal.EXEC_ONCE;
		} else {
			throw new RuntimeException("SesameRootGoal: getExecMode: Invalid execution mode: "+mode);
		}
	}
	public void setExecMode(int execMode) { }
}
