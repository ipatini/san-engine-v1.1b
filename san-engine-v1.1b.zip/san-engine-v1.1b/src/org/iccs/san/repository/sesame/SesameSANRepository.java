package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;
import org.iccs.san.util.Metadata;
import org.iccs.san.util.SANHelper;
import org.iccs.san.util.SANThread;
import org.iccs.san.util.sesame.*;
import org.iccs.san.repository.basic.BasicSANRepository;
import org.iccs.san.util.sesame.SesameGraph;
import org.iccs.san.util.sesame.SesameRDFRepository;
import org.openrdf.model.Literal;
import org.openrdf.model.util.LiteralUtil;
import org.openrdf.model.URI;
import org.openrdf.query.algebra.evaluation.function.StringCast;
import org.openrdf.rio.RDFFormat;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

public class SesameSANRepository extends BasicSANRepository {

	// 2012-07-11:  Addition of 'main' and 'printHelp' methods, in order to perform syntax check on RDF/N3 files.
	//              It attemps to load specified files in a Sesame repository.
	public static void main(String[] args) {
		if (args.length==0) {
			printHelp();
			return;
		}
		
		if (args[0].trim().equalsIgnoreCase("--check-syntax")) {
			if (args.length==1) {
				System.out.println("No RDF/N3 files specified");
				printHelp();
				return;
			}
			
			SesameSANRepository rep = new SesameSANRepository();
			for (int i=1; i<args.length; i++) {
				try {
					System.out.println("Loading file: "+args[i]+"...");
					rep.setSource(args[i]);
				} catch (Exception e) {
					System.out.println("Fail  "+e);
					e.printStackTrace(System.out);
					break;
				}
				System.out.println("ok");
			}
		} else
		if (args[0].trim().equalsIgnoreCase("--interactive")) {
			if (args.length==1) {
				System.out.println("No RDF/N3 files specified");
				printHelp();
				return;
			}
			
			// Load RDF files
			SesameSANRepository rep = new SesameSANRepository();
			for (int i=1; i<args.length; i++) {
				try {
					System.out.println("Loading file: "+args[i]+"...");
					rep.addSource(args[i]);
				} catch (Exception e) {
					System.out.println("Fail  "+e);
					e.printStackTrace(System.out);
					break;
				}
				System.out.println("ok");
			}
			
			// Enter CLI
			while (true) {
				// display prompt
				System.out.print("SPARQL> ");
				System.out.flush();
				System.out.flush();
				
				// read user input (SPARQL query)
				java.util.Scanner scanner = new java.util.Scanner(System.in);
				StringBuffer qryText = new StringBuffer();
				boolean multiline = false;
				do {
					String line = scanner.nextLine();
					if (line.equals("\\") && multiline==false) { multiline = true; continue; }
					if (line.equals("\\") && multiline==true) break;
					qryText.append(line);
					qryText.append("\n");
				} while (multiline);
				String query = qryText.toString();
				if (query.trim().equalsIgnoreCase("exit") || query.trim().equalsIgnoreCase("x")) break;
				if (query.trim().equals("")) continue;
				if (query.trim().equals("p")) {
					System.out.println(rep.getRepositoryContents());
					continue;
				}
				
				// running query
				try {
					List<HashMap> result = rep.runQuery(query);
					if (result==null) {
						System.out.println("RESULTS: NULL");
						continue;
					}
					Iterator<HashMap> iterator = result.iterator();
					int cnt = 0;
					System.out.println("RESULTS:");
					while (iterator.hasNext()) {
						HashMap hm = iterator.next();
						System.out.print("{ ");
						for (Object key : hm.keySet()) {
							String val = hm.get(key).toString();
							System.out.print(key.toString()+" = "+val+", ");
						}
						System.out.println("}\n");
					}
				} catch (Exception e) {
					System.err.println("EXCEPTION: "+e);
					e.printStackTrace();
				}
			}
			System.out.println("Bye");
		} else {
			System.out.println("Unknown option: "+args[0]);
			printHelp();
		}
	}
	
	public List<HashMap> runQuery(String query) {
		return sg.runSPARQL(query);
	}
	
	public static void printHelp() {
		System.out.println("Usage:\njava "+SesameSANRepository.class.getName()+" --check-syntax <files>+");
		System.out.println("or\njava "+SesameSANRepository.class.getName()+" --interactive <files>+");
	}
	
	// constants // TODO transfer in other package
	static String SAN_BASE_URI = "http://imu.ntua.gr/ontologies/san/2011/06/01/san.rdf#";
	static String NSP = "PREFIX san: <" + SAN_BASE_URI + "> "
			+ "PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>  "
			+ "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>  "
			+ "PREFIX owl: <http://www.w3.org/2002/07/owl#>  "
			+ "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>  \n";

	protected SesameRDFRepository rep;
	protected SesameGraph sg;
	protected boolean debug;
	protected Hashtable<String,String> sources;
	
	public SesameSANRepository() {
		rep = new SesameRDFRepository(false);	// false = not inferencing
		sg = new SesameGraph(rep.getRepository());
		debug = false;
		sources = new Hashtable<String,String>();
	}

	/**
	 * SesameRDFRepository rep; SesameGraph sg;
	 * 
	 * SesameSANRepository() { rep = new SesameRDFRepository(); sg = new
	 * SesameGraph(rep.getRepository()); }
	 **/

	public void setSource(String source) {
		if (source == null || source.trim().equals("")) {
			printErr("SesameSANRepository: setSource: Repository source is empty or null");
			return;
		}
		
		printOut("Intializing Sesame repository...");
		addSource(source);
		super.setSource(source);
	}

	public void addSource(String source) {
		if (source == null || source.trim().equals("")) {
			throw new IllegalArgumentException("SesameSANRepository: addSource: Parameter 'source' is empty or null");
		}
		// Check if already loaded
		if (sources==null) sources = new Hashtable<String,String>();
		if (sources.containsKey(source)) {
			printErr("Loading source file from '" + source + "'... Already loaded");
			return;
		}
		
		// get file format from extension
		int p = source.lastIndexOf(".");
		if (p==-1) throw new IllegalArgumentException("SesameSANRepository: addSource: Unknown file extension in 'source' parameter : "+source);
		String ext = source.substring(p).trim().toLowerCase();
		RDFFormat rdfFormat = null;
		if (ext.equals(".n3")) {
			rdfFormat = sg.N3;
		} else
		if (ext.equals(".nt") || ext.equals(".ntriples")) {
			rdfFormat = sg.NTRIPLES;
		} else
		if (ext.equals(".xml") || ext.equals(".rdfxml")) {
			rdfFormat = sg.RDFXML;
		} else
		if (ext.equals(".trig")) {
			rdfFormat = sg.TRIG;
		} else {
			throw new IllegalArgumentException("SesameSANRepository: addSource: Unknown or unsupported file format in 'source' parameter : "+source);
		}
		
		// load RDF file into repository
		printOut("Loading source file from '" + source + "'...");
// XXX: 2012-07-23:  replaced by addString in order to allow loading from external resources too
//		sg.addFile(source, rdfFormat);
		String rdfString = SANHelper.getResourceContent(source);
		if (rdfString!=null && !rdfString.trim().equals("")) {
			sg.addString(rdfString, rdfFormat);
			printOut("Loading source file from '" + source + "'...done");
		} else {
			printOut("Loading source file from '" + source + "'...fail:  resource not found");
		}
		
		// Store added source file name
		sources.put(source, source);
	}
	
	public String getRepositoryContents() {
		return getRepositoryContents(sg.N3);	// N3 is our default format ???
	}
	
	public String getRepositoryContents(Object format) {
		RDFFormat rdfFormat = null;
		if (format instanceof RDFFormat) rdfFormat = (RDFFormat)format;
		else if (format instanceof String) {
			rdfFormat = RDFFormat.valueOf((String)format);
			if (rdfFormat==null) {
				throw new IllegalArgumentException("SesameSANRepository: getRepositoryContents: Invalid RDFFormat specified. You passed : "+format);
			}
		}
		
		if (rdfFormat==null) {
			throw new IllegalArgumentException("SesameSANRepository: getRepositoryContents: Only RDFFormat and String format objects are supported. You passed : "+format.getClass().getName());
		}
		
		OutputStream out = new ByteArrayOutputStream();
		sg.dumpRDF(out, rdfFormat);
		return out.toString();
	}
	
	public Object[] getRepositoryFormats() {
		return RDFFormat.values().toArray();
	}
	
	
	///////////////////////////
	//     Print methods     //
	///////////////////////////
	
	protected void configError(String mesg) {
		printErr(mesg);
		throw new RuntimeException(mesg);
	}
	
	protected void printOut(String mesg) {
		SANThread.getOut().println(mesg);
	}
	
	protected void printErr(String mesg) {
		SANThread.getErr().println(mesg);
	}
	
	protected void debugOut(String mesg) {
		if (!debug) return;
		SANThread.getErr().println(mesg);
	}
	
	public boolean getDebug() { return this.debug; }
	
	public void setDebug(boolean d) { this.debug = d; }
	
	
	////////////////////////////////////////////
	//   SESAME REPOSITORY QUERYING METHODS   //
	////////////////////////////////////////////
	
	@SuppressWarnings("unchecked")
	public SANEntity[] getAutoStartEntities() {
		String qs = NSP
				+ "select ?x WHERE { ?x rdf:type san:SANEntity . ?x san:auto-start ?y . FILTER ( ?y = 'yes' ) }";
		List<HashMap> result = sg.runSPARQL(qs);
		Iterator<HashMap> iterator = result.iterator();

		Vector<SANEntity> tmp = new Vector<SANEntity>();
		int cnt = 0;
		while (iterator.hasNext()) {
			HashMap hm = iterator.next();
			String uri = hm.get("x").toString();
			SesameSANEntity entity = (SesameSANEntity)getEntity(uri);
			tmp.add(entity);
			cnt++;
			printOut("**sesame getAutoStartEntities: " + uri);
		}

		SANEntity[] entities = new SANEntity[cnt];
		entities = tmp.toArray(entities);
		return entities;
	}
	
	public SANEntity getEntity(String entityURI) {
		return (SANEntity)getSANObject(entityURI);
	}
	
	public SANEntity[] getEntityByName(String name) {
		SANObject[] objects = getSANObjectByName(name);
		if (objects==null) return null;
		SANEntity[] entities = new SANEntity[objects.length];
		for (int i=0; i<objects.length; i++) {
			entities[i] = (SANEntity)objects[i];
		}
		return entities;
	}
	
	@SuppressWarnings("unchecked")
	public RootGoal[] getEntityRootGoals(String entityURI) {
		String qs = NSP
				+ "select ?x ?name WHERE { <" + entityURI + "> san:hasRootGoal ?x . ?x rdf:type san:RootGoal . ?x san:name ?name }";
		List<HashMap> result = sg.runSPARQL(qs);
		Iterator<HashMap> iterator = result.iterator();

		Vector<RootGoal> tmp = new Vector<RootGoal>();
		int cnt = 0;
		while (iterator.hasNext()) {
			HashMap hm = iterator.next();
			String uri = hm.get("x").toString();
			String name = hm.get("name").toString();
			SesameRootGoal root = new SesameRootGoal();
			root.setObjectURI(uri);
			root.setName(getString( name ));
			root.repository = this;
			tmp.add(root);
			cnt++;
			printOut("**sesame getEntityRootGoals: " + name + " " + uri);
		}

		RootGoal[] roots = new RootGoal[cnt];
		roots = tmp.toArray(roots);
		return roots;
	}
	
	public SANObject[] getAllObjects() {
		// NOT IMPLEMENTED
		return null;
	};

	@SuppressWarnings("unchecked")
	public Goal getSAN(String objectURI) {
		String name = getValue(objectURI, "name");
		String type = getType(objectURI);
		
		Goal goal = null;
		
		if (name!=null && type!=null && type.trim().equalsIgnoreCase("Goal")) {
			String uri = objectURI;
			goal = new SesameGoal();
			// minimum is : objectURI + name
			goal.setObjectURI(uri);
			goal.setName(name);
			
			((SesameGoal)goal).repository = this;
		}
		return goal;
	};

	@SuppressWarnings("unchecked")
	public SANObject getSANObject(String objectURI) {
		String name = getValue(objectURI, "name");
		String type = getType(objectURI);
		
		SesameSANObject object = null;
		
		if (name!=null && type!=null) {
			String uri = objectURI;
			
			// Initialize appropriate SANObject class
			String objectType = this.getClass().getPackage().getName()+".Sesame"+type;
			try {
				printOut("Initializing Object of type '"+objectType+"'...");
				object = (SesameSANObject)Class.forName(objectType).newInstance();
				((SesameSANObject)object).repository = this;
			} catch (Exception ex) {
				configError("SesameSANRepository: getSANObject: Invalid Object Type: "+objectType+" ("+type+")");
			}
			
			// minimum is : objectURI + name
			object.setObjectURI(uri);
			object.setName(name);
			// sn.setType(type);
		}
		return object;
	};

	@SuppressWarnings("unchecked")
	public SANObject getSANObjectRAW(String objectURI, boolean onErrorUseSANObject) {
		// Get object type...
		String type = getType(objectURI);
		// ...if not found, use default (SANObject)
		if (type==null) {
			printOut("Could not get Object type: "+objectURI);
			printOut("Using instead default: SesameSANObject");
			type = "SANObject";
		}
		
		return getSANObjectRAW(objectURI, type, onErrorUseSANObject);
	};

	@SuppressWarnings("unchecked")
	public SANObject getSANObjectRAW(String objectURI, String type, boolean onErrorUseSANObject) {
		// Initialize appropriate SANObject class
		SANObject object = null;
		String objectType = this.getClass().getPackage().getName()+".Sesame"+type;
		try {
			printOut("Initializing RAW Object of type '"+objectType+"'...");
			object = (SesameSANObject)Class.forName(objectType).newInstance();
			((SesameSANObject)object).repository = this;
			object.setObjectURI(objectURI);
		} catch (Exception ex) {
			printOut("Type NOT FOUND: "+objectType+".   Using SesameSANObject instead...");
			if (onErrorUseSANObject) {
				try {
					object = new SesameSANObject();
					((SesameSANObject)object).repository = this;
					object.setObjectURI(objectURI);
				} catch (Exception ex2) {
					configError("SesameSANRepository: getSANObjectRAW: INTERNAL REPOSITORY ERROR: Could not initialize type 'SesameSANObject'");
				}
			} else {
				configError("SesameSANRepository: getSANObjectRAW: Could not initialize type: "+type);
			}
		}
		return object;
	};

	// NOT IMPLEMENTED
	public Goal getSANByName(String name) {
		return null;
	};

	@SuppressWarnings("unchecked")
	public SANObject[] getSANObjectByName(String name) {
		String qs = NSP
				+ "select ?x ?name WHERE { ?x san:name ?name . FILTER ( ?name = '"+name+"' ) }";
		List<HashMap> result = sg.runSPARQL(qs);
		Iterator<HashMap> iterator = result.iterator();

		Vector<SANObject> tmp = new Vector<SANObject>();
		int cnt = 0;
		while (iterator.hasNext()) {
			HashMap hm = iterator.next();
			String uri = hm.get("x").toString();
			SANObject object = getSANObject(uri) ;
			tmp.add(object);
			cnt++;
			printOut("**sesame getSANObjectByName: " + name + " " + uri);
		}

		SANObject[] objects = new SANObject[cnt];
		objects = tmp.toArray(objects);
		return objects;
	}

	@SuppressWarnings("unchecked")
	public SesameSituation getSituation(String objectURI) {
		String qs = NSP + "select ?x ?name ?dialect ?definition WHERE { <" + objectURI
				+ "> san:hasSituation ?x . ?x san:name ?name . ?x san:dialect ?dialect . ?x san:defined-by ?definition }";
		SesameSituation sit = null;
		List<HashMap> result = sg.runSPARQL(qs);
		Iterator<HashMap> iterator = result.iterator();
		if (iterator.hasNext()) {
			HashMap hm = iterator.next();
			String uri = hm.get("x").toString();
			String name = getString( hm.get("name").toString() );
			sit = new SesameSituation();
			// minimum is : objectURI + name
			sit.setObjectURI(uri);
			sit.setName(name);
			sit.repository = this;
			
			// Situation CEPAT
			CEPAT cepat = new SesameCEPAT();
			cepat.setName("CEPAT for Situation: "+sit.getName());
			// CEPAT definition is embeded in Situation definition
			cepat.setObjectURI(sit.getObjectURI());
			((SesameCEPAT)cepat).repository = this;
			sit.setCEPAT(cepat);
		}
		return sit;
	}

	@SuppressWarnings("unchecked")
	public SesameContextCondition getContextCondition(String objectURI) {
		String qs = NSP + "select ?x ?name ?dialect ?expr WHERE { <" + objectURI
				+ "> san:hasContextCondition ?x . ?x san:name ?name . ?x san:defined-by ?expr . ?x san:dialect ?dialect }";
		SesameContextCondition ctx = null;
		List<HashMap> result = sg.runSPARQL(qs);
		Iterator<HashMap> iterator = result.iterator();
		if (iterator.hasNext()) {
			HashMap hm = iterator.next();
			String uri = hm.get("x").toString();
			String name = getString( hm.get("name").toString() );
			ctx = new SesameContextCondition();
			// minimum is : objectURI + name
			ctx.setObjectURI(uri);
			ctx.setName(name);
			ctx.repository = this;
		}
		return ctx;
	}

	@SuppressWarnings("unchecked")
	public SANNode getGoalJob(String objectURI) {
		String qs = NSP
				+ "select ?x WHERE { <"
				+ objectURI
				+ "> san:hasAction ?x }";
		SesameSANNode sn = null;
		List<HashMap> result = sg.runSPARQL(qs);
		Iterator<HashMap> iterator = result.iterator();
		if (iterator.hasNext()) {
			HashMap hm = iterator.next();
			String uri = hm.get("x").toString();
			
			return getJob(uri);
		}
		return sn;
	}
	
	@SuppressWarnings("unchecked")
	public SANNode getFirstJob(String objectURI) {
		String qs = NSP
				+ "select ?x WHERE { <"
				+ objectURI
				+ "> san:hasAction ?x }";
		SesameSANNode sn = null;
		List<HashMap> result = sg.runSPARQL(qs);
		Iterator<HashMap> iterator = result.iterator();
		if (iterator.hasNext()) {
			HashMap hm = iterator.next();
			String uri = hm.get("x").toString();
			
			return getJob(uri);
		}
		return sn;
	}

	@SuppressWarnings("unchecked")
	public SANNode getNextJob(String objectURI) {
		String qs = NSP
				+ "select ?x ?name ?type WHERE { <"
				+ objectURI
				+ "> san:nextAction ?x  . ?x san:name ?name . ?x rdf:type ?type }";
		SANNode sn = null;
		List<HashMap> result = sg.runSPARQL(qs);
		Iterator<HashMap> iterator = result.iterator();
		if (iterator.hasNext()) {
			HashMap hm = iterator.next();
			String uri = hm.get("x").toString();
			sn = (SANNode)getJob(uri);
		}
		return sn;
	}

	@SuppressWarnings("unchecked")
	public SANNode[] getAllJobs(String objectURI) {
		String qs = NSP
				+ "select ?x WHERE { <"
				+ objectURI
				+ "> san:hasAction ?x }";
		SANNode[] jobs = null;
		Vector<SANNode> tmp = new Vector<SANNode>();
		List<HashMap> result = sg.runSPARQL(qs);
		Iterator<HashMap> iterator = result.iterator();
		while (iterator.hasNext()) {
			HashMap hm = iterator.next();
			String uri = hm.get("x").toString();
			SANNode job = (SANNode)getJob(uri);
			if (job!=null) tmp.add( job );
			else configError("SesameSANRepository: getAllJobs: Misconfiguration Error : Could not find job with uri '"+uri+"' in object '"+objectURI+"'");
		}
		if (tmp.size()==0) return null;
		jobs = new SANNode[ tmp.size() ];
		return tmp.toArray(jobs);
	}
	
	@SuppressWarnings("unchecked")
	public SANNode[] getJobsByQuery(String objectURI, String query, String jobURIColumn) {
		String qs = NSP
				+ query;
		SANNode[] jobs = null;
		Vector<SANNode> tmp = new Vector<SANNode>();
		List<HashMap> result = sg.runSPARQL(qs);
		Iterator<HashMap> iterator = result.iterator();
		while (iterator.hasNext()) {
			HashMap hm = iterator.next();
			String uri = hm.get( jobURIColumn ).toString();
			SANNode job = (SANNode)getJob(uri);
			if (job!=null) tmp.add( job );
			else configError("SesameSANRepository: getJobsByQuery: Misconfiguration Error : Could not find job with uri '"+uri+"' in object '"+objectURI+"'");
		}
		if (tmp.size()==0) return null;
		jobs = new SANNode[ tmp.size() ];
		return tmp.toArray(jobs);
	}
	
	//////////////////////////////////////////////
	//   HELPER REPOSITORY QUERYING FUNCTIONS   //
	//////////////////////////////////////////////
	protected String getString(String str) {
		return str.split("\"")[1]; 		// dirty hack to extract literal
										// from "value"^^xsd:string
	}
	
	@SuppressWarnings("unchecked")
	public String getValue(String objectURI, String field) {
		String qs = NSP
				+ "select ?value WHERE { <"
				+ objectURI
				+ "> san:"+field+" ?value }";
		List<HashMap> result = sg.runSPARQL(qs);
		Iterator<HashMap> iterator = result.iterator();
		if (iterator.hasNext()) {
			HashMap hm = iterator.next();
			String value = getString( hm.get("value").toString() );
			return value;
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public String[] getValuesArray(String objectURI, String field) {
		String qs = NSP
				+ "select ?value WHERE { <"
				+ objectURI
				+ "> san:"+field+" ?value }";
		List<HashMap> result = sg.runSPARQL(qs);
		Iterator<HashMap> iterator = result.iterator();
		Vector<String> values = new Vector<String>();
		while (iterator.hasNext()) {
			HashMap hm = iterator.next();
			String value = getString( hm.get("value").toString() );
			values.add(value);
		}
		return (String[]) values.toArray(new String[values.size()]);
	}
	
	public boolean getBoolean(String objectURI, String field, boolean defValue) {
		String val = getValue(objectURI, field);
		if (val==null || val.trim().equals("")) return defValue;
		String value = val.trim().toUpperCase();
		if (value.equals("YES") || value.equals("TRUE") || value.equals("ON") || value.equals("1")) return true;
		if (value.equals("NO") || value.equals("FALSE") || value.equals("OFF") || value.equals("0")) return false;
		throw new RuntimeException("SesameSANRepository: getBoolean: Invalid boolean value: "+val+"  at field '"+field+"' in URI: "+objectURI);
	}
	
	@SuppressWarnings("unchecked")
	protected String getType(String objectURI) {
		String qs = NSP
				+ "select ?type WHERE { <"
				+ objectURI
				+ "> a ?type }";
		List<HashMap> result = sg.runSPARQL(qs);
		Iterator<HashMap> iterator = result.iterator();
		if (iterator.hasNext()) {
			HashMap hm = iterator.next();
			String value = hm.get("type").toString().split("#")[1];
			return value;
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public SANNode getJob(String objectURI) {
		String name = getValue(objectURI, "name");
		String type = getType(objectURI);
		SANNode sn = null;
		
		if (name!=null && type!=null) {
			String uri = objectURI;
			
			// Initialize appropriate Job class
			String nodeType = this.getClass().getPackage().getName()+".Sesame"+type;
			try {
				printOut("Initializing job of type '"+nodeType+"'...");
				sn = (SANNode)Class.forName(nodeType).newInstance();
				((SesameSANNode)sn).repository = this;
			} catch (Exception ex) {
				configError("SesameSANRepository: getJob: Invalid Job Type: "+nodeType+" ("+type+") at Goal "+objectURI);
			}
			
			// minimum is : objectURI + name
			sn.setObjectURI(uri);
			sn.setName(name);
			// sn.setType(type);
			
			// Job-specific initializations
			// IF Job-Type :  GOAL
			if (sn instanceof SesameGoal) {
				;
			} else
			// IF Job-Type :  ACTION
			if (sn instanceof Action) {
				if (sn instanceof PrimitiveAction) {
					((PrimitiveAction)sn).setCommand( getValue(uri, "command") );
				} else
				if (sn instanceof MountAction) {
					((MountAction)sn).setReferencedSAN( getValue(uri, "san") );
				} else
				if (sn instanceof AbstractAction) {
// TODO
				} else
				if (sn instanceof CalculationAction) {
// TODO
				} else
				if (sn instanceof CompositeAction) {
					// Settings common to all Composite Actions
					
					// Settings specific to Selector Action
					if (sn instanceof SelectorAction) {
						String selectionMethod = getValue(uri, "selection-method");
						int selMeth;
						if (selectionMethod.equals("SEQUENTIAL")) {
							selMeth = SelectorAction.ORDER_SEQUENTIAL;
						} else
						if (selectionMethod.equals("RANDOM")) {
							selMeth = SelectorAction.ORDER_RANDOM;
						} else
						if (selectionMethod.equals("PROBABLISTIC")) {
							selMeth = SelectorAction.ORDER_PROBABLISTIC;
						} else {
							configError("FileSANRepository: parseAction: Invalid Selector Action attribute value in SELECTOR Action specification: "+selectionMethod);
							return null;
						}
						((SelectorAction)sn).setSelectionMethod(selMeth);
					}
				} else {
					configError("SesameSANRepository: getJob: Invalid Action type : "+sn.getClass().getName());
				}
			} else
			// IF Job-Type:  DECORATOR
			if (sn instanceof Decorator) {
				// Settings common to all Decorators
				
				// Settings specific to certain Decorators
				if (sn instanceof Decorator) {
					;
				} else {
					configError("SesameSANRepository: getJob: Invalid Decorator type : "+sn.getClass().getName());
				}
			} else {
				configError("SesameSANRepository: getJob: Invalid Job type : "+sn.getClass().getName());
			}
		} else {
			configError("SesameSANRepository: getJob: missing 'name' or 'type' information for repository object '"+objectURI+"' : name="+(name==null ? "null" : name)+", type="+(type==null ? "null" : type));
		}
		
		return sn;
	}
	
	public Expression getExpression(String objectURI) {
		return getExpression(objectURI, "");
	}
	
	public Expression getExpression(String objectURI, String base) {
		String base1 = (base==null || base.trim().equals("")) ? "" : base.trim()+"-";
		return getExpression(objectURI, base1+"dialect", base1+"defined-by", base1+"hasParameter");
	}
	
	@SuppressWarnings("unchecked")
	public Expression getExpression(String objectURI, String dialectField, String definitionField, String paramsField) {
		// Create an expression object and set its basic information
		String dialect = getValue(objectURI, dialectField);
		String exprStr = getValue(objectURI, definitionField);
		Expression expression = new SesameExpression();
		expression.setObjectURI(objectURI);
		expression.setName(objectURI);
		((SesameExpression)expression).repository = this;
		expression.setDialect(dialect);
		expression.setDefinition(exprStr);
		
		// Set expression parameters information
		String qs = NSP
				+ "select ?param ?name ?source WHERE { <"
				+ objectURI
				+ "> san:"+paramsField+" ?param . ?param a san:Parameter . ?param san:name ?name . ?param san:source ?source } ";
		List<HashMap> result = sg.runSPARQL(qs);
		Iterator<HashMap> iterator = result.iterator();
		while (iterator.hasNext()) {
			HashMap hm = iterator.next();
			String uri = hm.get("param").toString();
			String name = getString( hm.get("name").toString() );
			String source = getString( hm.get("source").toString() );
			
			Parameter param = new SesameParameter();
			param.setObjectURI(uri);
			param.setName(name);
			param.setSource(source);
			
			expression.addParameter(param);
		}
		
		return expression;
	}
	
	@SuppressWarnings("unchecked")
	public String getObjectUri(String objectURI, String field) {
		String qs = NSP
				+ "select ?x WHERE { <"
				+ objectURI
				+ "> san:"+field+" ?x }";
		List<HashMap> result = sg.runSPARQL(qs);
		Iterator<HashMap> iterator = result.iterator();
		if (iterator.hasNext()) {
			HashMap hm = iterator.next();
			String uri = hm.get("x").toString();
			return uri;
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public String[] getObjectUriArray(String objectURI, String field) {
		String qs = NSP
				+ "select ?x WHERE { <"
				+ objectURI
				+ "> san:"+field+" ?x }";
		List<HashMap> result = sg.runSPARQL(qs);
		Iterator<HashMap> iterator = result.iterator();
		Vector<String> uris = new Vector<String>();
		while (iterator.hasNext()) {
			HashMap hm = iterator.next();
			String uri = hm.get("x").toString();
			uris.add(uri);
		}
		return uris.toArray(new String[uris.size()]);
	}
	
	@SuppressWarnings("unchecked")
	public Metadata<?> getMetadata(String objectURI, String metaName) {
		if (metaName==null || metaName.trim().equals("")) return null;
		String metaUri = null;

		// Find metadata URI, querying by metadata name
		String qs = NSP
				+ "select ?meta_uri WHERE { <"
				+ objectURI
				+ "> san:hasMetadata ?meta_uri . ?meta_uri san:name ?name . FILTER ( ?name = '"+metaName+"' ) } ";
		List<HashMap> result = sg.runSPARQL(qs);
		Iterator<HashMap> iterator = result.iterator();
		if (iterator.hasNext()) {
			HashMap hm = iterator.next();
			metaUri = hm.get("meta_uri").toString();
		}
		if (metaUri==null || metaUri.trim().equals("")) {
			return null;
		}
		
		return getMetadata(metaUri);
	}
	
	@SuppressWarnings("unchecked")
	public Metadata<?> getMetadata(String metaURI) {
		// Collect metadata specification
		String name = getValue(metaURI, "name");
		String type = getValue(metaURI, "type");
		String unit = getValue(metaURI, "unit");
		String value = getValue(metaURI, "value");
		//String exprUri = getValue(metaURI, "expression");
		Expression expression = (type!=null && (type.trim().equalsIgnoreCase("constraint") || type.trim().equalsIgnoreCase("expression"))) ? getExpression(metaURI) : null;
		String rangeMin = getValue(metaURI, "range-min");
		String rangeMax = getValue(metaURI, "range-max");
		String rangeStep = getValue(metaURI, "range-step");
		
		if (name==null || type==null) {
			return null;
		}
		
		name = name.trim();
		type = type.trim();
		if (unit!=null) unit = unit.trim();
		if (value!=null) {
			value = value.trim();
			if (value.equals("")) value = null;
		}
		
		if (name.equals("") || type.equals("")) {
			return null;
		}
		
		// Create a metadata object and set its basic information
		Metadata meta = null;
		type = type.trim().toLowerCase();
		if (type.equals("number") || type.equals("numeric")) {
			meta = new Metadata<Double>();
			if (value!=null) {
				meta.setValue( new Double(value) );
			}
			if (expression!=null) {
				meta.setExpression(new org.iccs.san.util.Expression<Double>(expression));
			}
			if (rangeMin!=null && !rangeMin.trim().equals("")) meta.setRangeMin( Double.parseDouble(rangeMin) );
			if (rangeMax!=null && !rangeMax.trim().equals("")) meta.setRangeMax( Double.parseDouble(rangeMax) );
			if (rangeStep!=null && !rangeStep.trim().equals("")) meta.setRangeStep( Double.parseDouble(rangeStep) );
		} else if (type.equals("boolean")) {
			meta = new Metadata<Boolean>();
			if (value!=null) {
				meta.setValue( new Boolean(value) );
			}
			if (expression!=null) {
				meta.setExpression(new org.iccs.san.util.Expression<Boolean>(expression));
			}
		} else if (type.equals("string")) {
			meta = new Metadata<String>();
			if (value!=null) {
				meta.setValue( value );
			}
			if (expression!=null) {
				meta.setExpression(new org.iccs.san.util.Expression<String>(expression));
			}
		} else if (type.equals("mcdm")) {
			meta = new Metadata<Object>();
		} else {
			meta = new Metadata<Object>();
			if (value!=null) {
				meta.setValue( value );
			}
			if (expression!=null) {
				meta.setExpression(new org.iccs.san.util.Expression<Object>(expression));
			}
		}
		
		meta.setName(name);
		meta.setType(type);
		
		return meta;
	}
	
	@SuppressWarnings("unchecked")
	public Iterator<Metadata<?>> getAllMetadata(String objectURI) {
		Vector<Metadata<?>> tmp = new Vector<Metadata<?>>();
		
		// Retrieve object metadata
		String qs = NSP
				+ "select ?param WHERE { <"
				+ objectURI
				+ "> san:hasMetadata ?param } ";
		List<HashMap> result = sg.runSPARQL(qs);
		Iterator<HashMap> iterator = result.iterator();
		while (iterator.hasNext()) {
			HashMap hm = iterator.next();
			String metaUri = hm.get("param").toString();
			tmp.add( getMetadata(metaUri) );
		}
		
		return tmp.iterator();
	}
}
