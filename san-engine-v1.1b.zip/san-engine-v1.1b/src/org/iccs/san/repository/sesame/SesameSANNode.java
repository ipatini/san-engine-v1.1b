package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameSANNode extends SesameSANObject implements org.iccs.san.api.SANNode {
	protected int order = -1;
	protected SANNode nextJob = null;
	
	public int getOrder() {
		if (order<0) {
			String val = this.repository.getValue(getObjectURI(), "order");
			if (val==null || val.trim().equals("")) return order;
			else return Integer.parseInt( val );
		} else {
			return order;
		}
	}
	
	public void setOrder(int ord) {
		this.order = ord;
	}
	
	public SANNode getNextJob() {
		if (nextJob==null) {
			// Query repository to get the next job
			SANNode sn = this.repository.getNextJob(this.getObjectURI());
			return sn;
		} else {
			return nextJob;
		}
	}
	
	public void setNextJob(SANNode job) {
		this.nextJob = job;
	}
}
