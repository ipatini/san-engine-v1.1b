package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameConditionDecorator extends SesameDecorator implements org.iccs.san.api.ConditionDecorator {
	public Expression getCondition() { return this.repository.getExpression(getObjectURI(), "condition"); }
	public void setCondition(Expression expr) { }
}
