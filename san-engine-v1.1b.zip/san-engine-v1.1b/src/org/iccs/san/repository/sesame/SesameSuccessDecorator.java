package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameSuccessDecorator extends SesameDecorator implements org.iccs.san.api.SuccessDecorator {
}
