package org.iccs.san.repository.sesame;

import org.iccs.san.api.*;

public class SesameNotDecorator extends SesameDecorator implements org.iccs.san.api.NotDecorator {
}
