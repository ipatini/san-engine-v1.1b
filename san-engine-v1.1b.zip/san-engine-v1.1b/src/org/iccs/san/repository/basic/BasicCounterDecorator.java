package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicCounterDecorator extends BasicDecorator implements org.iccs.san.api.CounterDecorator {
	protected String varName;
	protected int startCount = 0;
	protected int step = 1;
	
	public String getVariable() { return varName; }
	public int getStartCount() { return startCount; }
	public int getStep() { return step; }
	public void setVariable(String vname) { this.varName = vname; }
	public void setStartCount(int startValue) { this.startCount = startValue; }
	public void setStep(int step) { this.step = step; }
}
