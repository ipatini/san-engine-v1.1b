package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicDecorator extends BasicSANNode implements org.iccs.san.api.Decorator {
	protected String type;
	protected SANNode job;
	
	public SANNode getJob() { return this.job; }	// The job following this decorator
	public String getDecoratorType() { return this.type; }	// Isws na min xreiazetai

	public void setDecoratorType(String t) { this.type = t; }
	public void setJob(SANNode job) { this.job = job; job.setOrder(1); }

//IP:	public int doDecorator();
}
