package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicGoal extends BasicSANNode implements org.iccs.san.api.Goal {
	protected Situation situation;
	protected ContextCondition contextCondition;
	protected SANNode job;
	
	public Situation getSituation() { return this.situation; }
	public ContextCondition getContextCondition() { return this.contextCondition; }
	public SANNode getJob() { return this.job; }	// JOB, ennoei Goal, Decorator 'h Action

	public void setSituation(Situation situation) { this.situation = situation; situation.setOrder(1); }
	public void setContextCondition(ContextCondition contextCondition) { this.contextCondition = contextCondition; contextCondition.setOrder(2); }
	public void setJob(SANNode job) { this.job = job; job.setOrder(3); }
	
	public String toString() {
		return super.toString()+" {\n"+
				"\tsituation : "+((BasicSituation)situation).toString()+"\n"+
				"\tcontext-condition : "+((BasicContextCondition)contextCondition).toString()+"\n"+
				"\tjob : "+((BasicSANNode)job).toString()+"\n"+
				"}";
	}
	
	public void stopGoal() { throw new RuntimeException(getClass().getName()+": stopGoal: THIS METHOD SHOULD NOT BE INVOKED"); }
}
