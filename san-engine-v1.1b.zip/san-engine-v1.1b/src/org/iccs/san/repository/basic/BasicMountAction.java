package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicMountAction extends BasicAction implements org.iccs.san.api.MountAction {
	protected String refSAN;
	
	public String getReferencedSAN() { return this.refSAN; }
	public void setReferencedSAN(String rootGoal)  { this.refSAN = rootGoal; }
}
