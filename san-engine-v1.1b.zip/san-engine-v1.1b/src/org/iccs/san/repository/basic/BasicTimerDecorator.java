package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicTimerDecorator extends BasicDecorator implements org.iccs.san.api.TimerDecorator {
	protected long timeout;
	protected int returnCode;
	
	public long getTimeout() { return timeout; }
	public int getReturnCode() { return returnCode; }
	public void setTimeout(long msec) { timeout = msec; }
	public void setReturnCode(int rc) { returnCode = rc; }
}
