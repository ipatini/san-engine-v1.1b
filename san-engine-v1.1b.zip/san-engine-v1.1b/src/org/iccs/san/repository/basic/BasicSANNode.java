package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicSANNode extends BasicSANObject implements org.iccs.san.api.SANNode {
	protected int order;
	protected SANNode nextJob;
	
	public int getOrder() { return this.order; }		// H seira tou node se sxesh me ta simblings tou
	public void setOrder(int order) { this.order = order; }
	
// Gia sequence / selector / parallel actions 
	public SANNode getNextJob() { return this.nextJob; }
	public void setNextJob(SANNode nextJob) { this.nextJob = nextJob; }
	
	public String toString() {
		return super.toString()+" : "+getOrder();
	}
}
