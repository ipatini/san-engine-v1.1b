package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicActionPool extends BasicSANObject implements org.iccs.san.api.ActionPool {
	public SANNode[] getPoolJobs() { return null; }
	public void setPoolJobs(SANNode[] jobs) { }
}
