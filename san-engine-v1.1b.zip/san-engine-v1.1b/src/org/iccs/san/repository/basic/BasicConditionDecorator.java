package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicConditionDecorator extends BasicDecorator implements org.iccs.san.api.ConditionDecorator {
	protected Expression condition;
	
	public Expression getCondition() { return condition; }
	public void setCondition(Expression expr) { this.condition = expr; }
}
