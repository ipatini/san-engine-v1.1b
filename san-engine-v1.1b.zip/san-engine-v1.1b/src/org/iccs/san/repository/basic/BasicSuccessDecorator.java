package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicSuccessDecorator extends BasicDecorator implements org.iccs.san.api.SuccessDecorator {
}
