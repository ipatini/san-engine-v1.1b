package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicContextCondition extends BasicSANNode implements org.iccs.san.api.ContextCondition {
	protected Expression expression;
	
	public Expression getExpression() { return this.expression; }
	public void setExpression(Expression expr) { this.expression = expr; }
	
	public String toString() {
		return super.toString()+" {\n\texpression : "+expression.toString()+"\n}";
	}
}
