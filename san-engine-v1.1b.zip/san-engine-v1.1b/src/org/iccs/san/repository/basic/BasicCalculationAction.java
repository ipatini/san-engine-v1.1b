package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicCalculationAction extends BasicAction implements org.iccs.san.api.CalculationAction {
	protected Expression expression;
	
	public Expression getExpression() {
		return this.expression;
	}

	public void setExpression(Expression expression) {
		this.expression = expression;
	}
}
