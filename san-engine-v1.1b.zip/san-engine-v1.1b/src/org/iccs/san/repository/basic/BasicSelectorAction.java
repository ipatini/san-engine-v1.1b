package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicSelectorAction extends BasicCompositeAction implements org.iccs.san.api.SelectorAction {
	protected int selectionMethod = SelectorAction.ORDER_UNSPECIFIED;
	
	public int getSelectionMethod() {
		return this.selectionMethod;
	}
	
	public void setSelectionMethod(int method) {
		if (method!=ORDER_SEQUENTIAL && method!=ORDER_RANDOM && method!=ORDER_PROBABLISTIC) {
			throw new IllegalArgumentException("Invalid Selection Method : "+method);
		}
		this.selectionMethod = method;
	}
}
