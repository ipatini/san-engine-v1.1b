package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicPrintDecorator extends BasicDecorator implements org.iccs.san.api.PrintDecorator {
	protected String message;
	
	public String getMessage() { return message; }
	public void setMessage(String message) { this.message = message; }
}
