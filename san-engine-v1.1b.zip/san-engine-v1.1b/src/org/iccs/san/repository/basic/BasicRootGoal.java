package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicRootGoal extends BasicGoal implements org.iccs.san.api.RootGoal {	// MARKS a TOP-LEVEL-SAN root goal
	protected boolean autoStart = false;
	protected boolean multInst = true;
	protected int execMode = RootGoal.EXEC_DEFAULT;
	
	public boolean isAutoStart() { return autoStart; }
	public void setAutoStart(boolean autoStart) { this.autoStart = autoStart; }
	public boolean getMultipleInstancesAllowed() { return multInst; }
	public void setMultipleInstancesAllowed(boolean allow) { this.multInst = allow; }
	public int getExecMode() { return execMode; }
	public void setExecMode(int execMode) { this.execMode = execMode; }
	
	public String toString() {
		return "ROOT GOAL "+super.toString();
	}
}
