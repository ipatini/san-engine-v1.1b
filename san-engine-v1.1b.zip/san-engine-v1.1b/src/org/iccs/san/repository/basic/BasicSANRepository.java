package org.iccs.san.repository.basic;

import org.iccs.san.api.*;
import org.iccs.san.util.Configurator;


public class BasicSANRepository implements org.iccs.san.api.SANRepository {
	protected Configurator configurator;
	protected String source;
	
	public SANEntity[] getAutoStartEntities() { return null; }
	public SANEntity getEntity(String entityURI) { return null; }
	public SANEntity[] getEntityByName(String name) { return null; }
	public RootGoal[] getEntityRootGoals(String entityURI) { return null; }
	
	public SANObject[] getAllObjects() { return null; }
	
	public Goal getSAN(String objectURI) { return null; }
	public Goal getSANByName(String name) { return null; }
	public SANObject getSANObject(String objectURI) { return null; }
	public SANObject[] getSANObjectByName(String name) { return null; }
	
	public String getSource() { return this.source; }
	public void setSource(String source) { this.source = source; }
	public void addSource(String source) { }
	
	public String getRepositoryContents() { return null; }
	public String getRepositoryContents(Object format) { return null; }
	public Object[] getRepositoryFormats() { return null; }
	
	public Configurator getConfigurator() { return this.configurator; }
	public void setConfigurator(Configurator configurator) { this.configurator = configurator; }
}
