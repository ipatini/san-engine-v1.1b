package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicLoopDecorator extends BasicDecorator implements org.iccs.san.api.LoopDecorator {
	Expression loopCondition;
	
	public Expression getLoopExpression() { return loopCondition; }
	public void setLoopExpression(Expression expr) { loopCondition = expr; }
}
