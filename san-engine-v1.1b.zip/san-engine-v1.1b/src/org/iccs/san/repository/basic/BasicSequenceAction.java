package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicSequenceAction extends BasicCompositeAction implements org.iccs.san.api.SequenceAction {
}
