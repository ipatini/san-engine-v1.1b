package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicFailureDecorator extends BasicDecorator implements org.iccs.san.api.FailureDecorator {
}
