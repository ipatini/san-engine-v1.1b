package org.iccs.san.repository.basic;

import org.iccs.san.api.*;
import java.util.Arrays;
import java.util.Vector;


public class BasicCompositeAction extends BasicAction implements org.iccs.san.api.CompositeAction {
	protected Vector<SANNode> jobs;
	protected boolean ordered = false;
	protected SANNode[] T = new SANNode[0];	// Used to specify the return type of 'Vector.toArray()' in 'getJobs()' method
	protected SANNode firstJob;
	
	public SANNode[] getJobs() {
		if (this.jobs==null) return null;
		SANNode[] arr = this.jobs.toArray(T);
		if (!ordered) {
			Arrays.sort(arr, SANNode.Comparator);
			ordered = true;
		}
		return arr;
	}

	public void setJobs(SANNode[] jobs) {
		if (this.jobs!=null) this.jobs.clear();
		for (int i=0; i<jobs.length; i++) {
			addJob(jobs[i]);
		}
		this.jobs.trimToSize();
	}
	
	public void addJob(SANNode job) {
		if (this.jobs==null) this.jobs = new Vector<SANNode>();
		this.jobs.add(job);
		this.ordered = false;
	}

// ENALLAKTIKO ACTION API
	public SANNode getFirstJob() { return this.firstJob; }
	public void setFirstJob(SANNode firstJob) {	if (this.firstJob==null) this.firstJob = firstJob; }
}
