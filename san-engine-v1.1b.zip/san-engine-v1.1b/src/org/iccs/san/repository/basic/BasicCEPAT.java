package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicCEPAT extends BasicSANObject implements org.iccs.san.api.CEPAT {
	protected Expression expression;
	
	public Expression getDefinition() { return this.expression; }
	public String[] getInputEventTypes() { return null; }	// ??? Mipws na valw EventType anti gia String
	public String[] getOutputEventTypes() { return null; }

	public void setDefinition(Expression definition) { this.expression = definition; }
	public void setInputEventTypes(String[] types) { }
	public void setOutputEventTypes(String[] types) { }
	
	public String toString() {
		return super.toString()+" {\n\texpression : "+expression.toString()+"\n}";
	}
}
