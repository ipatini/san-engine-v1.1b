package org.iccs.san.repository.basic;

import org.iccs.san.api.*;
import org.iccs.san.context.contextualizer.Contextualizer;


public class BasicSituation extends BasicSANNode implements org.iccs.san.api.Situation {
	protected CEPAT cepat;
	
	public CEPAT getCEPAT() { return this.cepat; }
	public void setCEPAT(CEPAT cepat) { this.cepat = cepat; }
	
	public Contextualizer.Descriptor getContextualizerDescriptor(Contextualizer ctxlzr) { throw new RuntimeException("BasicSituation: getContextualizerDescriptor: METHOD NOT IMPLEMENTED"); }
	
	public Situation.Policy getPolicy() { throw new RuntimeException("BasicSituation: getPolicy: METHOD NOT IMPLEMENTED"); }
	
	public String toString() {
		return super.toString()+"\n\tcepat : "+cepat.toString();
	}
}
