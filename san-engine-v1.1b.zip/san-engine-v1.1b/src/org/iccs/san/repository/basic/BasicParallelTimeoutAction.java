package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicParallelTimeoutAction extends BasicCompositeAction implements org.iccs.san.api.ParallelTimeoutAction {
	protected long timeout;
	
	public long getTimeout() { return timeout; }
	public void setTimeout(long timeout) { this.timeout = timeout; }
}
