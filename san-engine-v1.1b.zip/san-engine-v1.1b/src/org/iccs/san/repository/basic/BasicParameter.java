package org.iccs.san.repository.basic;

import org.iccs.san.api.*;


public class BasicParameter extends BasicSANObject implements org.iccs.san.api.Parameter {
	protected String source;
	
	public String getSource() { return this.source; }
	public void setSource(String source) { this.source = source; }
	
	public String toString() {
		return super.toString()+" : source = '"+source+"'";
	}
}
