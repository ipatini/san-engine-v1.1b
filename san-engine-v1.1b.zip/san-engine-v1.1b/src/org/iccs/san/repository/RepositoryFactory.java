package org.iccs.san.repository;

import org.iccs.san.api.SANRepository;
import org.iccs.san.util.Configurator;
import java.util.Hashtable;
import java.util.Properties;

/**
 *	Manages SAN Repository singletons
 */
public class RepositoryFactory {
// XXX	protected static Hashtable<String,SANRepository> repositoryPool;

	public static SANRepository getRepository(Configurator configurator)
		throws ClassNotFoundException, InstantiationException, IllegalAccessException
	{
		String className = configurator.configuration.getProperty("repository.class");
		String source = configurator.configuration.getProperty("repository.source");
		SANRepository repository = getRepository(className);
		repository.setSource(source);
		repository.setConfigurator(configurator);
		return repository;
	}
	
	protected static SANRepository getRepository(String repositoryClassName) 
		throws ClassNotFoundException, InstantiationException, IllegalAccessException
	{
		SANRepository rep;
/* XXX
		// Initialize repositories pool, if needed
		if (repositoryPool==null) {
			repositoryPool = new Hashtable<String,SANRepository>();
		}

		// Check if a repository instance has already been created
		rep = repositoryPool.get( repositoryClassName );
		if (rep!=null) {
			// If so, return it
			return rep;
		}*/

		// If no previous instance of this repository type exist
		// then create one and save it in repositoryPool for use
		// in subsequent calls
		rep = (SANRepository) Class.forName( repositoryClassName ).newInstance();
// XXX		repositoryPool.put( repositoryClassName, rep );
		return rep;
	}
}
