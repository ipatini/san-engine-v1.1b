package org.iccs.san.repository.file;


public class FilePrimitiveAction extends org.iccs.san.repository.basic.BasicPrimitiveAction {
}
