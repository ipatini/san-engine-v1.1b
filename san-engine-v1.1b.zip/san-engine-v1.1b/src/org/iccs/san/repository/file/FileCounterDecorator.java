package org.iccs.san.repository.file;


public class FileCounterDecorator extends org.iccs.san.repository.basic.BasicCounterDecorator {
}
