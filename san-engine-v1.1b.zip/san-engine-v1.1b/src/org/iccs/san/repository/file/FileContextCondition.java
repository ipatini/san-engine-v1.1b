package org.iccs.san.repository.file;


public class FileContextCondition extends org.iccs.san.repository.basic.BasicContextCondition {
}
