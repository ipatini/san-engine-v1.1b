package org.iccs.san.repository.file;


public class FileFailureDecorator extends org.iccs.san.repository.basic.BasicFailureDecorator {
}
