package org.iccs.san.repository.file;


public class FileExpression extends org.iccs.san.repository.basic.BasicExpression {
}
