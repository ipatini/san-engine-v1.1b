package org.iccs.san.repository.file;


public class FileLoopDecorator extends org.iccs.san.repository.basic.BasicLoopDecorator {
}
