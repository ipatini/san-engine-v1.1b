package org.iccs.san.repository.file;


public class FileDecorator extends org.iccs.san.repository.basic.BasicDecorator {
}
