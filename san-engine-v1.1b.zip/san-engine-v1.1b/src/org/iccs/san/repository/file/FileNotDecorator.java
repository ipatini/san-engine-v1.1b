package org.iccs.san.repository.file;


public class FileNotDecorator extends org.iccs.san.repository.basic.BasicNotDecorator {
}
