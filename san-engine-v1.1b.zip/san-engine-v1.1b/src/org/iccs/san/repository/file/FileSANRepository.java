package org.iccs.san.repository.file;

import org.iccs.san.api.*;
import org.iccs.san.util.Scope;
import org.iccs.san.util.SANHelper;
import org.iccs.san.repository.basic.*;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;


public class FileSANRepository extends BasicSANRepository {
	protected boolean initialized = false;
	protected Hashtable<String,SANNode> repository;
	protected String namespace;
	protected RootGoal[] roots;
	protected Goal[] goals;
	protected SANObject[] objects;
	
	public SANObject[] getAllObjects() {
		if (!initialized) throw new RuntimeException("FileSANRepository: getAllObjects:  FileSANRepository has not been initialized. Set Configuration using setConfiguration() method");
		return this.objects;
	}
	
	public Goal getSAN(String objectURI) {
		if (!initialized) throw new RuntimeException("FileSANRepository: getSAN:  FileSANRepository has not been initialized. Set Configuration using setConfiguration() method");
		
		String fullURI = objectURI;
		if (!objectURI.startsWith(namespace)) {
			fullURI = namespace+'#'+objectURI;
		}
		
		for (int i=0, n=this.roots.length; i<n; i++) {
			if (this.roots[i].getObjectURI().equals(fullURI)) return this.roots[i];
			if (this.roots[i].getObjectURI().equals(objectURI)) return this.roots[i];
		}
		for (int i=0, n=this.goals.length; i<n; i++) {
			if (this.goals[i].getObjectURI().equals(fullURI)) return this.goals[i];
			if (this.goals[i].getObjectURI().equals(objectURI)) return this.goals[i];
		}
		return null;
	}
	
	public Goal getSANByName(String name) {
		if (!initialized) throw new RuntimeException("FileSANRepository: getSANByName:  FileSANRepository has not been initialized. Set Configuration using setConfiguration() method");
		
		for (int i=0, n=this.roots.length; i<n; i++) {
			if (this.roots[i].getName().equals(name)) return this.roots[i];
		}
		for (int i=0, n=this.goals.length; i<n; i++) {
			if (this.goals[i].getName().equals(name)) return this.goals[i];
		}
		return null;
	}
	
	public SANObject getSANObject(String objectURI) {
		if (!initialized) throw new RuntimeException("FileSANRepository: getSANObject:  FileSANRepository has not been initialized. Set Configuration using setConfiguration() method");
		
		Enumeration en = this.repository.keys();
		while (en.hasMoreElements()) {
			String key = (String)en.nextElement();
			SANObject object = (SANObject)this.repository.get(key);
			if (object.getObjectURI().equals(objectURI)) return object;
		}
		
		return null;
	}
	
	public SANObject[] getSANObjectByName(String name) {
		if (!initialized) throw new RuntimeException("FileSANRepository: getSANObjectByName:  FileSANRepository has not been initialized. Set Configuration using setConfiguration() method");
		
		Enumeration en = this.repository.keys();
		Vector<SANObject> tmp = new Vector<SANObject>();
		while (en.hasMoreElements()) {
			String key = (String)en.nextElement();
			SANObject object = (SANObject)this.repository.get(key);
			if (object.getName().equals(name)) tmp.add( object );
		}
		
		if (tmp.size()>0) {
			SANObject[] objects = new SANObject[tmp.size()];
			objects = tmp.toArray(objects);
			return objects;
		}
		
		return null;
	}
	
	public void setSource(String source) {
		if (source==null || source.trim().equals("")) {
			throw new IllegalArgumentException("FileSANRepository: setSource: source parameter is empty or null");
		}
		
		try {
			if (initialized) throw new RuntimeException("FileSANRepository: setSource: Repository Source has already been set");
			super.setSource(source);
			initialized = parse( SANHelper.loadFile(source) );
			if (!initialized) throw new RuntimeException("FileSANRepository: setSource: Repository could not be initialized. See previous messages for details.");
		} catch (java.io.IOException ex) {
			throw new RuntimeException("FileSANRepository: setSource: Error while reading repository source : "+source, ex);
		} catch (NullPointerException ex) {
			throw ex;
		}
	}
	
	/*
	 *	Parser methods
	 */
	protected boolean parseError;
	
	protected void configError(String mesg) {
		parseError = true;
		throw new RuntimeException(mesg);
		//org.iccs.san.util.SANThread.getErr().println(mesg);
	}
	
	protected boolean parse(String config) {
		parseError = false;
		Scope tree = new Scope();
		tree.parse(config);
		
		// Get namespace (if any)
		namespace = tree.getValue("namespace", "");
		if (namespace.endsWith("#")) namespace = namespace.substring(0, namespace.length()-1);
		
		// Load Root SANs
		Scope rootsScope = tree.getScope("Root.Goal");
		if (rootsScope!=null && rootsScope.size()>0) {
			Enumeration<String> en1 = rootsScope.keys();
			this.roots = new RootGoal[ rootsScope.size() ];
			int i = 0;
			while (en1.hasMoreElements()) {
				String key = en1.nextElement();
				RootGoal newRoot = new FileRootGoal();
				this.roots[i++] = (RootGoal)parseGoal(newRoot, key, rootsScope, namespace);
			}
			Arrays.sort(this.roots, SANNode.Comparator);
		} else {
			this.roots = new RootGoal[0];
		}
		
		// Build SAN using Configuration Tree
		Scope goalsScope = tree.getScope("Goal");
		if (goalsScope!=null && goalsScope.size()>0) {
			Enumeration<String> en2 = goalsScope.keys();
			this.goals = new Goal[ goalsScope.size() ];
			int i = 0;
			while (en2.hasMoreElements()) {
				String key = en2.nextElement();
				Goal newGoal = new FileGoal();
				this.goals[i++] = parseGoal(newGoal, key, goalsScope, namespace);
			}
			Arrays.sort(this.goals, SANNode.Comparator);
		} else {
			this.goals = new Goal[0];
		}
		
		// Prepare 'repository' and 'objects'
		this.repository = new Hashtable<String,SANNode>();
		this.objects = new SANObject[ this.roots.length + this.goals.length ];
		int j = 0;
		for (int i=0, n=this.roots.length; i<n; i++) {
			this.repository.put(this.roots[i].getObjectURI(), this.roots[i]);
			this.objects[j++] = this.roots[i];
		}
		for (int i=0, n=this.goals.length; i<n; i++) {
			this.repository.put(this.goals[i].getObjectURI(), this.goals[i]);
			this.objects[j++] = this.goals[i];
		}
		
		return !parseError;
	}
	
	protected void parseNodeMetadata(SANObject node, Scope scope, String namespace) {
		// Retrieve node metadata
		String name = scope.getValue("Name");
		if (name==null || name.equals("")) configError("FileSANRepository: parseNodeMetadata: Missing Name attribute in Node specification");
		String uri = scope.getValue("URI");
		if (uri==null || uri.equals("")) uri = namespace+"#"+name;
		if (!uri.startsWith(namespace) && uri.indexOf("://")<0) uri = namespace+'#'+uri;
		int order = -1;
		if (node instanceof SANNode) {
			String ordStr = scope.getValue("Order");
			if (ordStr==null || ordStr.equals("")) configError("FileSANRepository: parseNodeMetadata: Missing Order attribute in Node specification");
			order = Integer.parseInt(ordStr);
		}
		
		// Set node metadata
		node.setName(name);
		node.setObjectURI(uri);
		if (node instanceof SANNode) {
			((SANNode)node).setOrder(order);
		}
	}
	
	protected Goal parseGoal(Goal newGoal, String goalName, Scope parentScope, String namespace) {
		// Prepare goal node
		Scope goalScope = parentScope.getScope(goalName);
		if (goalScope==null) configError("FileSANRepository: parseGoal: Missing Goal specification in Parent scope");
		parseNodeMetadata(newGoal, goalScope, namespace);
		
		// Prepare goal's situation node
		Situation situation = parseSituation(goalScope, namespace);
		newGoal.setSituation( situation );
		
		// Prepare goal's context condition node
		ContextCondition cc = parseContextCondition(goalScope, namespace);
		newGoal.setContextCondition( cc );
		
		// Check goal's job node 
		SANNode job = parseJob(goalScope.getScope("Job"), namespace);
		newGoal.setJob( job );
		
		return newGoal;
	}
	
	protected Situation parseSituation(Scope goalScope, String namespace) {
		// Prepare situation node
		Scope situationScope = goalScope.getScope("Situation");
		if (situationScope==null) configError("FileSANRepository: parseSituation: Missing Situation specification in Goal");
		Situation situation = new FileSituation();
		parseNodeMetadata(situation, situationScope, namespace);
		
		// Prepare situation's CEPAT node
		Scope cepatScope = situationScope.getScope("CEPAT");
		if (cepatScope==null) configError("FileSANRepository: parseSituation: Missing CEPAT specification in Situation");
		CEPAT cepat = new FileCEPAT();
		parseNodeMetadata(cepat, cepatScope, namespace);
		
		String dialect = cepatScope.getValue("dialect");
		if (dialect==null || dialect.equals("")) configError("FileSANRepository: parseSituation: Missing Dialect attribute in CEPAT specification");
		String definedBy = cepatScope.getValue("defined-by");
		if (definedBy==null || definedBy.equals("")) configError("FileSANRepository: parseSituation: Missing Defined-By attribute in CEPAT specification");
		FileExpression expr = new FileExpression();
		expr.setDialect(dialect);
		expr.setDefinition(definedBy);
		cepat.setDefinition( expr );
		situation.setCEPAT(cepat);
		
		return situation;
	}
	
	protected ContextCondition parseContextCondition(Scope goalScope, String namespace) {
		// Prepare context condition node
		Scope ccScope = goalScope.getScope("Context-Condition");
		if (ccScope==null) configError("FileSANRepository: parseContextCondition: Missing Context Condition specification in Goal");
		ContextCondition cc = new FileContextCondition();
		parseNodeMetadata(cc, ccScope, namespace);
		
		// Prepare context condition's expression
		String expr = ccScope.getValue("expression");
		if (expr==null || expr.equals("")) configError("FileSANRepository: parseContextCondition: Missing Expression attribute in Context Condition specification");
		Expression expression = new FileExpression();
		expression.setDefinition( expr);
		cc.setExpression( expression );
		
		return cc;
	}
	
	protected SANNode parseJob(Scope jobScope, String namespace) {
		// Check goal's job node 
		if (jobScope==null) configError("FileSANRepository: parseJob: Missing Job specification (i.e. NULL jobScope argument)");
		if (jobScope.size()==0) configError("FileSANRepository: parseJob: No Job specification in Goal");
		if (jobScope.size()>1) configError("FileSANRepository: parseJob: Many Job specifications in Goal: "+jobScope.size());
		String key = jobScope.keys().nextElement().toUpperCase();
		SANNode job;
		if (key.equals("GOAL")) {
			Goal subgoal = new FileGoal();
			Scope jobGoalScope = jobScope.getScope("Goal");
			if (jobGoalScope==null) configError("FileSANRepository: parseJob: Missing Job Sub-Goal specification in Goal");
			if (jobGoalScope.size()==0) configError("FileSANRepository: parseJob: No Job Sub-Goal specification in Goal");
			if (jobGoalScope.size()>1) configError("FileSANRepository: parseJob: Many Job Sub-Goal specifications in Goal: "+jobGoalScope.size());
			key = jobGoalScope.keys().nextElement();
			job = parseGoal(subgoal, key, jobGoalScope, namespace);
		} else
		if (key.equals("ACTION")) {
			job = parseAction(jobScope, namespace);
		} else
		if (key.equals("DECORATOR")) {
			job = parseDecorator(jobScope, namespace);
		} else {
			configError("FileSANRepository: parseJob: Invalid Job specification in Goal: "+key);
			return null;
		}
		
		return job;
	}
	
	protected Action parseAction(Scope goalScope, String namespace) {
		// Prepare action node
		Scope actionScope = goalScope.getScope("Action");
		if (actionScope==null) configError("FileSANRepository: parseAction: Missing Action specification in Goal");
		String actionType = actionScope.getValue("Type");
		if (actionType==null || actionType.equals("")) configError("FileSANRepository: parseAction: Missing Type attribute in Action specification");
		actionType = actionType.toUpperCase();
		
		Action action;
		if (actionType.equals("PRIMITIVE")) {
			action = new FilePrimitiveAction();
			String command = actionScope.getValue("command");
			if (command==null || command.equals("")) configError("FileSANRepository: parseAction: Missing Command attribute in PRIMITIVE Action specification");
			((PrimitiveAction)action).setCommand(command);
		} else
		if (actionType.equals("ABSTRACT")) {
			action = new FileAbstractAction();
		} else
		if (actionType.equals("MOUNT")) {
			action = new FileMountAction();
			String referredSAN = actionScope.getValue("SAN");
			if (referredSAN==null || referredSAN.equals("")) configError("FileSANRepository: parseAction: Missing SAN attribute in MOUNT Action specification");
			((MountAction)action).setReferencedSAN(referredSAN);
		} else
		if (actionType.equals("CALCULATION")) {
			action = new FileCalculationAction();
			String calculation = actionScope.getValue("calculation");
			if (calculation==null || calculation.equals("")) configError("FileSANRepository: parseAction: Missing Calculation attribute in CALCULATION Action specification");
			//((CalculationAction)action).setExpression(calculation);
		} else
		if (actionType.equals("SEQUENCE")) {
			action = new FileSequenceAction();
			parseActionSet((CompositeAction)action, actionScope, namespace);
		} else
		if (actionType.equals("SELECTOR")) {
			action = new FileSelectorAction();
			String selectionMethod = actionScope.getValue("selection-method");
			if (selectionMethod==null || selectionMethod.equals("")) configError("FileSANRepository: parseAction: Missing Selection Method attribute in SELECTOR Action specification");
			selectionMethod = selectionMethod.toUpperCase();
			int selMeth;
			if (selectionMethod.equals("SEQUENTIAL")) {
				selMeth = SelectorAction.ORDER_SEQUENTIAL;
			} else
			if (selectionMethod.equals("RANDOM")) {
				selMeth = SelectorAction.ORDER_RANDOM;
			} else
			if (selectionMethod.equals("PROBABLISTIC")) {
				selMeth = SelectorAction.ORDER_PROBABLISTIC;
			} else {
				configError("FileSANRepository: parseAction: Invalid Selector Action attribute value in SELECTOR Action specification: "+selectionMethod);
				return null;
			}
			((SelectorAction)action).setSelectionMethod(selMeth);
			parseActionSet((CompositeAction)action, actionScope, namespace);
		} else
		if (actionType.equals("PARALLEL_ANY")) {
			action = new FileParallelAnyAction();
			parseActionSet((CompositeAction)action, actionScope, namespace);
		} else
		if (actionType.equals("PARALLEL_ALL")) {
			action = new FileParallelAllAction();
			parseActionSet((CompositeAction)action, actionScope, namespace);
		} else {
			configError("FileSANRepository: parseAction: Invalid Action Type attribute value in Action specification: "+actionType);
			return null;
		}
		
		parseNodeMetadata(action, actionScope, namespace);
		return action;
	}
	
	protected void parseActionSet(CompositeAction action, Scope actionScope, String namespace) {
		Scope jobSetScope = actionScope.getScope("Set");
		Enumeration<String> en = jobSetScope.keys();
		while (en.hasMoreElements()) {
			String key = en.nextElement();
			Scope jobScope = jobSetScope.getScope(key);
			SANNode job = parseJob(jobScope, namespace);
			action.addJob(job);
		}
		SANNode[] jobs = action.getJobs();
		if (jobs!=null && jobs.length>1) {
			action.setFirstJob(jobs[0]);
			SANNode prevJob = jobs[0];
			for (int i=1; i<jobs.length; i++) {
				jobs[i-1].setNextJob(jobs[i]);
			}
		}
	}
	
	protected Decorator parseDecorator(Scope goalScope, String namespace) {
		// Prepare decorator node
		Scope decoratorScope = goalScope.getScope("Decorator");
		if (decoratorScope==null) configError("FileSANRepository: parseDecorator: Missing Decorator specification in Goal");
		String decoratorType = decoratorScope.getValue("Type");
		if (decoratorType==null || decoratorType.equals("")) configError("FileSANRepository: parseDecorator: Missing Type attribute in Decorator specification");
		decoratorType = decoratorType.toUpperCase();
		
		Decorator decorator;
		if (decoratorType.equals("LOOP")) {
			decorator = new FileLoopDecorator();
			String exprStr = decoratorScope.getValue("loop-condition");
			if (exprStr==null || exprStr.equals("")) configError("FileSANRepository: parseDecorator: Missing Loop Condition attribute in LOOP Decorator specification");
			Expression expr = new FileExpression();
			expr.setDefinition(exprStr);
			((LoopDecorator)decorator).setLoopExpression(expr);
		} else
		if (decoratorType.equals("COUNTER")) {
			decorator = new FileCounterDecorator();
			String varName = decoratorScope.getValue("context-var").trim().toUpperCase();
			String startCount = decoratorScope.getValue("start-count");
			String step = decoratorScope.getValue("step");
			if (varName==null || varName.equals("")) configError("FileSANRepository: parseDecorator: Missing Context Variable attribute in COUNTER Decorator specification");
			if (startCount==null || startCount.equals("")) configError("FileSANRepository: parseDecorator: Missing Start Count attribute in COUNTER Decorator specification");
			if (step==null || step.equals("")) configError("FileSANRepository: parseDecorator: Missing Step attribute in COUNTER Decorator specification");
			((CounterDecorator)decorator).setVariable(varName);
			((CounterDecorator)decorator).setStartCount(Integer.parseInt(startCount));
			((CounterDecorator)decorator).setStep(Integer.parseInt(step));
		} else
		if (decoratorType.equals("TIMER")) {
			decorator = new FileTimerDecorator();
			String timeout = decoratorScope.getValue("timeout");
			String returnCode = decoratorScope.getValue("return");
			if (timeout==null || timeout.equals("")) configError("FileSANRepository: parseDecorator: Missing Timeout attribute in TIMER Decorator specification");
			if (returnCode==null || returnCode.equals("")) returnCode = "FAILURE"; // configError("FileSANRepository: parseDecorator: Missing Return attribute in TIMER Decorator specification");
			((TimerDecorator)decorator).setTimeout(Long.parseLong(timeout));
			returnCode = returnCode.toUpperCase();
			if (returnCode.equals("SUCCESS")) {
				((TimerDecorator)decorator).setReturnCode(SANNode.SUCCESS);
			} else
			if (returnCode.equals("FAILURE")) {
				((TimerDecorator)decorator).setReturnCode(SANNode.FAILURE);
			} else {
				configError("FileSANRepository: parseDecorator: Invalid Return attribute value '"+returnCode+"' in TIMER Decorator specification");
			}
		} else
		if (decoratorType.equals("DEBUG_BREAK")) {
			decorator = new FileBreakDecorator();
			String mesg = decoratorScope.getValue("message");
			if (mesg==null || mesg.equals("")) configError("FileSANRepository: parseDecorator: Missing Message attribute in DEBUG_PRINT Decorator specification");
			((BreakDecorator)decorator).setMessage(mesg);
		} else
		if (decoratorType.equals("DEBUG_PRINT")) {
			decorator = new FilePrintDecorator();
			String mesg = decoratorScope.getValue("message");
			if (mesg==null || mesg.equals("")) configError("FileSANRepository: parseDecorator: Missing Message attribute in DEBUG_PRINT Decorator specification");
			((PrintDecorator)decorator).setMessage(mesg);
		} else
		if (decoratorType.equals("SUCCESS")) {
			decorator = new FileSuccessDecorator();
		} else
		if (decoratorType.equals("FAILURE")) {
			decorator = new FileFailureDecorator();
		} else
		if (decoratorType.equals("EXCEPTION_HANDLER")) {
			decorator = new FileExceptionHandlerDecorator();
			String type = decoratorScope.getValue("exception");
			if (type==null || type.equals("")) configError("FileSANRepository: parseDecorator: Missing Exception attribute in EXCEPTION HANDLER Decorator specification");
			try {
				Class clss = Class.forName(type);
				Class exClss = Exception.class;
				Class parent;
				while ((parent=clss.getSuperclass())!=null) {
					clss = parent;
					if (clss.equals(exClss)) break;
				}
				if (clss==null) {
					configError("FileSANRepository: parseDecorator: Exception class '"+type+"' in Exception Type attribute of Decorator specification is NOT a subclass of Exception");
				}
			} catch (ClassNotFoundException ex) {
				configError("FileSANRepository: parseDecorator: Exception class '"+type+"' in Exception Type attribute of Decorator specification was NOT FOUND");
			}
			((ExceptionHandlerDecorator)decorator).setExceptionType(type);
			
			SANNode failoverJob = parseJob(decoratorScope.getScope("Failover-Job"), namespace);
			((ExceptionHandlerDecorator)decorator).setFailoverJob( failoverJob );
		} else
		if (decoratorType.equals("CONDITION")) {
			decorator = new FileConditionDecorator();
			String dialect = decoratorScope.getValue("condition.dialect");
			String definition = decoratorScope.getValue("condition.defined-by");
			if (definition==null || definition.equals("")) configError("FileSANRepository: parseDecorator: Missing Condition Definined-By attribute in CONDITION Decorator specification");
			Expression expr = new FileExpression();
			expr.setDialect(dialect);
			expr.setDefinition(definition);
			((ConditionDecorator)decorator).setCondition(expr);
		} else {
			configError("FileSANRepository: parseDecorator: Invalid Decorator Type attribute value in Decorator specification: "+decoratorType);
			return null;
		}
		
		parseNodeMetadata(decorator, decoratorScope, namespace);
		SANNode job = parseJob(decoratorScope.getScope("Job"), namespace);
		decorator.setJob( job );
		
		return decorator;
	}
}
