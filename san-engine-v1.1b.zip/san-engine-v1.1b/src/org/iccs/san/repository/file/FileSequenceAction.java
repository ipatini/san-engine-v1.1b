package org.iccs.san.repository.file;


public class FileSequenceAction extends org.iccs.san.repository.basic.BasicSequenceAction {
}
