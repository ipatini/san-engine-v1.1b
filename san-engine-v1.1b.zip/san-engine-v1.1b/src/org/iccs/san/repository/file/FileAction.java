package org.iccs.san.repository.file;


public class FileAction extends org.iccs.san.repository.basic.BasicAction {
}
