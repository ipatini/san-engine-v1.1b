package org.iccs.san.repository.file;


public class FileSuccessDecorator extends org.iccs.san.repository.basic.BasicSuccessDecorator {
}
