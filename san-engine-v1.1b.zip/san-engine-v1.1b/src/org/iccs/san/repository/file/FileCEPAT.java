package org.iccs.san.repository.file;


public class FileCEPAT extends org.iccs.san.repository.basic.BasicCEPAT {
}
