package org.iccs.san.repository.file;


public class FileBreakDecorator extends org.iccs.san.repository.basic.BasicBreakDecorator {
}
