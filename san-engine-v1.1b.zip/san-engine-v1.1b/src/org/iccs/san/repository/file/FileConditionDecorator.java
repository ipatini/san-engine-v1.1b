package org.iccs.san.repository.file;


public class FileConditionDecorator extends org.iccs.san.repository.basic.BasicConditionDecorator {
}
