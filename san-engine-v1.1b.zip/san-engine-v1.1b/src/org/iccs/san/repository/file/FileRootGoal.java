package org.iccs.san.repository.file;


public class FileRootGoal extends org.iccs.san.repository.basic.BasicRootGoal {
}
