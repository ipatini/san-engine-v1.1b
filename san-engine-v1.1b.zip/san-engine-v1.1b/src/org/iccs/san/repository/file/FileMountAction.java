package org.iccs.san.repository.file;


public class FileMountAction extends org.iccs.san.repository.basic.BasicMountAction {
}
