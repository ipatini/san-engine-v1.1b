package org.iccs.san.repository.file;


public class FileSANObject extends org.iccs.san.repository.basic.BasicSANObject {
}
