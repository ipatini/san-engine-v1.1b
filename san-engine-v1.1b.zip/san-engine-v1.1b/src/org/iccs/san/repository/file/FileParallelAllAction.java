package org.iccs.san.repository.file;


public class FileParallelAllAction extends org.iccs.san.repository.basic.BasicParallelAllAction {
}
