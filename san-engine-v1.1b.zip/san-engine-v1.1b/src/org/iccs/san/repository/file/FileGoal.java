package org.iccs.san.repository.file;


public class FileGoal extends org.iccs.san.repository.basic.BasicGoal {
}
