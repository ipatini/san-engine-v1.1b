package org.iccs.san.repository.file;


public class FileParallelAnyAction extends org.iccs.san.repository.basic.BasicParallelAnyAction {
}
