package org.iccs.san.repository.file;


public class FileCompositeAction extends org.iccs.san.repository.basic.BasicCompositeAction {
}
