package org.iccs.san.repository.file;


public class FileExceptionHandlerDecorator extends org.iccs.san.repository.basic.BasicExceptionHandlerDecorator {
}
