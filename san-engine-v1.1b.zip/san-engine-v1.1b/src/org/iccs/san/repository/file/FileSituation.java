package org.iccs.san.repository.file;


public class FileSituation extends org.iccs.san.repository.basic.BasicSituation {
}
