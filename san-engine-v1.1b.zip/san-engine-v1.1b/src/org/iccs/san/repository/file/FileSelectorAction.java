package org.iccs.san.repository.file;


public class FileSelectorAction extends org.iccs.san.repository.basic.BasicSelectorAction {
}
