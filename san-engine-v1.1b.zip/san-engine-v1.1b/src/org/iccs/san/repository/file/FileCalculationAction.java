package org.iccs.san.repository.file;


public class FileCalculationAction extends org.iccs.san.repository.basic.BasicCalculationAction {
}
