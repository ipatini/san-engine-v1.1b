package org.iccs.san.repository.file;


public class FileTimerDecorator extends org.iccs.san.repository.basic.BasicTimerDecorator {
}
