package org.iccs.san.repository.file;


public class FileSANNode extends org.iccs.san.repository.basic.BasicSANNode {
}
