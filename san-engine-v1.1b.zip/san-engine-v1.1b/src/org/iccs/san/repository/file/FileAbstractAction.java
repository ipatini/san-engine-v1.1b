package org.iccs.san.repository.file;


public class FileAbstractAction extends org.iccs.san.repository.basic.BasicAbstractAction {
}
