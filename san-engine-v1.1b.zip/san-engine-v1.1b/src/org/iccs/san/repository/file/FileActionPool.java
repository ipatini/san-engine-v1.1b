package org.iccs.san.repository.file;


public class FileActionPool extends org.iccs.san.repository.basic.BasicActionPool {
}
