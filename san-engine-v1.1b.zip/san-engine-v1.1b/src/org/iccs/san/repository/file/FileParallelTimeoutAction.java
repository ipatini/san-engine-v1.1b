package org.iccs.san.repository.file;


public class FileParallelTimeoutAction extends org.iccs.san.repository.basic.BasicParallelTimeoutAction {
}
