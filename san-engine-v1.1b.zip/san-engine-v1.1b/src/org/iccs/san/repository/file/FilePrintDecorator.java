package org.iccs.san.repository.file;


public class FilePrintDecorator extends org.iccs.san.repository.basic.BasicPrintDecorator {
}
